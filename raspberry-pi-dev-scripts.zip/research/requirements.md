# Development Workflow Requirements for Raspberry Pi 5

## Technology Stack Versions (Current as of January 2025)

### Core Runtime and Framework Versions

#### Node.js
- **Current Stable Version**: Node.js 20.9.0 LTS (Codename: 'Iron')
- **LTS Status**: Active LTS (entered October 2023)
- **ARM64 Compatibility**: Full support for ARM64 architecture
- **Raspberry Pi 5 Support**: Confirmed compatible with official ARM builds
- **Installation Method**: Use Node Version Manager (nvm) for flexible version management
- **Future Considerations**: Node.js 22 expected in January 2025

#### React
- **Current Stable Version**: React 19.1.0
- **Release Status**: Recently released in early 2025
- **Key Features**: 
  - Enhanced debugging tools (Owner Stack)
  - Improved Suspense support
  - Optimized asynchronous rendering
- **Compatibility Considerations**: 
  - Some libraries not yet fully compatible
  - Joy UI has known compatibility issues
  - Thorough testing recommended before production use

#### TypeScript
- **Current Stable Version**: TypeScript 5.8.3
- **Release Date**: February 28, 2025
- **Key Features**:
  - ECMAScript 2024 support (--target es2024)
  - Enhanced error reporting for uninitialized variables
  - Stable --module node18 flag
- **Future Versions**: 
  - TypeScript 5.9 preview expected in 2025
  - TypeScript 6.0 anticipated with breaking changes

#### NestJS
- **Current Stable Version**: NestJS 11.1.3
- **Release Date**: June 2025
- **Migration Notes**: 
  - Express v5 is now default in NestJS 11
  - Significant changes from version 10.x
  - Migration guide available for version upgrades
- **ARM64 Compatibility**: Requires verification for latest version

#### Vite
- **Current Stable Version**: Vite 7.0.4
- **Release Date**: July 10, 2025
- **Key Features**:
  - AI-powered optimization engine (introduced in 5.3)
  - Experimental Environment API (Vite 6)
  - Enhanced development workflow simplification
- **Configuration**: Supports both JavaScript and TypeScript config files

#### PostgreSQL
- **Current Stable Version**: PostgreSQL 17.5
- **Release Date**: May 8, 2025
- **ARM64 Support**: Confirmed Linux ARM64 compatibility
- **Performance**: ~200 TPS on Raspberry Pi (17+ million transactions/day)
- **Use Cases**: Suitable for development and light production workloads

## Raspberry Pi 5 Hardware Specifications

### CPU Specifications
- **Processor**: 64-bit quad-core Arm Cortex-A76
- **Clock Speed**: 2.4 GHz
- **Cache**: 
  - 512KB L2 cache
  - 2MB shared L3 cache
- **Performance**: Up to 3x faster than Raspberry Pi 4
- **Chipset**: Broadcom BCM2712

### Memory Configuration
- **Available RAM**: 1GB, 2GB, 4GB, or 8GB LPDDR4
- **Recommended for Development**: 8GB model for optimal performance
- **Memory Optimization**: 16KB page size provides up to 7% performance increase

### Storage and PCIe
- **PCIe Interface**: PCIe 2.0 x1
- **NVMe Support**: Full NVMe SSD support via PCIe
- **Performance**: Up to 1,000 MB/s with PCIe Gen 3 speeds
- **Storage Optimization**: Significant responsiveness improvement over SD cards

### Graphics
- **GPU**: VideoCore VII running at 800 MHz
- **Performance**: Enhanced graphics capabilities for development tools

## Operating System Requirements

### Raspberry Pi OS
- **Current Version**: Bookworm (Debian 12)
- **Architecture**: 64-bit ARM64 support
- **Kernel Version**: 6.12
- **Next Release**: May 13, 2025
- **Recommended**: Use 64-bit version for optimal performance

## Performance Optimization Strategies

### Memory and CPU Optimization
1. **Page Size Configuration**
   - Use 16KB pages (default on Pi 5 kernel)
   - Provides up to 7% performance increase in random memory access

2. **SDRAM Tuning**
   - Apply Raspberry Pi engineers' SDRAM timing optimizations
   - Results in 10-20% speed boost at default 2.4 GHz clock

3. **NUMA Emulation**
   - Enable NUMA emulation patch for up to 18% performance boost
   - Particularly beneficial for multi-threaded workloads

### NVMe Storage Configuration
1. **Setup Requirements**
   - Ensure proper PCIe PIP (Peripheral Interconnect Port) connection
   - Verify connection using `lspci` command
   - Enable PCIe Generation 3 speeds

2. **Performance Benefits**
   - Significant system responsiveness improvement
   - Optimal for development environments requiring fast I/O
   - Suitable for database storage and build processes

### Network Configuration
- **Raspberry Pi Connect**: Enables remote access without manual network setup
- **ARM64 Native Support**: Full network stack optimization for ARM64

## Development Environment Setup

### VS Code Remote Development
1. **Installation Approach**
   - Use VS Code Remote - SSH extension
   - Install on local machine, connect to Pi 5 remotely
   - Requires SSH server configuration on Pi 5

2. **ARM64 Considerations**
   - VS Code not officially supported on Pi (community support available)
   - Requires careful ARM64-specific configuration
   - Performance may vary based on workload

3. **Setup Process**
   - Configure SSH server with key-based authentication
   - Install Remote Development Extension Pack
   - Use SSH config file for connection management

### Node.js Version Management
1. **Recommended Tool**: NVM (Node Version Manager)
   - POSIX-compliant shell support (sh, dash, ksh, zsh, bash)
   - Per-user, per-shell version management
   - Easy switching between Node.js versions

2. **Installation Commands**
   ```bash
   curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/master/install.sh | bash
   command -v nvm  # Verify installation
   nvm install 20  # Install Node.js 20 LTS
   ```

3. **ARM64 Compatibility**
   - Verify ARM64 support before installation
   - Use NodeSource for ARM64 builds if needed
   - Test thoroughly on Pi 5 environment

### PostgreSQL Development Configuration
1. **Performance Optimization**
   - Adjust system-wide settings for database requirements
   - Focus on ARM64 architecture-specific tuning
   - Use pgbench for performance assessment

2. **Configuration Areas**
   - Memory allocation optimization
   - NVMe storage configuration
   - Network performance tuning
   - ARM64-specific database settings

## Security Best Practices

### SSH Server Hardening
1. **Authentication Security**
   - Change default passwords immediately
   - Create custom user accounts (avoid default 'pi' user)
   - Disable root SSH login
   - Use SSH key-based authentication exclusively
   - Change SSH port to non-standard port (30000-65335 range)

2. **Network Security**
   - Implement strict iptables firewall rules
   - Limit network port exposure
   - Configure fail2ban for brute-force protection
   - Use VPN or jump host for additional security

3. **System Security**
   - Regular OS and SSH server updates
   - Disable unused services
   - Implement comprehensive logging
   - Set up authentication attempt alerts
   - Use strong SSH key passphrases

### Development-Specific Security
- Create dedicated development user with limited permissions
- Regular SSH key rotation
- Use SSH config file for connection parameter management
- Implement multi-factor authentication where possible

## Bash Scripting Standards

### POSIX Compliance Requirements
1. **Error Handling Patterns**
   - Use `set -e` to exit on command errors
   - Implement `set -u` for undefined variable detection
   - Use `set -x` for debugging script execution
   - Implement graceful error management

2. **Logging Mechanisms**
   - Use stderr for error message logging
   - Implement structured logging with consistent formats
   - Create dedicated logging functions for severity levels
   - Redirect outputs to persistent log files

3. **Security Considerations**
   - Always quote variables to prevent vulnerabilities
   - Implement input validation and sanitization
   - Use strict error handling for unexpected behavior
   - Follow portable scripting techniques

### Recommended Script Structure
```bash
#!/bin/sh
# Strict mode and error handling
set -eu

# Logging function
log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2
}

log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*"
}

# Error handling example
command_that_might_fail || {
    log_error "Command failed with exit code $?"
    exit 1
}
```

## ARM64 Compatibility Notes

### General Considerations
- All listed technologies have confirmed or expected ARM64 support
- Thorough testing required for each component on Pi 5
- Some packages may require specific ARM64 builds
- Performance characteristics may differ from x86_64 systems

### Specific Technology Notes
1. **Node.js**: Official ARM64 builds available
2. **React**: No ARM64-specific issues expected
3. **TypeScript**: Transpilation tool, architecture-independent
4. **NestJS**: Requires verification for version 11.x on ARM64
5. **Vite**: Build tool, should work on ARM64
6. **PostgreSQL**: Confirmed ARM64 support with performance optimizations

## Implementation Guidelines

### Script Development Priorities
1. **System Setup Scripts**: Focus on Pi 5 optimization and security
2. **Environment Scripts**: Emphasize ARM64 compatibility verification
3. **Database Scripts**: Include performance tuning for NVMe storage
4. **Project Scripts**: Implement version management and dependency checking
5. **Workflow Scripts**: Automate common development tasks
6. **Deployment Scripts**: Prepare for production-ready configurations
7. **Monitoring Scripts**: Track system performance and resource usage
8. **Debugging Scripts**: Provide troubleshooting and diagnostic capabilities

### Configuration Management
- Use template-based configuration files
- Implement environment-specific variable management
- Provide secure credential management mechanisms
- Enable easy customization for different development scenarios

### Documentation Requirements
- Comprehensive inline comments in all scripts
- Usage examples for each script
- Troubleshooting guides for common issues
- Performance optimization recommendations
- Security configuration explanations

## Validation and Testing Requirements

### Pre-deployment Testing
- Verify all scripts on clean Raspberry Pi 5 installation
- Test with different RAM configurations (4GB vs 8GB)
- Validate NVMe storage optimization scripts
- Confirm ARM64 compatibility for all components
- Test remote development workflow end-to-end

### Performance Benchmarking
- Database performance testing with pgbench
- Node.js application startup and runtime performance
- Build process optimization with Vite
- Network and SSH connection performance
- Storage I/O performance with NVMe configuration

This requirements document provides the foundation for developing comprehensive bash scripts optimized for Raspberry Pi 5 development workflows, ensuring current technology versions, proper ARM64 support, and security best practices.