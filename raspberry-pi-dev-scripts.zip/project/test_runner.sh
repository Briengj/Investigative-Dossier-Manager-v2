#!/bin/bash
#
# Test Suite Execution Script for React/NestJS Projects on Raspberry Pi 5
# Handles running tests for React 19.1.0 with Vite 7.0.4 and NestJS 11.1.3 projects
# Optimized for ARM64 architecture and comprehensive test coverage
#
# Usage: ./test_runner.sh [--dry-run] [--project-type TYPE] [--test-type TYPE]
# 
# Prerequisites:
# - Node.js 20 LTS installed via NVM
# - npm 10+ with proper configuration
# - TypeScript 5.8.3 globally or locally available
# - Project with package.json and test configuration
# - Test frameworks installed (Jest, Vitest, etc.)
#
# Features:
# - Unit test execution with coverage reporting
# - Integration and E2E test support
# - Test result analysis and reporting
# - ARM64 performance optimizations
# - Parallel test execution
# - Test artifact management
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/test_runner.log"
DRY_RUN=false
PROJECT_TYPE="auto"
TEST_TYPE="all"
PROJECT_PATH="$(pwd)"
COVERAGE_ENABLED=true
PARALLEL_TESTS=true
WATCH_MODE=false
GENERATE_REPORT=true
COVERAGE_THRESHOLD=80

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --project-type)
            PROJECT_TYPE="$2"
            shift 2
            ;;
        --test-type)
            TEST_TYPE="$2"
            shift 2
            ;;
        --project-path)
            PROJECT_PATH="$2"
            shift 2
            ;;
        --no-coverage)
            COVERAGE_ENABLED=false
            shift
            ;;
        --no-parallel)
            PARALLEL_TESTS=false
            shift
            ;;
        --watch)
            WATCH_MODE=true
            shift
            ;;
        --no-report)
            GENERATE_REPORT=false
            shift
            ;;
        --coverage-threshold)
            COVERAGE_THRESHOLD="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--project-type TYPE] [--test-type TYPE]"
            echo "Executes test suites for React and NestJS projects"
            echo ""
            echo "Options:"
            echo "  --dry-run                Show what would be done without making changes"
            echo "  --project-type TYPE      Project type: react, nestjs, auto (default: auto)"
            echo "  --test-type TYPE         Test type: unit, integration, e2e, all (default: all)"
            echo "  --project-path PATH      Project directory path (default: current directory)"
            echo "  --no-coverage            Skip code coverage collection"
            echo "  --no-parallel            Disable parallel test execution"
            echo "  --watch                  Run tests in watch mode"
            echo "  --no-report              Skip test report generation"
            echo "  --coverage-threshold N   Coverage threshold percentage (default: 80)"
            echo "  -h, --help               Show this help message"
            echo ""
            echo "Project Types:"
            echo "  react                    React 19.1.0 + Vite 7.0.4 project (Vitest)"
            echo "  nestjs                   NestJS 11.1.3 + TypeScript 5.8.3 project (Jest)"
            echo "  auto                     Auto-detect project type (default)"
            echo ""
            echo "Test Types:"
            echo "  unit                     Unit tests only"
            echo "  integration              Integration tests only"
            echo "  e2e                      End-to-end tests only"
            echo "  all                      All test types (default)"
            echo ""
            echo "Examples:"
            echo "  $0                                    # Auto-detect and run all tests"
            echo "  $0 --project-type react --test-type unit"
            echo "  $0 --project-type nestjs --watch --no-coverage"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Node.js
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        exit 1
    fi
    
    local node_version
    node_version=$(node --version | sed 's/v//')
    local node_major_version
    node_major_version=$(echo "$node_version" | cut -d. -f1)
    
    if [[ "$node_major_version" -lt 18 ]]; then
        log_error "Node.js version 18+ required, found: v$node_version"
        exit 1
    fi
    
    log_info "Node.js version: v$node_version ✓"
    
    # Check npm
    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not available"
        exit 1
    fi
    
    local npm_version
    npm_version=$(npm --version)
    log_info "npm version: v$npm_version ✓"
    
    # Check project directory
    if [[ ! -d "$PROJECT_PATH" ]]; then
        log_error "Project directory does not exist: $PROJECT_PATH"
        exit 1
    fi
    
    # Check package.json
    if [[ ! -f "$PROJECT_PATH/package.json" ]]; then
        log_error "package.json not found in: $PROJECT_PATH"
        exit 1
    fi
    
    # Change to project directory
    cd "$PROJECT_PATH"
    log_info "Working in project directory: $(pwd)"
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" == "aarch64" ]]; then
        log_info "ARM64 architecture detected - applying optimizations"
    else
        log_warning "Not running on ARM64 architecture: $(uname -m)"
    fi
    
    log_info "Prerequisites check completed"
}

# Auto-detect project type
detect_project_type() {
    if [[ "$PROJECT_TYPE" != "auto" ]]; then
        log_info "Project type specified: $PROJECT_TYPE"
        return 0
    fi
    
    log_info "Auto-detecting project type..."
    
    # Check for React project indicators
    if grep -q '"react"' package.json 2>/dev/null; then
        if grep -q '"vite"' package.json 2>/dev/null || grep -q '"vitest"' package.json 2>/dev/null; then
            PROJECT_TYPE="react"
            log_info "Detected React project with Vite/Vitest"
            return 0
        fi
    fi
    
    # Check for NestJS project indicators
    if grep -q '"@nestjs/core"' package.json 2>/dev/null; then
        PROJECT_TYPE="nestjs"
        log_info "Detected NestJS project"
        return 0
    fi
    
    # Check for test frameworks
    if grep -q '"vitest"' package.json 2>/dev/null; then
        PROJECT_TYPE="react"
        log_info "Detected React/Vite project from Vitest"
        return 0
    fi
    
    if grep -q '"jest"' package.json 2>/dev/null && grep -q '"@nestjs/testing"' package.json 2>/dev/null; then
        PROJECT_TYPE="nestjs"
        log_info "Detected NestJS project from Jest + NestJS testing"
        return 0
    fi
    
    log_error "Could not auto-detect project type"
    log_error "Please specify --project-type react or --project-type nestjs"
    exit 1
}

# Check test framework availability
check_test_framework() {
    log_info "Checking test framework availability..."
    
    case "$PROJECT_TYPE" in
        "react")
            if ! grep -q '"vitest"' package.json 2>/dev/null; then
                log_warning "Vitest not found in package.json - checking for other test frameworks"
                if grep -q '"jest"' package.json 2>/dev/null; then
                    log_info "Found Jest configuration"
                else
                    log_error "No test framework found for React project"
                    log_error "Please install Vitest: npm install --save-dev vitest"
                    exit 1
                fi
            else
                log_info "Vitest found ✓"
            fi
            ;;
        "nestjs")
            if ! grep -q '"jest"' package.json 2>/dev/null; then
                log_error "Jest not found in package.json"
                log_error "Please install Jest: npm install --save-dev jest @types/jest"
                exit 1
            else
                log_info "Jest found ✓"
            fi
            
            if ! grep -q '"@nestjs/testing"' package.json 2>/dev/null; then
                log_warning "@nestjs/testing not found - some tests may not work properly"
            else
                log_info "@nestjs/testing found ✓"
            fi
            ;;
    esac
}

# Ensure dependencies are installed
ensure_dependencies() {
    log_info "Ensuring test dependencies are installed..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would check and install test dependencies"
        return 0
    fi
    
    if [[ ! -d "node_modules" ]]; then
        log_info "Installing dependencies..."
        if npm ci; then
            log_success "Dependencies installed"
        else
            log_error "Failed to install dependencies"
            exit 1
        fi
    else
        log_info "Dependencies already installed"
    fi
}

# Run React tests with Vitest
run_react_tests() {
    log_info "Running React tests..."
    log_info "Test type: $TEST_TYPE"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would run React tests"
        return 0
    fi
    
    # Set environment variables for ARM64 optimization
    export NODE_OPTIONS="--max-old-space-size=2048"
    
    # Build test command
    local test_command="npm run test"
    local test_args=""
    
    # Add coverage if enabled
    if [[ "$COVERAGE_ENABLED" == "true" ]]; then
        test_args="$test_args --coverage"
    fi
    
    # Add watch mode if enabled
    if [[ "$WATCH_MODE" == "true" ]]; then
        test_args="$test_args --watch"
    else
        test_args="$test_args --run"
    fi
    
    # Configure parallel execution
    if [[ "$PARALLEL_TESTS" == "true" ]]; then
        # Vitest runs in parallel by default, but limit for ARM64
        test_args="$test_args --threads --maxThreads=2"
    else
        test_args="$test_args --no-threads"
    fi
    
    # Add test type filtering
    case "$TEST_TYPE" in
        "unit")
            test_args="$test_args --testNamePattern='unit|Unit'"
            ;;
        "integration")
            test_args="$test_args --testNamePattern='integration|Integration'"
            ;;
        "e2e")
            test_args="$test_args --testNamePattern='e2e|E2E|end-to-end'"
            ;;
        "all")
            # Run all tests
            ;;
    esac
    
    # Execute tests
    local full_command="$test_command $test_args"
    log_info "Executing: $full_command"
    
    local test_start
    test_start=$(date +%s)
    
    if eval "$full_command"; then
        local test_end
        test_end=$(date +%s)
        local test_duration=$((test_end - test_start))
        log_success "React tests completed in ${test_duration}s"
    else
        log_error "React tests failed"
        return 1
    fi
}

# Run NestJS tests with Jest
run_nestjs_tests() {
    log_info "Running NestJS tests..."
    log_info "Test type: $TEST_TYPE"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would run NestJS tests"
        return 0
    fi
    
    # Set environment variables for ARM64 optimization
    export NODE_OPTIONS="--max-old-space-size=2048"
    
    # Determine test command based on test type
    local test_command
    case "$TEST_TYPE" in
        "unit")
            test_command="npm run test"
            ;;
        "integration")
            test_command="npm run test:integration"
            ;;
        "e2e")
            test_command="npm run test:e2e"
            ;;
        "all")
            # Run all test types sequentially
            run_nestjs_unit_tests
            run_nestjs_integration_tests
            run_nestjs_e2e_tests
            return $?
            ;;
        *)
            log_error "Unknown test type: $TEST_TYPE"
            return 1
            ;;
    esac
    
    local test_args=""
    
    # Add coverage if enabled
    if [[ "$COVERAGE_ENABLED" == "true" ]]; then
        test_args="$test_args --coverage"
    fi
    
    # Add watch mode if enabled
    if [[ "$WATCH_MODE" == "true" ]]; then
        test_args="$test_args --watch"
    fi
    
    # Configure parallel execution for ARM64
    if [[ "$PARALLEL_TESTS" == "true" ]]; then
        test_args="$test_args --maxWorkers=2"
    else
        test_args="$test_args --runInBand"
    fi
    
    # Execute tests
    local full_command="$test_command $test_args"
    log_info "Executing: $full_command"
    
    local test_start
    test_start=$(date +%s)
    
    if eval "$full_command"; then
        local test_end
        test_end=$(date +%s)
        local test_duration=$((test_end - test_start))
        log_success "NestJS tests completed in ${test_duration}s"
    else
        log_error "NestJS tests failed"
        return 1
    fi
}

# Run NestJS unit tests
run_nestjs_unit_tests() {
    log_info "Running NestJS unit tests..."
    
    local test_command="npm run test"
    local test_args=""
    
    if [[ "$COVERAGE_ENABLED" == "true" ]]; then
        test_args="$test_args --coverage"
    fi
    
    if [[ "$PARALLEL_TESTS" == "true" ]]; then
        test_args="$test_args --maxWorkers=2"
    else
        test_args="$test_args --runInBand"
    fi
    
    local full_command="$test_command $test_args"
    log_info "Executing unit tests: $full_command"
    
    if eval "$full_command"; then
        log_success "Unit tests passed"
    else
        log_error "Unit tests failed"
        return 1
    fi
}

# Run NestJS integration tests
run_nestjs_integration_tests() {
    log_info "Running NestJS integration tests..."
    
    # Check if integration test script exists
    if ! npm run | grep -q "test:integration"; then
        log_warning "Integration test script not found, skipping"
        return 0
    fi
    
    local test_command="npm run test:integration"
    local test_args=""
    
    if [[ "$PARALLEL_TESTS" == "true" ]]; then
        test_args="$test_args --maxWorkers=2"
    else
        test_args="$test_args --runInBand"
    fi
    
    local full_command="$test_command $test_args"
    log_info "Executing integration tests: $full_command"
    
    if eval "$full_command"; then
        log_success "Integration tests passed"
    else
        log_error "Integration tests failed"
        return 1
    fi
}

# Run NestJS E2E tests
run_nestjs_e2e_tests() {
    log_info "Running NestJS E2E tests..."
    
    # Check if E2E test script exists
    if ! npm run | grep -q "test:e2e"; then
        log_warning "E2E test script not found, skipping"
        return 0
    fi
    
    local test_command="npm run test:e2e"
    local test_args="--runInBand"  # E2E tests should run sequentially
    
    local full_command="$test_command $test_args"
    log_info "Executing E2E tests: $full_command"
    
    if eval "$full_command"; then
        log_success "E2E tests passed"
    else
        log_error "E2E tests failed"
        return 1
    fi
}

# Analyze test results
analyze_test_results() {
    log_info "Analyzing test results..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would analyze test results"
        return 0
    fi
    
    # Check for coverage reports
    if [[ "$COVERAGE_ENABLED" == "true" ]]; then
        analyze_coverage_report
    fi
    
    # Check for test result files
    if [[ -f "test-results.xml" ]] || [[ -f "junit.xml" ]]; then
        log_info "Test result files found"
    fi
    
    # Look for common test output directories
    local coverage_dirs=("coverage" "coverage-report" ".nyc_output")
    for dir in "${coverage_dirs[@]}"; do
        if [[ -d "$dir" ]]; then
            log_info "Coverage directory found: $dir"
        fi
    done
}

# Analyze coverage report
analyze_coverage_report() {
    log_info "Analyzing code coverage..."
    
    local coverage_file=""
    
    # Look for coverage files
    if [[ -f "coverage/lcov-report/index.html" ]]; then
        coverage_file="coverage/lcov-report/index.html"
    elif [[ -f "coverage/index.html" ]]; then
        coverage_file="coverage/index.html"
    fi
    
    if [[ -n "$coverage_file" ]]; then
        log_info "Coverage report found: $coverage_file"
        
        # Extract coverage percentage if possible
        if command -v grep >/dev/null 2>&1; then
            local coverage_percent
            coverage_percent=$(grep -o '[0-9]\+\.[0-9]\+%' "$coverage_file" | head -1 | sed 's/%//' || echo "")
            
            if [[ -n "$coverage_percent" ]]; then
                log_info "Code coverage: ${coverage_percent}%"
                
                # Check against threshold
                if (( $(echo "$coverage_percent >= $COVERAGE_THRESHOLD" | bc -l) )); then
                    log_success "Coverage meets threshold (${COVERAGE_THRESHOLD}%)"
                else
                    log_warning "Coverage below threshold: ${coverage_percent}% < ${COVERAGE_THRESHOLD}%"
                fi
            fi
        fi
    else
        log_warning "No coverage report found"
    fi
}

# Generate test report
generate_test_report() {
    if [[ "$GENERATE_REPORT" != "true" ]]; then
        log_info "Skipping test report generation (--no-report specified)"
        return 0
    fi
    
    log_info "Generating test report..."
    
    local report_file="test-report-$(date +%Y%m%d_%H%M%S).txt"
    
    {
        echo "=== Test Execution Report ==="
        echo "Date: $(date)"
        echo "Project Type: $PROJECT_TYPE"
        echo "Test Type: $TEST_TYPE"
        echo "Project Path: $PROJECT_PATH"
        echo "Node.js Version: $(node --version)"
        echo "npm Version: v$(npm --version)"
        echo "Architecture: $(uname -m)"
        echo ""
        
        if [[ -f "package.json" ]]; then
            echo "=== Project Information ==="
            echo "Name: $(node -p "require('./package.json').name" 2>/dev/null || echo "Unknown")"
            echo "Version: $(node -p "require('./package.json').version" 2>/dev/null || echo "Unknown")"
            echo ""
        fi
        
        echo "=== Test Configuration ==="
        echo "Coverage Enabled: $COVERAGE_ENABLED"
        echo "Parallel Tests: $PARALLEL_TESTS"
        echo "Watch Mode: $WATCH_MODE"
        echo "Coverage Threshold: ${COVERAGE_THRESHOLD}%"
        echo ""
        
        echo "=== Test Results ==="
        if [[ -d "coverage" ]]; then
            echo "Coverage directory: coverage/"
            echo "Coverage files:"
            find coverage -name "*.html" -o -name "*.json" -o -name "*.lcov" | head -10
        fi
        
        echo ""
        echo "=== Test Framework Information ==="
        case "$PROJECT_TYPE" in
            "react")
                if grep -q '"vitest"' package.json 2>/dev/null; then
                    echo "Test Framework: Vitest"
                    echo "Version: $(npm list vitest --depth=0 2>/dev/null | grep vitest | awk '{print $2}' || echo "Unknown")"
                fi
                ;;
            "nestjs")
                if grep -q '"jest"' package.json 2>/dev/null; then
                    echo "Test Framework: Jest"
                    echo "Version: $(npm list jest --depth=0 2>/dev/null | grep jest | awk '{print $2}' || echo "Unknown")"
                fi
                ;;
        esac
        
    } > "$report_file"
    
    log_success "Test report generated: $report_file"
}

# Main test execution
execute_tests() {
    local test_result=0
    
    case "$PROJECT_TYPE" in
        "react")
            run_react_tests || test_result=$?
            ;;
        "nestjs")
            run_nestjs_tests || test_result=$?
            ;;
        *)
            log_error "Unknown project type: $PROJECT_TYPE"
            exit 1
            ;;
    esac
    
    return $test_result
}

# Display summary
display_summary() {
    log_info "=== Test Execution Summary ==="
    log_info "Project Type: $PROJECT_TYPE"
    log_info "Test Type: $TEST_TYPE"
    log_info "Project Path: $PROJECT_PATH"
    log_info "Coverage Enabled: $COVERAGE_ENABLED"
    log_info "Parallel Tests: $PARALLEL_TESTS"
    log_info "Watch Mode: $WATCH_MODE"
    log_info ""
    
    if [[ -d "coverage" ]]; then
        log_info "Coverage Report: coverage/"
        if [[ -f "coverage/lcov-report/index.html" ]]; then
            log_info "HTML Report: coverage/lcov-report/index.html"
        fi
    fi
    
    log_info ""
    log_info "=== Next Steps ==="
    log_info "1. Review test results and coverage report"
    log_info "2. Fix any failing tests"
    log_info "3. Improve test coverage if below threshold"
    log_info "4. Consider adding more test types (unit/integration/e2e)"
    
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting test execution..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Test type: $TEST_TYPE"
    
    check_prerequisites
    detect_project_type
    check_test_framework
    ensure_dependencies
    
    local test_result=0
    execute_tests || test_result=$?
    
    analyze_test_results
    generate_test_report
    
    if [[ $test_result -eq 0 ]]; then
        log_success "All tests passed successfully!"
    else
        log_error "Some tests failed"
    fi
    
    display_summary
    
    exit $test_result
}

# Execute main function
main "$@"