#!/bin/bash
#
# Build Automation Script for React/NestJS Projects on Raspberry Pi 5
# Handles building React 19.1.0 with Vite 7.0.4 and NestJS 11.1.3 projects
# Optimized for ARM64 architecture and production deployment
#
# Usage: ./build_automation.sh [--dry-run] [--project-type TYPE] [--build-mode MODE]
# 
# Prerequisites:
# - Node.js 20 LTS installed via NVM
# - npm 10+ with proper configuration
# - TypeScript 5.8.3 globally or locally available
# - Project with package.json in target directory
# - Internet connection for package downloads
#
# Features:
# - React 19.1.0 + Vite 7.0.4 production builds
# - NestJS 11.1.3 + TypeScript 5.8.3 compilation
# - Build optimization for ARM64 architecture
# - Asset optimization and minification
# - Build artifact validation
# - Performance analysis and reporting
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/build_automation.log"
DRY_RUN=false
PROJECT_TYPE="auto"
BUILD_MODE="production"
PROJECT_PATH="$(pwd)"
OPTIMIZE_BUILD=true
ANALYZE_BUNDLE=false
CLEAN_BEFORE_BUILD=true
VALIDATE_BUILD=true

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --project-type)
            PROJECT_TYPE="$2"
            shift 2
            ;;
        --build-mode)
            BUILD_MODE="$2"
            shift 2
            ;;
        --project-path)
            PROJECT_PATH="$2"
            shift 2
            ;;
        --no-optimization)
            OPTIMIZE_BUILD=false
            shift
            ;;
        --analyze-bundle)
            ANALYZE_BUNDLE=true
            shift
            ;;
        --no-clean)
            CLEAN_BEFORE_BUILD=false
            shift
            ;;
        --no-validation)
            VALIDATE_BUILD=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--project-type TYPE] [--build-mode MODE]"
            echo "Automates building React and NestJS projects"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --project-type TYPE    Project type: react, nestjs, auto (default: auto)"
            echo "  --build-mode MODE      Build mode: development, production (default: production)"
            echo "  --project-path PATH    Project directory path (default: current directory)"
            echo "  --no-optimization      Skip build optimizations"
            echo "  --analyze-bundle       Analyze bundle size and composition"
            echo "  --no-clean             Skip cleaning before build"
            echo "  --no-validation        Skip build artifact validation"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Project Types:"
            echo "  react                  React 19.1.0 + Vite 7.0.4 project"
            echo "  nestjs                 NestJS 11.1.3 + TypeScript 5.8.3 project"
            echo "  auto                   Auto-detect project type (default)"
            echo ""
            echo "Build Modes:"
            echo "  development            Development build with debugging"
            echo "  production             Optimized production build"
            echo ""
            echo "Examples:"
            echo "  $0                                    # Auto-detect and build for production"
            echo "  $0 --project-type react --analyze-bundle"
            echo "  $0 --project-type nestjs --build-mode development"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Node.js
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        exit 1
    fi
    
    local node_version
    node_version=$(node --version | sed 's/v//')
    local node_major_version
    node_major_version=$(echo "$node_version" | cut -d. -f1)
    
    if [[ "$node_major_version" -lt 18 ]]; then
        log_error "Node.js version 18+ required, found: v$node_version"
        exit 1
    fi
    
    log_info "Node.js version: v$node_version ✓"
    
    # Check npm
    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not available"
        exit 1
    fi
    
    local npm_version
    npm_version=$(npm --version)
    log_info "npm version: v$npm_version ✓"
    
    # Check project directory
    if [[ ! -d "$PROJECT_PATH" ]]; then
        log_error "Project directory does not exist: $PROJECT_PATH"
        exit 1
    fi
    
    # Check package.json
    if [[ ! -f "$PROJECT_PATH/package.json" ]]; then
        log_error "package.json not found in: $PROJECT_PATH"
        exit 1
    fi
    
    # Change to project directory
    cd "$PROJECT_PATH"
    log_info "Working in project directory: $(pwd)"
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" == "aarch64" ]]; then
        log_info "ARM64 architecture detected - applying optimizations"
    else
        log_warning "Not running on ARM64 architecture: $(uname -m)"
    fi
    
    log_info "Prerequisites check completed"
}

# Auto-detect project type
detect_project_type() {
    if [[ "$PROJECT_TYPE" != "auto" ]]; then
        log_info "Project type specified: $PROJECT_TYPE"
        return 0
    fi
    
    log_info "Auto-detecting project type..."
    
    # Check for React project indicators
    if grep -q '"react"' package.json 2>/dev/null; then
        if grep -q '"vite"' package.json 2>/dev/null; then
            PROJECT_TYPE="react"
            log_info "Detected React project with Vite"
            return 0
        fi
    fi
    
    # Check for NestJS project indicators
    if grep -q '"@nestjs/core"' package.json 2>/dev/null; then
        PROJECT_TYPE="nestjs"
        log_info "Detected NestJS project"
        return 0
    fi
    
    # Check for build scripts
    if grep -q '"vite build"' package.json 2>/dev/null; then
        PROJECT_TYPE="react"
        log_info "Detected React/Vite project from build script"
        return 0
    fi
    
    if grep -q '"nest build"' package.json 2>/dev/null; then
        PROJECT_TYPE="nestjs"
        log_info "Detected NestJS project from build script"
        return 0
    fi
    
    log_error "Could not auto-detect project type"
    log_error "Please specify --project-type react or --project-type nestjs"
    exit 1
}

# Clean build artifacts
clean_build_artifacts() {
    if [[ "$CLEAN_BEFORE_BUILD" != "true" ]]; then
        log_info "Skipping clean (--no-clean specified)"
        return 0
    fi
    
    log_info "Cleaning build artifacts..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would clean build artifacts"
        return 0
    fi
    
    case "$PROJECT_TYPE" in
        "react")
            if [[ -d "dist" ]]; then
                rm -rf dist
                log_info "Removed dist directory"
            fi
            if [[ -d "build" ]]; then
                rm -rf build
                log_info "Removed build directory"
            fi
            ;;
        "nestjs")
            if [[ -d "dist" ]]; then
                rm -rf dist
                log_info "Removed dist directory"
            fi
            ;;
    esac
    
    log_success "Build artifacts cleaned"
}

# Install dependencies if needed
ensure_dependencies() {
    log_info "Ensuring dependencies are installed..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would check and install dependencies"
        return 0
    fi
    
    if [[ ! -d "node_modules" ]] || [[ ! -f "package-lock.json" ]]; then
        log_info "Installing dependencies..."
        if npm ci; then
            log_success "Dependencies installed"
        else
            log_error "Failed to install dependencies"
            exit 1
        fi
    else
        log_info "Dependencies already installed"
    fi
}

# Build React project with Vite
build_react_project() {
    log_info "Building React project with Vite..."
    log_info "Build mode: $BUILD_MODE"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would build React project"
        return 0
    fi
    
    # Set environment variables for ARM64 optimization
    export NODE_OPTIONS="--max-old-space-size=2048"
    
    # Build command based on mode
    local build_command
    case "$BUILD_MODE" in
        "development")
            build_command="npm run build -- --mode development"
            ;;
        "production")
            if [[ "$OPTIMIZE_BUILD" == "true" ]]; then
                build_command="npm run build -- --mode production"
            else
                build_command="npm run build"
            fi
            ;;
        *)
            log_error "Unknown build mode: $BUILD_MODE"
            exit 1
            ;;
    esac
    
    log_info "Executing: $build_command"
    
    # Record build start time
    local build_start
    build_start=$(date +%s)
    
    # Execute build
    if eval "$build_command"; then
        local build_end
        build_end=$(date +%s)
        local build_duration=$((build_end - build_start))
        log_success "React build completed in ${build_duration}s"
    else
        log_error "React build failed"
        exit 1
    fi
    
    # Analyze bundle if requested
    if [[ "$ANALYZE_BUNDLE" == "true" ]]; then
        analyze_react_bundle
    fi
}

# Build NestJS project
build_nestjs_project() {
    log_info "Building NestJS project..."
    log_info "Build mode: $BUILD_MODE"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would build NestJS project"
        return 0
    fi
    
    # Set environment variables for ARM64 optimization
    export NODE_OPTIONS="--max-old-space-size=2048"
    
    # Build command
    local build_command="npm run build"
    
    log_info "Executing: $build_command"
    
    # Record build start time
    local build_start
    build_start=$(date +%s)
    
    # Execute build
    if eval "$build_command"; then
        local build_end
        build_end=$(date +%s)
        local build_duration=$((build_end - build_start))
        log_success "NestJS build completed in ${build_duration}s"
    else
        log_error "NestJS build failed"
        exit 1
    fi
    
    # Run type checking
    if command -v tsc >/dev/null 2>&1; then
        log_info "Running TypeScript type checking..."
        if tsc --noEmit; then
            log_success "Type checking passed"
        else
            log_warning "Type checking found issues"
        fi
    fi
}

# Analyze React bundle
analyze_react_bundle() {
    log_info "Analyzing React bundle..."
    
    if [[ ! -d "dist" ]]; then
        log_warning "Build directory not found, skipping bundle analysis"
        return 0
    fi
    
    # Calculate bundle sizes
    log_info "=== Bundle Size Analysis ==="
    
    if command -v du >/dev/null 2>&1; then
        local total_size
        total_size=$(du -sh dist | cut -f1)
        log_info "Total bundle size: $total_size"
        
        # Analyze individual files
        log_info "Largest files in bundle:"
        find dist -type f -name "*.js" -o -name "*.css" | xargs ls -lh | sort -k5 -hr | head -10
    fi
    
    # Check for common optimization opportunities
    log_info "=== Optimization Opportunities ==="
    
    # Check for source maps in production
    if [[ "$BUILD_MODE" == "production" ]] && find dist -name "*.map" | grep -q .; then
        log_warning "Source maps found in production build - consider disabling for smaller bundle"
    fi
    
    # Check for unminified files
    if find dist -name "*.js" -exec grep -l "console.log" {} \; | grep -q .; then
        log_warning "Console.log statements found - consider removing for production"
    fi
}

# Validate build artifacts
validate_build_artifacts() {
    if [[ "$VALIDATE_BUILD" != "true" ]]; then
        log_info "Skipping build validation (--no-validation specified)"
        return 0
    fi
    
    log_info "Validating build artifacts..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would validate build artifacts"
        return 0
    fi
    
    case "$PROJECT_TYPE" in
        "react")
            validate_react_build
            ;;
        "nestjs")
            validate_nestjs_build
            ;;
    esac
}

# Validate React build
validate_react_build() {
    log_info "Validating React build artifacts..."
    
    # Check if dist directory exists
    if [[ ! -d "dist" ]]; then
        log_error "Build directory 'dist' not found"
        exit 1
    fi
    
    # Check for index.html
    if [[ ! -f "dist/index.html" ]]; then
        log_error "index.html not found in build output"
        exit 1
    fi
    
    # Check for JavaScript files
    if ! find dist -name "*.js" | grep -q .; then
        log_error "No JavaScript files found in build output"
        exit 1
    fi
    
    # Check for CSS files (optional but common)
    if find dist -name "*.css" | grep -q .; then
        log_info "CSS files found in build output ✓"
    else
        log_warning "No CSS files found in build output"
    fi
    
    # Validate HTML structure
    if grep -q "<div id=\"root\">" dist/index.html; then
        log_info "React root element found in HTML ✓"
    else
        log_warning "React root element not found in HTML"
    fi
    
    log_success "React build validation completed"
}

# Validate NestJS build
validate_nestjs_build() {
    log_info "Validating NestJS build artifacts..."
    
    # Check if dist directory exists
    if [[ ! -d "dist" ]]; then
        log_error "Build directory 'dist' not found"
        exit 1
    fi
    
    # Check for main.js
    if [[ ! -f "dist/main.js" ]]; then
        log_error "main.js not found in build output"
        exit 1
    fi
    
    # Check if main.js is executable Node.js code
    if node -c dist/main.js 2>/dev/null; then
        log_info "main.js is valid Node.js code ✓"
    else
        log_error "main.js contains syntax errors"
        exit 1
    fi
    
    # Check for TypeScript declaration files
    if find dist -name "*.d.ts" | grep -q .; then
        log_info "TypeScript declaration files found ✓"
    else
        log_warning "No TypeScript declaration files found"
    fi
    
    log_success "NestJS build validation completed"
}

# Generate build report
generate_build_report() {
    log_info "Generating build report..."
    
    local report_file="build-report-$(date +%Y%m%d_%H%M%S).txt"
    
    {
        echo "=== Build Report ==="
        echo "Date: $(date)"
        echo "Project Type: $PROJECT_TYPE"
        echo "Build Mode: $BUILD_MODE"
        echo "Project Path: $PROJECT_PATH"
        echo "Node.js Version: $(node --version)"
        echo "npm Version: v$(npm --version)"
        echo "Architecture: $(uname -m)"
        echo ""
        
        if [[ -f "package.json" ]]; then
            echo "=== Project Information ==="
            echo "Name: $(node -p "require('./package.json').name" 2>/dev/null || echo "Unknown")"
            echo "Version: $(node -p "require('./package.json').version" 2>/dev/null || echo "Unknown")"
            echo ""
        fi
        
        echo "=== Build Artifacts ==="
        if [[ -d "dist" ]]; then
            echo "Build directory: dist"
            echo "Total size: $(du -sh dist 2>/dev/null | cut -f1 || echo "Unknown")"
            echo "File count: $(find dist -type f | wc -l)"
            echo ""
            echo "File listing:"
            find dist -type f | head -20
        else
            echo "No build directory found"
        fi
        
        echo ""
        echo "=== Build Configuration ==="
        echo "Clean before build: $CLEAN_BEFORE_BUILD"
        echo "Optimization enabled: $OPTIMIZE_BUILD"
        echo "Bundle analysis: $ANALYZE_BUNDLE"
        echo "Build validation: $VALIDATE_BUILD"
        
    } > "$report_file"
    
    log_success "Build report generated: $report_file"
}

# Main build execution
execute_build() {
    case "$PROJECT_TYPE" in
        "react")
            build_react_project
            ;;
        "nestjs")
            build_nestjs_project
            ;;
        *)
            log_error "Unknown project type: $PROJECT_TYPE"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== Build Automation Summary ==="
    log_info "Project Type: $PROJECT_TYPE"
    log_info "Build Mode: $BUILD_MODE"
    log_info "Project Path: $PROJECT_PATH"
    log_info "Optimization: $OPTIMIZE_BUILD"
    log_info "Bundle Analysis: $ANALYZE_BUNDLE"
    log_info "Validation: $VALIDATE_BUILD"
    log_info ""
    
    if [[ -d "dist" ]]; then
        local build_size
        build_size=$(du -sh dist 2>/dev/null | cut -f1 || echo "Unknown")
        log_info "Build Output: dist/ ($build_size)"
        
        local file_count
        file_count=$(find dist -type f | wc -l)
        log_info "Files Generated: $file_count"
    fi
    
    log_info ""
    log_info "=== Next Steps ==="
    case "$PROJECT_TYPE" in
        "react")
            log_info "1. Test the build: npm run preview"
            log_info "2. Deploy dist/ directory to web server"
            log_info "3. Configure web server for SPA routing"
            ;;
        "nestjs")
            log_info "1. Test the build: node dist/main.js"
            log_info "2. Set up production environment variables"
            log_info "3. Deploy with PM2: pm2 start dist/main.js"
            ;;
    esac
    
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting build automation..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Build mode: $BUILD_MODE"
    
    check_prerequisites
    detect_project_type
    clean_build_artifacts
    ensure_dependencies
    execute_build
    validate_build_artifacts
    generate_build_report
    
    log_success "Build automation completed successfully!"
    display_summary
}

# Execute main function
main "$@"