#!/bin/bash
#
# React Project Initialization Script for Raspberry Pi 5
# Creates new React 19.1.0 projects with Vite 7.0.4 and TypeScript 5.8.3
# Optimized for ARM64 architecture and development workflow
#
# Usage: ./init_react_project.sh [--dry-run] [--project-name NAME] [--template TYPE]
# 
# Prerequisites:
# - Node.js 20 LTS installed via NVM
# - npm with global packages (create-react-app, vite)
# - TypeScript 5.8.3 globally available
# - Internet connection for package downloads
#
# Features:
# - React 19.1.0 project creation with Vite 7.0.4
# - TypeScript 5.8.3 configuration
# - ESLint and Prettier setup
# - Git workflow automation with Husky
# - ARM64 optimized configurations
# - Development environment integration
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/react_project_init.log"
DRY_RUN=false
PROJECT_NAME=""
PROJECT_TEMPLATE="typescript"
PROJECT_DIR="$HOME/development/projects"
USE_VITE=true
SETUP_GIT=true
INSTALL_DEPS=true

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --project-name)
            PROJECT_NAME="$2"
            shift 2
            ;;
        --template)
            PROJECT_TEMPLATE="$2"
            shift 2
            ;;
        --project-dir)
            PROJECT_DIR="$2"
            shift 2
            ;;
        --no-git)
            SETUP_GIT=false
            shift
            ;;
        --no-deps)
            INSTALL_DEPS=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--project-name NAME] [--template TYPE]"
            echo "Creates new React 19.1.0 project with Vite 7.0.4 and TypeScript 5.8.3"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --project-name NAME    Project name (required)"
            echo "  --template TYPE        Project template (typescript, javascript)"
            echo "  --project-dir DIR      Project directory (default: ~/development/projects)"
            echo "  --no-git               Skip Git repository initialization"
            echo "  --no-deps              Skip dependency installation"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Templates:"
            echo "  typescript             React + TypeScript + Vite (default)"
            echo "  javascript             React + JavaScript + Vite"
            echo ""
            echo "Examples:"
            echo "  $0 --project-name my-app"
            echo "  $0 --project-name my-app --template javascript"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Validate required parameters
if [[ -z "$PROJECT_NAME" ]]; then
    echo "Error: Project name is required" >&2
    echo "Use: $0 --project-name YOUR_PROJECT_NAME" >&2
    exit 1
fi

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Node.js version
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        log_error "Please run the Node.js setup script first"
        exit 1
    fi
    
    local node_version
    node_version=$(node --version | sed 's/v//')
    local node_major_version
    node_major_version=$(echo "$node_version" | cut -d. -f1)
    
    if [[ "$node_major_version" -lt 18 ]]; then
        log_error "Node.js version 18+ required, found: v$node_version"
        log_error "Please update Node.js using NVM"
        exit 1
    fi
    
    log_info "Node.js version: v$node_version ✓"
    
    # Check npm
    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not available"
        exit 1
    fi
    
    local npm_version
    npm_version=$(npm --version)
    log_info "npm version: v$npm_version ✓"
    
    # Check if Vite is available globally
    if ! npm list -g vite >/dev/null 2>&1; then
        log_warning "Vite not found globally, will install locally"
    fi
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" != "aarch64" ]]; then
        log_warning "Not running on ARM64 architecture: $(uname -m)"
    fi
    
    # Check internet connectivity
    if ! ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        log_error "Internet connection required for package downloads"
        exit 1
    fi
    
    # Check project directory
    if [[ ! -d "$PROJECT_DIR" ]]; then
        log_info "Creating project directory: $PROJECT_DIR"
        mkdir -p "$PROJECT_DIR"
    fi
    
    # Check if project already exists
    if [[ -d "$PROJECT_DIR/$PROJECT_NAME" ]]; then
        log_error "Project directory already exists: $PROJECT_DIR/$PROJECT_NAME"
        exit 1
    fi
    
    log_info "Prerequisites check completed"
}

# Create React project with Vite
create_react_project() {
    log_info "Creating React project: $PROJECT_NAME"
    log_info "Template: $PROJECT_TEMPLATE"
    log_info "Directory: $PROJECT_DIR"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create React project with Vite"
        return 0
    fi
    
    cd "$PROJECT_DIR"
    
    # Create Vite project based on template
    local vite_template
    case "$PROJECT_TEMPLATE" in
        "typescript")
            vite_template="react-ts"
            ;;
        "javascript")
            vite_template="react"
            ;;
        *)
            log_error "Unknown template: $PROJECT_TEMPLATE"
            exit 1
            ;;
    esac
    
    log_info "Creating Vite project with template: $vite_template"
    if npm create vite@latest "$PROJECT_NAME" -- --template "$vite_template"; then
        log_success "React project created successfully"
    else
        log_error "Failed to create React project"
        exit 1
    fi
    
    cd "$PROJECT_NAME"
    log_info "Project created at: $(pwd)"
}

# Install dependencies
install_dependencies() {
    if [[ "$INSTALL_DEPS" != "true" ]]; then
        log_info "Skipping dependency installation (--no-deps specified)"
        return 0
    fi
    
    log_info "Installing project dependencies..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install npm dependencies"
        return 0
    fi
    
    # Install base dependencies
    if npm install; then
        log_success "Base dependencies installed"
    else
        log_error "Failed to install base dependencies"
        exit 1
    fi
    
    # Install development dependencies
    local dev_deps=(
        "eslint"
        "prettier"
        "@typescript-eslint/parser"
        "@typescript-eslint/eslint-plugin"
        "eslint-config-prettier"
        "eslint-plugin-prettier"
        "eslint-plugin-react"
        "eslint-plugin-react-hooks"
        "husky"
        "lint-staged"
        "@commitlint/cli"
        "@commitlint/config-conventional"
    )
    
    log_info "Installing development dependencies..."
    if npm install --save-dev "${dev_deps[@]}"; then
        log_success "Development dependencies installed"
    else
        log_error "Failed to install development dependencies"
        exit 1
    fi
}

# Configure ESLint and Prettier
configure_linting() {
    log_info "Configuring ESLint and Prettier..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure ESLint and Prettier"
        return 0
    fi
    
    # Create ESLint configuration
    cat > .eslintrc.json << 'EOF'
{
  "env": {
    "browser": true,
    "es2021": true,
    "node": true
  },
  "extends": [
    "eslint:recommended",
    "@typescript-eslint/recommended",
    "plugin:react/recommended",
    "plugin:react-hooks/recommended",
    "prettier"
  ],
  "parser": "@typescript-eslint/parser",
  "parserOptions": {
    "ecmaFeatures": {
      "jsx": true
    },
    "ecmaVersion": "latest",
    "sourceType": "module"
  },
  "plugins": [
    "react",
    "react-hooks",
    "@typescript-eslint",
    "prettier"
  ],
  "rules": {
    "prettier/prettier": "error",
    "react/react-in-jsx-scope": "off",
    "@typescript-eslint/no-unused-vars": "error",
    "@typescript-eslint/explicit-function-return-type": "off"
  },
  "settings": {
    "react": {
      "version": "detect"
    }
  }
}
EOF
    
    # Create Prettier configuration
    cat > .prettierrc << 'EOF'
{
  "semi": true,
  "trailingComma": "es5",
  "singleQuote": true,
  "printWidth": 80,
  "tabWidth": 2,
  "useTabs": false
}
EOF
    
    # Create .prettierignore
    cat > .prettierignore << 'EOF'
dist
build
node_modules
*.min.js
*.min.css
EOF
    
    log_success "ESLint and Prettier configured"
}

# Setup Git workflow automation
setup_git_workflow() {
    if [[ "$SETUP_GIT" != "true" ]]; then
        log_info "Skipping Git setup (--no-git specified)"
        return 0
    fi
    
    log_info "Setting up Git workflow automation..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would setup Git workflow with Husky"
        return 0
    fi
    
    # Initialize Git repository
    if ! git rev-parse --git-dir >/dev/null 2>&1; then
        git init
        log_info "Git repository initialized"
    fi
    
    # Setup Husky
    npx husky install
    npm pkg set scripts.prepare="husky install"
    
    # Create pre-commit hook
    npx husky add .husky/pre-commit "npx lint-staged"
    
    # Create commit-msg hook
    npx husky add .husky/commit-msg 'npx --no -- commitlint --edit ${1}'
    
    # Configure lint-staged
    npm pkg set lint-staged.*.ts="eslint --fix"
    npm pkg set lint-staged.*.tsx="eslint --fix"
    npm pkg set lint-staged.*.js="eslint --fix"
    npm pkg set lint-staged.*.jsx="eslint --fix"
    npm pkg set lint-staged.*="prettier --write"
    
    # Create commitlint configuration
    cat > commitlint.config.js << 'EOF'
module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'type-enum': [
      2,
      'always',
      [
        'feat',
        'fix',
        'docs',
        'style',
        'refactor',
        'perf',
        'test',
        'chore',
        'ci',
        'build'
      ]
    ]
  }
};
EOF
    
    log_success "Git workflow automation configured"
}

# Update package.json scripts
update_package_scripts() {
    log_info "Updating package.json scripts..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would update package.json scripts"
        return 0
    fi
    
    # Add custom scripts
    npm pkg set scripts.lint="eslint . --ext .ts,.tsx,.js,.jsx"
    npm pkg set scripts.lint:fix="eslint . --ext .ts,.tsx,.js,.jsx --fix"
    npm pkg set scripts.format="prettier --write ."
    npm pkg set scripts.format:check="prettier --check ."
    npm pkg set scripts.type-check="tsc --noEmit"
    npm pkg set scripts.build:prod="vite build --mode production"
    npm pkg set scripts.preview:prod="vite preview --mode production"
    
    log_success "Package.json scripts updated"
}

# Create development configuration files
create_dev_configs() {
    log_info "Creating development configuration files..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create development configuration files"
        return 0
    fi
    
    # Create .env.development
    cat > .env.development << 'EOF'
# Development Environment Variables
VITE_APP_TITLE=Pi5 Development App
VITE_API_URL=http://localhost:3000/api
VITE_APP_ENV=development

# Development Server Configuration
VITE_HOST=0.0.0.0
VITE_PORT=5173

# Enable development features
VITE_DEV_TOOLS=true
VITE_DEBUG=true
EOF
    
    # Create .env.production
    cat > .env.production << 'EOF'
# Production Environment Variables
VITE_APP_TITLE=Pi5 Production App
VITE_API_URL=/api
VITE_APP_ENV=production

# Disable development features
VITE_DEV_TOOLS=false
VITE_DEBUG=false
EOF
    
    # Create .gitignore
    cat > .gitignore << 'EOF'
# Dependencies
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Production builds
dist/
build/

# Environment variables
.env.local
.env.*.local

# IDE files
.vscode/
.idea/
*.swp
*.swo

# OS files
.DS_Store
Thumbs.db

# Logs
logs/
*.log

# Runtime data
pids/
*.pid
*.seed
*.pid.lock

# Coverage directory used by tools like istanbul
coverage/

# Temporary folders
tmp/
temp/
EOF
    
    log_success "Development configuration files created"
}

# Create README with project information
create_readme() {
    log_info "Creating project README..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create README.md"
        return 0
    fi
    
    cat > README.md << EOF
# $PROJECT_NAME

React 19.1.0 application with Vite 7.0.4 and TypeScript 5.8.3, optimized for Raspberry Pi 5.

## Technology Stack

- **React**: 19.1.0
- **Vite**: 7.0.4
- **TypeScript**: 5.8.3
- **ESLint**: Latest with TypeScript support
- **Prettier**: Code formatting
- **Husky**: Git hooks automation

## Development Setup

### Prerequisites

- Node.js 20 LTS (installed via NVM)
- npm 10+
- Git

### Installation

\`\`\`bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
\`\`\`

### Development Commands

\`\`\`bash
# Linting
npm run lint          # Check for linting errors
npm run lint:fix      # Fix linting errors automatically

# Formatting
npm run format        # Format code with Prettier
npm run format:check  # Check code formatting

# Type checking
npm run type-check    # Run TypeScript type checking

# Production build
npm run build:prod    # Build for production
npm run preview:prod  # Preview production build
\`\`\`

## Project Structure

\`\`\`
$PROJECT_NAME/
├── src/                 # Source code
├── public/              # Static assets
├── dist/                # Production build output
├── .husky/              # Git hooks
├── .env.development     # Development environment variables
├── .env.production      # Production environment variables
├── .eslintrc.json       # ESLint configuration
├── .prettierrc          # Prettier configuration
├── commitlint.config.js # Commit message linting
├── tsconfig.json        # TypeScript configuration
├── vite.config.ts       # Vite configuration
└── package.json         # Project dependencies and scripts
\`\`\`

## Git Workflow

This project uses automated Git workflows with:

- **Pre-commit hooks**: Automatic linting and formatting
- **Commit message linting**: Conventional commit format
- **Lint-staged**: Only lint changed files

### Commit Message Format

\`\`\`
type(scope): description

feat: add new feature
fix: fix bug
docs: update documentation
style: formatting changes
refactor: code refactoring
test: add tests
chore: maintenance tasks
\`\`\`

## Raspberry Pi 5 Optimizations

This project is optimized for ARM64 architecture:

- Configured for ARM64 package compatibility
- Optimized build settings for Pi 5 hardware
- Development server configured for network access
- Performance optimizations for limited resources

## Environment Variables

### Development (.env.development)
- \`VITE_APP_TITLE\`: Application title
- \`VITE_API_URL\`: API endpoint URL
- \`VITE_HOST\`: Development server host
- \`VITE_PORT\`: Development server port

### Production (.env.production)
- Production-optimized environment variables
- Debug features disabled
- Optimized API endpoints

## Deployment

For production deployment on Raspberry Pi 5:

1. Build the application: \`npm run build:prod\`
2. Serve the \`dist\` directory with a web server
3. Configure environment variables for production
4. Set up process management with PM2 (if needed)

## Contributing

1. Follow the established code style (ESLint + Prettier)
2. Use conventional commit messages
3. Ensure all tests pass before committing
4. Update documentation as needed

## License

[Add your license information here]
EOF
    
    log_success "README.md created"
}

# Display project summary
display_summary() {
    log_info "=== React Project Creation Summary ==="
    log_info "Project Name: $PROJECT_NAME"
    log_info "Project Directory: $PROJECT_DIR/$PROJECT_NAME"
    log_info "Template: $PROJECT_TEMPLATE"
    log_info "Technology Stack:"
    log_info "  - React 19.1.0"
    log_info "  - Vite 7.0.4"
    log_info "  - TypeScript 5.8.3"
    log_info "  - ESLint + Prettier"
    log_info "  - Husky + lint-staged"
    log_info ""
    log_info "=== Next Steps ==="
    log_info "1. Navigate to project: cd $PROJECT_DIR/$PROJECT_NAME"
    log_info "2. Start development server: npm run dev"
    log_info "3. Open browser: http://localhost:5173"
    log_info "4. Begin development!"
    log_info ""
    log_info "=== Available Commands ==="
    log_info "npm run dev          # Start development server"
    log_info "npm run build        # Build for production"
    log_info "npm run lint         # Check code quality"
    log_info "npm run format       # Format code"
    log_info "npm run type-check   # Check TypeScript types"
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting React project initialization..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Project name: $PROJECT_NAME"
    log_info "Template: $PROJECT_TEMPLATE"
    
    check_prerequisites
    create_react_project
    install_dependencies
    configure_linting
    setup_git_workflow
    update_package_scripts
    create_dev_configs
    create_readme
    
    log_success "React project initialization completed successfully!"
    display_summary
}

# Execute main function
main "$@"