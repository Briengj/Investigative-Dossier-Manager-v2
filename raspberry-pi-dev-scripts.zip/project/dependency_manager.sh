#!/bin/bash
#
# Dependency Management Script for Node.js Projects on Raspberry Pi 5
# Manages npm packages, security audits, and dependency updates
# Optimized for React 19.1.0, NestJS 11.1.3, and TypeScript 5.8.3 projects
#
# Usage: ./dependency_manager.sh [--dry-run] [--action ACTION] [--project-path PATH]
# 
# Prerequisites:
# - Node.js 20 LTS installed via NVM
# - npm 10+ with proper configuration
# - Project with package.json in target directory
# - Internet connection for package registry access
#
# Features:
# - Dependency updates with compatibility checking
# - Security vulnerability scanning and fixes
# - Package audit and cleanup
# - ARM64 compatibility validation
# - Dependency tree analysis
# - Lock file management
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/dependency_manager.log"
DRY_RUN=false
ACTION="check"
PROJECT_PATH="$(pwd)"
BACKUP_ENABLED=true
SECURITY_AUDIT=true
UPDATE_STRATEGY="minor"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --action)
            ACTION="$2"
            shift 2
            ;;
        --project-path)
            PROJECT_PATH="$2"
            shift 2
            ;;
        --update-strategy)
            UPDATE_STRATEGY="$2"
            shift 2
            ;;
        --no-backup)
            BACKUP_ENABLED=false
            shift
            ;;
        --no-security-audit)
            SECURITY_AUDIT=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--action ACTION] [--project-path PATH]"
            echo "Manages npm dependencies for Node.js projects"
            echo ""
            echo "Options:"
            echo "  --dry-run                Show what would be done without making changes"
            echo "  --action ACTION          Action to perform (default: check)"
            echo "  --project-path PATH      Project directory path (default: current directory)"
            echo "  --update-strategy LEVEL  Update strategy: patch, minor, major (default: minor)"
            echo "  --no-backup              Skip package.json backup before updates"
            echo "  --no-security-audit      Skip security vulnerability scanning"
            echo "  -h, --help               Show this help message"
            echo ""
            echo "Actions:"
            echo "  check                    Check for outdated packages and vulnerabilities"
            echo "  update                   Update packages based on strategy"
            echo "  audit                    Run security audit and fix vulnerabilities"
            echo "  clean                    Clean node_modules and reinstall"
            echo "  analyze                  Analyze dependency tree and sizes"
            echo "  validate                 Validate ARM64 compatibility"
            echo ""
            echo "Update Strategies:"
            echo "  patch                    Update patch versions only (1.0.1 -> 1.0.2)"
            echo "  minor                    Update minor versions (1.0.1 -> 1.1.0)"
            echo "  major                    Update major versions (1.0.1 -> 2.0.0)"
            echo ""
            echo "Examples:"
            echo "  $0 --action check"
            echo "  $0 --action update --update-strategy minor"
            echo "  $0 --action audit --project-path /path/to/project"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Node.js
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        exit 1
    fi
    
    local node_version
    node_version=$(node --version | sed 's/v//')
    log_info "Node.js version: v$node_version"
    
    # Check npm
    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not available"
        exit 1
    fi
    
    local npm_version
    npm_version=$(npm --version)
    log_info "npm version: v$npm_version"
    
    # Check project directory
    if [[ ! -d "$PROJECT_PATH" ]]; then
        log_error "Project directory does not exist: $PROJECT_PATH"
        exit 1
    fi
    
    # Check package.json
    if [[ ! -f "$PROJECT_PATH/package.json" ]]; then
        log_error "package.json not found in: $PROJECT_PATH"
        exit 1
    fi
    
    # Change to project directory
    cd "$PROJECT_PATH"
    log_info "Working in project directory: $(pwd)"
    
    # Check internet connectivity
    if ! ping -c 1 registry.npmjs.org >/dev/null 2>&1; then
        log_error "Cannot reach npm registry - internet connection required"
        exit 1
    fi
    
    log_info "Prerequisites check completed"
}

# Create backup of package files
create_backup() {
    if [[ "$BACKUP_ENABLED" != "true" ]]; then
        log_info "Backup disabled (--no-backup specified)"
        return 0
    fi
    
    log_info "Creating backup of package files..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create backup of package.json and package-lock.json"
        return 0
    fi
    
    local backup_dir="backups/$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$backup_dir"
    
    if [[ -f "package.json" ]]; then
        cp "package.json" "$backup_dir/"
        log_info "Backed up package.json"
    fi
    
    if [[ -f "package-lock.json" ]]; then
        cp "package-lock.json" "$backup_dir/"
        log_info "Backed up package-lock.json"
    fi
    
    if [[ -f "npm-shrinkwrap.json" ]]; then
        cp "npm-shrinkwrap.json" "$backup_dir/"
        log_info "Backed up npm-shrinkwrap.json"
    fi
    
    log_success "Backup created in: $backup_dir"
}

# Check for outdated packages
check_outdated() {
    log_info "Checking for outdated packages..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would check for outdated packages"
        return 0
    fi
    
    log_info "=== Outdated Packages Report ==="
    
    # Check outdated packages
    if npm outdated --long 2>/dev/null; then
        log_info "All packages are up to date"
    else
        log_warning "Some packages are outdated (see above)"
    fi
    
    # Show current package versions for key technologies
    log_info "=== Current Key Package Versions ==="
    
    local key_packages=(
        "react"
        "@types/react"
        "typescript"
        "vite"
        "@nestjs/core"
        "@nestjs/common"
        "eslint"
        "prettier"
    )
    
    for package in "${key_packages[@]}"; do
        if npm list "$package" --depth=0 2>/dev/null | grep -q "$package"; then
            local version
            version=$(npm list "$package" --depth=0 2>/dev/null | grep "$package" | awk '{print $2}' | sed 's/@//')
            log_info "$package: $version"
        fi
    done
}

# Update packages based on strategy
update_packages() {
    log_info "Updating packages with strategy: $UPDATE_STRATEGY"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would update packages with $UPDATE_STRATEGY strategy"
        return 0
    fi
    
    create_backup
    
    case "$UPDATE_STRATEGY" in
        "patch")
            log_info "Updating patch versions only..."
            npm update --save
            ;;
        "minor")
            log_info "Updating minor versions..."
            # Use npm-check-updates for minor updates
            if command -v ncu >/dev/null 2>&1; then
                ncu -u --target minor
                npm install
            else
                log_warning "npm-check-updates not found, using npm update"
                npm update --save
            fi
            ;;
        "major")
            log_info "Updating major versions (use with caution)..."
            if command -v ncu >/dev/null 2>&1; then
                ncu -u
                npm install
            else
                log_warning "npm-check-updates not found, using npm update"
                npm update --save
            fi
            ;;
        *)
            log_error "Unknown update strategy: $UPDATE_STRATEGY"
            exit 1
            ;;
    esac
    
    log_success "Package updates completed"
}

# Run security audit
run_security_audit() {
    if [[ "$SECURITY_AUDIT" != "true" ]]; then
        log_info "Security audit disabled (--no-security-audit specified)"
        return 0
    fi
    
    log_info "Running security audit..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would run npm audit and fix vulnerabilities"
        return 0
    fi
    
    log_info "=== Security Audit Report ==="
    
    # Run audit
    if npm audit --audit-level moderate; then
        log_success "No security vulnerabilities found"
    else
        log_warning "Security vulnerabilities detected"
        
        # Attempt to fix automatically
        log_info "Attempting to fix vulnerabilities automatically..."
        if npm audit fix; then
            log_success "Vulnerabilities fixed automatically"
        else
            log_warning "Some vulnerabilities require manual intervention"
            log_info "Run 'npm audit fix --force' to force fixes (may cause breaking changes)"
        fi
    fi
}

# Clean and reinstall dependencies
clean_dependencies() {
    log_info "Cleaning dependencies and reinstalling..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would clean node_modules and reinstall"
        return 0
    fi
    
    create_backup
    
    # Remove node_modules and lock files
    log_info "Removing node_modules directory..."
    rm -rf node_modules
    
    log_info "Removing package-lock.json..."
    rm -f package-lock.json
    
    # Clear npm cache
    log_info "Clearing npm cache..."
    npm cache clean --force
    
    # Reinstall dependencies
    log_info "Reinstalling dependencies..."
    if npm install; then
        log_success "Dependencies reinstalled successfully"
    else
        log_error "Failed to reinstall dependencies"
        exit 1
    fi
}

# Analyze dependency tree
analyze_dependencies() {
    log_info "Analyzing dependency tree..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would analyze dependency tree and sizes"
        return 0
    fi
    
    log_info "=== Dependency Tree Analysis ==="
    
    # Show dependency tree
    log_info "Dependency tree (top level):"
    npm list --depth=0
    
    # Show package sizes if available
    if command -v npm-check >/dev/null 2>&1; then
        log_info "Package analysis with npm-check:"
        npm-check
    fi
    
    # Show duplicate packages
    log_info "Checking for duplicate packages:"
    npm ls --depth=0 --parseable | xargs ls -la | grep "^l" || log_info "No duplicate packages found"
    
    # Show production vs development dependencies
    log_info "Production dependencies:"
    npm list --prod --depth=0
    
    log_info "Development dependencies:"
    npm list --dev --depth=0
}

# Validate ARM64 compatibility
validate_arm64_compatibility() {
    log_info "Validating ARM64 compatibility..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would validate ARM64 compatibility"
        return 0
    fi
    
    log_info "=== ARM64 Compatibility Check ==="
    
    # Check current architecture
    log_info "Current architecture: $(uname -m)"
    
    # Check for native modules that might have ARM64 issues
    local problematic_packages=(
        "node-sass"
        "node-gyp"
        "sqlite3"
        "bcrypt"
        "sharp"
    )
    
    log_info "Checking for potentially problematic packages on ARM64:"
    for package in "${problematic_packages[@]}"; do
        if npm list "$package" --depth=0 2>/dev/null | grep -q "$package"; then
            local version
            version=$(npm list "$package" --depth=0 2>/dev/null | grep "$package" | awk '{print $2}' | sed 's/@//')
            log_warning "Found potentially problematic package: $package@$version"
            log_info "  Consider alternatives or ensure ARM64 compatibility"
        fi
    done
    
    # Check for prebuilt binaries
    log_info "Checking for packages with prebuilt binaries..."
    if [[ -d "node_modules" ]]; then
        find node_modules -name "*.node" -type f | head -10 | while read -r binary; do
            log_info "Native binary found: $binary"
            if command -v file >/dev/null 2>&1; then
                file "$binary" | grep -q "ARM aarch64" && log_success "  ARM64 compatible" || log_warning "  May not be ARM64 compatible"
            fi
        done
    fi
}

# Main action dispatcher
execute_action() {
    case "$ACTION" in
        "check")
            check_outdated
            if [[ "$SECURITY_AUDIT" == "true" ]]; then
                run_security_audit
            fi
            ;;
        "update")
            update_packages
            if [[ "$SECURITY_AUDIT" == "true" ]]; then
                run_security_audit
            fi
            ;;
        "audit")
            run_security_audit
            ;;
        "clean")
            clean_dependencies
            ;;
        "analyze")
            analyze_dependencies
            ;;
        "validate")
            validate_arm64_compatibility
            ;;
        *)
            log_error "Unknown action: $ACTION"
            log_error "Valid actions: check, update, audit, clean, analyze, validate"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== Dependency Management Summary ==="
    log_info "Action: $ACTION"
    log_info "Project: $PROJECT_PATH"
    log_info "Update Strategy: $UPDATE_STRATEGY"
    log_info "Backup Enabled: $BACKUP_ENABLED"
    log_info "Security Audit: $SECURITY_AUDIT"
    log_info ""
    
    if [[ -f "package.json" ]]; then
        local project_name
        project_name=$(node -p "require('./package.json').name" 2>/dev/null || echo "Unknown")
        local project_version
        project_version=$(node -p "require('./package.json').version" 2>/dev/null || echo "Unknown")
        log_info "Project: $project_name@$project_version"
    fi
    
    log_info "Node.js: $(node --version)"
    log_info "npm: v$(npm --version)"
    log_info ""
    log_info "=== Recommendations ==="
    log_info "1. Run 'npm audit' regularly to check for vulnerabilities"
    log_info "2. Use 'npm outdated' to check for package updates"
    log_info "3. Test thoroughly after major version updates"
    log_info "4. Keep package-lock.json in version control"
    log_info "5. Consider using 'npm ci' in production environments"
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting dependency management..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Action: $ACTION"
    log_info "Project path: $PROJECT_PATH"
    
    check_prerequisites
    execute_action
    
    log_success "Dependency management completed successfully!"
    display_summary
}

# Execute main function
main "$@"