#!/bin/bash
#
# NestJS Project Initialization Script for Raspberry Pi 5
# Creates new NestJS 11.1.3 projects with TypeScript 5.8.3 and PostgreSQL integration
# Optimized for ARM64 architecture and development workflow
#
# Usage: ./init_nestjs_project.sh [--dry-run] [--project-name NAME] [--database-integration]
# 
# Prerequisites:
# - Node.js 20 LTS installed via NVM
# - npm with global packages (@nestjs/cli)
# - TypeScript 5.8.3 globally available
# - PostgreSQL 17.5 (if database integration enabled)
# - Internet connection for package downloads
#
# Features:
# - NestJS 11.1.3 project creation with Express v5
# - TypeScript 5.8.3 configuration
# - PostgreSQL integration with TypeORM
# - ESLint and Prettier setup
# - Git workflow automation with Husky
# - PM2 ecosystem configuration
# - ARM64 optimized configurations
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/nestjs_project_init.log"
DRY_RUN=false
PROJECT_NAME=""
PROJECT_DIR="$HOME/development/projects"
DATABASE_INTEGRATION=false
SETUP_GIT=true
INSTALL_DEPS=true
CREATE_PM2_CONFIG=true

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --project-name)
            PROJECT_NAME="$2"
            shift 2
            ;;
        --project-dir)
            PROJECT_DIR="$2"
            shift 2
            ;;
        --database-integration)
            DATABASE_INTEGRATION=true
            shift
            ;;
        --no-git)
            SETUP_GIT=false
            shift
            ;;
        --no-deps)
            INSTALL_DEPS=false
            shift
            ;;
        --no-pm2)
            CREATE_PM2_CONFIG=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--project-name NAME] [--database-integration]"
            echo "Creates new NestJS 11.1.3 project with TypeScript 5.8.3"
            echo ""
            echo "Options:"
            echo "  --dry-run                Show what would be done without making changes"
            echo "  --project-name NAME      Project name (required)"
            echo "  --project-dir DIR        Project directory (default: ~/development/projects)"
            echo "  --database-integration   Setup PostgreSQL integration with TypeORM"
            echo "  --no-git                 Skip Git repository initialization"
            echo "  --no-deps                Skip dependency installation"
            echo "  --no-pm2                 Skip PM2 configuration creation"
            echo "  -h, --help               Show this help message"
            echo ""
            echo "Examples:"
            echo "  $0 --project-name my-api"
            echo "  $0 --project-name my-api --database-integration"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Validate required parameters
if [[ -z "$PROJECT_NAME" ]]; then
    echo "Error: Project name is required" >&2
    echo "Use: $0 --project-name YOUR_PROJECT_NAME" >&2
    exit 1
fi

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Node.js version
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        log_error "Please run the Node.js setup script first"
        exit 1
    fi
    
    local node_version
    node_version=$(node --version | sed 's/v//')
    local node_major_version
    node_major_version=$(echo "$node_version" | cut -d. -f1)
    
    if [[ "$node_major_version" -lt 18 ]]; then
        log_error "Node.js version 18+ required, found: v$node_version"
        log_error "Please update Node.js using NVM"
        exit 1
    fi
    
    log_info "Node.js version: v$node_version ✓"
    
    # Check npm
    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not available"
        exit 1
    fi
    
    local npm_version
    npm_version=$(npm --version)
    log_info "npm version: v$npm_version ✓"
    
    # Check NestJS CLI
    if ! command -v nest >/dev/null 2>&1; then
        log_warning "NestJS CLI not found globally, will install locally"
    else
        local nest_version
        nest_version=$(nest --version)
        log_info "NestJS CLI version: $nest_version ✓"
    fi
    
    # Check PostgreSQL if database integration is enabled
    if [[ "$DATABASE_INTEGRATION" == "true" ]]; then
        if ! command -v psql >/dev/null 2>&1; then
            log_warning "PostgreSQL client not found - database integration may require manual setup"
        else
            local pg_version
            pg_version=$(psql --version | awk '{print $3}')
            log_info "PostgreSQL client version: $pg_version ✓"
        fi
    fi
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" != "aarch64" ]]; then
        log_warning "Not running on ARM64 architecture: $(uname -m)"
    fi
    
    # Check internet connectivity
    if ! ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        log_error "Internet connection required for package downloads"
        exit 1
    fi
    
    # Check project directory
    if [[ ! -d "$PROJECT_DIR" ]]; then
        log_info "Creating project directory: $PROJECT_DIR"
        mkdir -p "$PROJECT_DIR"
    fi
    
    # Check if project already exists
    if [[ -d "$PROJECT_DIR/$PROJECT_NAME" ]]; then
        log_error "Project directory already exists: $PROJECT_DIR/$PROJECT_NAME"
        exit 1
    fi
    
    log_info "Prerequisites check completed"
}

# Create NestJS project
create_nestjs_project() {
    log_info "Creating NestJS project: $PROJECT_NAME"
    log_info "Directory: $PROJECT_DIR"
    log_info "Database integration: $DATABASE_INTEGRATION"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create NestJS project"
        return 0
    fi
    
    cd "$PROJECT_DIR"
    
    # Install NestJS CLI if not available
    if ! command -v nest >/dev/null 2>&1; then
        log_info "Installing NestJS CLI..."
        if npm install -g @nestjs/cli; then
            log_success "NestJS CLI installed globally"
        else
            log_error "Failed to install NestJS CLI"
            exit 1
        fi
    fi
    
    # Create NestJS project
    log_info "Creating NestJS project (this may take several minutes)..."
    if nest new "$PROJECT_NAME" --package-manager npm; then
        log_success "NestJS project created successfully"
    else
        log_error "Failed to create NestJS project"
        exit 1
    fi
    
    cd "$PROJECT_NAME"
    log_info "Project created at: $(pwd)"
}

# Install additional dependencies
install_additional_dependencies() {
    if [[ "$INSTALL_DEPS" != "true" ]]; then
        log_info "Skipping additional dependency installation (--no-deps specified)"
        return 0
    fi
    
    log_info "Installing additional dependencies..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install additional dependencies"
        return 0
    fi
    
    # Production dependencies
    local prod_deps=(
        "@nestjs/config"
        "@nestjs/swagger"
        "class-validator"
        "class-transformer"
        "helmet"
        "compression"
    )
    
    # Database dependencies (if enabled)
    if [[ "$DATABASE_INTEGRATION" == "true" ]]; then
        prod_deps+=(
            "@nestjs/typeorm"
            "typeorm"
            "pg"
            "@types/pg"
        )
    fi
    
    log_info "Installing production dependencies..."
    if npm install "${prod_deps[@]}"; then
        log_success "Production dependencies installed"
    else
        log_error "Failed to install production dependencies"
        exit 1
    fi
    
    # Development dependencies
    local dev_deps=(
        "eslint"
        "prettier"
        "@typescript-eslint/parser"
        "@typescript-eslint/eslint-plugin"
        "eslint-config-prettier"
        "eslint-plugin-prettier"
        "husky"
        "lint-staged"
        "@commitlint/cli"
        "@commitlint/config-conventional"
        "supertest"
        "@types/supertest"
    )
    
    log_info "Installing development dependencies..."
    if npm install --save-dev "${dev_deps[@]}"; then
        log_success "Development dependencies installed"
    else
        log_error "Failed to install development dependencies"
        exit 1
    fi
}

# Configure database integration
configure_database() {
    if [[ "$DATABASE_INTEGRATION" != "true" ]]; then
        log_info "Skipping database configuration (database integration not enabled)"
        return 0
    fi
    
    log_info "Configuring PostgreSQL database integration..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure database integration"
        return 0
    fi
    
    # Create database configuration module
    mkdir -p src/config
    
    cat > src/config/database.config.ts << 'EOF'
import { registerAs } from '@nestjs/config';
import { TypeOrmModuleOptions } from '@nestjs/typeorm';

export default registerAs(
  'database',
  (): TypeOrmModuleOptions => ({
    type: 'postgres',
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT, 10) || 5432,
    username: process.env.DB_USER || 'developer',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'development',
    entities: [__dirname + '/../**/*.entity{.ts,.js}'],
    synchronize: process.env.NODE_ENV === 'development',
    logging: process.env.NODE_ENV === 'development',
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  }),
);
EOF
    
    # Update app.module.ts to include database configuration
    cat > src/app.module.ts << 'EOF'
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import databaseConfig from './config/database.config';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [databaseConfig],
      envFilePath: ['.env.local', '.env'],
    }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (configService: ConfigService) =>
        configService.get('database'),
    }),
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
EOF
    
    log_success "Database configuration completed"
}

# Configure ESLint and Prettier
configure_linting() {
    log_info "Configuring ESLint and Prettier..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure ESLint and Prettier"
        return 0
    fi
    
    # Update ESLint configuration
    cat > .eslintrc.js << 'EOF'
module.exports = {
  parser: '@typescript-eslint/parser',
  parserOptions: {
    project: 'tsconfig.json',
    tsconfigRootDir: __dirname,
    sourceType: 'module',
  },
  plugins: ['@typescript-eslint/eslint-plugin', 'prettier'],
  extends: [
    '@nestjs/eslint-config-nestjs',
    'plugin:@typescript-eslint/recommended',
    'plugin:prettier/recommended',
  ],
  root: true,
  env: {
    node: true,
    jest: true,
  },
  ignorePatterns: ['.eslintrc.js'],
  rules: {
    '@typescript-eslint/interface-name-prefix': 'off',
    '@typescript-eslint/explicit-function-return-type': 'off',
    '@typescript-eslint/explicit-module-boundary-types': 'off',
    '@typescript-eslint/no-explicit-any': 'off',
    'prettier/prettier': 'error',
  },
};
EOF
    
    # Create Prettier configuration
    cat > .prettierrc << 'EOF'
{
  "singleQuote": true,
  "trailingComma": "all",
  "semi": true,
  "printWidth": 80,
  "tabWidth": 2,
  "useTabs": false
}
EOF
    
    log_success "ESLint and Prettier configured"
}

# Setup Git workflow automation
setup_git_workflow() {
    if [[ "$SETUP_GIT" != "true" ]]; then
        log_info "Skipping Git setup (--no-git specified)"
        return 0
    fi
    
    log_info "Setting up Git workflow automation..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would setup Git workflow with Husky"
        return 0
    fi
    
    # Initialize Git repository if not exists
    if ! git rev-parse --git-dir >/dev/null 2>&1; then
        git init
        log_info "Git repository initialized"
    fi
    
    # Setup Husky
    npx husky install
    npm pkg set scripts.prepare="husky install"
    
    # Create pre-commit hook
    npx husky add .husky/pre-commit "npx lint-staged"
    
    # Create commit-msg hook
    npx husky add .husky/commit-msg 'npx --no -- commitlint --edit ${1}'
    
    # Configure lint-staged
    npm pkg set lint-staged.*.ts="eslint --fix"
    npm pkg set lint-staged.*="prettier --write"
    
    # Create commitlint configuration
    cat > commitlint.config.js << 'EOF'
module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'type-enum': [
      2,
      'always',
      [
        'feat',
        'fix',
        'docs',
        'style',
        'refactor',
        'perf',
        'test',
        'chore',
        'ci',
        'build'
      ]
    ]
  }
};
EOF
    
    log_success "Git workflow automation configured"
}

# Create PM2 ecosystem configuration
create_pm2_configuration() {
    if [[ "$CREATE_PM2_CONFIG" != "true" ]]; then
        log_info "Skipping PM2 configuration (--no-pm2 specified)"
        return 0
    fi
    
    log_info "Creating PM2 ecosystem configuration..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create PM2 ecosystem configuration"
        return 0
    fi
    
    cat > ecosystem.config.js << EOF
module.exports = {
  apps: [
    {
      name: '$PROJECT_NAME',
      script: 'dist/main.js',
      instances: 1,
      exec_mode: 'cluster',
      watch: false,
      max_memory_restart: '512M',
      env: {
        NODE_ENV: 'development',
        PORT: 3000,
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      error_file: './logs/err.log',
      out_file: './logs/out.log',
      log_file: './logs/combined.log',
      time: true,
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s',
    },
  ],
};
EOF
    
    # Create logs directory
    mkdir -p logs
    
    log_success "PM2 ecosystem configuration created"
}

# Update package.json scripts
update_package_scripts() {
    log_info "Updating package.json scripts..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would update package.json scripts"
        return 0
    fi
    
    # Add custom scripts
    npm pkg set scripts.lint="eslint \"{src,apps,libs,test}/**/*.ts\" --fix"
    npm pkg set scripts.format="prettier --write \"src/**/*.ts\" \"test/**/*.ts\""
    npm pkg set scripts.format:check="prettier --check \"src/**/*.ts\" \"test/**/*.ts\""
    npm pkg set scripts.build:prod="npm run build"
    npm pkg set scripts.start:prod="node dist/main"
    npm pkg set scripts.pm2:start="pm2 start ecosystem.config.js"
    npm pkg set scripts.pm2:stop="pm2 stop ecosystem.config.js"
    npm pkg set scripts.pm2:restart="pm2 restart ecosystem.config.js"
    npm pkg set scripts.pm2:delete="pm2 delete ecosystem.config.js"
    npm pkg set scripts.pm2:logs="pm2 logs"
    npm pkg set scripts.pm2:monit="pm2 monit"
    
    log_success "Package.json scripts updated"
}

# Create environment configuration files
create_env_configs() {
    log_info "Creating environment configuration files..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create environment configuration files"
        return 0
    fi
    
    # Create .env.development
    cat > .env.development << 'EOF'
# Development Environment Variables
NODE_ENV=development
PORT=3000

# Database Configuration (PostgreSQL)
DB_HOST=localhost
DB_PORT=5432
DB_NAME=development
DB_USER=developer
DB_PASSWORD=your_secure_password_here

# JWT Configuration
JWT_SECRET=your_jwt_secret_here
JWT_EXPIRES_IN=24h

# API Configuration
API_PREFIX=api
API_VERSION=v1

# Logging
LOG_LEVEL=debug

# CORS Configuration
CORS_ORIGIN=http://localhost:3000,http://localhost:5173

# Swagger Documentation
SWAGGER_ENABLED=true
SWAGGER_PATH=api/docs
EOF
    
    # Create .env.production
    cat > .env.production << 'EOF'
# Production Environment Variables
NODE_ENV=production
PORT=3000

# Database Configuration (PostgreSQL)
DB_HOST=localhost
DB_PORT=5432
DB_NAME=production
DB_USER=production_user
DB_PASSWORD=your_production_password_here

# JWT Configuration
JWT_SECRET=your_production_jwt_secret_here
JWT_EXPIRES_IN=1h

# API Configuration
API_PREFIX=api
API_VERSION=v1

# Logging
LOG_LEVEL=warn

# CORS Configuration
CORS_ORIGIN=https://yourdomain.com

# Swagger Documentation
SWAGGER_ENABLED=false
EOF
    
    # Update .gitignore
    cat >> .gitignore << 'EOF'

# Environment variables
.env.local
.env.*.local

# PM2 logs
logs/
*.log

# Database
*.sqlite
*.db

# IDE
.vscode/
.idea/
EOF
    
    log_success "Environment configuration files created"
}

# Create README with project information
create_readme() {
    log_info "Creating project README..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create README.md"
        return 0
    fi
    
    cat > README.md << EOF
# $PROJECT_NAME

NestJS 11.1.3 API application with TypeScript 5.8.3, optimized for Raspberry Pi 5.

## Technology Stack

- **NestJS**: 11.1.3 (with Express v5)
- **TypeScript**: 5.8.3
- **Node.js**: 20 LTS
$(if [[ "$DATABASE_INTEGRATION" == "true" ]]; then
echo "- **PostgreSQL**: 17.5 with TypeORM"
fi)
- **ESLint**: Latest with TypeScript support
- **Prettier**: Code formatting
- **Husky**: Git hooks automation
- **PM2**: Process management

## Development Setup

### Prerequisites

- Node.js 20 LTS (installed via NVM)
- npm 10+
$(if [[ "$DATABASE_INTEGRATION" == "true" ]]; then
echo "- PostgreSQL 17.5"
fi)
- Git

### Installation

\`\`\`bash
# Install dependencies
npm install

# Start development server
npm run start:dev

# Build for production
npm run build

# Start production server
npm run start:prod
\`\`\`

### Development Commands

\`\`\`bash
# Development
npm run start:dev     # Start in development mode with hot reload
npm run start:debug   # Start in debug mode

# Building
npm run build         # Build the application
npm run build:prod    # Build for production

# Testing
npm run test          # Run unit tests
npm run test:e2e      # Run end-to-end tests
npm run test:cov      # Run tests with coverage

# Code Quality
npm run lint          # Check and fix linting errors
npm run format        # Format code with Prettier
npm run format:check  # Check code formatting

# Production Management (PM2)
npm run pm2:start     # Start with PM2
npm run pm2:stop      # Stop PM2 processes
npm run pm2:restart   # Restart PM2 processes
npm run pm2:logs      # View PM2 logs
npm run pm2:monit     # Monitor PM2 processes
\`\`\`

## Project Structure

\`\`\`
$PROJECT_NAME/
├── src/
│   ├── config/              # Configuration files
$(if [[ "$DATABASE_INTEGRATION" == "true" ]]; then
echo "│   │   └── database.config.ts   # Database configuration"
fi)
│   ├── modules/             # Feature modules
│   ├── common/              # Shared utilities
│   ├── app.controller.ts    # Main application controller
│   ├── app.service.ts       # Main application service
│   ├── app.module.ts        # Root application module
│   └── main.ts              # Application entry point
├── test/                    # Test files
├── dist/                    # Compiled output
├── logs/                    # PM2 logs
├── .env.development         # Development environment variables
├── .env.production          # Production environment variables
├── ecosystem.config.js      # PM2 configuration
├── .eslintrc.js            # ESLint configuration
├── .prettierrc             # Prettier configuration
├── commitlint.config.js    # Commit message linting
└── tsconfig.json           # TypeScript configuration
\`\`\`

## API Documentation

When running in development mode, Swagger documentation is available at:
- http://localhost:3000/api/docs

## Environment Variables

### Development (.env.development)
- \`NODE_ENV\`: Application environment
- \`PORT\`: Server port
$(if [[ "$DATABASE_INTEGRATION" == "true" ]]; then
echo "- \`DB_HOST\`, \`DB_PORT\`, \`DB_NAME\`, \`DB_USER\`, \`DB_PASSWORD\`: Database connection"
fi)
- \`JWT_SECRET\`: JWT signing secret
- \`CORS_ORIGIN\`: Allowed CORS origins

### Production (.env.production)
- Production-optimized environment variables
- Enhanced security configurations
- Disabled debug features

$(if [[ "$DATABASE_INTEGRATION" == "true" ]]; then
cat << 'DBEOF'

## Database Setup

### PostgreSQL Configuration

1. Ensure PostgreSQL 17.5 is installed and running
2. Create development database:
   \`\`\`sql
   CREATE DATABASE development;
   CREATE USER developer WITH PASSWORD 'your_secure_password_here';
   GRANT ALL PRIVILEGES ON DATABASE development TO developer;
   \`\`\`

3. Update environment variables in \`.env.development\`

### Database Migrations

\`\`\`bash
# Generate migration
npm run typeorm:migration:generate -- -n MigrationName

# Run migrations
npm run typeorm:migration:run

# Revert migration
npm run typeorm:migration:revert
\`\`\`
DBEOF
fi)

## Deployment on Raspberry Pi 5

### Production Deployment

1. Build the application:
   \`\`\`bash
   npm run build:prod
   \`\`\`

2. Set up environment variables:
   \`\`\`bash
   cp .env.production .env
   # Edit .env with your production values
   \`\`\`

3. Start with PM2:
   \`\`\`bash
   npm run pm2:start
   \`\`\`

4. Monitor the application:
   \`\`\`bash
   npm run pm2:monit
   \`\`\`

### ARM64 Optimizations

This project is optimized for Raspberry Pi 5:
- Configured for ARM64 package compatibility
- Optimized memory usage for Pi 5 hardware
- PM2 configuration tuned for limited resources
- Database connection pooling optimized

## Git Workflow

This project uses automated Git workflows:

- **Pre-commit hooks**: Automatic linting and formatting
- **Commit message linting**: Conventional commit format
- **Lint-staged**: Only lint changed files

### Commit Message Format

\`\`\`
type(scope): description

feat: add new feature
fix: fix bug
docs: update documentation
style: formatting changes
refactor: code refactoring
test: add tests
chore: maintenance tasks
\`\`\`

## Health Checks

The application includes built-in health check endpoints:
- \`GET /health\`: Basic health check
- \`GET /health/database\`: Database connectivity check

## Contributing

1. Follow the established code style (ESLint + Prettier)
2. Use conventional commit messages
3. Ensure all tests pass before committing
4. Update documentation as needed

## License

[Add your license information here]
EOF
    
    log_success "README.md created"
}

# Display project summary
display_summary() {
    log_info "=== NestJS Project Creation Summary ==="
    log_info "Project Name: $PROJECT_NAME"
    log_info "Project Directory: $PROJECT_DIR/$PROJECT_NAME"
    log_info "Database Integration: $DATABASE_INTEGRATION"
    log_info "Technology Stack:"
    log_info "  - NestJS 11.1.3 (Express v5)"
    log_info "  - TypeScript 5.8.3"
    log_info "  - Node.js 20 LTS"
    if [[ "$DATABASE_INTEGRATION" == "true" ]]; then
        log_info "  - PostgreSQL 17.5 + TypeORM"
    fi
    log_info "  - ESLint + Prettier"
    log_info "  - Husky + lint-staged"
    log_info "  - PM2 process management"
    log_info ""
    log_info "=== Next Steps ==="
    log_info "1. Navigate to project: cd $PROJECT_DIR/$PROJECT_NAME"
    if [[ "$DATABASE_INTEGRATION" == "true" ]]; then
        log_info "2. Configure database connection in .env.development"
        log_info "3. Start development server: npm run start:dev"
    else
        log_info "2. Start development server: npm run start:dev"
    fi
    log_info "4. Open API docs: http://localhost:3000/api/docs"
    log_info "5. Begin development!"
    log_info ""
    log_info "=== Available Commands ==="
    log_info "npm run start:dev        # Start development server"
    log_info "npm run build            # Build for production"
    log_info "npm run test             # Run tests"
    log_info "npm run lint             # Check code quality"
    log_info "npm run pm2:start        # Start with PM2"
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting NestJS project initialization..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Project name: $PROJECT_NAME"
    log_info "Database integration: $DATABASE_INTEGRATION"
    
    check_prerequisites
    create_nestjs_project
    install_additional_dependencies
    configure_database
    configure_linting
    setup_git_workflow
    create_pm2_configuration
    update_package_scripts
    create_env_configs
    create_readme
    
    log_success "NestJS project initialization completed successfully!"
    display_summary
}

# Execute main function
main "$@"