#!/bin/bash
#
# Code Quality Checks Script for React/NestJS Projects on Raspberry Pi 5
# Handles linting, formatting, and type checking for TypeScript 5.8.3 projects
# Integrates ESLint, Prettier, and TypeScript compiler checks
#
# Usage: ./code_quality.sh [--dry-run] [--project-type TYPE] [--check-type TYPE]
# 
# Prerequisites:
# - Node.js 20 LTS installed via NVM
# - npm 10+ with proper configuration
# - TypeScript 5.8.3 globally or locally available
# - ESLint and Prettier configured in project
# - Project with package.json and proper configurations
#
# Features:
# - ESLint linting with TypeScript support
# - Prettier code formatting checks and fixes
# - TypeScript type checking and compilation
# - Code complexity analysis
# - Import/export validation
# - ARM64 optimized execution
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/code_quality.log"
DRY_RUN=false
PROJECT_TYPE="auto"
CHECK_TYPE="all"
PROJECT_PATH="$(pwd)"
FIX_ISSUES=false
STRICT_MODE=false
GENERATE_REPORT=true
FAIL_ON_ERROR=true

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --project-type)
            PROJECT_TYPE="$2"
            shift 2
            ;;
        --check-type)
            CHECK_TYPE="$2"
            shift 2
            ;;
        --project-path)
            PROJECT_PATH="$2"
            shift 2
            ;;
        --fix)
            FIX_ISSUES=true
            shift
            ;;
        --strict)
            STRICT_MODE=true
            shift
            ;;
        --no-report)
            GENERATE_REPORT=false
            shift
            ;;
        --no-fail)
            FAIL_ON_ERROR=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--project-type TYPE] [--check-type TYPE]"
            echo "Performs code quality checks for React and NestJS projects"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --project-type TYPE    Project type: react, nestjs, auto (default: auto)"
            echo "  --check-type TYPE      Check type: lint, format, types, all (default: all)"
            echo "  --project-path PATH    Project directory path (default: current directory)"
            echo "  --fix                  Automatically fix issues where possible"
            echo "  --strict               Use strict checking rules"
            echo "  --no-report            Skip quality report generation"
            echo "  --no-fail              Don't fail on quality issues (warnings only)"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Project Types:"
            echo "  react                  React 19.1.0 + TypeScript 5.8.3 project"
            echo "  nestjs                 NestJS 11.1.3 + TypeScript 5.8.3 project"
            echo "  auto                   Auto-detect project type (default)"
            echo ""
            echo "Check Types:"
            echo "  lint                   ESLint code linting"
            echo "  format                 Prettier code formatting"
            echo "  types                  TypeScript type checking"
            echo "  all                    All quality checks (default)"
            echo ""
            echo "Examples:"
            echo "  $0                                    # Run all checks"
            echo "  $0 --check-type lint --fix"
            echo "  $0 --project-type nestjs --strict"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]] && [[ "$FAIL_ON_ERROR" == "true" ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Node.js
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        exit 1
    fi
    
    local node_version
    node_version=$(node --version | sed 's/v//')
    local node_major_version
    node_major_version=$(echo "$node_version" | cut -d. -f1)
    
    if [[ "$node_major_version" -lt 18 ]]; then
        log_error "Node.js version 18+ required, found: v$node_version"
        exit 1
    fi
    
    log_info "Node.js version: v$node_version ✓"
    
    # Check npm
    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not available"
        exit 1
    fi
    
    local npm_version
    npm_version=$(npm --version)
    log_info "npm version: v$npm_version ✓"
    
    # Check project directory
    if [[ ! -d "$PROJECT_PATH" ]]; then
        log_error "Project directory does not exist: $PROJECT_PATH"
        exit 1
    fi
    
    # Check package.json
    if [[ ! -f "$PROJECT_PATH/package.json" ]]; then
        log_error "package.json not found in: $PROJECT_PATH"
        exit 1
    fi
    
    # Change to project directory
    cd "$PROJECT_PATH"
    log_info "Working in project directory: $(pwd)"
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" == "aarch64" ]]; then
        log_info "ARM64 architecture detected"
    else
        log_warning "Not running on ARM64 architecture: $(uname -m)"
    fi
    
    log_info "Prerequisites check completed"
}

# Auto-detect project type
detect_project_type() {
    if [[ "$PROJECT_TYPE" != "auto" ]]; then
        log_info "Project type specified: $PROJECT_TYPE"
        return 0
    fi
    
    log_info "Auto-detecting project type..."
    
    # Check for React project indicators
    if grep -q '"react"' package.json 2>/dev/null; then
        PROJECT_TYPE="react"
        log_info "Detected React project"
        return 0
    fi
    
    # Check for NestJS project indicators
    if grep -q '"@nestjs/core"' package.json 2>/dev/null; then
        PROJECT_TYPE="nestjs"
        log_info "Detected NestJS project"
        return 0
    fi
    
    # Check for TypeScript project
    if [[ -f "tsconfig.json" ]]; then
        PROJECT_TYPE="typescript"
        log_info "Detected TypeScript project"
        return 0
    fi
    
    log_warning "Could not auto-detect specific project type, using generic TypeScript"
    PROJECT_TYPE="typescript"
}

# Check tool availability
check_tool_availability() {
    log_info "Checking code quality tools availability..."
    
    local tools_missing=false
    
    # Check ESLint
    if ! npm list eslint --depth=0 >/dev/null 2>&1; then
        log_warning "ESLint not found in project dependencies"
        tools_missing=true
    else
        log_info "ESLint found ✓"
    fi
    
    # Check Prettier
    if ! npm list prettier --depth=0 >/dev/null 2>&1; then
        log_warning "Prettier not found in project dependencies"
        tools_missing=true
    else
        log_info "Prettier found ✓"
    fi
    
    # Check TypeScript
    if ! npm list typescript --depth=0 >/dev/null 2>&1 && ! command -v tsc >/dev/null 2>&1; then
        log_warning "TypeScript not found in project or globally"
        tools_missing=true
    else
        log_info "TypeScript found ✓"
    fi
    
    if [[ "$tools_missing" == "true" ]]; then
        log_warning "Some code quality tools are missing"
        log_info "Consider installing: npm install --save-dev eslint prettier typescript"
    fi
}

# Run ESLint checks
run_eslint_checks() {
    log_info "Running ESLint checks..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would run ESLint checks"
        return 0
    fi
    
    # Check if ESLint is available
    if ! npm list eslint --depth=0 >/dev/null 2>&1; then
        log_warning "ESLint not available, skipping lint checks"
        return 0
    fi
    
    # Build ESLint command
    local eslint_command="npx eslint"
    local eslint_args=""
    
    # Add file patterns based on project type
    case "$PROJECT_TYPE" in
        "react")
            eslint_args="src/**/*.{ts,tsx,js,jsx}"
            ;;
        "nestjs")
            eslint_args="src/**/*.ts test/**/*.ts"
            ;;
        "typescript")
            eslint_args="src/**/*.ts"
            ;;
        *)
            eslint_args="**/*.{ts,tsx,js,jsx}"
            ;;
    esac
    
    # Add fix option if requested
    if [[ "$FIX_ISSUES" == "true" ]]; then
        eslint_command="$eslint_command --fix"
    fi
    
    # Add strict mode options
    if [[ "$STRICT_MODE" == "true" ]]; then
        eslint_command="$eslint_command --max-warnings 0"
    fi
    
    # Add output format
    eslint_command="$eslint_command --format stylish"
    
    local full_command="$eslint_command $eslint_args"
    log_info "Executing: $full_command"
    
    local eslint_result=0
    if eval "$full_command"; then
        log_success "ESLint checks passed"
    else
        eslint_result=$?
        if [[ "$FAIL_ON_ERROR" == "true" ]]; then
            log_error "ESLint checks failed"
        else
            log_warning "ESLint checks found issues"
        fi
    fi
    
    return $eslint_result
}

# Run Prettier checks
run_prettier_checks() {
    log_info "Running Prettier checks..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would run Prettier checks"
        return 0
    fi
    
    # Check if Prettier is available
    if ! npm list prettier --depth=0 >/dev/null 2>&1; then
        log_warning "Prettier not available, skipping format checks"
        return 0
    fi
    
    # Build Prettier command
    local prettier_command="npx prettier"
    local prettier_args=""
    
    # Add file patterns based on project type
    case "$PROJECT_TYPE" in
        "react")
            prettier_args="\"src/**/*.{ts,tsx,js,jsx,css,scss,json,md}\""
            ;;
        "nestjs")
            prettier_args="\"src/**/*.ts\" \"test/**/*.ts\" \"*.{js,json,md}\""
            ;;
        "typescript")
            prettier_args="\"src/**/*.ts\" \"*.{js,json,md}\""
            ;;
        *)
            prettier_args="\"**/*.{ts,tsx,js,jsx,css,scss,json,md}\""
            ;;
    esac
    
    # Determine action (check or fix)
    if [[ "$FIX_ISSUES" == "true" ]]; then
        prettier_command="$prettier_command --write"
        log_info "Prettier will format files"
    else
        prettier_command="$prettier_command --check"
        log_info "Prettier will check formatting"
    fi
    
    local full_command="$prettier_command $prettier_args"
    log_info "Executing: $full_command"
    
    local prettier_result=0
    if eval "$full_command"; then
        if [[ "$FIX_ISSUES" == "true" ]]; then
            log_success "Files formatted with Prettier"
        else
            log_success "Prettier formatting checks passed"
        fi
    else
        prettier_result=$?
        if [[ "$FAIL_ON_ERROR" == "true" ]]; then
            log_error "Prettier formatting checks failed"
        else
            log_warning "Prettier found formatting issues"
        fi
    fi
    
    return $prettier_result
}

# Run TypeScript type checks
run_typescript_checks() {
    log_info "Running TypeScript type checks..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would run TypeScript type checks"
        return 0
    fi
    
    # Check if TypeScript is available
    if ! npm list typescript --depth=0 >/dev/null 2>&1 && ! command -v tsc >/dev/null 2>&1; then
        log_warning "TypeScript not available, skipping type checks"
        return 0
    fi
    
    # Check for tsconfig.json
    if [[ ! -f "tsconfig.json" ]]; then
        log_warning "tsconfig.json not found, skipping TypeScript checks"
        return 0
    fi
    
    # Build TypeScript command
    local tsc_command="npx tsc --noEmit"
    
    # Add strict mode options
    if [[ "$STRICT_MODE" == "true" ]]; then
        tsc_command="$tsc_command --strict"
    fi
    
    log_info "Executing: $tsc_command"
    
    local tsc_result=0
    if eval "$tsc_command"; then
        log_success "TypeScript type checks passed"
    else
        tsc_result=$?
        if [[ "$FAIL_ON_ERROR" == "true" ]]; then
            log_error "TypeScript type checks failed"
        else
            log_warning "TypeScript found type issues"
        fi
    fi
    
    return $tsc_result
}

# Run import/export validation
run_import_validation() {
    log_info "Running import/export validation..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would run import/export validation"
        return 0
    fi
    
    # Check for unused imports/exports
    if npm list eslint-plugin-unused-imports --depth=0 >/dev/null 2>&1; then
        log_info "Checking for unused imports..."
        npx eslint --rule "unused-imports/no-unused-imports: error" "src/**/*.{ts,tsx}" || log_warning "Found unused imports"
    fi
    
    # Check for circular dependencies
    if command -v madge >/dev/null 2>&1; then
        log_info "Checking for circular dependencies..."
        if madge --circular src/; then
            log_success "No circular dependencies found"
        else
            log_warning "Circular dependencies detected"
        fi
    fi
    
    log_info "Import/export validation completed"
}

# Analyze code complexity
analyze_code_complexity() {
    log_info "Analyzing code complexity..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would analyze code complexity"
        return 0
    fi
    
    # Use ESLint complexity rules if available
    if npm list eslint --depth=0 >/dev/null 2>&1; then
        log_info "Checking code complexity with ESLint..."
        npx eslint --rule "complexity: [warn, 10]" "src/**/*.{ts,tsx}" || log_warning "High complexity functions found"
    fi
    
    # Count lines of code
    if [[ -d "src" ]]; then
        local loc_count
        loc_count=$(find src -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" | xargs wc -l | tail -1 | awk '{print $1}')
        log_info "Total lines of code: $loc_count"
    fi
    
    log_info "Code complexity analysis completed"
}

# Execute quality checks based on type
execute_quality_checks() {
    local overall_result=0
    
    case "$CHECK_TYPE" in
        "lint")
            run_eslint_checks || overall_result=$?
            ;;
        "format")
            run_prettier_checks || overall_result=$?
            ;;
        "types")
            run_typescript_checks || overall_result=$?
            ;;
        "all")
            run_eslint_checks || overall_result=$?
            run_prettier_checks || overall_result=$?
            run_typescript_checks || overall_result=$?
            run_import_validation
            analyze_code_complexity
            ;;
        *)
            log_error "Unknown check type: $CHECK_TYPE"
            exit 1
            ;;
    esac
    
    return $overall_result
}

# Generate quality report
generate_quality_report() {
    if [[ "$GENERATE_REPORT" != "true" ]]; then
        log_info "Skipping quality report generation (--no-report specified)"
        return 0
    fi
    
    log_info "Generating code quality report..."
    
    local report_file="quality-report-$(date +%Y%m%d_%H%M%S).txt"
    
    {
        echo "=== Code Quality Report ==="
        echo "Date: $(date)"
        echo "Project Type: $PROJECT_TYPE"
        echo "Check Type: $CHECK_TYPE"
        echo "Project Path: $PROJECT_PATH"
        echo "Node.js Version: $(node --version)"
        echo "npm Version: v$(npm --version)"
        echo "Architecture: $(uname -m)"
        echo ""
        
        if [[ -f "package.json" ]]; then
            echo "=== Project Information ==="
            echo "Name: $(node -p "require('./package.json').name" 2>/dev/null || echo "Unknown")"
            echo "Version: $(node -p "require('./package.json').version" 2>/dev/null || echo "Unknown")"
            echo ""
        fi
        
        echo "=== Quality Tools Configuration ==="
        echo "Fix Issues: $FIX_ISSUES"
        echo "Strict Mode: $STRICT_MODE"
        echo "Fail on Error: $FAIL_ON_ERROR"
        echo ""
        
        echo "=== Tool Versions ==="
        if npm list eslint --depth=0 >/dev/null 2>&1; then
            echo "ESLint: $(npm list eslint --depth=0 2>/dev/null | grep eslint | awk '{print $2}' || echo "Unknown")"
        fi
        if npm list prettier --depth=0 >/dev/null 2>&1; then
            echo "Prettier: $(npm list prettier --depth=0 2>/dev/null | grep prettier | awk '{print $2}' || echo "Unknown")"
        fi
        if npm list typescript --depth=0 >/dev/null 2>&1; then
            echo "TypeScript: $(npm list typescript --depth=0 2>/dev/null | grep typescript | awk '{print $2}' || echo "Unknown")"
        fi
        echo ""
        
        echo "=== Configuration Files ==="
        [[ -f ".eslintrc.js" ]] && echo "ESLint config: .eslintrc.js"
        [[ -f ".eslintrc.json" ]] && echo "ESLint config: .eslintrc.json"
        [[ -f ".prettierrc" ]] && echo "Prettier config: .prettierrc"
        [[ -f "prettier.config.js" ]] && echo "Prettier config: prettier.config.js"
        [[ -f "tsconfig.json" ]] && echo "TypeScript config: tsconfig.json"
        echo ""
        
        echo "=== Code Statistics ==="
        if [[ -d "src" ]]; then
            echo "Source files:"
            find src -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" | wc -l | xargs echo "  Total files:"
            find src -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" | xargs wc -l | tail -1 | awk '{print "  Total lines: " $1}'
        fi
        
    } > "$report_file"
    
    log_success "Quality report generated: $report_file"
}

# Display summary
display_summary() {
    log_info "=== Code Quality Summary ==="
    log_info "Project Type: $PROJECT_TYPE"
    log_info "Check Type: $CHECK_TYPE"
    log_info "Project Path: $PROJECT_PATH"
    log_info "Fix Issues: $FIX_ISSUES"
    log_info "Strict Mode: $STRICT_MODE"
    log_info ""
    
    log_info "=== Tools Used ==="
    if npm list eslint --depth=0 >/dev/null 2>&1; then
        log_info "✓ ESLint (linting)"
    fi
    if npm list prettier --depth=0 >/dev/null 2>&1; then
        log_info "✓ Prettier (formatting)"
    fi
    if npm list typescript --depth=0 >/dev/null 2>&1 || command -v tsc >/dev/null 2>&1; then
        log_info "✓ TypeScript (type checking)"
    fi
    
    log_info ""
    log_info "=== Recommendations ==="
    log_info "1. Run quality checks before committing code"
    log_info "2. Set up pre-commit hooks with Husky"
    log_info "3. Configure IDE to use ESLint and Prettier"
    log_info "4. Use --fix option to automatically resolve issues"
    log_info "5. Consider using --strict mode for higher quality standards"
    
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting code quality checks..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Check type: $CHECK_TYPE"
    log_info "Fix issues: $FIX_ISSUES"
    
    check_prerequisites
    detect_project_type
    check_tool_availability
    
    local quality_result=0
    execute_quality_checks || quality_result=$?
    
    generate_quality_report
    
    if [[ $quality_result -eq 0 ]]; then
        log_success "All code quality checks passed!"
    else
        if [[ "$FAIL_ON_ERROR" == "true" ]]; then
            log_error "Code quality checks failed"
        else
            log_warning "Code quality issues found (not failing due to --no-fail)"
            quality_result=0
        fi
    fi
    
    display_summary
    
    exit $quality_result
}

# Execute main function
main "$@"