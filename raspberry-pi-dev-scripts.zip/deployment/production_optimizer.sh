#!/bin/bash
#
# Production Build Optimization Script for Raspberry Pi 5 Deployment
# Optimizes React 19.1.0 and NestJS 11.1.3 applications for production
# Implements ARM64-specific optimizations and performance tuning
#
# Usage: ./production_optimizer.sh [--dry-run] [--project-type TYPE] [--optimization-level LEVEL]
# 
# Prerequisites:
# - Node.js 20 LTS installed via NVM
# - npm 10+ with proper configuration
# - Built application ready for optimization
# - Sufficient disk space for optimization process
#
# Features:
# - React bundle optimization with Vite 7.0.4
# - NestJS production build optimization
# - ARM64-specific performance tuning
# - Asset compression and minification
# - Tree shaking and dead code elimination
# - Source map optimization
# - Memory usage optimization for Pi 5
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/production_optimizer.log"
DRY_RUN=false
PROJECT_TYPE="auto"
PROJECT_PATH="$(pwd)"
OPTIMIZATION_LEVEL="standard"
ENABLE_COMPRESSION=true
ENABLE_TREE_SHAKING=true
ENABLE_MINIFICATION=true
GENERATE_SOURCEMAPS=false
ARM64_OPTIMIZATIONS=true
MAX_MEMORY="2048"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --project-type)
            PROJECT_TYPE="$2"
            shift 2
            ;;
        --project-path)
            PROJECT_PATH="$2"
            shift 2
            ;;
        --optimization-level)
            OPTIMIZATION_LEVEL="$2"
            shift 2
            ;;
        --no-compression)
            ENABLE_COMPRESSION=false
            shift
            ;;
        --no-tree-shaking)
            ENABLE_TREE_SHAKING=false
            shift
            ;;
        --no-minification)
            ENABLE_MINIFICATION=false
            shift
            ;;
        --sourcemaps)
            GENERATE_SOURCEMAPS=true
            shift
            ;;
        --no-arm64-opts)
            ARM64_OPTIMIZATIONS=false
            shift
            ;;
        --max-memory)
            MAX_MEMORY="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--project-type TYPE] [--optimization-level LEVEL]"
            echo "Optimizes applications for production deployment on Raspberry Pi 5"
            echo ""
            echo "Options:"
            echo "  --dry-run                Show what would be done without making changes"
            echo "  --project-type TYPE      Project type: react, nestjs, auto (default: auto)"
            echo "  --project-path PATH      Project directory path (default: current directory)"
            echo "  --optimization-level L   Optimization level: basic, standard, aggressive (default: standard)"
            echo "  --no-compression         Skip asset compression"
            echo "  --no-tree-shaking        Skip tree shaking optimization"
            echo "  --no-minification        Skip code minification"
            echo "  --sourcemaps             Generate source maps for production"
            echo "  --no-arm64-opts          Skip ARM64-specific optimizations"
            echo "  --max-memory SIZE        Maximum memory for build process (default: 2048MB)"
            echo "  -h, --help               Show this help message"
            echo ""
            echo "Project Types:"
            echo "  react                    React 19.1.0 + Vite 7.0.4 project"
            echo "  nestjs                   NestJS 11.1.3 + TypeScript 5.8.3 project"
            echo "  auto                     Auto-detect project type (default)"
            echo ""
            echo "Optimization Levels:"
            echo "  basic                    Basic optimizations (fast build)"
            echo "  standard                 Standard optimizations (balanced)"
            echo "  aggressive               Maximum optimizations (slower build)"
            echo ""
            echo "Examples:"
            echo "  $0 --project-type react --optimization-level aggressive"
            echo "  $0 --project-type nestjs --no-sourcemaps"
            echo "  $0 --optimization-level basic --max-memory 1024"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Node.js
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        exit 1
    fi
    
    local node_version
    node_version=$(node --version | sed 's/v//')
    local node_major_version
    node_major_version=$(echo "$node_version" | cut -d. -f1)
    
    if [[ "$node_major_version" -lt 18 ]]; then
        log_error "Node.js version 18+ required, found: v$node_version"
        exit 1
    fi
    
    log_info "Node.js version: v$node_version ✓"
    
    # Check npm
    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not available"
        exit 1
    fi
    
    local npm_version
    npm_version=$(npm --version)
    log_info "npm version: v$npm_version ✓"
    
    # Check project directory
    if [[ ! -d "$PROJECT_PATH" ]]; then
        log_error "Project directory does not exist: $PROJECT_PATH"
        exit 1
    fi
    
    # Check package.json
    if [[ ! -f "$PROJECT_PATH/package.json" ]]; then
        log_error "package.json not found in: $PROJECT_PATH"
        exit 1
    fi
    
    # Change to project directory
    cd "$PROJECT_PATH"
    log_info "Working in project directory: $(pwd)"
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" == "aarch64" ]]; then
        log_info "ARM64 architecture detected - applying Pi 5 optimizations"
    else
        log_warning "Not running on ARM64 architecture: $(uname -m)"
        ARM64_OPTIMIZATIONS=false
    fi
    
    # Check available memory
    local available_memory
    available_memory=$(free -m | awk 'NR==2{printf "%.0f", $7}')
    log_info "Available memory: ${available_memory}MB"
    
    if [[ "$available_memory" -lt 1024 ]]; then
        log_warning "Low memory detected, reducing optimization settings"
        MAX_MEMORY="1024"
    fi
    
    log_info "Prerequisites check completed"
}

# Auto-detect project type
detect_project_type() {
    if [[ "$PROJECT_TYPE" != "auto" ]]; then
        log_info "Project type specified: $PROJECT_TYPE"
        return 0
    fi
    
    log_info "Auto-detecting project type..."
    
    # Check for React project indicators
    if grep -q '"react"' package.json 2>/dev/null; then
        if grep -q '"vite"' package.json 2>/dev/null; then
            PROJECT_TYPE="react"
            log_info "Detected React project with Vite"
            return 0
        fi
    fi
    
    # Check for NestJS project indicators
    if grep -q '"@nestjs/core"' package.json 2>/dev/null; then
        PROJECT_TYPE="nestjs"
        log_info "Detected NestJS project"
        return 0
    fi
    
    # Check for build scripts
    if grep -q '"vite build"' package.json 2>/dev/null; then
        PROJECT_TYPE="react"
        log_info "Detected React/Vite project from build script"
        return 0
    fi
    
    if grep -q '"nest build"' package.json 2>/dev/null; then
        PROJECT_TYPE="nestjs"
        log_info "Detected NestJS project from build script"
        return 0
    fi
    
    log_error "Could not auto-detect project type"
    log_error "Please specify --project-type react or --project-type nestjs"
    exit 1
}

# Set optimization parameters based on level
configure_optimization_level() {
    log_info "Configuring optimization level: $OPTIMIZATION_LEVEL"
    
    case "$OPTIMIZATION_LEVEL" in
        "basic")
            ENABLE_COMPRESSION=false
            ENABLE_TREE_SHAKING=true
            ENABLE_MINIFICATION=true
            GENERATE_SOURCEMAPS=false
            ;;
        "standard")
            ENABLE_COMPRESSION=true
            ENABLE_TREE_SHAKING=true
            ENABLE_MINIFICATION=true
            GENERATE_SOURCEMAPS=false
            ;;
        "aggressive")
            ENABLE_COMPRESSION=true
            ENABLE_TREE_SHAKING=true
            ENABLE_MINIFICATION=true
            GENERATE_SOURCEMAPS=false
            ;;
        *)
            log_error "Unknown optimization level: $OPTIMIZATION_LEVEL"
            exit 1
            ;;
    esac
    
    log_info "Optimization settings configured"
}

# Optimize React production build
optimize_react_build() {
    log_info "Optimizing React production build..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would optimize React build"
        return 0
    fi
    
    # Set Node.js memory limit for ARM64
    if [[ "$ARM64_OPTIMIZATIONS" == "true" ]]; then
        export NODE_OPTIONS="--max-old-space-size=$MAX_MEMORY"
        log_info "Set Node.js memory limit: ${MAX_MEMORY}MB"
    fi
    
    # Create optimized Vite configuration
    create_optimized_vite_config
    
    # Clean previous build
    if [[ -d "dist" ]]; then
        rm -rf dist
        log_info "Cleaned previous build"
    fi
    
    # Run optimized build
    log_info "Running optimized production build..."
    local build_start
    build_start=$(date +%s)
    
    if npm run build; then
        local build_end
        build_end=$(date +%s)
        local build_duration=$((build_end - build_start))
        log_success "React build completed in ${build_duration}s"
    else
        log_error "React build failed"
        return 1
    fi
    
    # Post-build optimizations
    optimize_react_assets
    
    # Generate build report
    generate_react_build_report
}

# Create optimized Vite configuration
create_optimized_vite_config() {
    log_info "Creating optimized Vite configuration..."
    
    # Backup existing config
    if [[ -f "vite.config.ts" ]]; then
        cp vite.config.ts "vite.config.ts.backup.$(date +%Y%m%d_%H%M%S)"
    elif [[ -f "vite.config.js" ]]; then
        cp vite.config.js "vite.config.js.backup.$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Create optimized configuration
    cat > vite.config.production.ts << EOF
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    target: 'es2020',
    outDir: 'dist',
    assetsDir: 'assets',
    sourcemap: $GENERATE_SOURCEMAPS,
    minify: $(if [[ "$ENABLE_MINIFICATION" == "true" ]]; then echo "'terser'"; else echo "false"; fi),
    cssMinify: $ENABLE_MINIFICATION,
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          utils: ['lodash', 'axios', 'date-fns']
        },
        chunkFileNames: 'assets/js/[name]-[hash].js',
        entryFileNames: 'assets/js/[name]-[hash].js',
        assetFileNames: 'assets/[ext]/[name]-[hash].[ext]'
      },
      treeshake: $ENABLE_TREE_SHAKING
    },
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true,
        pure_funcs: ['console.log', 'console.info', 'console.debug']
      },
      mangle: {
        safari10: true
      }
    },
    chunkSizeWarningLimit: 1000,
    // ARM64 optimizations
    reportCompressedSize: false,
    write: true
  },
  esbuild: {
    target: 'es2020',
    drop: ['console', 'debugger'],
    legalComments: 'none'
  },
  optimizeDeps: {
    include: ['react', 'react-dom'],
    esbuildOptions: {
      target: 'es2020'
    }
  }
})
EOF
    
    log_success "Optimized Vite configuration created"
}

# Optimize React assets
optimize_react_assets() {
    log_info "Optimizing React build assets..."
    
    if [[ ! -d "dist" ]]; then
        log_error "Build directory not found"
        return 1
    fi
    
    # Compress assets if enabled
    if [[ "$ENABLE_COMPRESSION" == "true" ]]; then
        compress_assets "dist"
    fi
    
    # Optimize images
    optimize_images "dist"
    
    # Generate asset manifest
    generate_asset_manifest "dist"
    
    log_success "React assets optimized"
}

# Optimize NestJS production build
optimize_nestjs_build() {
    log_info "Optimizing NestJS production build..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would optimize NestJS build"
        return 0
    fi
    
    # Set Node.js memory limit for ARM64
    if [[ "$ARM64_OPTIMIZATIONS" == "true" ]]; then
        export NODE_OPTIONS="--max-old-space-size=$MAX_MEMORY"
        log_info "Set Node.js memory limit: ${MAX_MEMORY}MB"
    fi
    
    # Create optimized TypeScript configuration
    create_optimized_tsconfig
    
    # Clean previous build
    if [[ -d "dist" ]]; then
        rm -rf dist
        log_info "Cleaned previous build"
    fi
    
    # Run optimized build
    log_info "Running optimized production build..."
    local build_start
    build_start=$(date +%s)
    
    if npm run build; then
        local build_end
        build_end=$(date +%s)
        local build_duration=$((build_end - build_start))
        log_success "NestJS build completed in ${build_duration}s"
    else
        log_error "NestJS build failed"
        return 1
    fi
    
    # Post-build optimizations
    optimize_nestjs_assets
    
    # Generate build report
    generate_nestjs_build_report
}

# Create optimized TypeScript configuration
create_optimized_tsconfig() {
    log_info "Creating optimized TypeScript configuration..."
    
    # Backup existing config
    if [[ -f "tsconfig.build.json" ]]; then
        cp tsconfig.build.json "tsconfig.build.json.backup.$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Create optimized build configuration
    cat > tsconfig.production.json << EOF
{
  "extends": "./tsconfig.json",
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "lib": ["ES2020"],
    "outDir": "./dist",
    "rootDir": "./src",
    "removeComments": true,
    "emitDecoratorMetadata": true,
    "experimentalDecorators": true,
    "allowSyntheticDefaultImports": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "noFallthroughCasesInSwitch": true,
    "declaration": false,
    "declarationMap": false,
    "sourceMap": $GENERATE_SOURCEMAPS,
    "incremental": true,
    "tsBuildInfoFile": "./dist/.tsbuildinfo"
  },
  "include": ["src/**/*"],
  "exclude": [
    "node_modules",
    "dist",
    "test",
    "**/*.spec.ts",
    "**/*.test.ts"
  ]
}
EOF
    
    log_success "Optimized TypeScript configuration created"
}

# Optimize NestJS assets
optimize_nestjs_assets() {
    log_info "Optimizing NestJS build assets..."
    
    if [[ ! -d "dist" ]]; then
        log_error "Build directory not found"
        return 1
    fi
    
    # Remove source maps if not needed
    if [[ "$GENERATE_SOURCEMAPS" != "true" ]]; then
        find dist -name "*.map" -delete
        log_info "Removed source maps"
    fi
    
    # Compress JavaScript files if enabled
    if [[ "$ENABLE_COMPRESSION" == "true" ]]; then
        compress_assets "dist"
    fi
    
    # Generate asset manifest
    generate_asset_manifest "dist"
    
    log_success "NestJS assets optimized"
}

# Compress assets using gzip
compress_assets() {
    local build_dir=$1
    
    if [[ "$ENABLE_COMPRESSION" != "true" ]]; then
        return 0
    fi
    
    log_info "Compressing assets in: $build_dir"
    
    # Compress JavaScript files
    find "$build_dir" -name "*.js" -type f | while read -r js_file; do
        if [[ ! -f "${js_file}.gz" ]]; then
            gzip -c "$js_file" > "${js_file}.gz"
            log_info "Compressed: $(basename "$js_file")"
        fi
    done
    
    # Compress CSS files
    find "$build_dir" -name "*.css" -type f | while read -r css_file; do
        if [[ ! -f "${css_file}.gz" ]]; then
            gzip -c "$css_file" > "${css_file}.gz"
            log_info "Compressed: $(basename "$css_file")"
        fi
    done
    
    # Compress HTML files
    find "$build_dir" -name "*.html" -type f | while read -r html_file; do
        if [[ ! -f "${html_file}.gz" ]]; then
            gzip -c "$html_file" > "${html_file}.gz"
            log_info "Compressed: $(basename "$html_file")"
        fi
    done
    
    log_success "Asset compression completed"
}

# Optimize images
optimize_images() {
    local build_dir=$1
    
    log_info "Optimizing images in: $build_dir"
    
    # Check if imagemin is available
    if ! command -v imagemin >/dev/null 2>&1; then
        log_warning "imagemin not found, skipping image optimization"
        log_info "Install with: npm install -g imagemin-cli"
        return 0
    fi
    
    # Optimize PNG files
    find "$build_dir" -name "*.png" -type f | while read -r png_file; do
        local original_size
        original_size=$(stat -c%s "$png_file")
        
        if imagemin "$png_file" --out-dir="$(dirname "$png_file")" --plugin=pngquant; then
            local new_size
            new_size=$(stat -c%s "$png_file")
            local savings=$((original_size - new_size))
            log_info "Optimized PNG: $(basename "$png_file") (saved ${savings} bytes)"
        fi
    done
    
    # Optimize JPEG files
    find "$build_dir" -name "*.jpg" -o -name "*.jpeg" -type f | while read -r jpg_file; do
        local original_size
        original_size=$(stat -c%s "$jpg_file")
        
        if imagemin "$jpg_file" --out-dir="$(dirname "$jpg_file")" --plugin=mozjpeg; then
            local new_size
            new_size=$(stat -c%s "$jpg_file")
            local savings=$((original_size - new_size))
            log_info "Optimized JPEG: $(basename "$jpg_file") (saved ${savings} bytes)"
        fi
    done
    
    log_success "Image optimization completed"
}

# Generate asset manifest
generate_asset_manifest() {
    local build_dir=$1
    
    log_info "Generating asset manifest..."
    
    local manifest_file="$build_dir/asset-manifest.json"
    
    {
        echo "{"
        echo "  \"generated\": \"$(date -Iseconds)\","
        echo "  \"build_info\": {"
        echo "    \"project_type\": \"$PROJECT_TYPE\","
        echo "    \"optimization_level\": \"$OPTIMIZATION_LEVEL\","
        echo "    \"compression_enabled\": $ENABLE_COMPRESSION,"
        echo "    \"minification_enabled\": $ENABLE_MINIFICATION,"
        echo "    \"tree_shaking_enabled\": $ENABLE_TREE_SHAKING,"
        echo "    \"sourcemaps_enabled\": $GENERATE_SOURCEMAPS,"
        echo "    \"arm64_optimizations\": $ARM64_OPTIMIZATIONS"
        echo "  },"
        echo "  \"assets\": {"
        
        local first=true
        find "$build_dir" -type f \( -name "*.js" -o -name "*.css" -o -name "*.html" \) | while read -r asset; do
            local relative_path
            relative_path=$(realpath --relative-to="$build_dir" "$asset")
            local file_size
            file_size=$(stat -c%s "$asset")
            
            if [[ "$first" != "true" ]]; then
                echo ","
            fi
            echo -n "    \"$relative_path\": {\"size\": $file_size}"
            first=false
        done
        
        echo ""
        echo "  }"
        echo "}"
    } > "$manifest_file"
    
    log_success "Asset manifest generated: $manifest_file"
}

# Generate React build report
generate_react_build_report() {
    log_info "Generating React build report..."
    
    local report_file="build-report-react-$(date +%Y%m%d_%H%M%S).txt"
    
    {
        echo "=== React Production Build Report ==="
        echo "Date: $(date)"
        echo "Project Type: $PROJECT_TYPE"
        echo "Optimization Level: $OPTIMIZATION_LEVEL"
        echo "ARM64 Optimizations: $ARM64_OPTIMIZATIONS"
        echo ""
        
        echo "=== Build Configuration ==="
        echo "Compression: $ENABLE_COMPRESSION"
        echo "Minification: $ENABLE_MINIFICATION"
        echo "Tree Shaking: $ENABLE_TREE_SHAKING"
        echo "Source Maps: $GENERATE_SOURCEMAPS"
        echo "Max Memory: ${MAX_MEMORY}MB"
        echo ""
        
        echo "=== Build Output Analysis ==="
        if [[ -d "dist" ]]; then
            echo "Build directory: dist/"
            echo "Total size: $(du -sh dist | cut -f1)"
            echo "File count: $(find dist -type f | wc -l)"
            echo ""
            
            echo "=== Asset Breakdown ==="
            echo "JavaScript files:"
            find dist -name "*.js" -type f -exec du -h {} \; | sort -hr | head -10
            echo ""
            echo "CSS files:"
            find dist -name "*.css" -type f -exec du -h {} \; | sort -hr | head -5
            echo ""
            echo "Image files:"
            find dist -name "*.png" -o -name "*.jpg" -o -name "*.jpeg" -o -name "*.svg" -type f -exec du -h {} \; | sort -hr | head -5
        fi
        
        echo ""
        echo "=== Optimization Results ==="
        if [[ "$ENABLE_COMPRESSION" == "true" ]]; then
            echo "Compressed files:"
            find dist -name "*.gz" -type f | wc -l | xargs echo "  Gzipped assets:"
        fi
        
        echo ""
        echo "=== Performance Recommendations ==="
        echo "1. Serve compressed assets with proper headers"
        echo "2. Enable HTTP/2 for better multiplexing"
        echo "3. Implement proper caching strategies"
        echo "4. Consider using a CDN for static assets"
        echo "5. Monitor bundle sizes in CI/CD pipeline"
        
    } > "$report_file"
    
    log_success "React build report generated: $report_file"
}

# Generate NestJS build report
generate_nestjs_build_report() {
    log_info "Generating NestJS build report..."
    
    local report_file="build-report-nestjs-$(date +%Y%m%d_%H%M%S).txt"
    
    {
        echo "=== NestJS Production Build Report ==="
        echo "Date: $(date)"
        echo "Project Type: $PROJECT_TYPE"
        echo "Optimization Level: $OPTIMIZATION_LEVEL"
        echo "ARM64 Optimizations: $ARM64_OPTIMIZATIONS"
        echo ""
        
        echo "=== Build Configuration ==="
        echo "Compression: $ENABLE_COMPRESSION"
        echo "Source Maps: $GENERATE_SOURCEMAPS"
        echo "Max Memory: ${MAX_MEMORY}MB"
        echo ""
        
        echo "=== Build Output Analysis ==="
        if [[ -d "dist" ]]; then
            echo "Build directory: dist/"
            echo "Total size: $(du -sh dist | cut -f1)"
            echo "File count: $(find dist -type f | wc -l)"
            echo ""
            
            echo "=== Main Application Files ==="
            if [[ -f "dist/main.js" ]]; then
                echo "Main application: $(du -h dist/main.js | cut -f1)"
            fi
            
            echo "JavaScript files (top 10):"
            find dist -name "*.js" -type f -exec du -h {} \; | sort -hr | head -10
        fi
        
        echo ""
        echo "=== Optimization Results ==="
        if [[ "$ENABLE_COMPRESSION" == "true" ]]; then
            echo "Compressed files:"
            find dist -name "*.gz" -type f | wc -l | xargs echo "  Gzipped assets:"
        fi
        
        echo ""
        echo "=== Deployment Recommendations ==="
        echo "1. Use PM2 for process management"
        echo "2. Configure proper environment variables"
        echo "3. Set up health checks and monitoring"
        echo "4. Implement graceful shutdown handling"
        echo "5. Configure log rotation and management"
        
    } > "$report_file"
    
    log_success "NestJS build report generated: $report_file"
}

# Execute optimization based on project type
execute_optimization() {
    case "$PROJECT_TYPE" in
        "react")
            optimize_react_build
            ;;
        "nestjs")
            optimize_nestjs_build
            ;;
        *)
            log_error "Unknown project type: $PROJECT_TYPE"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== Production Optimization Summary ==="
    log_info "Project Type: $PROJECT_TYPE"
    log_info "Project Path: $PROJECT_PATH"
    log_info "Optimization Level: $OPTIMIZATION_LEVEL"
    log_info "ARM64 Optimizations: $ARM64_OPTIMIZATIONS"
    log_info ""
    
    log_info "=== Optimization Settings ==="
    log_info "Compression: $ENABLE_COMPRESSION"
    log_info "Minification: $ENABLE_MINIFICATION"
    log_info "Tree Shaking: $ENABLE_TREE_SHAKING"
    log_info "Source Maps: $GENERATE_SOURCEMAPS"
    log_info "Max Memory: ${MAX_MEMORY}MB"
    log_info ""
    
    if [[ -d "dist" ]]; then
        local build_size
        build_size=$(du -sh dist | cut -f1)
        local file_count
        file_count=$(find dist -type f | wc -l)
        
        log_info "=== Build Results ==="
        log_info "Build directory: dist/"
        log_info "Total size: $build_size"
        log_info "Files generated: $file_count"
        
        if [[ "$ENABLE_COMPRESSION" == "true" ]]; then
            local compressed_count
            compressed_count=$(find dist -name "*.gz" -type f | wc -l)
            log_info "Compressed files: $compressed_count"
        fi
    fi
    
    log_info ""
    log_info "=== Next Steps ==="
    case "$PROJECT_TYPE" in
        "react")
            log_info "1. Deploy dist/ directory to web server"
            log_info "2. Configure web server for SPA routing"
            log_info "3. Set up proper caching headers"
            log_info "4. Enable gzip compression on server"
            ;;
        "nestjs")
            log_info "1. Deploy dist/ directory to production server"
            log_info "2. Configure PM2 ecosystem file"
            log_info "3. Set up environment variables"
            log_info "4. Configure reverse proxy (nginx)"
            ;;
    esac
    
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting production optimization..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Optimization level: $OPTIMIZATION_LEVEL"
    
    check_prerequisites
    detect_project_type
    configure_optimization_level
    execute_optimization
    
    log_success "Production optimization completed successfully!"
    display_summary
}

# Execute main function
main "$@"