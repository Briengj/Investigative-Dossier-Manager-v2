#!/bin/bash
#
# Environment Configuration Switching Utilities for Raspberry Pi 5 Deployment
# Manages environment configurations for React 19.1.0 and NestJS 11.1.3 applications
# Handles development, staging, and production environment switching
#
# Usage: ./environment_switcher.sh [--dry-run] [--environment ENV] [--project-type TYPE]
# 
# Prerequisites:
# - Node.js 20 LTS installed via NVM
# - Environment configuration files (.env.*)
# - Project with proper environment variable setup
# - Write access to configuration files
#
# Features:
# - Environment configuration validation
# - Secure environment variable management
# - Configuration backup and restore
# - Environment-specific service configuration
# - Database connection switching
# - API endpoint configuration
# - SSL/TLS certificate management
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/environment_switcher.log"
DRY_RUN=false
TARGET_ENVIRONMENT=""
PROJECT_TYPE="auto"
PROJECT_PATH="$(pwd)"
BACKUP_CONFIGS=true
VALIDATE_CONFIG=true
RESTART_SERVICES=false
CONFIG_DIR="config"

# Environment configurations
declare -A ENV_FILES=(
    ["development"]=".env.development"
    ["staging"]=".env.staging"
    ["production"]=".env.production"
    ["testing"]=".env.test"
)

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --environment)
            TARGET_ENVIRONMENT="$2"
            shift 2
            ;;
        --project-type)
            PROJECT_TYPE="$2"
            shift 2
            ;;
        --project-path)
            PROJECT_PATH="$2"
            shift 2
            ;;
        --no-backup)
            BACKUP_CONFIGS=false
            shift
            ;;
        --no-validation)
            VALIDATE_CONFIG=false
            shift
            ;;
        --restart-services)
            RESTART_SERVICES=true
            shift
            ;;
        --config-dir)
            CONFIG_DIR="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--environment ENV] [--project-type TYPE]"
            echo "Switches between different environment configurations"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --environment ENV      Target environment: development, staging, production, testing"
            echo "  --project-type TYPE    Project type: react, nestjs, auto (default: auto)"
            echo "  --project-path PATH    Project directory path (default: current directory)"
            echo "  --no-backup            Skip configuration backup"
            echo "  --no-validation        Skip configuration validation"
            echo "  --restart-services     Restart services after environment switch"
            echo "  --config-dir DIR       Configuration directory (default: config)"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Environments:"
            echo "  development            Development environment with debug features"
            echo "  staging                Staging environment for testing"
            echo "  production             Production environment with optimizations"
            echo "  testing                Testing environment for automated tests"
            echo ""
            echo "Project Types:"
            echo "  react                  React 19.1.0 + Vite 7.0.4 project"
            echo "  nestjs                 NestJS 11.1.3 + TypeScript 5.8.3 project"
            echo "  auto                   Auto-detect project type (default)"
            echo ""
            echo "Examples:"
            echo "  $0 --environment production"
            echo "  $0 --environment staging --restart-services"
            echo "  $0 --environment development --project-type nestjs"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Validate environment parameter
if [[ -z "$TARGET_ENVIRONMENT" ]]; then
    echo "Error: Environment is required" >&2
    echo "Use: $0 --environment ENV" >&2
    echo "Valid environments: development, staging, production, testing" >&2
    exit 1
fi

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check project directory
    if [[ ! -d "$PROJECT_PATH" ]]; then
        log_error "Project directory does not exist: $PROJECT_PATH"
        exit 1
    fi
    
    # Check package.json
    if [[ ! -f "$PROJECT_PATH/package.json" ]]; then
        log_error "package.json not found in: $PROJECT_PATH"
        exit 1
    fi
    
    # Change to project directory
    cd "$PROJECT_PATH"
    log_info "Working in project directory: $(pwd)"
    
    # Validate target environment
    if [[ ! "${ENV_FILES[$TARGET_ENVIRONMENT]:-}" ]]; then
        log_error "Invalid environment: $TARGET_ENVIRONMENT"
        log_error "Valid environments: ${!ENV_FILES[*]}"
        exit 1
    fi
    
    # Check if target environment file exists
    local target_env_file="${ENV_FILES[$TARGET_ENVIRONMENT]}"
    if [[ ! -f "$target_env_file" ]]; then
        log_error "Environment file not found: $target_env_file"
        log_error "Create the environment file first"
        exit 1
    fi
    
    log_info "Target environment file: $target_env_file ✓"
    
    # Create config directory if it doesn't exist
    if [[ ! -d "$CONFIG_DIR" ]]; then
        mkdir -p "$CONFIG_DIR"
        log_info "Created config directory: $CONFIG_DIR"
    fi
    
    log_info "Prerequisites check completed"
}

# Auto-detect project type
detect_project_type() {
    if [[ "$PROJECT_TYPE" != "auto" ]]; then
        log_info "Project type specified: $PROJECT_TYPE"
        return 0
    fi
    
    log_info "Auto-detecting project type..."
    
    # Check for React project indicators
    if grep -q '"react"' package.json 2>/dev/null; then
        if grep -q '"vite"' package.json 2>/dev/null; then
            PROJECT_TYPE="react"
            log_info "Detected React project with Vite"
            return 0
        fi
    fi
    
    # Check for NestJS project indicators
    if grep -q '"@nestjs/core"' package.json 2>/dev/null; then
        PROJECT_TYPE="nestjs"
        log_info "Detected NestJS project"
        return 0
    fi
    
    # Default to generic Node.js project
    PROJECT_TYPE="nodejs"
    log_info "Detected generic Node.js project"
}

# Backup current configuration
backup_current_config() {
    if [[ "$BACKUP_CONFIGS" != "true" ]]; then
        log_info "Skipping configuration backup (--no-backup specified)"
        return 0
    fi
    
    log_info "Backing up current configuration..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would backup current configuration"
        return 0
    fi
    
    local backup_dir="$CONFIG_DIR/backups/$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$backup_dir"
    
    # Backup .env file if it exists
    if [[ -f ".env" ]]; then
        cp ".env" "$backup_dir/.env"
        log_info "Backed up .env to $backup_dir"
    fi
    
    # Backup environment-specific files
    for env_file in "${ENV_FILES[@]}"; do
        if [[ -f "$env_file" ]]; then
            cp "$env_file" "$backup_dir/"
            log_info "Backed up $env_file to $backup_dir"
        fi
    done
    
    # Backup project-specific configuration files
    case "$PROJECT_TYPE" in
        "react")
            backup_react_configs "$backup_dir"
            ;;
        "nestjs")
            backup_nestjs_configs "$backup_dir"
            ;;
    esac
    
    log_success "Configuration backup completed: $backup_dir"
}

# Backup React-specific configurations
backup_react_configs() {
    local backup_dir=$1
    
    # Backup Vite configuration
    if [[ -f "vite.config.ts" ]]; then
        cp "vite.config.ts" "$backup_dir/"
    elif [[ -f "vite.config.js" ]]; then
        cp "vite.config.js" "$backup_dir/"
    fi
    
    # Backup public directory configuration
    if [[ -f "public/config.js" ]]; then
        cp "public/config.js" "$backup_dir/"
    fi
}

# Backup NestJS-specific configurations
backup_nestjs_configs() {
    local backup_dir=$1
    
    # Backup NestJS configuration
    if [[ -f "nest-cli.json" ]]; then
        cp "nest-cli.json" "$backup_dir/"
    fi
    
    # Backup PM2 ecosystem file
    if [[ -f "ecosystem.config.js" ]]; then
        cp "ecosystem.config.js" "$backup_dir/"
    fi
    
    # Backup TypeScript configuration
    if [[ -f "tsconfig.json" ]]; then
        cp "tsconfig.json" "$backup_dir/"
    fi
}

# Validate environment configuration
validate_environment_config() {
    if [[ "$VALIDATE_CONFIG" != "true" ]]; then
        log_info "Skipping configuration validation (--no-validation specified)"
        return 0
    fi
    
    log_info "Validating environment configuration..."
    
    local target_env_file="${ENV_FILES[$TARGET_ENVIRONMENT]}"
    local validation_errors=0
    
    # Check required variables based on project type
    case "$PROJECT_TYPE" in
        "react")
            validation_errors=$(validate_react_config "$target_env_file")
            ;;
        "nestjs")
            validation_errors=$(validate_nestjs_config "$target_env_file")
            ;;
        *)
            validation_errors=$(validate_generic_config "$target_env_file")
            ;;
    esac
    
    if [[ $validation_errors -gt 0 ]]; then
        log_error "Configuration validation failed with $validation_errors errors"
        return 1
    fi
    
    log_success "Environment configuration validation passed"
    return 0
}

# Validate React configuration
validate_react_config() {
    local env_file=$1
    local errors=0
    
    log_info "Validating React configuration in: $env_file"
    
    # Required React environment variables
    local required_vars=(
        "VITE_APP_TITLE"
        "VITE_API_URL"
        "VITE_APP_ENV"
    )
    
    for var in "${required_vars[@]}"; do
        if ! grep -q "^$var=" "$env_file"; then
            log_error "Missing required variable: $var"
            ((errors++))
        fi
    done
    
    # Environment-specific validations
    case "$TARGET_ENVIRONMENT" in
        "production")
            if grep -q "VITE_DEBUG=true" "$env_file"; then
                log_warning "Debug mode enabled in production environment"
            fi
            if grep -q "localhost" "$env_file"; then
                log_warning "Localhost URLs found in production configuration"
            fi
            ;;
        "development")
            if ! grep -q "VITE_DEBUG=true" "$env_file"; then
                log_warning "Debug mode not enabled in development environment"
            fi
            ;;
    esac
    
    echo $errors
}

# Validate NestJS configuration
validate_nestjs_config() {
    local env_file=$1
    local errors=0
    
    log_info "Validating NestJS configuration in: $env_file"
    
    # Required NestJS environment variables
    local required_vars=(
        "NODE_ENV"
        "PORT"
        "DB_HOST"
        "DB_PORT"
        "DB_NAME"
        "DB_USER"
        "JWT_SECRET"
    )
    
    for var in "${required_vars[@]}"; do
        if ! grep -q "^$var=" "$env_file"; then
            log_error "Missing required variable: $var"
            ((errors++))
        fi
    done
    
    # Environment-specific validations
    case "$TARGET_ENVIRONMENT" in
        "production")
            if grep -q "NODE_ENV=development" "$env_file"; then
                log_error "NODE_ENV should be 'production' in production environment"
                ((errors++))
            fi
            if grep -q "LOG_LEVEL=debug" "$env_file"; then
                log_warning "Debug logging enabled in production environment"
            fi
            # Check for secure JWT secret
            local jwt_secret
            jwt_secret=$(grep "^JWT_SECRET=" "$env_file" | cut -d= -f2)
            if [[ ${#jwt_secret} -lt 32 ]]; then
                log_error "JWT_SECRET should be at least 32 characters in production"
                ((errors++))
            fi
            ;;
        "development")
            if ! grep -q "NODE_ENV=development" "$env_file"; then
                log_warning "NODE_ENV should be 'development' in development environment"
            fi
            ;;
    esac
    
    echo $errors
}

# Validate generic configuration
validate_generic_config() {
    local env_file=$1
    local errors=0
    
    log_info "Validating generic configuration in: $env_file"
    
    # Basic validation - check for empty values
    while IFS= read -r line; do
        if [[ "$line" =~ ^[A-Z_]+=$ ]]; then
            local var_name
            var_name=$(echo "$line" | cut -d= -f1)
            log_warning "Empty value for variable: $var_name"
        fi
    done < "$env_file"
    
    echo $errors
}

# Switch environment configuration
switch_environment() {
    log_info "Switching to environment: $TARGET_ENVIRONMENT"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would switch to $TARGET_ENVIRONMENT environment"
        return 0
    fi
    
    local target_env_file="${ENV_FILES[$TARGET_ENVIRONMENT]}"
    
    # Copy target environment file to .env
    if cp "$target_env_file" ".env"; then
        log_success "Switched to $TARGET_ENVIRONMENT environment"
        log_info "Active configuration: .env (copied from $target_env_file)"
    else
        log_error "Failed to switch environment configuration"
        return 1
    fi
    
    # Update project-specific configurations
    case "$PROJECT_TYPE" in
        "react")
            update_react_config
            ;;
        "nestjs")
            update_nestjs_config
            ;;
    esac
    
    # Create environment indicator file
    echo "$TARGET_ENVIRONMENT" > "$CONFIG_DIR/current_environment"
    log_info "Environment indicator updated: $CONFIG_DIR/current_environment"
}

# Update React-specific configuration
update_react_config() {
    log_info "Updating React-specific configuration..."
    
    # Update package.json scripts if needed
    case "$TARGET_ENVIRONMENT" in
        "production")
            npm pkg set scripts.start="vite preview"
            ;;
        "development")
            npm pkg set scripts.start="vite"
            ;;
    esac
    
    # Update public configuration if it exists
    if [[ -f "public/config.js" ]]; then
        update_public_config
    fi
    
    log_info "React configuration updated"
}

# Update NestJS-specific configuration
update_nestjs_config() {
    log_info "Updating NestJS-specific configuration..."
    
    # Update PM2 ecosystem configuration if it exists
    if [[ -f "ecosystem.config.js" ]]; then
        update_pm2_config
    fi
    
    # Update package.json scripts
    case "$TARGET_ENVIRONMENT" in
        "production")
            npm pkg set scripts.start="node dist/main.js"
            ;;
        "development")
            npm pkg set scripts.start="nest start --watch"
            ;;
    esac
    
    log_info "NestJS configuration updated"
}

# Update public configuration for React
update_public_config() {
    log_info "Updating public configuration..."
    
    # Source environment variables
    set -a
    source .env
    set +a
    
    # Create public config file
    cat > public/config.js << EOF
window.APP_CONFIG = {
  API_URL: '${VITE_API_URL:-}',
  APP_ENV: '${VITE_APP_ENV:-}',
  APP_TITLE: '${VITE_APP_TITLE:-}',
  DEBUG: ${VITE_DEBUG:-false}
};
EOF
    
    log_info "Public configuration updated"
}

# Update PM2 ecosystem configuration
update_pm2_config() {
    log_info "Updating PM2 ecosystem configuration..."
    
    # Backup current ecosystem file
    if [[ -f "ecosystem.config.js" ]]; then
        cp "ecosystem.config.js" "ecosystem.config.js.backup.$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Update ecosystem file with environment-specific settings
    case "$TARGET_ENVIRONMENT" in
        "production")
            update_pm2_production_config
            ;;
        "staging")
            update_pm2_staging_config
            ;;
        "development")
            update_pm2_development_config
            ;;
    esac
    
    log_info "PM2 ecosystem configuration updated"
}

# Update PM2 production configuration
update_pm2_production_config() {
    local app_name
    app_name=$(node -p "require('./package.json').name" 2>/dev/null || echo "app")
    
    cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: '$app_name',
    script: 'dist/main.js',
    instances: 'max',
    exec_mode: 'cluster',
    watch: false,
    max_memory_restart: '512M',
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000,
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true,
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s',
    restart_delay: 4000
  }]
};
EOF
}

# Update PM2 staging configuration
update_pm2_staging_config() {
    local app_name
    app_name=$(node -p "require('./package.json').name" 2>/dev/null || echo "app")
    
    cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: '$app_name-staging',
    script: 'dist/main.js',
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '256M',
    env_staging: {
      NODE_ENV: 'staging',
      PORT: 3001,
    },
    error_file: './logs/staging-err.log',
    out_file: './logs/staging-out.log',
    log_file: './logs/staging-combined.log',
    time: true,
    autorestart: true,
    max_restarts: 5,
    min_uptime: '5s'
  }]
};
EOF
}

# Update PM2 development configuration
update_pm2_development_config() {
    local app_name
    app_name=$(node -p "require('./package.json').name" 2>/dev/null || echo "app")
    
    cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: '$app_name-dev',
    script: 'dist/main.js',
    instances: 1,
    exec_mode: 'fork',
    watch: true,
    max_memory_restart: '256M',
    env: {
      NODE_ENV: 'development',
      PORT: 3000,
    },
    error_file: './logs/dev-err.log',
    out_file: './logs/dev-out.log',
    log_file: './logs/dev-combined.log',
    time: true,
    ignore_watch: ['node_modules', 'logs'],
    watch_options: {
      followSymlinks: false
    }
  }]
};
EOF
}

# Restart services if requested
restart_services() {
    if [[ "$RESTART_SERVICES" != "true" ]]; then
        log_info "Skipping service restart (--restart-services not specified)"
        return 0
    fi
    
    log_info "Restarting services for environment: $TARGET_ENVIRONMENT"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would restart services"
        return 0
    fi
    
    case "$PROJECT_TYPE" in
        "nestjs")
            restart_nestjs_services
            ;;
        "react")
            log_info "React applications typically don't require service restart"
            ;;
    esac
}

# Restart NestJS services
restart_nestjs_services() {
    log_info "Restarting NestJS services..."
    
    # Check if PM2 is available and has running processes
    if command -v pm2 >/dev/null 2>&1; then
        local app_name
        app_name=$(node -p "require('./package.json').name" 2>/dev/null || echo "app")
        
        # Try to restart the application
        if pm2 restart "$app_name" 2>/dev/null; then
            log_success "Restarted PM2 process: $app_name"
        elif pm2 restart ecosystem.config.js 2>/dev/null; then
            log_success "Restarted PM2 processes from ecosystem file"
        else
            log_warning "No PM2 processes found to restart"
        fi
    else
        log_warning "PM2 not available - manual service restart required"
    fi
}

# Display current environment status
show_environment_status() {
    log_info "=== Environment Status ==="
    
    # Show current environment
    if [[ -f "$CONFIG_DIR/current_environment" ]]; then
        local current_env
        current_env=$(cat "$CONFIG_DIR/current_environment")
        log_info "Current environment: $current_env"
    else
        log_info "Current environment: Unknown"
    fi
    
    # Show active .env file info
    if [[ -f ".env" ]]; then
        local env_size
        env_size=$(wc -l < .env)
        log_info "Active .env file: $env_size lines"
        
        # Show key variables (without values for security)
        log_info "Key variables configured:"
        grep -E "^[A-Z_]+=" .env | cut -d= -f1 | head -10 | while read -r var; do
            log_info "  - $var"
        done
    else
        log_warning "No active .env file found"
    fi
    
    # Show available environment files
    log_info ""
    log_info "Available environment files:"
    for env in "${!ENV_FILES[@]}"; do
        local env_file="${ENV_FILES[$env]}"
        if [[ -f "$env_file" ]]; then
            local file_size
            file_size=$(wc -l < "$env_file")
            log_info "  - $env: $env_file ($file_size lines)"
        else
            log_info "  - $env: $env_file (missing)"
        fi
    done
}

# Display summary
display_summary() {
    log_info "=== Environment Switch Summary ==="
    log_info "Target Environment: $TARGET_ENVIRONMENT"
    log_info "Project Type: $PROJECT_TYPE"
    log_info "Project Path: $PROJECT_PATH"
    log_info "Configuration Backup: $BACKUP_CONFIGS"
    log_info "Configuration Validation: $VALIDATE_CONFIG"
    log_info "Service Restart: $RESTART_SERVICES"
    log_info ""
    
    show_environment_status
    
    log_info ""
    log_info "=== Next Steps ==="
    case "$TARGET_ENVIRONMENT" in
        "production")
            log_info "1. Verify all production configurations"
            log_info "2. Test application functionality"
            log_info "3. Monitor application performance"
            log_info "4. Check logs for any issues"
            ;;
        "development")
            log_info "1. Start development server"
            log_info "2. Verify debug features are enabled"
            log_info "3. Check database connections"
            log_info "4. Test hot reload functionality"
            ;;
        "staging")
            log_info "1. Deploy to staging environment"
            log_info "2. Run integration tests"
            log_info "3. Verify staging-specific configurations"
            log_info "4. Prepare for production deployment"
            ;;
    esac
    
    log_info ""
    log_info "=== Configuration Files ==="
    log_info "Active: .env"
    log_info "Source: ${ENV_FILES[$TARGET_ENVIRONMENT]}"
    log_info "Backup: $CONFIG_DIR/backups/"
    log_info "Environment indicator: $CONFIG_DIR/current_environment"
    
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting environment configuration switch..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Target environment: $TARGET_ENVIRONMENT"
    
    check_prerequisites
    detect_project_type
    backup_current_config
    
    if validate_environment_config; then
        switch_environment
        restart_services
        log_success "Environment switch completed successfully!"
    else
        log_error "Environment switch failed due to validation errors"
        exit 1
    fi
    
    display_summary
}

# Execute main function
main "$@"