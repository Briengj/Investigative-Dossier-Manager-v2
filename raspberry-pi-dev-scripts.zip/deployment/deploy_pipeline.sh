#!/bin/bash
#
# Automated Deployment Pipeline Script for Raspberry Pi 5
# Handles complete deployment of React 19.1.0 and NestJS 11.1.3 applications
# Integrates with existing infrastructure and optimization scripts
#
# Usage: ./deploy_pipeline.sh [--dry-run] [--environment ENV] [--project-type TYPE]
# 
# Prerequisites:
# - Git repository with application code
# - Node.js 20 LTS installed via NVM
# - PM2 for process management (NestJS)
# - Web server configuration (nginx for React)
# - Database setup (PostgreSQL for NestJS)
#
# Features:
# - Automated Git deployment workflow
# - Environment-specific configuration
# - Production build optimization
# - Database migration handling
# - Service deployment and restart
# - Health check validation
# - Rollback capability
# - Deployment notifications
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/deploy_pipeline.log"
DRY_RUN=false
TARGET_ENVIRONMENT="production"
PROJECT_TYPE="auto"
PROJECT_PATH="$(pwd)"
GIT_BRANCH="main"
BACKUP_ENABLED=true
RUN_MIGRATIONS=true
RUN_TESTS=true
HEALTH_CHECK=true
ROLLBACK_ON_FAILURE=true
DEPLOYMENT_DIR="/var/www"
SERVICE_NAME=""

# Deployment stages
DEPLOYMENT_STAGES=(
    "pre_deployment_checks"
    "backup_current_deployment"
    "fetch_latest_code"
    "install_dependencies"
    "run_tests"
    "build_application"
    "run_migrations"
    "deploy_application"
    "restart_services"
    "health_check_deployment"
    "post_deployment_tasks"
)

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --environment)
            TARGET_ENVIRONMENT="$2"
            shift 2
            ;;
        --project-type)
            PROJECT_TYPE="$2"
            shift 2
            ;;
        --project-path)
            PROJECT_PATH="$2"
            shift 2
            ;;
        --git-branch)
            GIT_BRANCH="$2"
            shift 2
            ;;
        --deployment-dir)
            DEPLOYMENT_DIR="$2"
            shift 2
            ;;
        --service-name)
            SERVICE_NAME="$2"
            shift 2
            ;;
        --no-backup)
            BACKUP_ENABLED=false
            shift
            ;;
        --no-migrations)
            RUN_MIGRATIONS=false
            shift
            ;;
        --no-tests)
            RUN_TESTS=false
            shift
            ;;
        --no-health-check)
            HEALTH_CHECK=false
            shift
            ;;
        --no-rollback)
            ROLLBACK_ON_FAILURE=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--environment ENV] [--project-type TYPE]"
            echo "Automated deployment pipeline for React and NestJS applications"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --environment ENV      Target environment: development, staging, production"
            echo "  --project-type TYPE    Project type: react, nestjs, auto (default: auto)"
            echo "  --project-path PATH    Project directory path (default: current directory)"
            echo "  --git-branch BRANCH    Git branch to deploy (default: main)"
            echo "  --deployment-dir DIR   Deployment directory (default: /var/www)"
            echo "  --service-name NAME    Service name for process management"
            echo "  --no-backup            Skip backup of current deployment"
            echo "  --no-migrations        Skip database migrations"
            echo "  --no-tests             Skip running tests"
            echo "  --no-health-check      Skip post-deployment health checks"
            echo "  --no-rollback          Disable automatic rollback on failure"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Environments:"
            echo "  development            Development environment deployment"
            echo "  staging                Staging environment deployment"
            echo "  production             Production environment deployment"
            echo ""
            echo "Project Types:"
            echo "  react                  React 19.1.0 + Vite 7.0.4 project"
            echo "  nestjs                 NestJS 11.1.3 + TypeScript 5.8.3 project"
            echo "  auto                   Auto-detect project type (default)"
            echo ""
            echo "Examples:"
            echo "  $0 --environment production --project-type nestjs"
            echo "  $0 --environment staging --git-branch develop"
            echo "  $0 --project-type react --no-migrations"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_stage() {
    echo "" | tee -a "$LOG_FILE"
    echo "=== $* ===" | tee -a "$LOG_FILE"
    echo "" | tee -a "$LOG_FILE"
}

# Error handling with rollback capability
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Deployment failed with exit code $exit_code"
        
        if [[ "$ROLLBACK_ON_FAILURE" == "true" ]] && [[ "$DRY_RUN" != "true" ]]; then
            log_error "Initiating automatic rollback..."
            rollback_deployment || log_error "Rollback failed"
        fi
        
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_stage "Checking Prerequisites"
    
    # Check Git
    if ! command -v git >/dev/null 2>&1; then
        log_error "Git is not installed"
        exit 1
    fi
    
    local git_version
    git_version=$(git --version | awk '{print $3}')
    log_info "Git version: $git_version ✓"
    
    # Check Node.js
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        exit 1
    fi
    
    local node_version npm_version
    node_version=$(node --version)
    npm_version=$(npm --version)
    log_info "Node.js version: $node_version ✓"
    log_info "npm version: v$npm_version ✓"
    
    # Check project directory
    if [[ ! -d "$PROJECT_PATH" ]]; then
        log_error "Project directory does not exist: $PROJECT_PATH"
        exit 1
    fi
    
    # Change to project directory
    cd "$PROJECT_PATH"
    log_info "Working in project directory: $(pwd)"
    
    # Check if it's a Git repository
    if ! git rev-parse --git-dir >/dev/null 2>&1; then
        log_error "Not a Git repository"
        exit 1
    fi
    
    # Check package.json
    if [[ ! -f "package.json" ]]; then
        log_error "package.json not found"
        exit 1
    fi
    
    # Check deployment directory permissions
    if [[ ! -w "$(dirname "$DEPLOYMENT_DIR")" ]]; then
        log_error "No write permission to deployment directory parent: $(dirname "$DEPLOYMENT_DIR")"
        log_error "You may need to run with sudo or adjust permissions"
        exit 1
    fi
    
    log_success "Prerequisites check completed"
}

# Auto-detect project type
detect_project_type() {
    if [[ "$PROJECT_TYPE" != "auto" ]]; then
        log_info "Project type specified: $PROJECT_TYPE"
        return 0
    fi
    
    log_info "Auto-detecting project type..."
    
    # Check for React project indicators
    if grep -q '"react"' package.json 2>/dev/null; then
        if grep -q '"vite"' package.json 2>/dev/null; then
            PROJECT_TYPE="react"
            log_info "Detected React project with Vite"
            return 0
        fi
    fi
    
    # Check for NestJS project indicators
    if grep -q '"@nestjs/core"' package.json 2>/dev/null; then
        PROJECT_TYPE="nestjs"
        log_info "Detected NestJS project"
        return 0
    fi
    
    log_error "Could not auto-detect project type"
    log_error "Please specify --project-type react or --project-type nestjs"
    exit 1
}

# Set service name if not provided
set_service_name() {
    if [[ -z "$SERVICE_NAME" ]]; then
        SERVICE_NAME=$(node -p "require('./package.json').name" 2>/dev/null || echo "app")
        log_info "Service name set to: $SERVICE_NAME"
    fi
}

# Pre-deployment checks
pre_deployment_checks() {
    log_stage "Pre-deployment Checks"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would perform pre-deployment checks"
        return 0
    fi
    
    # Check Git status
    if [[ -n "$(git status --porcelain)" ]]; then
        log_warning "Working directory has uncommitted changes"
        git status --short
    fi
    
    # Check if target branch exists
    if ! git show-ref --verify --quiet "refs/heads/$GIT_BRANCH"; then
        log_error "Branch '$GIT_BRANCH' does not exist"
        exit 1
    fi
    
    # Check environment configuration
    local env_file=".env.$TARGET_ENVIRONMENT"
    if [[ ! -f "$env_file" ]]; then
        log_error "Environment file not found: $env_file"
        exit 1
    fi
    
    log_success "Pre-deployment checks completed"
}

# Backup current deployment
backup_current_deployment() {
    log_stage "Backing Up Current Deployment"
    
    if [[ "$BACKUP_ENABLED" != "true" ]]; then
        log_info "Backup disabled (--no-backup specified)"
        return 0
    fi
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would backup current deployment"
        return 0
    fi
    
    local backup_dir="$DEPLOYMENT_DIR/backups/$SERVICE_NAME-$(date +%Y%m%d_%H%M%S)"
    local current_deployment="$DEPLOYMENT_DIR/$SERVICE_NAME"
    
    if [[ -d "$current_deployment" ]]; then
        log_info "Creating backup: $backup_dir"
        mkdir -p "$(dirname "$backup_dir")"
        
        if cp -r "$current_deployment" "$backup_dir"; then
            log_success "Backup created successfully"
            echo "$backup_dir" > "/tmp/deployment_backup_path"
        else
            log_error "Failed to create backup"
            exit 1
        fi
    else
        log_info "No existing deployment to backup"
    fi
}

# Fetch latest code
fetch_latest_code() {
    log_stage "Fetching Latest Code"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would fetch latest code from $GIT_BRANCH"
        return 0
    fi
    
    log_info "Fetching latest changes from origin"
    if git fetch origin; then
        log_success "Fetched latest changes"
    else
        log_error "Failed to fetch from origin"
        exit 1
    fi
    
    log_info "Checking out branch: $GIT_BRANCH"
    if git checkout "$GIT_BRANCH"; then
        log_success "Checked out $GIT_BRANCH"
    else
        log_error "Failed to checkout $GIT_BRANCH"
        exit 1
    fi
    
    log_info "Pulling latest changes"
    if git pull origin "$GIT_BRANCH"; then
        log_success "Pulled latest changes"
        
        local commit_hash
        commit_hash=$(git rev-parse HEAD)
        log_info "Current commit: $commit_hash"
        echo "$commit_hash" > "/tmp/deployment_commit"
    else
        log_error "Failed to pull latest changes"
        exit 1
    fi
}

# Install dependencies
install_dependencies() {
    log_stage "Installing Dependencies"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install dependencies"
        return 0
    fi
    
    # Set Node.js memory limit for ARM64
    export NODE_OPTIONS="--max-old-space-size=2048"
    
    log_info "Installing npm dependencies..."
    if npm ci --production=false; then
        log_success "Dependencies installed successfully"
    else
        log_error "Failed to install dependencies"
        exit 1
    fi
    
    # Install global dependencies if needed
    case "$PROJECT_TYPE" in
        "nestjs")
            if ! command -v nest >/dev/null 2>&1; then
                log_info "Installing NestJS CLI globally..."
                npm install -g @nestjs/cli
            fi
            ;;
    esac
}

# Run tests
run_tests() {
    log_stage "Running Tests"
    
    if [[ "$RUN_TESTS" != "true" ]]; then
        log_info "Tests disabled (--no-tests specified)"
        return 0
    fi
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would run tests"
        return 0
    fi
    
    # Check if test script exists
    if ! npm run | grep -q "test"; then
        log_warning "No test script found in package.json"
        return 0
    fi
    
    log_info "Running test suite..."
    if npm run test; then
        log_success "All tests passed"
    else
        log_error "Tests failed"
        exit 1
    fi
}

# Build application
build_application() {
    log_stage "Building Application"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would build application for $TARGET_ENVIRONMENT"
        return 0
    fi
    
    # Switch to target environment
    log_info "Switching to $TARGET_ENVIRONMENT environment"
    if [[ -f "../environment_switcher.sh" ]]; then
        ../environment_switcher.sh --environment "$TARGET_ENVIRONMENT" --project-type "$PROJECT_TYPE"
    else
        # Fallback: copy environment file
        cp ".env.$TARGET_ENVIRONMENT" ".env"
        log_info "Copied environment configuration"
    fi
    
    # Run production build optimization
    log_info "Running optimized production build..."
    if [[ -f "../production_optimizer.sh" ]]; then
        ../production_optimizer.sh --project-type "$PROJECT_TYPE" --optimization-level aggressive
    else
        # Fallback: standard build
        case "$PROJECT_TYPE" in
            "react")
                npm run build
                ;;
            "nestjs")
                npm run build
                ;;
        esac
    fi
    
    # Verify build output
    case "$PROJECT_TYPE" in
        "react")
            if [[ ! -d "dist" ]] || [[ ! -f "dist/index.html" ]]; then
                log_error "React build output not found or incomplete"
                exit 1
            fi
            ;;
        "nestjs")
            if [[ ! -d "dist" ]] || [[ ! -f "dist/main.js" ]]; then
                log_error "NestJS build output not found or incomplete"
                exit 1
            fi
            ;;
    esac
    
    log_success "Application built successfully"
}

# Run database migrations
run_migrations() {
    log_stage "Running Database Migrations"
    
    if [[ "$RUN_MIGRATIONS" != "true" ]]; then
        log_info "Migrations disabled (--no-migrations specified)"
        return 0
    fi
    
    if [[ "$PROJECT_TYPE" != "nestjs" ]]; then
        log_info "Migrations not applicable for $PROJECT_TYPE projects"
        return 0
    fi
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would run database migrations"
        return 0
    fi
    
    # Check if migration scripts exist
    if npm run | grep -q "migration"; then
        log_info "Running database migrations..."
        if npm run migration:run; then
            log_success "Database migrations completed"
        else
            log_error "Database migrations failed"
            exit 1
        fi
    else
        log_info "No migration scripts found"
    fi
}

# Deploy application
deploy_application() {
    log_stage "Deploying Application"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would deploy application to $DEPLOYMENT_DIR"
        return 0
    fi
    
    local deployment_path="$DEPLOYMENT_DIR/$SERVICE_NAME"
    
    # Create deployment directory
    mkdir -p "$deployment_path"
    
    case "$PROJECT_TYPE" in
        "react")
            deploy_react_application "$deployment_path"
            ;;
        "nestjs")
            deploy_nestjs_application "$deployment_path"
            ;;
    esac
    
    log_success "Application deployed to: $deployment_path"
}

# Deploy React application
deploy_react_application() {
    local deployment_path=$1
    
    log_info "Deploying React application..."
    
    # Copy build output
    if cp -r dist/* "$deployment_path/"; then
        log_info "React build files copied"
    else
        log_error "Failed to copy React build files"
        exit 1
    fi
    
    # Create nginx configuration if needed
    create_nginx_config "$deployment_path"
    
    log_success "React application deployed"
}

# Deploy NestJS application
deploy_nestjs_application() {
    local deployment_path=$1
    
    log_info "Deploying NestJS application..."
    
    # Copy application files
    local files_to_copy=("dist" "package.json" "package-lock.json")
    
    for file in "${files_to_copy[@]}"; do
        if [[ -e "$file" ]]; then
            cp -r "$file" "$deployment_path/"
            log_info "Copied: $file"
        fi
    done
    
    # Copy environment configuration
    cp ".env" "$deployment_path/"
    
    # Copy PM2 ecosystem file if it exists
    if [[ -f "ecosystem.config.js" ]]; then
        cp "ecosystem.config.js" "$deployment_path/"
        log_info "Copied PM2 ecosystem configuration"
    fi
    
    # Install production dependencies in deployment directory
    cd "$deployment_path"
    if npm ci --production; then
        log_info "Production dependencies installed in deployment directory"
    else
        log_error "Failed to install production dependencies"
        exit 1
    fi
    
    cd - >/dev/null
    
    log_success "NestJS application deployed"
}

# Create nginx configuration for React
create_nginx_config() {
    local deployment_path=$1
    
    log_info "Creating nginx configuration..."
    
    local nginx_config="/etc/nginx/sites-available/$SERVICE_NAME"
    
    # Check if we can write to nginx directory
    if [[ ! -w "/etc/nginx/sites-available" ]]; then
        log_warning "Cannot write to nginx directory - manual configuration required"
        return 0
    fi
    
    cat > "$nginx_config" << EOF
server {
    listen 80;
    server_name localhost;
    root $deployment_path;
    index index.html;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    # Handle client-side routing
    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
}
EOF
    
    # Enable the site
    if [[ ! -L "/etc/nginx/sites-enabled/$SERVICE_NAME" ]]; then
        ln -s "$nginx_config" "/etc/nginx/sites-enabled/"
        log_info "Nginx site enabled"
    fi
    
    log_success "Nginx configuration created"
}

# Restart services
restart_services() {
    log_stage "Restarting Services"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would restart services"
        return 0
    fi
    
    case "$PROJECT_TYPE" in
        "react")
            restart_react_services
            ;;
        "nestjs")
            restart_nestjs_services
            ;;
    esac
    
    log_success "Services restarted"
}

# Restart React services (nginx)
restart_react_services() {
    log_info "Restarting React services..."
    
    # Test nginx configuration
    if command -v nginx >/dev/null 2>&1; then
        if nginx -t; then
            log_info "Nginx configuration is valid"
            
            # Reload nginx
            if systemctl reload nginx 2>/dev/null || service nginx reload 2>/dev/null; then
                log_success "Nginx reloaded successfully"
            else
                log_warning "Failed to reload nginx - manual restart may be required"
            fi
        else
            log_error "Nginx configuration is invalid"
            exit 1
        fi
    else
        log_warning "Nginx not found - manual web server configuration required"
    fi
}

# Restart NestJS services (PM2)
restart_nestjs_services() {
    log_info "Restarting NestJS services..."
    
    local deployment_path="$DEPLOYMENT_DIR/$SERVICE_NAME"
    
    if command -v pm2 >/dev/null 2>&1; then
        cd "$deployment_path"
        
        # Stop existing processes
        pm2 stop "$SERVICE_NAME" 2>/dev/null || log_info "No existing PM2 process to stop"
        pm2 delete "$SERVICE_NAME" 2>/dev/null || log_info "No existing PM2 process to delete"
        
        # Start with ecosystem file if available
        if [[ -f "ecosystem.config.js" ]]; then
            if pm2 start ecosystem.config.js --env "$TARGET_ENVIRONMENT"; then
                log_success "PM2 process started with ecosystem file"
            else
                log_error "Failed to start PM2 process with ecosystem file"
                exit 1
            fi
        else
            # Start with direct command
            if pm2 start dist/main.js --name "$SERVICE_NAME" --env "$TARGET_ENVIRONMENT"; then
                log_success "PM2 process started"
            else
                log_error "Failed to start PM2 process"
                exit 1
            fi
        fi
        
        # Save PM2 configuration
        pm2 save
        
        cd - >/dev/null
    else
        log_error "PM2 not found - cannot start NestJS application"
        exit 1
    fi
}

# Health check deployment
health_check_deployment() {
    log_stage "Health Check Deployment"
    
    if [[ "$HEALTH_CHECK" != "true" ]]; then
        log_info "Health check disabled (--no-health-check specified)"
        return 0
    fi
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would perform health checks"
        return 0
    fi
    
    # Wait for services to start
    log_info "Waiting for services to start..."
    sleep 10
    
    # Run health checks
    if [[ -f "../health_checker.sh" ]]; then
        log_info "Running comprehensive health checks..."
        if ../health_checker.sh --service "$PROJECT_TYPE" --check-type comprehensive; then
            log_success "Health checks passed"
        else
            log_error "Health checks failed"
            exit 1
        fi
    else
        # Basic health check
        case "$PROJECT_TYPE" in
            "react")
                basic_react_health_check
                ;;
            "nestjs")
                basic_nestjs_health_check
                ;;
        esac
    fi
}

# Basic React health check
basic_react_health_check() {
    log_info "Performing basic React health check..."
    
    local health_url="http://localhost"
    
    if command -v curl >/dev/null 2>&1; then
        if curl -f -s "$health_url" >/dev/null; then
            log_success "React application is responding"
        else
            log_error "React application is not responding"
            exit 1
        fi
    else
        log_warning "curl not available - manual health check required"
    fi
}

# Basic NestJS health check
basic_nestjs_health_check() {
    log_info "Performing basic NestJS health check..."
    
    local health_url="http://localhost:3000/api/health"
    
    if command -v curl >/dev/null 2>&1; then
        if curl -f -s "$health_url" >/dev/null; then
            log_success "NestJS application is responding"
        else
            log_error "NestJS application is not responding"
            exit 1
        fi
    else
        log_warning "curl not available - manual health check required"
    fi
}

# Post-deployment tasks
post_deployment_tasks() {
    log_stage "Post-deployment Tasks"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would perform post-deployment tasks"
        return 0
    fi
    
    # Clean up old backups (keep last 5)
    cleanup_old_backups
    
    # Generate deployment report
    generate_deployment_report
    
    # Send deployment notification
    send_deployment_notification
    
    log_success "Post-deployment tasks completed"
}

# Cleanup old backups
cleanup_old_backups() {
    log_info "Cleaning up old backups..."
    
    local backup_base_dir="$DEPLOYMENT_DIR/backups"
    
    if [[ -d "$backup_base_dir" ]]; then
        # Keep only the 5 most recent backups
        find "$backup_base_dir" -name "$SERVICE_NAME-*" -type d | sort -r | tail -n +6 | while read -r old_backup; do
            rm -rf "$old_backup"
            log_info "Removed old backup: $(basename "$old_backup")"
        done
    fi
}

# Generate deployment report
generate_deployment_report() {
    log_info "Generating deployment report..."
    
    local report_file="$HOME/development/logs/deployment_report_$(date +%Y%m%d_%H%M%S).txt"
    
    {
        echo "=== Deployment Report ==="
        echo "Date: $(date)"
        echo "Service: $SERVICE_NAME"
        echo "Project Type: $PROJECT_TYPE"
        echo "Environment: $TARGET_ENVIRONMENT"
        echo "Git Branch: $GIT_BRANCH"
        echo ""
        
        if [[ -f "/tmp/deployment_commit" ]]; then
            echo "Deployed Commit: $(cat /tmp/deployment_commit)"
        fi
        
        echo "Deployment Path: $DEPLOYMENT_DIR/$SERVICE_NAME"
        
        if [[ -f "/tmp/deployment_backup_path" ]]; then
            echo "Backup Location: $(cat /tmp/deployment_backup_path)"
        fi
        
        echo ""
        echo "=== Deployment Configuration ==="
        echo "Backup Enabled: $BACKUP_ENABLED"
        echo "Migrations Run: $RUN_MIGRATIONS"
        echo "Tests Run: $RUN_TESTS"
        echo "Health Check: $HEALTH_CHECK"
        echo "Rollback on Failure: $ROLLBACK_ON_FAILURE"
        
        echo ""
        echo "=== Service Status ==="
        case "$PROJECT_TYPE" in
            "nestjs")
                if command -v pm2 >/dev/null 2>&1; then
                    echo "PM2 Status:"
                    pm2 status --no-colors
                fi
                ;;
            "react")
                if command -v systemctl >/dev/null 2>&1; then
                    echo "Nginx Status:"
                    systemctl status nginx --no-pager -l
                fi
                ;;
        esac
        
    } > "$report_file"
    
    log_success "Deployment report generated: $report_file"
}

# Send deployment notification
send_deployment_notification() {
    log_info "Sending deployment notification..."
    
    # This is a placeholder for notification integration
    # You can integrate with Slack, Discord, email, etc.
    
    local message="✅ Deployment completed successfully
Service: $SERVICE_NAME
Environment: $TARGET_ENVIRONMENT
Time: $(date)
Commit: $(cat /tmp/deployment_commit 2>/dev/null || echo "Unknown")"
    
    log_info "Deployment notification:"
    echo "$message"
    
    # Example integrations (uncomment and configure as needed):
    # curl -X POST -H 'Content-type: application/json' --data "{\"text\":\"$message\"}" YOUR_SLACK_WEBHOOK_URL
    # echo "$message" | mail -s "Deployment Notification" admin@example.com
}

# Rollback deployment
rollback_deployment() {
    log_stage "Rolling Back Deployment"
    
    if [[ ! -f "/tmp/deployment_backup_path" ]]; then
        log_error "No backup path found - cannot rollback"
        return 1
    fi
    
    local backup_path
    backup_path=$(cat /tmp/deployment_backup_path)
    local deployment_path="$DEPLOYMENT_DIR/$SERVICE_NAME"
    
    log_info "Rolling back to: $backup_path"
    
    # Stop current services
    case "$PROJECT_TYPE" in
        "nestjs")
            if command -v pm2 >/dev/null 2>&1; then
                pm2 stop "$SERVICE_NAME" 2>/dev/null || true
            fi
            ;;
    esac
    
    # Restore backup
    if [[ -d "$backup_path" ]]; then
        rm -rf "$deployment_path"
        cp -r "$backup_path" "$deployment_path"
        log_info "Backup restored"
        
        # Restart services
        restart_services
        
        log_success "Rollback completed"
    else
        log_error "Backup directory not found: $backup_path"
        return 1
    fi
}

# Execute deployment pipeline
execute_deployment_pipeline() {
    log_stage "Starting Deployment Pipeline"
    
    for stage in "${DEPLOYMENT_STAGES[@]}"; do
        log_info "Executing stage: $stage"
        
        case "$stage" in
            "pre_deployment_checks")
                pre_deployment_checks
                ;;
            "backup_current_deployment")
                backup_current_deployment
                ;;
            "fetch_latest_code")
                fetch_latest_code
                ;;
            "install_dependencies")
                install_dependencies
                ;;
            "run_tests")
                run_tests
                ;;
            "build_application")
                build_application
                ;;
            "run_migrations")
                run_migrations
                ;;
            "deploy_application")
                deploy_application
                ;;
            "restart_services")
                restart_services
                ;;
            "health_check_deployment")
                health_check_deployment
                ;;
            "post_deployment_tasks")
                post_deployment_tasks
                ;;
        esac
        
        log_success "Stage completed: $stage"
    done
}

# Display summary
display_summary() {
    log_stage "Deployment Summary"
    
    log_info "=== Deployment Configuration ==="
    log_info "Service Name: $SERVICE_NAME"
    log_info "Project Type: $PROJECT_TYPE"
    log_info "Environment: $TARGET_ENVIRONMENT"
    log_info "Git Branch: $GIT_BRANCH"
    log_info "Deployment Directory: $DEPLOYMENT_DIR/$SERVICE_NAME"
    log_info ""
    
    log_info "=== Deployment Options ==="
    log_info "Backup Enabled: $BACKUP_ENABLED"
    log_info "Run Migrations: $RUN_MIGRATIONS"
    log_info "Run Tests: $RUN_TESTS"
    log_info "Health Check: $HEALTH_CHECK"
    log_info "Rollback on Failure: $ROLLBACK_ON_FAILURE"
    log_info ""
    
    log_info "=== Next Steps ==="
    case "$PROJECT_TYPE" in
        "react")
            log_info "1. Verify application at: http://localhost"
            log_info "2. Check nginx configuration and logs"
            log_info "3. Monitor application performance"
            ;;
        "nestjs")
            log_info "1. Verify API at: http://localhost:3000"
            log_info "2. Check PM2 process status: pm2 status"
            log_info "3. Monitor application logs: pm2 logs"
            ;;
    esac
    
    log_info ""
    log_info "=== Useful Commands ==="
    log_info "View deployment logs: tail -f $LOG_FILE"
    log_info "Check service status: systemctl status nginx (React) or pm2 status (NestJS)"
    log_info "Manual rollback: $0 --rollback (if implemented)"
    
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_stage "Deployment Pipeline Started"
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Target environment: $TARGET_ENVIRONMENT"
    log_info "Project type: $PROJECT_TYPE"
    
    check_prerequisites
    detect_project_type
    set_service_name
    
    execute_deployment_pipeline
    
    log_stage "Deployment Pipeline Completed Successfully"
    display_summary
    
    # Cleanup temporary files
    rm -f /tmp/deployment_backup_path /tmp/deployment_commit
}

# Execute main function
main "$@"