#!/bin/bash
#
# Health Check Script for Application Monitoring on Raspberry Pi 5
# Monitors React 19.1.0 and NestJS 11.1.3 applications health and performance
# Provides comprehensive health checks for production deployments
#
# Usage: ./health_checker.sh [--dry-run] [--service SERVICE] [--check-type TYPE]
# 
# Prerequisites:
# - Running applications (React, NestJS, PostgreSQL, etc.)
# - Network access to application endpoints
# - curl or wget for HTTP health checks
# - System monitoring tools available
#
# Features:
# - HTTP endpoint health checks
# - Database connectivity validation
# - System resource monitoring
# - Service process validation
# - Performance metrics collection
# - Alert generation for failures
# - Health status reporting
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/health_checker.log"
DRY_RUN=false
TARGET_SERVICE="all"
CHECK_TYPE="comprehensive"
PROJECT_PATH="$(pwd)"
TIMEOUT=30
RETRY_COUNT=3
ALERT_THRESHOLD=3
HEALTH_REPORT_DIR="$HOME/development/logs/health_reports"

# Service configurations
declare -A SERVICE_CONFIGS=(
    ["react"]="http://localhost:5173"
    ["nestjs"]="http://localhost:3000"
    ["postgresql"]="localhost:5432"
    ["nginx"]="http://localhost:80"
    ["pm2"]="pm2"
)

# Health check endpoints
declare -A HEALTH_ENDPOINTS=(
    ["nestjs"]="/api/health"
    ["react"]="/"
)

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --service)
            TARGET_SERVICE="$2"
            shift 2
            ;;
        --check-type)
            CHECK_TYPE="$2"
            shift 2
            ;;
        --project-path)
            PROJECT_PATH="$2"
            shift 2
            ;;
        --timeout)
            TIMEOUT="$2"
            shift 2
            ;;
        --retry-count)
            RETRY_COUNT="$2"
            shift 2
            ;;
        --alert-threshold)
            ALERT_THRESHOLD="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--service SERVICE] [--check-type TYPE]"
            echo "Performs health checks on applications and services"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --service SERVICE      Target service: react, nestjs, postgresql, nginx, pm2, all"
            echo "  --check-type TYPE      Check type: basic, comprehensive, performance, continuous"
            echo "  --project-path PATH    Project directory path (default: current directory)"
            echo "  --timeout SECONDS      HTTP request timeout (default: 30)"
            echo "  --retry-count N        Number of retries for failed checks (default: 3)"
            echo "  --alert-threshold N    Failure threshold for alerts (default: 3)"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Services:"
            echo "  react                  React development/production server"
            echo "  nestjs                 NestJS application server"
            echo "  postgresql             PostgreSQL database server"
            echo "  nginx                  Nginx web server"
            echo "  pm2                    PM2 process manager"
            echo "  all                    All available services (default)"
            echo ""
            echo "Check Types:"
            echo "  basic                  Basic connectivity and process checks"
            echo "  comprehensive          Full health validation including performance"
            echo "  performance            Performance metrics and resource usage"
            echo "  continuous             Continuous monitoring mode"
            echo ""
            echo "Examples:"
            echo "  $0 --service nestjs --check-type comprehensive"
            echo "  $0 --service all --check-type basic"
            echo "  $0 --check-type continuous --timeout 10"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log and report directories
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$HEALTH_REPORT_DIR"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check for HTTP client tools
    local http_client=""
    if command -v curl >/dev/null 2>&1; then
        http_client="curl"
        log_info "HTTP client: curl ✓"
    elif command -v wget >/dev/null 2>&1; then
        http_client="wget"
        log_info "HTTP client: wget ✓"
    else
        log_error "No HTTP client found (curl or wget required)"
        exit 1
    fi
    
    # Check for system monitoring tools
    local monitoring_tools=("ps" "netstat" "free" "df")
    for tool in "${monitoring_tools[@]}"; do
        if command -v "$tool" >/dev/null 2>&1; then
            log_info "Monitoring tool: $tool ✓"
        else
            log_warning "Monitoring tool not found: $tool"
        fi
    done
    
    # Check project directory if specified
    if [[ "$PROJECT_PATH" != "$(pwd)" ]] && [[ ! -d "$PROJECT_PATH" ]]; then
        log_error "Project directory does not exist: $PROJECT_PATH"
        exit 1
    fi
    
    # Change to project directory
    cd "$PROJECT_PATH"
    log_info "Working in project directory: $(pwd)"
    
    log_info "Prerequisites check completed"
}

# HTTP health check
http_health_check() {
    local service=$1
    local url=$2
    local endpoint=${3:-"/"}
    local full_url="$url$endpoint"
    
    log_info "Checking HTTP health for $service: $full_url"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would check HTTP health for $service"
        return 0
    fi
    
    local attempt=1
    local success=false
    
    while [[ $attempt -le $RETRY_COUNT ]]; do
        log_info "Attempt $attempt/$RETRY_COUNT for $service"
        
        if command -v curl >/dev/null 2>&1; then
            if curl -f -s -m "$TIMEOUT" "$full_url" >/dev/null 2>&1; then
                success=true
                break
            fi
        elif command -v wget >/dev/null 2>&1; then
            if wget -q -T "$TIMEOUT" -O /dev/null "$full_url" >/dev/null 2>&1; then
                success=true
                break
            fi
        fi
        
        ((attempt++))
        if [[ $attempt -le $RETRY_COUNT ]]; then
            sleep 2
        fi
    done
    
    if [[ "$success" == "true" ]]; then
        log_success "$service HTTP health check passed"
        return 0
    else
        log_error "$service HTTP health check failed after $RETRY_COUNT attempts"
        return 1
    fi
}

# Database connectivity check
database_health_check() {
    local service=$1
    local host_port=$2
    
    log_info "Checking database connectivity for $service: $host_port"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would check database connectivity for $service"
        return 0
    fi
    
    local host port
    host=$(echo "$host_port" | cut -d: -f1)
    port=$(echo "$host_port" | cut -d: -f2)
    
    # Check if port is open
    if command -v nc >/dev/null 2>&1; then
        if nc -z -w "$TIMEOUT" "$host" "$port" 2>/dev/null; then
            log_success "$service database connectivity check passed"
            return 0
        else
            log_error "$service database connectivity check failed"
            return 1
        fi
    elif command -v telnet >/dev/null 2>&1; then
        if timeout "$TIMEOUT" telnet "$host" "$port" </dev/null >/dev/null 2>&1; then
            log_success "$service database connectivity check passed"
            return 0
        else
            log_error "$service database connectivity check failed"
            return 1
        fi
    else
        log_warning "No network connectivity tools available (nc or telnet)"
        return 0
    fi
}

# Process health check
process_health_check() {
    local service=$1
    
    log_info "Checking process health for $service"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would check process health for $service"
        return 0
    fi
    
    case "$service" in
        "pm2")
            check_pm2_processes
            ;;
        "postgresql")
            check_postgresql_process
            ;;
        "nginx")
            check_nginx_process
            ;;
        *)
            check_generic_process "$service"
            ;;
    esac
}

# Check PM2 processes
check_pm2_processes() {
    if command -v pm2 >/dev/null 2>&1; then
        local pm2_status
        pm2_status=$(pm2 jlist 2>/dev/null | jq -r '.[].pm2_env.status' 2>/dev/null || echo "unknown")
        
        if echo "$pm2_status" | grep -q "online"; then
            log_success "PM2 processes are running"
            
            # Show process details
            log_info "PM2 process status:"
            pm2 status --no-colors | while read -r line; do
                log_info "  $line"
            done
            return 0
        else
            log_error "PM2 processes are not running properly"
            return 1
        fi
    else
        log_warning "PM2 not available"
        return 0
    fi
}

# Check PostgreSQL process
check_postgresql_process() {
    if pgrep -f postgres >/dev/null 2>&1; then
        log_success "PostgreSQL process is running"
        
        # Check PostgreSQL version and status
        if command -v psql >/dev/null 2>&1; then
            local pg_version
            pg_version=$(psql --version 2>/dev/null | head -1 || echo "Unknown version")
            log_info "PostgreSQL version: $pg_version"
        fi
        return 0
    else
        log_error "PostgreSQL process is not running"
        return 1
    fi
}

# Check Nginx process
check_nginx_process() {
    if pgrep -f nginx >/dev/null 2>&1; then
        log_success "Nginx process is running"
        
        # Check Nginx configuration
        if command -v nginx >/dev/null 2>&1; then
            if nginx -t >/dev/null 2>&1; then
                log_success "Nginx configuration is valid"
            else
                log_warning "Nginx configuration has issues"
            fi
        fi
        return 0
    else
        log_error "Nginx process is not running"
        return 1
    fi
}

# Check generic process
check_generic_process() {
    local service=$1
    
    if pgrep -f "$service" >/dev/null 2>&1; then
        log_success "$service process is running"
        
        # Show process details
        local pid_info
        pid_info=$(pgrep -f "$service" | head -1)
        if [[ -n "$pid_info" ]]; then
            log_info "$service PID: $pid_info"
        fi
        return 0
    else
        log_error "$service process is not running"
        return 1
    fi
}

# System resource check
system_resource_check() {
    log_info "Checking system resources..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would check system resources"
        return 0
    fi
    
    local resource_issues=0
    
    # Check memory usage
    if command -v free >/dev/null 2>&1; then
        local memory_usage
        memory_usage=$(free | awk 'NR==2{printf "%.0f", $3*100/$2}')
        log_info "Memory usage: ${memory_usage}%"
        
        if [[ "$memory_usage" -gt 90 ]]; then
            log_warning "High memory usage detected: ${memory_usage}%"
            ((resource_issues++))
        fi
    fi
    
    # Check disk usage
    if command -v df >/dev/null 2>&1; then
        local disk_usage
        disk_usage=$(df / | awk 'NR==2{print $5}' | sed 's/%//')
        log_info "Disk usage: ${disk_usage}%"
        
        if [[ "$disk_usage" -gt 85 ]]; then
            log_warning "High disk usage detected: ${disk_usage}%"
            ((resource_issues++))
        fi
    fi
    
    # Check CPU load
    if [[ -f "/proc/loadavg" ]]; then
        local load_avg
        load_avg=$(cat /proc/loadavg | awk '{print $1}')
        log_info "CPU load average (1min): $load_avg"
        
        # For Raspberry Pi 5 (4 cores), load > 4 is concerning
        if (( $(echo "$load_avg > 4" | bc -l) )); then
            log_warning "High CPU load detected: $load_avg"
            ((resource_issues++))
        fi
    fi
    
    # Check available file descriptors
    if [[ -f "/proc/sys/fs/file-nr" ]]; then
        local fd_usage
        fd_usage=$(cat /proc/sys/fs/file-nr | awk '{printf "%.0f", $1*100/$3}')
        log_info "File descriptor usage: ${fd_usage}%"
        
        if [[ "$fd_usage" -gt 80 ]]; then
            log_warning "High file descriptor usage: ${fd_usage}%"
            ((resource_issues++))
        fi
    fi
    
    if [[ $resource_issues -eq 0 ]]; then
        log_success "System resources are healthy"
        return 0
    else
        log_warning "System resource issues detected: $resource_issues"
        return 1
    fi
}

# Performance metrics collection
collect_performance_metrics() {
    log_info "Collecting performance metrics..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would collect performance metrics"
        return 0
    fi
    
    local metrics_file="$HEALTH_REPORT_DIR/performance_metrics_$(date +%Y%m%d_%H%M%S).json"
    
    {
        echo "{"
        echo "  \"timestamp\": \"$(date -Iseconds)\","
        echo "  \"system\": {"
        
        # System metrics
        if command -v free >/dev/null 2>&1; then
            local mem_total mem_used mem_free
            mem_total=$(free -m | awk 'NR==2{print $2}')
            mem_used=$(free -m | awk 'NR==2{print $3}')
            mem_free=$(free -m | awk 'NR==2{print $7}')
            echo "    \"memory_total_mb\": $mem_total,"
            echo "    \"memory_used_mb\": $mem_used,"
            echo "    \"memory_free_mb\": $mem_free,"
        fi
        
        if command -v df >/dev/null 2>&1; then
            local disk_total disk_used disk_free
            disk_total=$(df / | awk 'NR==2{print int($2/1024)}')
            disk_used=$(df / | awk 'NR==2{print int($3/1024)}')
            disk_free=$(df / | awk 'NR==2{print int($4/1024)}')
            echo "    \"disk_total_mb\": $disk_total,"
            echo "    \"disk_used_mb\": $disk_used,"
            echo "    \"disk_free_mb\": $disk_free,"
        fi
        
        if [[ -f "/proc/loadavg" ]]; then
            local load1 load5 load15
            load1=$(cat /proc/loadavg | awk '{print $1}')
            load5=$(cat /proc/loadavg | awk '{print $2}')
            load15=$(cat /proc/loadavg | awk '{print $3}')
            echo "    \"load_1min\": $load1,"
            echo "    \"load_5min\": $load5,"
            echo "    \"load_15min\": $load15,"
        fi
        
        echo "    \"cpu_count\": $(nproc)"
        echo "  },"
        
        # Network metrics
        echo "  \"network\": {"
        if command -v netstat >/dev/null 2>&1; then
            local tcp_connections
            tcp_connections=$(netstat -tn | grep -c ESTABLISHED || echo "0")
            echo "    \"tcp_connections\": $tcp_connections,"
        fi
        echo "    \"interfaces\": []"
        echo "  },"
        
        # Process metrics
        echo "  \"processes\": {"
        local total_processes
        total_processes=$(ps aux | wc -l)
        echo "    \"total_count\": $total_processes"
        echo "  }"
        
        echo "}"
    } > "$metrics_file"
    
    log_success "Performance metrics collected: $metrics_file"
}

# Health check for specific service
check_service_health() {
    local service=$1
    local health_status=0
    
    log_info "=== Health Check for $service ==="
    
    case "$service" in
        "react")
            local react_url="${SERVICE_CONFIGS[react]}"
            local react_endpoint="${HEALTH_ENDPOINTS[react]:-/}"
            if ! http_health_check "$service" "$react_url" "$react_endpoint"; then
                ((health_status++))
            fi
            ;;
        "nestjs")
            local nestjs_url="${SERVICE_CONFIGS[nestjs]}"
            local nestjs_endpoint="${HEALTH_ENDPOINTS[nestjs]:-/api/health}"
            if ! http_health_check "$service" "$nestjs_url" "$nestjs_endpoint"; then
                ((health_status++))
            fi
            if ! process_health_check "$service"; then
                ((health_status++))
            fi
            ;;
        "postgresql")
            local pg_host_port="${SERVICE_CONFIGS[postgresql]}"
            if ! database_health_check "$service" "$pg_host_port"; then
                ((health_status++))
            fi
            if ! process_health_check "$service"; then
                ((health_status++))
            fi
            ;;
        "nginx")
            local nginx_url="${SERVICE_CONFIGS[nginx]}"
            if ! http_health_check "$service" "$nginx_url"; then
                ((health_status++))
            fi
            if ! process_health_check "$service"; then
                ((health_status++))
            fi
            ;;
        "pm2")
            if ! process_health_check "$service"; then
                ((health_status++))
            fi
            ;;
        *)
            log_warning "Unknown service: $service"
            return 1
            ;;
    esac
    
    if [[ $health_status -eq 0 ]]; then
        log_success "$service health check passed"
        return 0
    else
        log_error "$service health check failed ($health_status issues)"
        return 1
    fi
}

# Comprehensive health check
comprehensive_health_check() {
    log_info "Running comprehensive health check..."
    
    local overall_status=0
    local services_to_check=()
    
    if [[ "$TARGET_SERVICE" == "all" ]]; then
        services_to_check=("${!SERVICE_CONFIGS[@]}")
    else
        services_to_check=("$TARGET_SERVICE")
    fi
    
    # Check each service
    for service in "${services_to_check[@]}"; do
        if ! check_service_health "$service"; then
            ((overall_status++))
        fi
    done
    
    # System resource check
    if [[ "$CHECK_TYPE" == "comprehensive" ]] || [[ "$CHECK_TYPE" == "performance" ]]; then
        if ! system_resource_check; then
            ((overall_status++))
        fi
    fi
    
    # Performance metrics collection
    if [[ "$CHECK_TYPE" == "performance" ]] || [[ "$CHECK_TYPE" == "comprehensive" ]]; then
        collect_performance_metrics
    fi
    
    return $overall_status
}

# Continuous monitoring mode
continuous_monitoring() {
    log_info "Starting continuous monitoring mode..."
    log_info "Press Ctrl+C to stop monitoring"
    
    local failure_count=0
    
    trap 'log_info "Stopping continuous monitoring..."; exit 0' INT
    
    while true; do
        log_info "=== Health Check Cycle $(date) ==="
        
        if comprehensive_health_check; then
            failure_count=0
            log_success "All health checks passed"
        else
            ((failure_count++))
            log_warning "Health check failures detected (count: $failure_count)"
            
            if [[ $failure_count -ge $ALERT_THRESHOLD ]]; then
                log_error "ALERT: Health check failures exceed threshold ($ALERT_THRESHOLD)"
                generate_alert_report
                failure_count=0  # Reset counter after alert
            fi
        fi
        
        log_info "Next check in 60 seconds..."
        sleep 60
    done
}

# Generate alert report
generate_alert_report() {
    log_info "Generating alert report..."
    
    local alert_file="$HEALTH_REPORT_DIR/alert_$(date +%Y%m%d_%H%M%S).txt"
    
    {
        echo "=== HEALTH CHECK ALERT ==="
        echo "Date: $(date)"
        echo "Alert Threshold: $ALERT_THRESHOLD failures"
        echo "Target Service: $TARGET_SERVICE"
        echo ""
        
        echo "=== System Status ==="
        if command -v uptime >/dev/null 2>&1; then
            echo "Uptime: $(uptime)"
        fi
        
        if command -v free >/dev/null 2>&1; then
            echo "Memory:"
            free -h
        fi
        
        if command -v df >/dev/null 2>&1; then
            echo "Disk Usage:"
            df -h /
        fi
        
        echo ""
        echo "=== Process Status ==="
        if command -v ps >/dev/null 2>&1; then
            echo "Top processes by CPU:"
            ps aux --sort=-%cpu | head -10
        fi
        
        echo ""
        echo "=== Network Status ==="
        if command -v netstat >/dev/null 2>&1; then
            echo "Network connections:"
            netstat -tuln | head -10
        fi
        
        echo ""
        echo "=== Recent Logs ==="
        if [[ -f "$LOG_FILE" ]]; then
            echo "Last 20 log entries:"
            tail -20 "$LOG_FILE"
        fi
        
    } > "$alert_file"
    
    log_error "Alert report generated: $alert_file"
    
    # Send alert if notification tools are available
    if command -v mail >/dev/null 2>&1; then
        log_info "Sending email alert (if configured)"
        # mail -s "Health Check Alert - $(hostname)" admin@example.com < "$alert_file" || true
    fi
}

# Generate health report
generate_health_report() {
    log_info "Generating health report..."
    
    local report_file="$HEALTH_REPORT_DIR/health_report_$(date +%Y%m%d_%H%M%S).txt"
    
    {
        echo "=== Application Health Report ==="
        echo "Date: $(date)"
        echo "Target Service: $TARGET_SERVICE"
        echo "Check Type: $CHECK_TYPE"
        echo "Hostname: $(hostname)"
        echo ""
        
        echo "=== Service Status ==="
        local services_to_report=()
        if [[ "$TARGET_SERVICE" == "all" ]]; then
            services_to_report=("${!SERVICE_CONFIGS[@]}")
        else
            services_to_report=("$TARGET_SERVICE")
        fi
        
        for service in "${services_to_report[@]}"; do
            echo "Service: $service"
            if check_service_health "$service" >/dev/null 2>&1; then
                echo "  Status: HEALTHY ✓"
            else
                echo "  Status: UNHEALTHY ✗"
            fi
            echo "  Configuration: ${SERVICE_CONFIGS[$service]}"
            echo ""
        done
        
        echo "=== System Resources ==="
        if command -v free >/dev/null 2>&1; then
            echo "Memory Usage:"
            free -h
            echo ""
        fi
        
        if command -v df >/dev/null 2>&1; then
            echo "Disk Usage:"
            df -h
            echo ""
        fi
        
        if [[ -f "/proc/loadavg" ]]; then
            echo "Load Average: $(cat /proc/loadavg)"
            echo ""
        fi
        
        echo "=== Network Information ==="
        if command -v ip >/dev/null 2>&1; then
            echo "Network Interfaces:"
            ip addr show | grep -E "inet |^[0-9]"
            echo ""
        fi
        
        echo "=== Recommendations ==="
        echo "1. Monitor system resources regularly"
        echo "2. Set up automated alerts for critical failures"
        echo "3. Implement log rotation to prevent disk space issues"
        echo "4. Consider load balancing for high-traffic applications"
        echo "5. Regular backup and disaster recovery testing"
        
    } > "$report_file"
    
    log_success "Health report generated: $report_file"
}

# Execute health checks based on type
execute_health_checks() {
    case "$CHECK_TYPE" in
        "basic")
            comprehensive_health_check
            ;;
        "comprehensive")
            comprehensive_health_check
            ;;
        "performance")
            comprehensive_health_check
            ;;
        "continuous")
            continuous_monitoring
            ;;
        *)
            log_error "Unknown check type: $CHECK_TYPE"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== Health Check Summary ==="
    log_info "Target Service: $TARGET_SERVICE"
    log_info "Check Type: $CHECK_TYPE"
    log_info "Project Path: $PROJECT_PATH"
    log_info "Timeout: ${TIMEOUT}s"
    log_info "Retry Count: $RETRY_COUNT"
    log_info "Alert Threshold: $ALERT_THRESHOLD"
    log_info ""
    
    log_info "=== Available Services ==="
    for service in "${!SERVICE_CONFIGS[@]}"; do
        log_info "  - $service: ${SERVICE_CONFIGS[$service]}"
    done
    
    log_info ""
    log_info "=== Health Check Types ==="
    log_info "  - basic: Quick connectivity and process checks"
    log_info "  - comprehensive: Full health validation with resources"
    log_info "  - performance: Detailed performance metrics collection"
    log_info "  - continuous: Real-time monitoring with alerts"
    
    log_info ""
    log_info "=== Reports and Logs ==="
    log_info "Health reports: $HEALTH_REPORT_DIR"
    log_info "Log file: $LOG_FILE"
    
    log_info ""
    log_info "=== Common Commands ==="
    log_info "Basic check: $0 --service all --check-type basic"
    log_info "NestJS health: $0 --service nestjs --check-type comprehensive"
    log_info "Continuous monitoring: $0 --check-type continuous"
    log_info "Performance metrics: $0 --check-type performance"
}

# Main execution function
main() {
    log_info "Starting health check..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Target service: $TARGET_SERVICE"
    log_info "Check type: $CHECK_TYPE"
    
    check_prerequisites
    
    local health_result=0
    execute_health_checks || health_result=$?
    
    # Generate report for non-continuous checks
    if [[ "$CHECK_TYPE" != "continuous" ]]; then
        generate_health_report
    fi
    
    if [[ $health_result -eq 0 ]]; then
        log_success "Health check completed successfully!"
    else
        log_error "Health check completed with issues"
    fi
    
    display_summary
    
    exit $health_result
}

# Execute main function
main "$@"