#!/bin/bash
#
# PostgreSQL Backup and Restore Utilities
# Comprehensive database backup, restore, and migration tools
# Optimized for Raspberry Pi 5 development workflows
#
# Usage: ./backup_restore_utils.sh <command> [options]
# 
# Prerequisites:
# - PostgreSQL installed and configured
# - Database credentials configured
# - Sufficient storage space for backups
#
# Features:
# - Automated backup scheduling
# - Incremental and full backups
# - Backup compression and encryption
# - Restore with validation
# - Migration utilities
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="/var/log/db_backup_restore.log"
BACKUP_DIR="/var/backups/postgresql"
CONFIG_FILE="/etc/postgresql-backup.conf"
DRY_RUN=false

# Default configuration
DEFAULT_DB_HOST="localhost"
DEFAULT_DB_PORT="5432"
DEFAULT_DB_USER="developer"
DEFAULT_DB_NAME="development"
DEFAULT_RETENTION_DAYS="30"
DEFAULT_COMPRESSION="gzip"

# Parse command line arguments
COMMAND=""
DB_HOST="$DEFAULT_DB_HOST"
DB_PORT="$DEFAULT_DB_PORT"
DB_USER="$DEFAULT_DB_USER"
DB_NAME="$DEFAULT_DB_NAME"
DB_PASSWORD=""
BACKUP_FILE=""
RETENTION_DAYS="$DEFAULT_RETENTION_DAYS"
COMPRESSION="$DEFAULT_COMPRESSION"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Operation failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Load configuration
load_config() {
    if [[ -f "$CONFIG_FILE" ]]; then
        log_info "Loading configuration from $CONFIG_FILE"
        source "$CONFIG_FILE"
    else
        log_info "Configuration file not found, using defaults"
    fi
}

# Create configuration file
create_config() {
    log_info "Creating configuration file..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create configuration file at $CONFIG_FILE"
        return 0
    fi
    
    cat > "$CONFIG_FILE" << EOF
# PostgreSQL Backup Configuration
# Generated on $(date)

# Database connection settings
DB_HOST="$DB_HOST"
DB_PORT="$DB_PORT"
DB_USER="$DB_USER"
DB_NAME="$DB_NAME"
# DB_PASSWORD should be set via environment variable PGPASSWORD

# Backup settings
BACKUP_DIR="$BACKUP_DIR"
RETENTION_DAYS="$RETENTION_DAYS"
COMPRESSION="$COMPRESSION"

# Notification settings (optional)
# EMAIL_NOTIFICATIONS="admin@example.com"
# SLACK_WEBHOOK=""

# Advanced settings
MAX_PARALLEL_JOBS="2"
BACKUP_TIMEOUT="3600"
VERIFY_BACKUPS="true"
EOF
    
    chmod 600 "$CONFIG_FILE"
    log_success "Configuration file created at $CONFIG_FILE"
}

# Validate database connection
validate_connection() {
    log_info "Validating database connection..."
    
    if [[ -z "$DB_PASSWORD" ]] && [[ -z "$PGPASSWORD" ]]; then
        log_error "Database password not provided"
        log_error "Set PGPASSWORD environment variable or use --password option"
        exit 1
    fi
    
    # Use provided password or environment variable
    export PGPASSWORD="${DB_PASSWORD:-$PGPASSWORD}"
    
    if psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -c "SELECT 1;" >/dev/null 2>&1; then
        log_success "Database connection validated"
    else
        log_error "Failed to connect to database"
        log_error "Host: $DB_HOST, Port: $DB_PORT, User: $DB_USER, Database: $DB_NAME"
        exit 1
    fi
}

# Create backup directory
setup_backup_directory() {
    log_info "Setting up backup directory..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create backup directory: $BACKUP_DIR"
        return 0
    fi
    
    mkdir -p "$BACKUP_DIR"
    chmod 750 "$BACKUP_DIR"
    
    # Create subdirectories
    mkdir -p "$BACKUP_DIR/full"
    mkdir -p "$BACKUP_DIR/incremental"
    mkdir -p "$BACKUP_DIR/schema"
    mkdir -p "$BACKUP_DIR/logs"
    
    log_success "Backup directory structure created at $BACKUP_DIR"
}

# Perform full backup
backup_full() {
    log_info "Starting full database backup..."
    
    local timestamp
    timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_file="$BACKUP_DIR/full/${DB_NAME}_full_$timestamp.sql"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create full backup: $backup_file"
        return 0
    fi
    
    log_info "Creating full backup of database: $DB_NAME"
    log_info "Backup file: $backup_file"
    
    # Create backup with verbose output
    if pg_dump -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
        --verbose --format=custom --no-owner --no-privileges \
        --file="$backup_file.custom" 2>&1 | tee -a "$LOG_FILE"; then
        
        # Also create plain SQL backup
        pg_dump -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
            --verbose --no-owner --no-privileges > "$backup_file"
        
        log_success "Full backup created successfully"
    else
        log_error "Full backup failed"
        exit 1
    fi
    
    # Compress backup
    if [[ "$COMPRESSION" == "gzip" ]]; then
        log_info "Compressing backup..."
        gzip "$backup_file"
        backup_file="$backup_file.gz"
        log_info "Backup compressed: $backup_file"
    fi
    
    # Verify backup
    verify_backup "$backup_file"
    
    log_success "Full backup completed: $backup_file"
}

# Perform schema-only backup
backup_schema() {
    log_info "Starting schema-only backup..."
    
    local timestamp
    timestamp=$(date +%Y%m%d_%H%M%S)
    local schema_file="$BACKUP_DIR/schema/${DB_NAME}_schema_$timestamp.sql"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create schema backup: $schema_file"
        return 0
    fi
    
    log_info "Creating schema backup of database: $DB_NAME"
    
    if pg_dump -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
        --schema-only --verbose --no-owner --no-privileges > "$schema_file"; then
        log_success "Schema backup created: $schema_file"
    else
        log_error "Schema backup failed"
        exit 1
    fi
    
    # Compress if enabled
    if [[ "$COMPRESSION" == "gzip" ]]; then
        gzip "$schema_file"
        log_info "Schema backup compressed: $schema_file.gz"
    fi
}

# Verify backup integrity
verify_backup() {
    local backup_file="$1"
    
    log_info "Verifying backup integrity..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would verify backup: $backup_file"
        return 0
    fi
    
    # Check if file exists and is not empty
    if [[ ! -f "$backup_file" ]] || [[ ! -s "$backup_file" ]]; then
        log_error "Backup file is missing or empty: $backup_file"
        return 1
    fi
    
    # For compressed files, test compression integrity
    if [[ "$backup_file" == *.gz ]]; then
        if gzip -t "$backup_file"; then
            log_info "Backup compression integrity verified"
        else
            log_error "Backup compression is corrupted"
            return 1
        fi
    fi
    
    # For custom format backups, use pg_restore to verify
    if [[ "$backup_file" == *.custom ]]; then
        if pg_restore --list "$backup_file" >/dev/null 2>&1; then
            log_info "Custom format backup verified"
        else
            log_error "Custom format backup verification failed"
            return 1
        fi
    fi
    
    log_success "Backup verification completed"
}

# Restore database from backup
restore_database() {
    local backup_file="$1"
    local target_db="${2:-$DB_NAME}"
    
    log_info "Starting database restore..."
    log_info "Backup file: $backup_file"
    log_info "Target database: $target_db"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would restore from: $backup_file to database: $target_db"
        return 0
    fi
    
    # Verify backup file exists
    if [[ ! -f "$backup_file" ]]; then
        log_error "Backup file not found: $backup_file"
        exit 1
    fi
    
    # Create target database if it doesn't exist
    log_info "Ensuring target database exists..."
    if ! psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres \
        -c "SELECT 1 FROM pg_database WHERE datname='$target_db';" | grep -q 1; then
        
        log_info "Creating database: $target_db"
        psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres \
            -c "CREATE DATABASE $target_db OWNER $DB_USER;"
    fi
    
    # Restore based on file type
    if [[ "$backup_file" == *.custom ]]; then
        log_info "Restoring from custom format backup..."
        if pg_restore -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$target_db" \
            --verbose --clean --if-exists --no-owner --no-privileges "$backup_file"; then
            log_success "Custom format restore completed"
        else
            log_error "Custom format restore failed"
            exit 1
        fi
    elif [[ "$backup_file" == *.gz ]]; then
        log_info "Restoring from compressed SQL backup..."
        if zcat "$backup_file" | psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$target_db"; then
            log_success "Compressed SQL restore completed"
        else
            log_error "Compressed SQL restore failed"
            exit 1
        fi
    else
        log_info "Restoring from SQL backup..."
        if psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$target_db" < "$backup_file"; then
            log_success "SQL restore completed"
        else
            log_error "SQL restore failed"
            exit 1
        fi
    fi
    
    log_success "Database restore completed successfully"
}

# Clean old backups
cleanup_old_backups() {
    log_info "Cleaning up old backups (retention: $RETENTION_DAYS days)..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would clean backups older than $RETENTION_DAYS days"
        return 0
    fi
    
    local deleted_count=0
    
    # Clean full backups
    while IFS= read -r -d '' file; do
        rm "$file"
        ((deleted_count++))
        log_info "Deleted old backup: $(basename "$file")"
    done < <(find "$BACKUP_DIR/full" -name "*.sql*" -mtime +$RETENTION_DAYS -print0 2>/dev/null)
    
    # Clean schema backups
    while IFS= read -r -d '' file; do
        rm "$file"
        ((deleted_count++))
        log_info "Deleted old schema backup: $(basename "$file")"
    done < <(find "$BACKUP_DIR/schema" -name "*.sql*" -mtime +$RETENTION_DAYS -print0 2>/dev/null)
    
    if [[ $deleted_count -gt 0 ]]; then
        log_success "Cleaned up $deleted_count old backup files"
    else
        log_info "No old backups to clean up"
    fi
}

# List available backups
list_backups() {
    log_info "Available backups in $BACKUP_DIR:"
    
    echo ""
    echo "=== Full Backups ==="
    if ls -la "$BACKUP_DIR/full/"*.sql* 2>/dev/null; then
        echo ""
    else
        echo "No full backups found"
        echo ""
    fi
    
    echo "=== Schema Backups ==="
    if ls -la "$BACKUP_DIR/schema/"*.sql* 2>/dev/null; then
        echo ""
    else
        echo "No schema backups found"
        echo ""
    fi
    
    echo "=== Backup Directory Usage ==="
    du -sh "$BACKUP_DIR"/* 2>/dev/null || echo "No backup data"
}

# Show usage information
show_usage() {
    cat << EOF
PostgreSQL Backup and Restore Utilities

Usage: $0 <command> [options]

Commands:
  backup-full              Create full database backup
  backup-schema           Create schema-only backup
  restore <backup_file>   Restore database from backup file
  list                    List available backups
  cleanup                 Remove old backups based on retention policy
  config                  Create configuration file
  verify <backup_file>    Verify backup integrity

Options:
  --dry-run               Show what would be done without making changes
  --host HOST             Database host (default: localhost)
  --port PORT             Database port (default: 5432)
  --user USER             Database user (default: developer)
  --database DATABASE     Database name (default: development)
  --password PASSWORD     Database password (or use PGPASSWORD env var)
  --backup-dir DIR        Backup directory (default: /var/backups/postgresql)
  --retention DAYS        Backup retention in days (default: 30)
  --compression TYPE      Compression type: gzip or none (default: gzip)

Examples:
  $0 backup-full --database myapp
  $0 restore /var/backups/postgresql/full/myapp_full_20250716_120000.sql.gz
  $0 cleanup --retention 7
  PGPASSWORD=secret $0 backup-full --user developer --database production

Environment Variables:
  PGPASSWORD             Database password
EOF
}

# Parse command line arguments
parse_arguments() {
    if [[ $# -eq 0 ]]; then
        show_usage
        exit 1
    fi
    
    COMMAND="$1"
    shift
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --dry-run)
                DRY_RUN=true
                shift
                ;;
            --host)
                DB_HOST="$2"
                shift 2
                ;;
            --port)
                DB_PORT="$2"
                shift 2
                ;;
            --user)
                DB_USER="$2"
                shift 2
                ;;
            --database)
                DB_NAME="$2"
                shift 2
                ;;
            --password)
                DB_PASSWORD="$2"
                shift 2
                ;;
            --backup-dir)
                BACKUP_DIR="$2"
                shift 2
                ;;
            --retention)
                RETENTION_DAYS="$2"
                shift 2
                ;;
            --compression)
                COMPRESSION="$2"
                shift 2
                ;;
            -h|--help)
                show_usage
                exit 0
                ;;
            *)
                if [[ "$COMMAND" == "restore" ]] || [[ "$COMMAND" == "verify" ]]; then
                    BACKUP_FILE="$1"
                    shift
                else
                    echo "Unknown option: $1" >&2
                    exit 1
                fi
                ;;
        esac
    done
}

# Main execution function
main() {
    parse_arguments "$@"
    
    log_info "Starting PostgreSQL backup/restore utility..."
    log_info "Command: $COMMAND"
    log_info "Dry run mode: $DRY_RUN"
    
    load_config
    
    case "$COMMAND" in
        backup-full)
            setup_backup_directory
            validate_connection
            backup_full
            cleanup_old_backups
            ;;
        backup-schema)
            setup_backup_directory
            validate_connection
            backup_schema
            ;;
        restore)
            if [[ -z "$BACKUP_FILE" ]]; then
                log_error "Backup file not specified for restore command"
                exit 1
            fi
            validate_connection
            restore_database "$BACKUP_FILE"
            ;;
        verify)
            if [[ -z "$BACKUP_FILE" ]]; then
                log_error "Backup file not specified for verify command"
                exit 1
            fi
            verify_backup "$BACKUP_FILE"
            ;;
        list)
            list_backups
            ;;
        cleanup)
            cleanup_old_backups
            ;;
        config)
            create_config
            ;;
        *)
            log_error "Unknown command: $COMMAND"
            show_usage
            exit 1
            ;;
    esac
    
    log_success "Operation completed successfully"
    log_info "Log file: $LOG_FILE"
}

# Execute main function
main "$@"