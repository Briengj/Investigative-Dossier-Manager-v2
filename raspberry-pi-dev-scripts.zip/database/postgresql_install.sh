#!/bin/bash
#
# PostgreSQL Installation and Configuration Script for Raspberry Pi 5
# Installs PostgreSQL 17.5 with ARM64 optimizations and development configuration
# Based on current PostgreSQL versions and Debian ARM64 compatibility
#
# Usage: sudo ./postgresql_install.sh [--dry-run] [--version VERSION] [--db-name DBNAME]
# 
# Prerequisites:
# - Raspberry Pi 5 with ARM64 architecture
# - Debian-based OS (Raspberry Pi OS Bookworm)
# - Root privileges for installation
# - Internet connection for package downloads
#
# Features:
# - PostgreSQL 17.5 installation from official repository
# - ARM64 performance optimizations
# - Development-friendly configuration
# - Database and user creation
# - Security configuration
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="/var/log/postgresql_install.log"
DRY_RUN=false
PG_VERSION="17"
DB_NAME="development"
DB_USER="developer"
DB_PASSWORD=""
CONFIGURE_PERFORMANCE=true

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --version)
            PG_VERSION="$2"
            shift 2
            ;;
        --db-name)
            DB_NAME="$2"
            shift 2
            ;;
        --db-user)
            DB_USER="$2"
            shift 2
            ;;
        --db-password)
            DB_PASSWORD="$2"
            shift 2
            ;;
        --no-performance-tuning)
            CONFIGURE_PERFORMANCE=false
            shift
            ;;
        -h|--help)
            echo "Usage: sudo $0 [--dry-run] [--version VERSION] [--db-name DBNAME] [--db-user USERNAME]"
            echo "Installs and configures PostgreSQL for Raspberry Pi 5 development"
            echo ""
            echo "Options:"
            echo "  --dry-run                 Show what would be done without making changes"
            echo "  --version VERSION         PostgreSQL version to install (default: 17)"
            echo "  --db-name DBNAME          Development database name (default: development)"
            echo "  --db-user USERNAME        Development user name (default: developer)"
            echo "  --db-password PASSWORD    Database user password (generated if not provided)"
            echo "  --no-performance-tuning   Skip ARM64 performance optimizations"
            echo "  -h, --help                Show this help message"
            echo ""
            echo "Supported PostgreSQL versions: 13, 14, 15, 16, 17"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
        log_error "PostgreSQL installation may be incomplete"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root (use sudo)"
        exit 1
    fi
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" != "aarch64" ]]; then
        log_error "This script requires ARM64 architecture (aarch64)"
        log_error "Current architecture: $(uname -m)"
        exit 1
    fi
    
    # Check if running on Raspberry Pi
    if ! grep -q "Raspberry Pi" /proc/device-tree/model 2>/dev/null; then
        log_warning "Not running on Raspberry Pi - proceeding anyway"
    fi
    
    # Check Debian version
    if ! grep -q "bookworm\|12" /etc/os-release 2>/dev/null; then
        log_warning "This script is optimized for Debian 12 (Bookworm)"
    fi
    
    # Validate PostgreSQL version
    case $PG_VERSION in
        13|14|15|16|17)
            log_info "PostgreSQL version $PG_VERSION is supported"
            ;;
        *)
            log_error "Unsupported PostgreSQL version: $PG_VERSION"
            log_error "Supported versions: 13, 14, 15, 16, 17"
            exit 1
            ;;
    esac
    
    # Check internet connectivity
    if ! ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        log_error "Internet connection required for package downloads"
        exit 1
    fi
    
    # Generate password if not provided
    if [[ -z "$DB_PASSWORD" ]]; then
        DB_PASSWORD=$(openssl rand -base64 16 2>/dev/null || date +%s | sha256sum | head -c 16)
        log_info "Generated random password for database user"
    fi
    
    log_info "Prerequisites check completed"
}

# Install PostgreSQL repository
setup_postgresql_repository() {
    log_info "Setting up PostgreSQL official repository..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would add PostgreSQL official repository"
        return 0
    fi
    
    # Install required packages
    apt update
    apt install -y wget ca-certificates
    
    # Add PostgreSQL signing key
    wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | apt-key add -
    
    # Add PostgreSQL repository
    local os_codename
    os_codename=$(lsb_release -cs)
    echo "deb http://apt.postgresql.org/pub/repos/apt/ $os_codename-pgdg main" > /etc/apt/sources.list.d/pgdg.list
    
    # Update package lists
    apt update
    
    log_success "PostgreSQL repository configured"
}

# Install PostgreSQL
install_postgresql() {
    log_info "Installing PostgreSQL $PG_VERSION..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install PostgreSQL $PG_VERSION and related packages"
        return 0
    fi
    
    # Install PostgreSQL and related packages
    local packages=(
        "postgresql-$PG_VERSION"
        "postgresql-client-$PG_VERSION"
        "postgresql-contrib-$PG_VERSION"
        "postgresql-server-dev-$PG_VERSION"
        "libpq-dev"
        "postgresql-common"
    )
    
    for package in "${packages[@]}"; do
        log_info "Installing $package..."
        if apt install -y "$package"; then
            log_info "Installed: $package"
        else
            log_error "Failed to install: $package"
            exit 1
        fi
    done
    
    # Verify installation
    if command -v psql >/dev/null 2>&1; then
        local pg_version_output
        pg_version_output=$(psql --version)
        log_success "PostgreSQL installed: $pg_version_output"
    else
        log_error "PostgreSQL installation failed - psql command not found"
        exit 1
    fi
    
    # Start and enable PostgreSQL service
    systemctl start postgresql
    systemctl enable postgresql
    
    log_success "PostgreSQL $PG_VERSION installation completed"
}

# Configure PostgreSQL for development
configure_postgresql() {
    log_info "Configuring PostgreSQL for development..."
    
    local pg_config_dir="/etc/postgresql/$PG_VERSION/main"
    local pg_config_file="$pg_config_dir/postgresql.conf"
    local pg_hba_file="$pg_config_dir/pg_hba.conf"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure PostgreSQL in $pg_config_dir"
        return 0
    fi
    
    # Backup original configuration files
    cp "$pg_config_file" "$pg_config_file.backup.$(date +%Y%m%d_%H%M%S)"
    cp "$pg_hba_file" "$pg_hba_file.backup.$(date +%Y%m%d_%H%M%S)"
    
    # Configure postgresql.conf for development
    log_info "Configuring postgresql.conf..."
    
    # Basic connection settings
    sed -i "s/#listen_addresses = 'localhost'/listen_addresses = 'localhost'/" "$pg_config_file"
    sed -i "s/#port = 5432/port = 5432/" "$pg_config_file"
    
    # Configure for ARM64 and development workloads
    if [[ "$CONFIGURE_PERFORMANCE" == "true" ]]; then
        configure_performance_settings "$pg_config_file"
    fi
    
    # Configure authentication
    log_info "Configuring pg_hba.conf..."
    
    # Add development-friendly authentication rules
    cat >> "$pg_hba_file" << EOF

# Development configuration
local   $DB_NAME        $DB_USER                                md5
host    $DB_NAME        $DB_USER        127.0.0.1/32            md5
host    $DB_NAME        $DB_USER        ::1/128                 md5
EOF
    
    log_success "PostgreSQL configuration completed"
}

# Configure performance settings for ARM64
configure_performance_settings() {
    local config_file="$1"
    
    log_info "Applying ARM64 performance optimizations..."
    
    # Memory settings (adjusted for Raspberry Pi 5)
    local total_memory_kb
    total_memory_kb=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    local shared_buffers_mb=$((total_memory_kb / 4 / 1024))  # 25% of RAM
    local effective_cache_size_mb=$((total_memory_kb * 3 / 4 / 1024))  # 75% of RAM
    
    # Ensure minimum values
    [[ $shared_buffers_mb -lt 128 ]] && shared_buffers_mb=128
    [[ $effective_cache_size_mb -lt 256 ]] && effective_cache_size_mb=256
    
    # Apply memory settings
    sed -i "s/#shared_buffers = 128MB/shared_buffers = ${shared_buffers_mb}MB/" "$config_file"
    sed -i "s/#effective_cache_size = 4GB/effective_cache_size = ${effective_cache_size_mb}MB/" "$config_file"
    sed -i "s/#work_mem = 4MB/work_mem = 16MB/" "$config_file"
    sed -i "s/#maintenance_work_mem = 64MB/maintenance_work_mem = 128MB/" "$config_file"
    
    # WAL settings for better performance
    sed -i "s/#wal_buffers = -1/wal_buffers = 16MB/" "$config_file"
    sed -i "s/#checkpoint_completion_target = 0.9/checkpoint_completion_target = 0.9/" "$config_file"
    sed -i "s/#max_wal_size = 1GB/max_wal_size = 2GB/" "$config_file"
    sed -i "s/#min_wal_size = 80MB/min_wal_size = 512MB/" "$config_file"
    
    # Connection settings
    sed -i "s/#max_connections = 100/max_connections = 50/" "$config_file"
    
    # Query planner settings
    sed -i "s/#random_page_cost = 4.0/random_page_cost = 1.1/" "$config_file"  # For SSD/NVMe
    sed -i "s/#effective_io_concurrency = 1/effective_io_concurrency = 200/" "$config_file"
    
    # Logging for development
    sed -i "s/#log_statement = 'none'/log_statement = 'mod'/" "$config_file"
    sed -i "s/#log_min_duration_statement = -1/log_min_duration_statement = 1000/" "$config_file"
    
    log_info "Applied ARM64 performance optimizations:"
    log_info "  - Shared buffers: ${shared_buffers_mb}MB"
    log_info "  - Effective cache size: ${effective_cache_size_mb}MB"
    log_info "  - Work memory: 16MB"
    log_info "  - Max connections: 50"
}

# Create database and user
create_database_and_user() {
    log_info "Creating database and user..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create database '$DB_NAME' and user '$DB_USER'"
        return 0
    fi
    
    # Restart PostgreSQL to apply configuration changes
    systemctl restart postgresql
    sleep 3
    
    # Create database user
    log_info "Creating database user: $DB_USER"
    sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';"
    
    # Create database
    log_info "Creating database: $DB_NAME"
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
    
    # Grant privileges
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
    sudo -u postgres psql -c "ALTER USER $DB_USER CREATEDB;"
    
    # Test connection
    log_info "Testing database connection..."
    if PGPASSWORD="$DB_PASSWORD" psql -h localhost -U "$DB_USER" -d "$DB_NAME" -c "SELECT version();" >/dev/null 2>&1; then
        log_success "Database connection test successful"
    else
        log_error "Database connection test failed"
        exit 1
    fi
    
    log_success "Database and user created successfully"
}

# Install additional tools
install_additional_tools() {
    log_info "Installing additional PostgreSQL tools..."
    
    local tools=(
        "pgbench"
        "postgresql-$PG_VERSION-postgis-3"
        "postgresql-$PG_VERSION-postgis-3-scripts"
    )
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install additional tools: ${tools[*]}"
        return 0
    fi
    
    for tool in "${tools[@]}"; do
        log_info "Installing $tool..."
        if apt install -y "$tool" 2>/dev/null; then
            log_info "Installed: $tool"
        else
            log_warning "Failed to install or not available: $tool"
        fi
    done
    
    log_success "Additional tools installation completed"
}

# Create management scripts
create_management_scripts() {
    log_info "Creating PostgreSQL management scripts..."
    
    local scripts_dir="/usr/local/bin"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create management scripts in $scripts_dir"
        return 0
    fi
    
    # Create database backup script
    cat > "$scripts_dir/pg-backup.sh" << EOF
#!/bin/bash
# PostgreSQL Backup Script
# Usage: pg-backup.sh [database_name]

DB_NAME="\${1:-$DB_NAME}"
BACKUP_DIR="/var/backups/postgresql"
TIMESTAMP=\$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="\$BACKUP_DIR/\${DB_NAME}_\$TIMESTAMP.sql"

mkdir -p "\$BACKUP_DIR"

echo "Backing up database: \$DB_NAME"
sudo -u postgres pg_dump "\$DB_NAME" > "\$BACKUP_FILE"

if [[ \$? -eq 0 ]]; then
    echo "Backup completed: \$BACKUP_FILE"
    gzip "\$BACKUP_FILE"
    echo "Compressed: \$BACKUP_FILE.gz"
else
    echo "Backup failed"
    exit 1
fi
EOF

    # Create database restore script
    cat > "$scripts_dir/pg-restore.sh" << EOF
#!/bin/bash
# PostgreSQL Restore Script
# Usage: pg-restore.sh <backup_file> [database_name]

if [[ \$# -lt 1 ]]; then
    echo "Usage: \$0 <backup_file> [database_name]"
    exit 1
fi

BACKUP_FILE="\$1"
DB_NAME="\${2:-$DB_NAME}"

if [[ ! -f "\$BACKUP_FILE" ]]; then
    echo "Backup file not found: \$BACKUP_FILE"
    exit 1
fi

echo "Restoring database: \$DB_NAME from \$BACKUP_FILE"

# Handle compressed files
if [[ "\$BACKUP_FILE" == *.gz ]]; then
    zcat "\$BACKUP_FILE" | sudo -u postgres psql "\$DB_NAME"
else
    sudo -u postgres psql "\$DB_NAME" < "\$BACKUP_FILE"
fi

if [[ \$? -eq 0 ]]; then
    echo "Restore completed successfully"
else
    echo "Restore failed"
    exit 1
fi
EOF

    # Create performance monitoring script
    cat > "$scripts_dir/pg-monitor.sh" << EOF
#!/bin/bash
# PostgreSQL Performance Monitoring Script

echo "=== PostgreSQL Status ==="
systemctl status postgresql --no-pager -l

echo ""
echo "=== Database Connections ==="
sudo -u postgres psql -c "SELECT datname, numbackends FROM pg_stat_database WHERE datname = '$DB_NAME';"

echo ""
echo "=== Database Size ==="
sudo -u postgres psql -c "SELECT pg_database.datname, pg_size_pretty(pg_database_size(pg_database.datname)) AS size FROM pg_database WHERE datname = '$DB_NAME';"

echo ""
echo "=== Active Queries ==="
sudo -u postgres psql -c "SELECT pid, now() - pg_stat_activity.query_start AS duration, query FROM pg_stat_activity WHERE (now() - pg_stat_activity.query_start) > interval '5 minutes';"

echo ""
echo "=== Cache Hit Ratio ==="
sudo -u postgres psql -c "SELECT sum(heap_blks_read) as heap_read, sum(heap_blks_hit) as heap_hit, (sum(heap_blks_hit) - sum(heap_blks_read)) / sum(heap_blks_hit) as ratio FROM pg_statio_user_tables;"
EOF

    # Make scripts executable
    chmod +x "$scripts_dir/pg-backup.sh"
    chmod +x "$scripts_dir/pg-restore.sh"
    chmod +x "$scripts_dir/pg-monitor.sh"
    
    log_success "Management scripts created in $scripts_dir"
}

# Run performance benchmark
run_performance_test() {
    log_info "Running PostgreSQL performance test..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would run pgbench performance test"
        return 0
    fi
    
    # Initialize pgbench
    log_info "Initializing pgbench..."
    if PGPASSWORD="$DB_PASSWORD" pgbench -h localhost -U "$DB_USER" -i -s 10 "$DB_NAME"; then
        log_info "pgbench initialized successfully"
    else
        log_warning "Failed to initialize pgbench"
        return 0
    fi
    
    # Run benchmark
    log_info "Running performance benchmark (this may take a few minutes)..."
    if PGPASSWORD="$DB_PASSWORD" pgbench -h localhost -U "$DB_USER" -c 10 -j 2 -t 1000 "$DB_NAME" | tee -a "$LOG_FILE"; then
        log_success "Performance benchmark completed"
    else
        log_warning "Performance benchmark failed"
    fi
}

# Display installation summary
display_summary() {
    log_info "=== PostgreSQL Installation Summary ==="
    log_info "PostgreSQL Version: $PG_VERSION"
    log_info "Database Name: $DB_NAME"
    log_info "Database User: $DB_USER"
    log_info "Database Password: $DB_PASSWORD"
    log_info "Configuration Directory: /etc/postgresql/$PG_VERSION/main"
    log_info "Data Directory: /var/lib/postgresql/$PG_VERSION/main"
    log_info ""
    log_info "=== Connection Information ==="
    log_info "Host: localhost"
    log_info "Port: 5432"
    log_info "Database: $DB_NAME"
    log_info "Username: $DB_USER"
    log_info ""
    log_info "=== Connection Examples ==="
    log_info "psql: PGPASSWORD='$DB_PASSWORD' psql -h localhost -U $DB_USER -d $DB_NAME"
    log_info "URL: postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME"
    log_info ""
    log_info "=== Management Commands ==="
    log_info "Service status: systemctl status postgresql"
    log_info "Backup database: pg-backup.sh $DB_NAME"
    log_info "Monitor performance: pg-monitor.sh"
    log_info "PostgreSQL logs: journalctl -u postgresql -f"
    log_info ""
    log_warning "IMPORTANT: Store the database password securely!"
}

# Main execution function
main() {
    log_info "Starting PostgreSQL installation for Raspberry Pi 5..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "PostgreSQL version: $PG_VERSION"
    log_info "Database name: $DB_NAME"
    log_info "Database user: $DB_USER"
    log_info "Performance tuning: $CONFIGURE_PERFORMANCE"
    
    check_prerequisites
    setup_postgresql_repository
    install_postgresql
    configure_postgresql
    create_database_and_user
    install_additional_tools
    create_management_scripts
    run_performance_test
    
    log_success "PostgreSQL installation and configuration completed successfully!"
    display_summary
    
    log_info "Log file: $LOG_FILE"
}

# Execute main function
main "$@"