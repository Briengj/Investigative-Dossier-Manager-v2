#!/bin/bash
#
# TypeScript Setup Script for Raspberry Pi 5 Development
# Installs and configures TypeScript 5.8.3 with ARM64 optimizations
# Based on current TypeScript version and development best practices
#
# Usage: ./typescript_setup.sh [--dry-run] [--global] [--project-dir DIR]
# 
# Prerequisites:
# - Node.js and npm installed
# - ARM64 architecture (Raspberry Pi 5)
# - Write permissions for installation
#
# Features:
# - TypeScript 5.8.3 installation
# - Development-friendly tsconfig.json
# - Type definitions for Node.js
# - Build optimization for ARM64
# - Integration with popular frameworks
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/typescript_setup.log"
DRY_RUN=false
GLOBAL_INSTALL=false
PROJECT_DIR=""
TS_VERSION="5.8.3"
INSTALL_TYPES=true

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --global)
            GLOBAL_INSTALL=true
            shift
            ;;
        --project-dir)
            PROJECT_DIR="$2"
            shift 2
            ;;
        --version)
            TS_VERSION="$2"
            shift 2
            ;;
        --no-types)
            INSTALL_TYPES=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--global] [--project-dir DIR]"
            echo "Sets up TypeScript for Raspberry Pi 5 development"
            echo ""
            echo "Options:"
            echo "  --dry-run           Show what would be done without making changes"
            echo "  --global            Install TypeScript globally"
            echo "  --project-dir DIR   Setup TypeScript in specific project directory"
            echo "  --version VERSION   TypeScript version to install (default: 5.8.3)"
            echo "  --no-types          Skip installing @types packages"
            echo "  -h, --help          Show this help message"
            echo ""
            echo "Features:"
            echo "  - TypeScript 5.8.3 with ECMAScript 2024 support"
            echo "  - ARM64 optimized configuration"
            echo "  - Development-friendly tsconfig.json"
            echo "  - Essential type definitions"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if npm is installed
    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not installed"
        log_error "Install Node.js and npm first"
        exit 1
    fi
    
    # Check Node.js version
    local node_version
    node_version=$(node --version)
    log_info "Node.js version: $node_version"
    
    # Check npm version
    local npm_version
    npm_version=$(npm --version)
    log_info "npm version: v$npm_version"
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" != "aarch64" ]]; then
        log_warning "Not running on ARM64 architecture - some optimizations may not apply"
        log_warning "Current architecture: $(uname -m)"
    fi
    
    # Validate project directory if specified
    if [[ -n "$PROJECT_DIR" ]]; then
        if [[ ! -d "$PROJECT_DIR" ]]; then
            log_error "Project directory does not exist: $PROJECT_DIR"
            exit 1
        fi
    fi
    
    log_info "Prerequisites check completed"
}

# Install TypeScript globally
install_typescript_global() {
    log_info "Installing TypeScript globally..."
    log_info "TypeScript version: $TS_VERSION"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install TypeScript $TS_VERSION globally"
        return 0
    fi
    
    # Install TypeScript
    if npm install -g "typescript@$TS_VERSION"; then
        log_success "TypeScript installed globally"
    else
        log_error "Failed to install TypeScript globally"
        exit 1
    fi
    
    # Install ts-node for development
    if npm install -g ts-node; then
        log_success "ts-node installed globally"
    else
        log_warning "Failed to install ts-node globally"
    fi
    
    # Verify installation
    if command -v tsc >/dev/null 2>&1; then
        local tsc_version
        tsc_version=$(tsc --version)
        log_success "TypeScript compiler installed: $tsc_version"
    else
        log_error "TypeScript compiler not found after installation"
        exit 1
    fi
    
    if command -v ts-node >/dev/null 2>&1; then
        local ts_node_version
        ts_node_version=$(ts-node --version)
        log_success "ts-node installed: $ts_node_version"
    fi
}

# Install TypeScript in project
install_typescript_project() {
    if [[ -z "$PROJECT_DIR" ]]; then
        return 0
    fi
    
    log_info "Installing TypeScript in project directory..."
    log_info "Project directory: $PROJECT_DIR"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install TypeScript in project: $PROJECT_DIR"
        return 0
    fi
    
    cd "$PROJECT_DIR"
    
    # Initialize package.json if it doesn't exist
    if [[ ! -f "package.json" ]]; then
        log_info "Creating package.json..."
        npm init -y
    fi
    
    # Install TypeScript as dev dependency
    if npm install --save-dev "typescript@$TS_VERSION"; then
        log_success "TypeScript installed as dev dependency"
    else
        log_error "Failed to install TypeScript in project"
        exit 1
    fi
    
    # Install ts-node for development
    if npm install --save-dev ts-node; then
        log_success "ts-node installed as dev dependency"
    else
        log_warning "Failed to install ts-node in project"
    fi
    
    # Install essential type definitions
    if [[ "$INSTALL_TYPES" == "true" ]]; then
        install_type_definitions
    fi
}

# Install essential type definitions
install_type_definitions() {
    log_info "Installing essential type definitions..."
    
    local type_packages=(
        "@types/node"
        "@types/jest"
        "@types/express"
        "@types/cors"
        "@types/dotenv"
    )
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install type packages: ${type_packages[*]}"
        return 0
    fi
    
    for package in "${type_packages[@]}"; do
        log_info "Installing $package..."
        if npm install --save-dev "$package"; then
            log_info "Installed: $package"
        else
            log_warning "Failed to install: $package (may not be needed)"
        fi
    done
    
    log_success "Type definitions installation completed"
}

# Create tsconfig.json
create_tsconfig() {
    local config_file
    if [[ -n "$PROJECT_DIR" ]]; then
        config_file="$PROJECT_DIR/tsconfig.json"
    else
        config_file="./tsconfig.json"
    fi
    
    log_info "Creating tsconfig.json..."
    log_info "Configuration file: $config_file"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create tsconfig.json at: $config_file"
        return 0
    fi
    
    # Create comprehensive tsconfig.json optimized for Pi 5
    cat > "$config_file" << EOF
{
  "compilerOptions": {
    /* Language and Environment */
    "target": "es2024",                          /* ECMAScript 2024 support (TypeScript 5.8.3) */
    "lib": ["es2024", "dom", "dom.iterable"],    /* Include necessary libraries */
    "module": "node16",                          /* Use stable node16 module resolution */
    "moduleResolution": "node16",                /* Node.js 16+ module resolution */
    
    /* Emit */
    "outDir": "./dist",                          /* Output directory */
    "rootDir": "./src",                          /* Root source directory */
    "removeComments": true,                      /* Remove comments for smaller output */
    "emitDecoratorMetadata": true,               /* For NestJS and other decorators */
    "experimentalDecorators": true,              /* Enable decorators */
    "sourceMap": true,                           /* Generate source maps for debugging */
    "declaration": true,                         /* Generate .d.ts files */
    "declarationMap": true,                      /* Generate declaration source maps */
    
    /* Interop Constraints */
    "isolatedModules": true,                     /* Ensure each file can be transpiled */
    "allowSyntheticDefaultImports": true,        /* Allow default imports from modules */
    "esModuleInterop": true,                     /* Enable ES module interop */
    "forceConsistentCasingInFileNames": true,    /* Enforce consistent file naming */
    
    /* Type Checking */
    "strict": true,                              /* Enable all strict type checking */
    "noUnusedLocals": true,                      /* Report unused local variables */
    "noUnusedParameters": true,                  /* Report unused parameters */
    "exactOptionalPropertyTypes": true,          /* Strict optional property types */
    "noImplicitReturns": true,                   /* Report missing return statements */
    "noFallthroughCasesInSwitch": true,         /* Report fallthrough cases */
    "noUncheckedIndexedAccess": true,           /* Add undefined to index signatures */
    "noImplicitOverride": true,                  /* Require explicit override keyword */
    
    /* Completeness */
    "skipLibCheck": true,                        /* Skip type checking of declaration files */
    
    /* ARM64 and Performance Optimizations */
    "incremental": true,                         /* Enable incremental compilation */
    "tsBuildInfoFile": "./dist/.tsbuildinfo",    /* Build info file location */
    "composite": false,                          /* Disable composite for single projects */
    
    /* Path Mapping */
    "baseUrl": "./",                             /* Base URL for module resolution */
    "paths": {
      "@/*": ["src/*"],                          /* Path alias for src directory */
      "@types/*": ["src/types/*"],               /* Path alias for types */
      "@utils/*": ["src/utils/*"],               /* Path alias for utilities */
      "@config/*": ["src/config/*"]              /* Path alias for configuration */
    },
    
    /* Advanced Options */
    "resolveJsonModule": true,                   /* Allow importing JSON files */
    "allowJs": true,                             /* Allow JavaScript files */
    "checkJs": false,                            /* Don't check JavaScript files */
    "maxNodeModuleJsDepth": 1,                   /* Limit JS dependency depth */
    
    /* React Support (if needed) */
    "jsx": "react-jsx",                          /* Modern React JSX transform */
    "jsxImportSource": "react"                   /* JSX import source */
  },
  
  "include": [
    "src/**/*",                                  /* Include all source files */
    "tests/**/*",                                /* Include test files */
    "*.config.ts",                               /* Include config files */
    "*.config.js"                                /* Include JS config files */
  ],
  
  "exclude": [
    "node_modules",                              /* Exclude node_modules */
    "dist",                                      /* Exclude output directory */
    "build",                                     /* Exclude build directory */
    "coverage",                                  /* Exclude coverage reports */
    "**/*.spec.ts",                              /* Exclude test files from build */
    "**/*.test.ts"                               /* Exclude test files from build */
  ],
  
  "ts-node": {
    "esm": true,                                 /* Enable ES modules in ts-node */
    "experimentalSpecifierResolution": "node",   /* Node.js module resolution */
    "compilerOptions": {
      "module": "esnext",                        /* Use latest module system for ts-node */
      "target": "es2022"                         /* Target for ts-node execution */
    }
  }
}
EOF
    
    log_success "tsconfig.json created successfully"
}

# Create project structure
create_project_structure() {
    if [[ -z "$PROJECT_DIR" ]]; then
        return 0
    fi
    
    log_info "Creating TypeScript project structure..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create project structure in: $PROJECT_DIR"
        return 0
    fi
    
    cd "$PROJECT_DIR"
    
    # Create directories
    local directories=(
        "src"
        "src/types"
        "src/utils"
        "src/config"
        "tests"
        "dist"
    )
    
    for dir in "${directories[@]}"; do
        if [[ ! -d "$dir" ]]; then
            mkdir -p "$dir"
            log_info "Created directory: $dir"
        fi
    done
    
    # Create example files
    create_example_files
    
    log_success "Project structure created"
}

# Create example TypeScript files
create_example_files() {
    log_info "Creating example TypeScript files..."
    
    # Create main index.ts
    if [[ ! -f "src/index.ts" ]]; then
        cat > "src/index.ts" << 'EOF'
/**
 * Main application entry point
 * Optimized for Raspberry Pi 5 ARM64 architecture
 */

import { config } from './config/app.config';
import { logger } from './utils/logger';

async function main(): Promise<void> {
  try {
    logger.info('Starting application on Raspberry Pi 5...');
    logger.info(`Environment: ${config.environment}`);
    logger.info(`Node.js version: ${process.version}`);
    logger.info(`Architecture: ${process.arch}`);
    
    // Your application logic here
    
    logger.info('Application started successfully');
  } catch (error) {
    logger.error('Failed to start application:', error);
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGINT', () => {
  logger.info('Received SIGINT, shutting down gracefully...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  logger.info('Received SIGTERM, shutting down gracefully...');
  process.exit(0);
});

main().catch((error) => {
  logger.error('Unhandled error:', error);
  process.exit(1);
});
EOF
        log_info "Created src/index.ts"
    fi
    
    # Create configuration file
    if [[ ! -f "src/config/app.config.ts" ]]; then
        cat > "src/config/app.config.ts" << 'EOF'
/**
 * Application configuration
 * Environment-based configuration for Raspberry Pi 5
 */

export interface AppConfig {
  environment: string;
  port: number;
  database: {
    host: string;
    port: number;
    name: string;
    user: string;
    password: string;
  };
  logging: {
    level: string;
    file?: string;
  };
  pi5: {
    optimizeForArm64: boolean;
    enableHardwareAcceleration: boolean;
  };
}

export const config: AppConfig = {
  environment: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT || '3000', 10),
  database: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432', 10),
    name: process.env.DB_NAME || 'development',
    user: process.env.DB_USER || 'developer',
    password: process.env.DB_PASSWORD || '',
  },
  logging: {
    level: process.env.LOG_LEVEL || 'info',
    file: process.env.LOG_FILE,
  },
  pi5: {
    optimizeForArm64: process.env.ARM_ARCHITECTURE === 'aarch64',
    enableHardwareAcceleration: process.env.ENABLE_HARDWARE_ACCELERATION === 'true',
  },
};
EOF
        log_info "Created src/config/app.config.ts"
    fi
    
    # Create logger utility
    if [[ ! -f "src/utils/logger.ts" ]]; then
        cat > "src/utils/logger.ts" << 'EOF'
/**
 * Logger utility
 * Simple logging utility for Raspberry Pi 5 applications
 */

export interface Logger {
  info(message: string, ...args: any[]): void;
  warn(message: string, ...args: any[]): void;
  error(message: string, ...args: any[]): void;
  debug(message: string, ...args: any[]): void;
}

class SimpleLogger implements Logger {
  private formatMessage(level: string, message: string): string {
    const timestamp = new Date().toISOString();
    return `[${timestamp}] [${level.toUpperCase()}] ${message}`;
  }

  info(message: string, ...args: any[]): void {
    console.log(this.formatMessage('info', message), ...args);
  }

  warn(message: string, ...args: any[]): void {
    console.warn(this.formatMessage('warn', message), ...args);
  }

  error(message: string, ...args: any[]): void {
    console.error(this.formatMessage('error', message), ...args);
  }

  debug(message: string, ...args: any[]): void {
    if (process.env.NODE_ENV === 'development') {
      console.debug(this.formatMessage('debug', message), ...args);
    }
  }
}

export const logger: Logger = new SimpleLogger();
EOF
        log_info "Created src/utils/logger.ts"
    fi
    
    # Create types file
    if [[ ! -f "src/types/index.ts" ]]; then
        cat > "src/types/index.ts" << 'EOF'
/**
 * Type definitions
 * Common types for Raspberry Pi 5 applications
 */

export interface Pi5SystemInfo {
  model: string;
  architecture: string;
  cpuCores: number;
  totalMemory: number;
  freeMemory: number;
}

export interface DatabaseConnection {
  host: string;
  port: number;
  database: string;
  connected: boolean;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: string;
}

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface PerformanceMetrics {
  cpuUsage: number;
  memoryUsage: number;
  diskUsage: number;
  temperature: number;
}
EOF
        log_info "Created src/types/index.ts"
    fi
    
    log_success "Example files created"
}

# Update package.json scripts
update_package_scripts() {
    if [[ -z "$PROJECT_DIR" ]]; then
        return 0
    fi
    
    log_info "Updating package.json scripts..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would update package.json scripts"
        return 0
    fi
    
    cd "$PROJECT_DIR"
    
    if [[ ! -f "package.json" ]]; then
        log_warning "package.json not found, skipping script updates"
        return 0
    fi
    
    # Add TypeScript build scripts using Node.js
    local temp_script=$(mktemp)
    cat > "$temp_script" << 'EOF'
const fs = require('fs');
const path = require('path');

const packagePath = './package.json';
const packageJson = JSON.parse(fs.readFileSync(packagePath, 'utf8'));

// Add TypeScript scripts
packageJson.scripts = packageJson.scripts || {};
packageJson.scripts.build = 'tsc';
packageJson.scripts.dev = 'ts-node src/index.ts';
packageJson.scripts.start = 'node dist/index.js';
packageJson.scripts['build:watch'] = 'tsc --watch';
packageJson.scripts['type-check'] = 'tsc --noEmit';
packageJson.scripts.clean = 'rm -rf dist';

fs.writeFileSync(packagePath, JSON.stringify(packageJson, null, 2));
console.log('Updated package.json scripts');
EOF
    
    node "$temp_script"
    rm "$temp_script"
    
    log_success "package.json scripts updated"
}

# Display setup summary
display_summary() {
    log_info "=== TypeScript Setup Summary ==="
    
    # Check TypeScript installation
    if command -v tsc >/dev/null 2>&1; then
        log_info "TypeScript compiler: $(tsc --version)"
    fi
    
    if command -v ts-node >/dev/null 2>&1; then
        log_info "ts-node: $(ts-node --version)"
    fi
    
    log_info "Target version: TypeScript $TS_VERSION"
    log_info "Global installation: $GLOBAL_INSTALL"
    log_info "Project directory: ${PROJECT_DIR:-'Not specified'}"
    log_info "Type definitions installed: $INSTALL_TYPES"
    
    log_info ""
    log_info "=== Configuration Files ==="
    if [[ -n "$PROJECT_DIR" ]] && [[ -f "$PROJECT_DIR/tsconfig.json" ]]; then
        log_info "✓ tsconfig.json created in project"
    elif [[ -f "./tsconfig.json" ]]; then
        log_info "✓ tsconfig.json created in current directory"
    fi
    
    log_info ""
    log_info "=== TypeScript 5.8.3 Features ==="
    log_info "✓ ECMAScript 2024 support (--target es2024)"
    log_info "✓ Enhanced error reporting for uninitialized variables"
    log_info "✓ Stable --module node16 flag"
    log_info "✓ ARM64 optimized configuration"
    
    log_info ""
    log_info "=== Next Steps ==="
    log_info "1. Start development: npm run dev"
    log_info "2. Build project: npm run build"
    log_info "3. Type check: npm run type-check"
    log_info "4. Run built app: npm start"
    
    log_info ""
    log_info "=== Useful Commands ==="
    log_info "Compile: tsc"
    log_info "Watch mode: tsc --watch"
    log_info "Run TypeScript: ts-node src/index.ts"
    log_info "Check version: tsc --version"
}

# Main execution function
main() {
    log_info "Starting TypeScript setup for Raspberry Pi 5..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "TypeScript version: $TS_VERSION"
    log_info "Global installation: $GLOBAL_INSTALL"
    log_info "Project directory: ${PROJECT_DIR:-'Not specified'}"
    
    check_prerequisites
    
    if [[ "$GLOBAL_INSTALL" == "true" ]]; then
        install_typescript_global
    fi
    
    if [[ -n "$PROJECT_DIR" ]]; then
        install_typescript_project
        create_project_structure
        update_package_scripts
    fi
    
    create_tsconfig
    
    log_success "TypeScript setup completed successfully!"
    display_summary
    
    log_info "Log file: $LOG_FILE"
}

# Execute main function
main "$@"