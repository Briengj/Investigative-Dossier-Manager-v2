#!/bin/bash
#
# npm Optimization Script for Raspberry Pi 5
# Optimizes npm configuration for ARM64 architecture and development workflows
# Based on current npm best practices and ARM64 performance considerations
#
# Usage: ./npm_optimization.sh [--dry-run] [--global] [--project-dir DIR]
# 
# Prerequisites:
# - Node.js and npm installed
# - ARM64 architecture (Raspberry Pi 5)
# - Write permissions for npm configuration
#
# Features:
# - ARM64-specific npm optimizations
# - Registry and cache configuration
# - Build tool optimizations
# - Security and audit settings
# - Project-specific configurations
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/npm_optimization.log"
DRY_RUN=false
GLOBAL_CONFIG=false
PROJECT_DIR=""
CACHE_DIR="$HOME/.npm-cache"
REGISTRY_URL="https://registry.npmjs.org/"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --global)
            GLOBAL_CONFIG=true
            shift
            ;;
        --project-dir)
            PROJECT_DIR="$2"
            shift 2
            ;;
        --cache-dir)
            CACHE_DIR="$2"
            shift 2
            ;;
        --registry)
            REGISTRY_URL="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--global] [--project-dir DIR]"
            echo "Optimizes npm configuration for Raspberry Pi 5 development"
            echo ""
            echo "Options:"
            echo "  --dry-run           Show what would be done without making changes"
            echo "  --global            Apply global npm configuration"
            echo "  --project-dir DIR   Apply optimizations to specific project directory"
            echo "  --cache-dir DIR     Set custom npm cache directory"
            echo "  --registry URL      Set npm registry URL"
            echo "  -h, --help          Show this help message"
            echo ""
            echo "Features:"
            echo "  - ARM64 performance optimizations"
            echo "  - Build timeout and retry configurations"
            echo "  - Cache and registry optimizations"
            echo "  - Security and audit settings"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if npm is installed
    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not installed"
        log_error "Install Node.js and npm first"
        exit 1
    fi
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" != "aarch64" ]]; then
        log_warning "Not running on ARM64 architecture - some optimizations may not apply"
        log_warning "Current architecture: $(uname -m)"
    fi
    
    # Check npm version
    local npm_version
    npm_version=$(npm --version)
    log_info "npm version: v$npm_version"
    
    # Check Node.js version
    if command -v node >/dev/null 2>&1; then
        local node_version
        node_version=$(node --version)
        log_info "Node.js version: $node_version"
    fi
    
    # Validate project directory if specified
    if [[ -n "$PROJECT_DIR" ]]; then
        if [[ ! -d "$PROJECT_DIR" ]]; then
            log_error "Project directory does not exist: $PROJECT_DIR"
            exit 1
        fi
        
        if [[ ! -f "$PROJECT_DIR/package.json" ]]; then
            log_warning "No package.json found in project directory: $PROJECT_DIR"
        fi
    fi
    
    log_info "Prerequisites check completed"
}

# Configure npm registry and authentication
configure_registry() {
    log_info "Configuring npm registry..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure npm registry: $REGISTRY_URL"
        return 0
    fi
    
    # Set registry
    npm config set registry "$REGISTRY_URL"
    log_info "Set npm registry to: $REGISTRY_URL"
    
    # Configure registry-specific settings
    if [[ "$REGISTRY_URL" == *"npmjs.org"* ]]; then
        # Official npm registry optimizations
        npm config set fetch-retry-mintimeout 20000
        npm config set fetch-retry-maxtimeout 120000
        npm config set fetch-timeout 300000
        log_info "Applied official npm registry optimizations"
    fi
    
    # Verify registry configuration
    local configured_registry
    configured_registry=$(npm config get registry)
    log_success "Registry configured: $configured_registry"
}

# Configure npm cache
configure_cache() {
    log_info "Configuring npm cache..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure npm cache directory: $CACHE_DIR"
        return 0
    fi
    
    # Create cache directory
    mkdir -p "$CACHE_DIR"
    
    # Set cache directory
    npm config set cache "$CACHE_DIR"
    log_info "Set npm cache directory to: $CACHE_DIR"
    
    # Configure cache settings
    npm config set cache-max 1073741824  # 1GB cache limit
    npm config set cache-min 10
    log_info "Configured cache size limits"
    
    # Verify cache configuration
    local configured_cache
    configured_cache=$(npm config get cache)
    log_success "Cache configured: $configured_cache"
}

# Configure ARM64-specific optimizations
configure_arm64_optimizations() {
    log_info "Applying ARM64-specific optimizations..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would apply ARM64 optimizations"
        return 0
    fi
    
    # Build timeout optimizations for ARM64 (slower compilation)
    npm config set timeout 600000  # 10 minutes
    npm config set fetch-retry-mintimeout 20000
    npm config set fetch-retry-maxtimeout 120000
    npm config set fetch-retries 5
    log_info "Configured extended timeouts for ARM64 builds"
    
    # Node-gyp optimizations for native modules
    npm config set node_gyp_timeout 300000  # 5 minutes for node-gyp
    npm config set build-from-source true
    log_info "Configured node-gyp optimizations"
    
    # Python path for node-gyp (common issue on ARM64)
    if command -v python3 >/dev/null 2>&1; then
        npm config set python "$(which python3)"
        log_info "Set Python path for node-gyp: $(which python3)"
    else
        log_warning "Python3 not found - may cause issues with native modules"
    fi
    
    # Parallel job configuration (conservative for Pi 5)
    local cpu_cores
    cpu_cores=$(nproc)
    local parallel_jobs=$((cpu_cores > 2 ? cpu_cores - 1 : 1))
    npm config set jobs "$parallel_jobs"
    log_info "Set parallel jobs to: $parallel_jobs (CPU cores: $cpu_cores)"
    
    log_success "ARM64 optimizations applied"
}

# Configure security and audit settings
configure_security() {
    log_info "Configuring security and audit settings..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure security settings"
        return 0
    fi
    
    # Audit configuration
    npm config set audit-level moderate
    npm config set fund false  # Disable funding messages
    log_info "Configured audit level to moderate"
    
    # Package-lock configuration
    npm config set package-lock true
    npm config set package-lock-only false
    log_info "Enabled package-lock.json generation"
    
    # Script security
    npm config set ignore-scripts false  # Allow scripts but be cautious
    log_info "Configured script execution settings"
    
    # Update notifications
    npm config set update-notifier false  # Reduce noise in CI/development
    log_info "Disabled update notifications"
    
    log_success "Security settings configured"
}

# Configure development-specific settings
configure_development() {
    log_info "Configuring development-specific settings..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure development settings"
        return 0
    fi
    
    # Logging and output
    npm config set loglevel info
    npm config set progress true
    log_info "Configured logging and progress display"
    
    # Save configuration
    npm config set save true
    npm config set save-exact false  # Allow semver ranges
    npm config set save-prefix "^"
    log_info "Configured package saving behavior"
    
    # Development dependencies
    npm config set optional true  # Install optional dependencies
    npm config set dev true
    log_info "Configured dependency installation"
    
    # Engine strict mode (helpful for development)
    npm config set engine-strict false  # Don't fail on engine mismatches
    log_info "Configured engine compatibility"
    
    log_success "Development settings configured"
}

# Configure project-specific optimizations
configure_project() {
    if [[ -z "$PROJECT_DIR" ]]; then
        return 0
    fi
    
    log_info "Configuring project-specific optimizations..."
    log_info "Project directory: $PROJECT_DIR"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure project in: $PROJECT_DIR"
        return 0
    fi
    
    cd "$PROJECT_DIR"
    
    # Create or update .npmrc in project directory
    local npmrc_file="$PROJECT_DIR/.npmrc"
    
    cat > "$npmrc_file" << EOF
# Project-specific npm configuration
# Generated on $(date)

# Performance optimizations for ARM64
timeout=600000
fetch-retry-mintimeout=20000
fetch-retry-maxtimeout=120000
fetch-retries=5

# Build optimizations
jobs=$(nproc)
build-from-source=true

# Cache and registry
registry=$REGISTRY_URL
cache=$CACHE_DIR

# Development settings
loglevel=info
progress=true
save=true
save-prefix=^

# Security
audit-level=moderate
package-lock=true
EOF
    
    log_success "Created project .npmrc: $npmrc_file"
    
    # Optimize package.json scripts if present
    if [[ -f "package.json" ]]; then
        optimize_package_scripts
    fi
    
    # Clean and reinstall node_modules for optimization
    if [[ -d "node_modules" ]]; then
        log_info "Cleaning and reinstalling node_modules for optimization..."
        rm -rf node_modules package-lock.json
        npm install
        log_success "node_modules reinstalled with optimized configuration"
    fi
}

# Optimize package.json scripts
optimize_package_scripts() {
    log_info "Analyzing package.json scripts for optimization opportunities..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would analyze package.json scripts"
        return 0
    fi
    
    # Check for common optimization opportunities
    if grep -q "\"build\":" package.json; then
        log_info "Build script found - consider using --max-old-space-size for large builds"
    fi
    
    if grep -q "\"test\":" package.json; then
        log_info "Test script found - consider parallel test execution"
    fi
    
    if grep -q "\"start\":" package.json; then
        log_info "Start script found - consider using PM2 for production"
    fi
    
    # Check for TypeScript
    if grep -q "typescript" package.json; then
        log_info "TypeScript detected - consider incremental compilation"
    fi
    
    # Check for build tools
    if grep -q "webpack\|vite\|rollup" package.json; then
        log_info "Build tool detected - consider build caching and optimization"
    fi
}

# Clean npm cache and temporary files
clean_npm_cache() {
    log_info "Cleaning npm cache and temporary files..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would clean npm cache"
        return 0
    fi
    
    # Clean npm cache
    npm cache clean --force
    log_info "npm cache cleaned"
    
    # Clean temporary directories
    if [[ -d "/tmp/npm-*" ]]; then
        rm -rf /tmp/npm-*
        log_info "Cleaned npm temporary files"
    fi
    
    # Verify cache
    npm cache verify
    log_success "npm cache verification completed"
}

# Update npm to latest version
update_npm() {
    log_info "Updating npm to latest version..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would update npm to latest version"
        return 0
    fi
    
    local current_version
    current_version=$(npm --version)
    log_info "Current npm version: v$current_version"
    
    # Update npm
    if npm install -g npm@latest; then
        local new_version
        new_version=$(npm --version)
        log_success "npm updated to version: v$new_version"
    else
        log_warning "Failed to update npm"
    fi
}

# Display configuration summary
display_summary() {
    log_info "=== npm Optimization Summary ==="
    
    # Display current configuration
    log_info "Registry: $(npm config get registry)"
    log_info "Cache directory: $(npm config get cache)"
    log_info "Timeout: $(npm config get timeout)ms"
    log_info "Parallel jobs: $(npm config get jobs)"
    log_info "Audit level: $(npm config get audit-level)"
    
    if [[ -n "$PROJECT_DIR" ]]; then
        log_info "Project directory: $PROJECT_DIR"
        if [[ -f "$PROJECT_DIR/.npmrc" ]]; then
            log_info "Project .npmrc: Created"
        fi
    fi
    
    log_info ""
    log_info "=== Optimization Benefits ==="
    log_info "✓ Extended timeouts for ARM64 builds"
    log_info "✓ Optimized cache configuration"
    log_info "✓ Parallel job configuration"
    log_info "✓ Security and audit settings"
    log_info "✓ Development-friendly defaults"
    
    log_info ""
    log_info "=== Next Steps ==="
    log_info "1. Test package installation: npm install <package>"
    log_info "2. Monitor build performance in your projects"
    log_info "3. Adjust parallel jobs if needed: npm config set jobs <number>"
    log_info "4. Consider using yarn or pnpm for additional performance"
    
    log_info ""
    log_info "=== Useful Commands ==="
    log_info "View config: npm config list"
    log_info "Reset config: npm config delete <key>"
    log_info "Cache info: npm cache verify"
    log_info "Update npm: npm install -g npm@latest"
}

# Main execution function
main() {
    log_info "Starting npm optimization for Raspberry Pi 5..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Global config: $GLOBAL_CONFIG"
    log_info "Project directory: ${PROJECT_DIR:-'Not specified'}"
    
    check_prerequisites
    
    if [[ "$GLOBAL_CONFIG" == "true" ]] || [[ -z "$PROJECT_DIR" ]]; then
        update_npm
        configure_registry
        configure_cache
        configure_arm64_optimizations
        configure_security
        configure_development
        clean_npm_cache
    fi
    
    if [[ -n "$PROJECT_DIR" ]]; then
        configure_project
    fi
    
    log_success "npm optimization completed successfully!"
    display_summary
    
    log_info "Log file: $LOG_FILE"
}

# Execute main function
main "$@"