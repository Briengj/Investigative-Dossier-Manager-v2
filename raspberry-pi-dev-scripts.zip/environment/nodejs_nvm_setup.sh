#!/bin/bash
#
# Node.js Version Management Setup Script with NVM
# Installs NVM and configures Node.js for Raspberry Pi 5 development
# Based on current NVM installation methods and ARM64 compatibility
#
# Usage: ./nodejs_nvm_setup.sh [--dry-run] [--node-version VERSION]
# 
# Prerequisites:
# - Raspberry Pi 5 with ARM64 architecture
# - Internet connection for downloads
# - curl or wget for installation
#
# Features:
# - NVM installation from official repository
# - Node.js LTS version installation
# - ARM64 compatibility validation
# - npm optimization for development
# - Global package management
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/nodejs_nvm_setup.log"
DRY_RUN=false
NODE_VERSION="20"  # Default to Node.js 20 LTS
NVM_VERSION="v0.39.1"  # Current stable NVM version
INSTALL_GLOBAL_PACKAGES=true

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --node-version)
            NODE_VERSION="$2"
            shift 2
            ;;
        --nvm-version)
            NVM_VERSION="$2"
            shift 2
            ;;
        --no-global-packages)
            INSTALL_GLOBAL_PACKAGES=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--node-version VERSION] [--nvm-version VERSION]"
            echo "Installs NVM and Node.js for Raspberry Pi 5 development"
            echo ""
            echo "Options:"
            echo "  --dry-run                Show what would be done without making changes"
            echo "  --node-version VERSION   Node.js version to install (default: 20)"
            echo "  --nvm-version VERSION    NVM version to install (default: v0.39.1)"
            echo "  --no-global-packages     Skip global package installation"
            echo "  -h, --help               Show this help message"
            echo ""
            echo "Examples:"
            echo "  $0                       # Install NVM with Node.js 20 LTS"
            echo "  $0 --node-version 18    # Install Node.js 18 LTS"
            echo "  $0 --node-version lts   # Install latest LTS version"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" != "aarch64" ]]; then
        log_error "This script requires ARM64 architecture (aarch64)"
        log_error "Current architecture: $(uname -m)"
        exit 1
    fi
    
    # Check if running on Raspberry Pi
    if ! grep -q "Raspberry Pi" /proc/device-tree/model 2>/dev/null; then
        log_warning "Not running on Raspberry Pi - proceeding anyway"
    fi
    
    # Check for curl or wget
    if ! command -v curl >/dev/null 2>&1 && ! command -v wget >/dev/null 2>&1; then
        log_error "curl or wget is required for NVM installation"
        log_info "Install with: sudo apt update && sudo apt install curl"
        exit 1
    fi
    
    # Check internet connectivity
    if ! ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        log_error "Internet connection required for downloads"
        exit 1
    fi
    
    # Check if NVM is already installed
    if [[ -d "$HOME/.nvm" ]]; then
        log_warning "NVM directory already exists at $HOME/.nvm"
        log_warning "This installation may overwrite existing NVM setup"
    fi
    
    log_info "Prerequisites check completed"
}

# Install NVM
install_nvm() {
    log_info "Installing NVM (Node Version Manager)..."
    log_info "NVM Version: $NVM_VERSION"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install NVM from: https://raw.githubusercontent.com/nvm-sh/nvm/$NVM_VERSION/install.sh"
        return 0
    fi
    
    # Download and install NVM
    local install_url="https://raw.githubusercontent.com/nvm-sh/nvm/$NVM_VERSION/install.sh"
    
    if command -v curl >/dev/null 2>&1; then
        if curl -o- "$install_url" | bash; then
            log_success "NVM installed successfully via curl"
        else
            log_error "Failed to install NVM via curl"
            exit 1
        fi
    elif command -v wget >/dev/null 2>&1; then
        if wget -qO- "$install_url" | bash; then
            log_success "NVM installed successfully via wget"
        else
            log_error "Failed to install NVM via wget"
            exit 1
        fi
    fi
    
    # Source NVM for current session
    export NVM_DIR="$HOME/.nvm"
    if [[ -s "$NVM_DIR/nvm.sh" ]]; then
        source "$NVM_DIR/nvm.sh"
        log_info "NVM sourced for current session"
    else
        log_error "NVM installation failed - nvm.sh not found"
        exit 1
    fi
    
    # Verify NVM installation
    if command -v nvm >/dev/null 2>&1; then
        local nvm_version_output
        nvm_version_output=$(nvm --version)
        log_success "NVM installed successfully - Version: $nvm_version_output"
    else
        log_error "NVM command not available after installation"
        exit 1
    fi
}

# Configure shell profiles
configure_shell_profiles() {
    log_info "Configuring shell profiles for NVM..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure shell profiles (.bashrc, .zshrc, .profile)"
        return 0
    fi
    
    local nvm_config='
# NVM Configuration
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion'
    
    # Configure .bashrc
    if [[ -f "$HOME/.bashrc" ]]; then
        if ! grep -q "NVM_DIR" "$HOME/.bashrc"; then
            echo "$nvm_config" >> "$HOME/.bashrc"
            log_info "Added NVM configuration to .bashrc"
        else
            log_info "NVM configuration already exists in .bashrc"
        fi
    fi
    
    # Configure .zshrc if it exists
    if [[ -f "$HOME/.zshrc" ]]; then
        if ! grep -q "NVM_DIR" "$HOME/.zshrc"; then
            echo "$nvm_config" >> "$HOME/.zshrc"
            log_info "Added NVM configuration to .zshrc"
        else
            log_info "NVM configuration already exists in .zshrc"
        fi
    fi
    
    # Configure .profile
    if [[ -f "$HOME/.profile" ]]; then
        if ! grep -q "NVM_DIR" "$HOME/.profile"; then
            echo "$nvm_config" >> "$HOME/.profile"
            log_info "Added NVM configuration to .profile"
        else
            log_info "NVM configuration already exists in .profile"
        fi
    fi
    
    log_success "Shell profiles configured for NVM"
}

# Install Node.js
install_nodejs() {
    log_info "Installing Node.js version: $NODE_VERSION"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install Node.js $NODE_VERSION via NVM"
        return 0
    fi
    
    # Ensure NVM is loaded
    export NVM_DIR="$HOME/.nvm"
    if [[ -s "$NVM_DIR/nvm.sh" ]]; then
        source "$NVM_DIR/nvm.sh"
    else
        log_error "NVM not found - cannot install Node.js"
        exit 1
    fi
    
    # Install Node.js
    log_info "Installing Node.js $NODE_VERSION (this may take several minutes on ARM64)..."
    if nvm install "$NODE_VERSION"; then
        log_success "Node.js $NODE_VERSION installed successfully"
    else
        log_error "Failed to install Node.js $NODE_VERSION"
        log_error "This may be due to ARM64 compatibility issues"
        exit 1
    fi
    
    # Set as default version
    if nvm use "$NODE_VERSION"; then
        log_info "Set Node.js $NODE_VERSION as active version"
    else
        log_error "Failed to activate Node.js $NODE_VERSION"
        exit 1
    fi
    
    if nvm alias default "$NODE_VERSION"; then
        log_info "Set Node.js $NODE_VERSION as default version"
    else
        log_warning "Failed to set Node.js $NODE_VERSION as default"
    fi
    
    # Verify installation
    if command -v node >/dev/null 2>&1; then
        local node_version npm_version
        node_version=$(node --version)
        npm_version=$(npm --version)
        log_success "Node.js installed: $node_version"
        log_success "npm installed: v$npm_version"
    else
        log_error "Node.js command not available after installation"
        exit 1
    fi
}

# Optimize npm configuration
optimize_npm() {
    log_info "Optimizing npm configuration..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would optimize npm configuration"
        return 0
    fi
    
    # Set npm registry (use default but ensure it's set)
    npm config set registry https://registry.npmjs.org/
    log_info "Set npm registry to official registry"
    
    # Configure npm for better performance on ARM64
    npm config set fetch-retry-mintimeout 20000
    npm config set fetch-retry-maxtimeout 120000
    npm config set fetch-timeout 300000
    log_info "Configured npm timeouts for ARM64 performance"
    
    # Set npm cache directory
    local npm_cache_dir="$HOME/.npm-cache"
    mkdir -p "$npm_cache_dir"
    npm config set cache "$npm_cache_dir"
    log_info "Set npm cache directory to $npm_cache_dir"
    
    # Configure npm audit
    npm config set audit-level moderate
    log_info "Set npm audit level to moderate"
    
    # Update npm to latest version
    log_info "Updating npm to latest version..."
    if npm install -g npm@latest; then
        local npm_version
        npm_version=$(npm --version)
        log_success "npm updated to version: v$npm_version"
    else
        log_warning "Failed to update npm"
    fi
    
    log_success "npm optimization completed"
}

# Install global packages
install_global_packages() {
    if [[ "$INSTALL_GLOBAL_PACKAGES" != "true" ]]; then
        log_info "Skipping global package installation (--no-global-packages specified)"
        return 0
    fi
    
    log_info "Installing essential global npm packages..."
    
    local global_packages=(
        "typescript"
        "ts-node"
        "@types/node"
        "nodemon"
        "pm2"
        "yarn"
        "pnpm"
        "eslint"
        "prettier"
        "@nestjs/cli"
        "create-react-app"
        "vite"
    )
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install global packages: ${global_packages[*]}"
        return 0
    fi
    
    for package in "${global_packages[@]}"; do
        log_info "Installing global package: $package"
        if npm install -g "$package"; then
            log_info "Installed: $package"
        else
            log_warning "Failed to install: $package"
        fi
    done
    
    log_success "Global package installation completed"
}

# Create development directories
create_dev_directories() {
    log_info "Creating development directories..."
    
    local dev_dirs=(
        "$HOME/development"
        "$HOME/development/projects"
        "$HOME/development/scripts"
        "$HOME/development/temp"
    )
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create directories: ${dev_dirs[*]}"
        return 0
    fi
    
    for dir in "${dev_dirs[@]}"; do
        if [[ ! -d "$dir" ]]; then
            mkdir -p "$dir"
            log_info "Created directory: $dir"
        else
            log_info "Directory already exists: $dir"
        fi
    done
    
    log_success "Development directories created"
}

# Create Node.js version management helper script
create_helper_script() {
    log_info "Creating Node.js management helper script..."
    
    local helper_script="$HOME/development/scripts/node-manager.sh"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create helper script at $helper_script"
        return 0
    fi
    
    mkdir -p "$(dirname "$helper_script")"
    
    cat > "$helper_script" << 'EOF'
#!/bin/bash
# Node.js Version Management Helper Script
# Provides convenient commands for Node.js development

# Load NVM
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

case "$1" in
    "list"|"ls")
        echo "=== Installed Node.js Versions ==="
        nvm list
        echo ""
        echo "=== Available LTS Versions ==="
        nvm list-remote --lts
        ;;
    "current")
        echo "Current Node.js version: $(node --version)"
        echo "Current npm version: v$(npm --version)"
        echo "NVM version: $(nvm --version)"
        ;;
    "install")
        if [[ -z "$2" ]]; then
            echo "Usage: $0 install <version>"
            echo "Example: $0 install 18"
            exit 1
        fi
        nvm install "$2"
        nvm use "$2"
        ;;
    "use")
        if [[ -z "$2" ]]; then
            echo "Usage: $0 use <version>"
            echo "Example: $0 use 18"
            exit 1
        fi
        nvm use "$2"
        ;;
    "default")
        if [[ -z "$2" ]]; then
            echo "Usage: $0 default <version>"
            echo "Example: $0 default 18"
            exit 1
        fi
        nvm alias default "$2"
        ;;
    "update-npm")
        npm install -g npm@latest
        echo "npm updated to version: v$(npm --version)"
        ;;
    "global-packages")
        echo "=== Global npm Packages ==="
        npm list -g --depth=0
        ;;
    "help"|*)
        echo "Node.js Version Management Helper"
        echo ""
        echo "Usage: $0 <command> [arguments]"
        echo ""
        echo "Commands:"
        echo "  list, ls           List installed Node.js versions"
        echo "  current            Show current versions"
        echo "  install <version>  Install Node.js version"
        echo "  use <version>      Switch to Node.js version"
        echo "  default <version>  Set default Node.js version"
        echo "  update-npm         Update npm to latest version"
        echo "  global-packages    List global npm packages"
        echo "  help               Show this help message"
        ;;
esac
EOF
    
    chmod +x "$helper_script"
    log_success "Helper script created at $helper_script"
    log_info "Usage: $helper_script help"
}

# Display installation summary
display_summary() {
    log_info "=== Node.js and NVM Installation Summary ==="
    
    # Load NVM for summary
    export NVM_DIR="$HOME/.nvm"
    if [[ -s "$NVM_DIR/nvm.sh" ]]; then
        source "$NVM_DIR/nvm.sh"
    fi
    
    if command -v nvm >/dev/null 2>&1; then
        log_info "NVM Version: $(nvm --version)"
    fi
    
    if command -v node >/dev/null 2>&1; then
        log_info "Node.js Version: $(node --version)"
        log_info "npm Version: v$(npm --version)"
    fi
    
    log_info "Installation Directory: $HOME/.nvm"
    log_info "Development Directory: $HOME/development"
    log_info "Helper Script: $HOME/development/scripts/node-manager.sh"
    log_info ""
    log_info "=== Next Steps ==="
    log_info "1. Restart your terminal or run: source ~/.bashrc"
    log_info "2. Verify installation: nvm --version && node --version"
    log_info "3. Use helper script: ~/development/scripts/node-manager.sh help"
    log_info "4. Install project dependencies: cd your-project && npm install"
    log_info ""
    log_info "=== Common Commands ==="
    log_info "List versions: nvm list"
    log_info "Install version: nvm install <version>"
    log_info "Switch version: nvm use <version>"
    log_info "Set default: nvm alias default <version>"
}

# Main execution function
main() {
    log_info "Starting Node.js and NVM setup for Raspberry Pi 5..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Node.js version: $NODE_VERSION"
    log_info "NVM version: $NVM_VERSION"
    log_info "Install global packages: $INSTALL_GLOBAL_PACKAGES"
    
    check_prerequisites
    install_nvm
    configure_shell_profiles
    install_nodejs
    optimize_npm
    install_global_packages
    create_dev_directories
    create_helper_script
    
    log_success "Node.js and NVM setup completed successfully!"
    display_summary
    
    log_info "Log file: $LOG_FILE"
}

# Execute main function
main "$@"