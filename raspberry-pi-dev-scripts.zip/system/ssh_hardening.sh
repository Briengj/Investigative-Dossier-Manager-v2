#!/bin/bash
#
# SSH Server Hardening Script for Raspberry Pi 5
# Implements current security best practices for SSH server configuration
# Based on 2025 Debian Linux security recommendations
#
# Usage: sudo ./ssh_hardening.sh [--dry-run] [--port PORT] [--user USERNAME]
# 
# Prerequisites:
# - Raspberry Pi OS (Debian-based system)
# - Root privileges for SSH configuration
# - SSH server installed (openssh-server)
#
# Features:
# - SSH key-based authentication setup
# - Password authentication disabling
# - SSH port configuration (non-standard)
# - Connection limits and timeouts
# - Fail2ban integration
# - Comprehensive security hardening
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="/var/log/ssh_hardening.log"
DRY_RUN=false
SSH_PORT=22
SSH_USER=""
BACKUP_DIR="/etc/ssh/backups"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --port)
            SSH_PORT="$2"
            shift 2
            ;;
        --user)
            SSH_USER="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: sudo $0 [--dry-run] [--port PORT] [--user USERNAME]"
            echo "Hardens SSH server configuration for security"
            echo ""
            echo "Options:"
            echo "  --dry-run         Show what would be done without making changes"
            echo "  --port PORT       Set SSH port (default: 22, recommended: 30000-65335)"
            echo "  --user USERNAME   Create/configure SSH user (optional)"
            echo "  -h, --help        Show this help message"
            echo ""
            echo "Security Features:"
            echo "  - Disable password authentication"
            echo "  - Enable SSH key authentication only"
            echo "  - Configure connection limits and timeouts"
            echo "  - Disable root login"
            echo "  - Install and configure fail2ban"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
        log_error "SSH configuration may be incomplete - verify manually"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root (use sudo)"
        exit 1
    fi
    
    # Check if SSH server is installed
    if ! command -v sshd >/dev/null 2>&1; then
        log_error "SSH server (openssh-server) is not installed"
        log_info "Install with: apt install openssh-server"
        exit 1
    fi
    
    # Validate SSH port range
    if [[ $SSH_PORT -lt 1 || $SSH_PORT -gt 65535 ]]; then
        log_error "Invalid SSH port: $SSH_PORT (must be 1-65535)"
        exit 1
    fi
    
    # Warn about non-standard ports
    if [[ $SSH_PORT -eq 22 ]]; then
        log_warning "Using default SSH port 22 - consider using non-standard port (30000-65335)"
    fi
    
    # Check if user exists (if specified)
    if [[ -n "$SSH_USER" ]] && ! id "$SSH_USER" >/dev/null 2>&1; then
        log_warning "User '$SSH_USER' does not exist - will be created"
    fi
    
    # Create backup directory
    mkdir -p "$BACKUP_DIR"
    
    log_info "Prerequisites check completed"
}

# Backup SSH configuration
backup_ssh_config() {
    log_info "Backing up SSH configuration..."
    
    local timestamp
    timestamp=$(date +%Y%m%d_%H%M%S)
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would backup SSH configuration to $BACKUP_DIR"
        return 0
    fi
    
    # Backup main SSH config
    if [[ -f /etc/ssh/sshd_config ]]; then
        cp /etc/ssh/sshd_config "$BACKUP_DIR/sshd_config.backup.$timestamp"
        log_info "Backed up sshd_config"
    fi
    
    # Backup SSH host keys
    cp /etc/ssh/ssh_host_* "$BACKUP_DIR/" 2>/dev/null || true
    
    log_info "SSH configuration backup completed"
}

# Create SSH user if specified
create_ssh_user() {
    if [[ -z "$SSH_USER" ]]; then
        return 0
    fi
    
    log_info "Setting up SSH user: $SSH_USER"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create/configure user: $SSH_USER"
        return 0
    fi
    
    # Create user if doesn't exist
    if ! id "$SSH_USER" >/dev/null 2>&1; then
        useradd -m -s /bin/bash "$SSH_USER"
        log_info "Created user: $SSH_USER"
        
        # Add to sudo group for development
        usermod -aG sudo "$SSH_USER"
        log_info "Added $SSH_USER to sudo group"
    fi
    
    # Create SSH directory
    local ssh_dir="/home/$SSH_USER/.ssh"
    mkdir -p "$ssh_dir"
    chown "$SSH_USER:$SSH_USER" "$ssh_dir"
    chmod 700 "$ssh_dir"
    
    # Create authorized_keys file
    touch "$ssh_dir/authorized_keys"
    chown "$SSH_USER:$SSH_USER" "$ssh_dir/authorized_keys"
    chmod 600 "$ssh_dir/authorized_keys"
    
    log_success "SSH user $SSH_USER configured successfully"
    log_info "Add SSH public keys to: $ssh_dir/authorized_keys"
}

# Configure SSH daemon
configure_sshd() {
    log_info "Configuring SSH daemon security settings..."
    
    local sshd_config="/etc/ssh/sshd_config"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure SSH daemon settings in $sshd_config"
        return 0
    fi
    
    # Create new secure configuration
    cat > "$sshd_config" << EOF
# SSH Daemon Configuration - Security Hardened
# Generated by SSH Hardening Script on $(date)

# Network Configuration
Port $SSH_PORT
AddressFamily inet
ListenAddress 0.0.0.0

# Protocol and Encryption
Protocol 2
HostKey /etc/ssh/ssh_host_rsa_key
HostKey /etc/ssh/ssh_host_ecdsa_key
HostKey /etc/ssh/ssh_host_ed25519_key

# Key Exchange and Ciphers (Strong algorithms only)
KexAlgorithms curve25519-sha256@libssh.org,ecdh-sha2-nistp521,ecdh-sha2-nistp384,ecdh-sha2-nistp256,diffie-hellman-group16-sha512
Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com,aes128-gcm@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr
MACs hmac-sha2-256-etm@openssh.com,hmac-sha2-512-etm@openssh.com,hmac-sha2-256,hmac-sha2-512

# Authentication Settings
LoginGraceTime 30
PermitRootLogin no
StrictModes yes
MaxAuthTries 3
MaxSessions 2
PubkeyAuthentication yes
AuthorizedKeysFile .ssh/authorized_keys

# Disable Password Authentication (Key-based only)
PasswordAuthentication no
PermitEmptyPasswords no
ChallengeResponseAuthentication no
UsePAM yes

# Connection Limits
ClientAliveInterval 300
ClientAliveCountMax 2
MaxStartups 2:30:10

# Disable Dangerous Features
PermitUserEnvironment no
AllowAgentForwarding no
AllowTcpForwarding no
X11Forwarding no
PrintMotd no
PrintLastLog yes
TCPKeepAlive yes
Compression no

# Logging
SyslogFacility AUTH
LogLevel VERBOSE

# Subsystem
Subsystem sftp /usr/lib/openssh/sftp-server -f AUTHPRIV -l INFO
EOF

    # Add user-specific configuration if user specified
    if [[ -n "$SSH_USER" ]]; then
        cat >> "$sshd_config" << EOF

# User-specific Configuration
AllowUsers $SSH_USER
EOF
        log_info "Configured SSH access for user: $SSH_USER"
    fi
    
    log_success "SSH daemon configuration completed"
}

# Install and configure fail2ban
setup_fail2ban() {
    log_info "Setting up fail2ban for SSH protection..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install and configure fail2ban"
        return 0
    fi
    
    # Install fail2ban
    if ! command -v fail2ban-server >/dev/null 2>&1; then
        log_info "Installing fail2ban..."
        apt update && apt install -y fail2ban
    fi
    
    # Configure fail2ban for SSH
    cat > /etc/fail2ban/jail.local << EOF
[DEFAULT]
# Ban settings
bantime = 3600
findtime = 600
maxretry = 3
backend = systemd

[sshd]
enabled = true
port = $SSH_PORT
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
bantime = 3600
EOF
    
    # Start and enable fail2ban
    systemctl enable fail2ban
    systemctl restart fail2ban
    
    log_success "Fail2ban configured and started"
}

# Configure firewall (UFW)
setup_firewall() {
    log_info "Configuring firewall for SSH..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure UFW firewall for SSH port $SSH_PORT"
        return 0
    fi
    
    # Install UFW if not present
    if ! command -v ufw >/dev/null 2>&1; then
        log_info "Installing UFW firewall..."
        apt update && apt install -y ufw
    fi
    
    # Configure UFW
    ufw --force reset
    ufw default deny incoming
    ufw default allow outgoing
    
    # Allow SSH on configured port
    ufw allow "$SSH_PORT/tcp"
    
    # Enable UFW
    ufw --force enable
    
    log_success "Firewall configured - SSH allowed on port $SSH_PORT"
}

# Generate SSH host keys with strong algorithms
regenerate_host_keys() {
    log_info "Regenerating SSH host keys with strong algorithms..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would regenerate SSH host keys"
        return 0
    fi
    
    # Remove old keys
    rm -f /etc/ssh/ssh_host_*
    
    # Generate new keys with strong parameters
    ssh-keygen -t rsa -b 4096 -f /etc/ssh/ssh_host_rsa_key -N ""
    ssh-keygen -t ecdsa -b 521 -f /etc/ssh/ssh_host_ecdsa_key -N ""
    ssh-keygen -t ed25519 -f /etc/ssh/ssh_host_ed25519_key -N ""
    
    # Set proper permissions
    chmod 600 /etc/ssh/ssh_host_*_key
    chmod 644 /etc/ssh/ssh_host_*_key.pub
    
    log_success "SSH host keys regenerated with strong algorithms"
}

# Validate SSH configuration
validate_ssh_config() {
    log_info "Validating SSH configuration..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would validate SSH configuration"
        return 0
    fi
    
    # Test SSH configuration
    if sshd -t; then
        log_success "SSH configuration is valid"
    else
        log_error "SSH configuration validation failed"
        log_error "Restoring backup configuration..."
        
        # Restore backup if available
        local latest_backup
        latest_backup=$(ls -t "$BACKUP_DIR"/sshd_config.backup.* 2>/dev/null | head -1)
        if [[ -n "$latest_backup" ]]; then
            cp "$latest_backup" /etc/ssh/sshd_config
            log_info "Restored backup configuration"
        fi
        exit 1
    fi
}

# Restart SSH service
restart_ssh_service() {
    log_info "Restarting SSH service..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would restart SSH service"
        return 0
    fi
    
    if systemctl restart ssh; then
        log_success "SSH service restarted successfully"
    else
        log_error "Failed to restart SSH service"
        exit 1
    fi
    
    # Check if SSH is listening on configured port
    sleep 2
    if ss -tlnp | grep -q ":$SSH_PORT "; then
        log_success "SSH is listening on port $SSH_PORT"
    else
        log_error "SSH is not listening on port $SSH_PORT"
        exit 1
    fi
}

# Display security summary
display_security_summary() {
    log_info "=== SSH Security Hardening Summary ==="
    log_info "SSH Port: $SSH_PORT"
    log_info "Root Login: Disabled"
    log_info "Password Authentication: Disabled"
    log_info "Key Authentication: Enabled"
    log_info "Connection Limits: Enabled"
    log_info "Fail2ban: Enabled"
    log_info "Firewall: Configured"
    
    if [[ -n "$SSH_USER" ]]; then
        log_info "SSH User: $SSH_USER"
        log_info "SSH Keys Directory: /home/$SSH_USER/.ssh/"
    fi
    
    log_info ""
    log_info "=== Next Steps ==="
    log_info "1. Add SSH public keys to authorized_keys file"
    if [[ -n "$SSH_USER" ]]; then
        log_info "   Location: /home/$SSH_USER/.ssh/authorized_keys"
    fi
    log_info "2. Test SSH connection from another terminal before closing this session"
    log_info "3. Connection command: ssh -p $SSH_PORT user@$(hostname -I | awk '{print $1}')"
    log_info "4. Monitor fail2ban: sudo fail2ban-client status sshd"
    log_info ""
    log_warning "IMPORTANT: Test SSH connection before closing this session!"
}

# Main execution function
main() {
    log_info "Starting SSH server hardening..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "SSH Port: $SSH_PORT"
    log_info "SSH User: ${SSH_USER:-'Not specified'}"
    
    check_prerequisites
    backup_ssh_config
    create_ssh_user
    regenerate_host_keys
    configure_sshd
    validate_ssh_config
    setup_fail2ban
    setup_firewall
    restart_ssh_service
    
    log_success "SSH server hardening completed successfully!"
    display_security_summary
    
    log_info "Log file: $LOG_FILE"
    log_info "Backup directory: $BACKUP_DIR"
}

# Execute main function
main "$@"