#!/bin/bash
#
# NVMe Storage Configuration and Optimization Script for Raspberry Pi 5
# Configures PCIe interface and optimizes NVMe SSD performance
# Based on current Raspberry Pi 5 PCIe capabilities and best practices
#
# Usage: sudo ./nvme_setup.sh [--dry-run] [--pcie-gen3]
# 
# Prerequisites:
# - Raspberry Pi 5 with NVMe SSD connected via PCIe
# - Root privileges for system modifications
# - NVMe SSD properly connected to PCIe PIP
#
# Features:
# - PCIe interface detection and configuration
# - NVMe device validation and setup
# - Performance optimization (up to 1,000 MB/s with PCIe Gen 3)
# - Boot configuration for NVMe priority
# - Comprehensive error handling and logging
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="/var/log/nvme_setup.log"
DRY_RUN=false
ENABLE_PCIE_GEN3=false

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --pcie-gen3)
            ENABLE_PCIE_GEN3=true
            shift
            ;;
        -h|--help)
            echo "Usage: sudo $0 [--dry-run] [--pcie-gen3]"
            echo "Configures and optimizes NVMe storage for Raspberry Pi 5"
            echo ""
            echo "Options:"
            echo "  --dry-run     Show what would be done without making changes"
            echo "  --pcie-gen3   Enable PCIe Gen 3 for maximum performance"
            echo "  -h, --help    Show this help message"
            echo ""
            echo "Note: PCIe Gen 3 may cause compatibility issues with some SSDs"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if running on Raspberry Pi 5
    if ! grep -q "Raspberry Pi 5" /proc/device-tree/model 2>/dev/null; then
        log_error "This script is designed for Raspberry Pi 5"
        exit 1
    fi
    
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root (use sudo)"
        exit 1
    fi
    
    # Check if lspci is available
    if ! command -v lspci >/dev/null 2>&1; then
        log_info "Installing pciutils for PCIe detection..."
        if [[ "$DRY_RUN" == "false" ]]; then
            apt update && apt install -y pciutils
        fi
    fi
    
    log_info "Prerequisites check completed"
}

# PCIe interface detection
detect_pcie_interface() {
    log_info "Detecting PCIe interface and devices..."
    
    # Check if PCIe interface is available
    if ! lspci >/dev/null 2>&1; then
        log_error "PCIe interface not detected or not accessible"
        exit 1
    fi
    
    # List PCIe devices
    log_info "PCIe devices detected:"
    lspci | tee -a "$LOG_FILE"
    
    # Check for NVMe devices specifically
    local nvme_devices
    nvme_devices=$(lspci | grep -i "non-volatile\|nvme" || true)
    
    if [[ -z "$nvme_devices" ]]; then
        log_warning "No NVMe devices detected via PCIe"
        log_warning "Please ensure NVMe SSD is properly connected to PCIe PIP"
        return 1
    else
        log_info "NVMe devices found:"
        echo "$nvme_devices" | tee -a "$LOG_FILE"
    fi
    
    return 0
}

# NVMe device validation
validate_nvme_devices() {
    log_info "Validating NVMe devices..."
    
    # Check for NVMe block devices
    local nvme_blocks
    nvme_blocks=$(ls /dev/nvme* 2>/dev/null || true)
    
    if [[ -z "$nvme_blocks" ]]; then
        log_error "No NVMe block devices found in /dev/"
        log_error "NVMe SSD may not be properly recognized"
        exit 1
    fi
    
    log_info "NVMe block devices found:"
    for device in $nvme_blocks; do
        if [[ -b "$device" ]]; then
            log_info "  $device"
            # Get device information
            if command -v nvme >/dev/null 2>&1; then
                nvme id-ctrl "$device" 2>/dev/null | head -5 | tee -a "$LOG_FILE" || true
            fi
        fi
    done
    
    return 0
}

# Configure PCIe settings
configure_pcie() {
    log_info "Configuring PCIe settings..."
    
    local config_file="/boot/firmware/config.txt"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure PCIe settings in $config_file"
        if [[ "$ENABLE_PCIE_GEN3" == "true" ]]; then
            log_info "[DRY RUN] Would enable PCIe Gen 3 mode"
        fi
        return 0
    fi
    
    # Backup original config
    cp "$config_file" "${config_file}.backup.$(date +%Y%m%d_%H%M%S)"
    
    # Enable PCIe interface
    if ! grep -q "dtparam=pciex1" "$config_file"; then
        echo "dtparam=pciex1" >> "$config_file"
        log_info "Enabled PCIe x1 interface"
    fi
    
    # Configure PCIe generation if requested
    if [[ "$ENABLE_PCIE_GEN3" == "true" ]]; then
        if ! grep -q "dtparam=pciex1_gen=3" "$config_file"; then
            echo "dtparam=pciex1_gen=3" >> "$config_file"
            log_info "Enabled PCIe Gen 3 mode (up to 1,000 MB/s)"
            log_warning "PCIe Gen 3 may cause compatibility issues with some SSDs"
        fi
    else
        log_info "Using default PCIe Gen 2 mode (safer compatibility)"
    fi
    
    log_info "PCIe configuration completed"
}

# Configure boot priority for NVMe
configure_boot_priority() {
    log_info "Configuring boot priority for NVMe..."
    
    local config_file="/boot/firmware/config.txt"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure NVMe boot priority in $config_file"
        return 0
    fi
    
    # Set boot order to prioritize NVMe
    if ! grep -q "boot_order=" "$config_file"; then
        echo "boot_order=0xf25641" >> "$config_file"
        log_info "Set boot order to prioritize NVMe (0xf25641)"
    fi
    
    # Enable early boot for NVMe
    if ! grep -q "program_usb_boot_mode=1" "$config_file"; then
        echo "program_usb_boot_mode=1" >> "$config_file"
        log_info "Enabled early boot mode for external storage"
    fi
    
    log_info "Boot priority configuration completed"
}

# Optimize NVMe performance
optimize_nvme_performance() {
    log_info "Applying NVMe performance optimizations..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would apply NVMe performance optimizations"
        return 0
    fi
    
    # Find NVMe devices
    local nvme_devices
    nvme_devices=$(ls /dev/nvme*n1 2>/dev/null || true)
    
    if [[ -z "$nvme_devices" ]]; then
        log_warning "No NVMe devices found for optimization"
        return 0
    fi
    
    for device in $nvme_devices; do
        log_info "Optimizing $device..."
        
        # Set scheduler to none for NVMe (optimal for SSDs)
        local device_name
        device_name=$(basename "$device")
        local scheduler_path="/sys/block/$device_name/queue/scheduler"
        
        if [[ -f "$scheduler_path" ]]; then
            echo "none" > "$scheduler_path" 2>/dev/null || true
            log_info "Set I/O scheduler to 'none' for $device"
        fi
        
        # Optimize queue depth
        local queue_depth_path="/sys/block/$device_name/queue/nr_requests"
        if [[ -f "$queue_depth_path" ]]; then
            echo "1024" > "$queue_depth_path" 2>/dev/null || true
            log_info "Set queue depth to 1024 for $device"
        fi
        
        # Enable write cache if available
        local write_cache_path="/sys/block/$device_name/queue/write_cache"
        if [[ -f "$write_cache_path" ]]; then
            echo "write back" > "$write_cache_path" 2>/dev/null || true
            log_info "Enabled write cache for $device"
        fi
    done
    
    log_info "NVMe performance optimizations applied"
}

# Create fstab optimization
optimize_fstab() {
    log_info "Optimizing fstab for NVMe performance..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would optimize fstab entries for NVMe devices"
        return 0
    fi
    
    # Backup fstab
    cp /etc/fstab /etc/fstab.backup.$(date +%Y%m%d_%H%M%S)
    
    # Check if any NVMe devices are mounted
    local nvme_mounts
    nvme_mounts=$(mount | grep nvme || true)
    
    if [[ -n "$nvme_mounts" ]]; then
        log_info "Current NVMe mounts:"
        echo "$nvme_mounts" | tee -a "$LOG_FILE"
        log_info "Consider adding 'noatime,discard' options to NVMe mounts in /etc/fstab"
        log_info "Example: /dev/nvme0n1p1 / ext4 defaults,noatime,discard 0 1"
    fi
    
    log_info "fstab optimization guidance provided"
}

# Performance testing
test_nvme_performance() {
    log_info "Testing NVMe performance..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would perform NVMe performance tests"
        return 0
    fi
    
    # Find mounted NVMe devices
    local nvme_mounts
    nvme_mounts=$(mount | grep nvme | awk '{print $3}' || true)
    
    if [[ -z "$nvme_mounts" ]]; then
        log_warning "No mounted NVMe devices found for testing"
        return 0
    fi
    
    for mount_point in $nvme_mounts; do
        if [[ -w "$mount_point" ]]; then
            log_info "Testing write performance on $mount_point..."
            
            # Simple write test (1GB)
            local test_file="$mount_point/nvme_test_$(date +%s).tmp"
            if dd if=/dev/zero of="$test_file" bs=1M count=1024 oflag=direct 2>&1 | tee -a "$LOG_FILE"; then
                rm -f "$test_file"
                log_info "Write test completed for $mount_point"
            else
                log_warning "Write test failed for $mount_point"
                rm -f "$test_file" 2>/dev/null || true
            fi
        fi
    done
    
    log_info "Performance testing completed"
}

# Create monitoring script
create_monitoring_script() {
    log_info "Creating NVMe monitoring script..."
    
    local monitor_script="/usr/local/bin/nvme_monitor.sh"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create monitoring script at $monitor_script"
        return 0
    fi
    
    cat > "$monitor_script" << 'EOF'
#!/bin/bash
# NVMe Monitoring Script
# Shows NVMe device status and performance metrics

echo "=== NVMe Device Status ==="
echo "Date: $(date)"
echo

# List NVMe devices
echo "NVMe Devices:"
ls -la /dev/nvme* 2>/dev/null || echo "No NVMe devices found"
echo

# Show NVMe device information
if command -v nvme >/dev/null 2>&1; then
    for device in /dev/nvme*n1; do
        if [[ -b "$device" ]]; then
            echo "=== $device Information ==="
            nvme id-ctrl "$device" 2>/dev/null | head -10 || echo "Failed to get device info"
            echo
        fi
    done
fi

# Show mount information
echo "=== NVMe Mounts ==="
mount | grep nvme || echo "No NVMe devices mounted"
echo

# Show I/O statistics
echo "=== I/O Statistics ==="
if command -v iostat >/dev/null 2>&1; then
    iostat -x 1 1 | grep nvme || echo "No NVMe I/O statistics available"
else
    echo "iostat not available (install sysstat package)"
fi
EOF

    chmod +x "$monitor_script"
    log_info "Created NVMe monitoring script at $monitor_script"
    log_info "Run 'sudo nvme_monitor.sh' to check NVMe status"
}

# Main execution function
main() {
    log_info "Starting NVMe setup and optimization for Raspberry Pi 5..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "PCIe Gen 3 mode: $ENABLE_PCIE_GEN3"
    
    check_prerequisites
    
    if detect_pcie_interface; then
        validate_nvme_devices
        configure_pcie
        configure_boot_priority
        optimize_nvme_performance
        optimize_fstab
        test_nvme_performance
        create_monitoring_script
        
        log_info "NVMe setup and optimization completed successfully!"
        
        if [[ "$DRY_RUN" == "false" ]]; then
            log_info "A system reboot is required to apply PCIe and boot configuration changes"
            log_info "Run: sudo reboot"
        fi
    else
        log_error "NVMe setup cannot continue without detected NVMe devices"
        exit 1
    fi
    
    log_info "Log file: $LOG_FILE"
}

# Execute main function
main "$@"