#!/bin/bash
#
# VS Code Server Installation Script for Raspberry Pi 5
# Installs code-server for remote development on ARM64 architecture
# Based on current ARM64 compatibility and installation methods
#
# Usage: ./vscode_server_install.sh [--dry-run] [--port PORT] [--password PASSWORD]
# 
# Prerequisites:
# - Raspberry Pi 5 with ARM64 architecture
# - Node.js installed (for npm installation method)
# - Internet connection for package downloads
#
# Features:
# - code-server installation via multiple methods
# - ARM64 compatibility validation
# - Service configuration and management
# - Extension installation support
# - Security configuration
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="/var/log/vscode_server_install.log"
DRY_RUN=false
VSCODE_PORT=8080
VSCODE_PASSWORD=""
INSTALL_METHOD="npm"
SERVICE_USER="$USER"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --port)
            VSCODE_PORT="$2"
            shift 2
            ;;
        --password)
            VSCODE_PASSWORD="$2"
            shift 2
            ;;
        --method)
            INSTALL_METHOD="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--port PORT] [--password PASSWORD] [--method METHOD]"
            echo "Installs VS Code Server (code-server) for Raspberry Pi 5"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --port PORT            Set code-server port (default: 8080)"
            echo "  --password PASSWORD    Set access password (generated if not provided)"
            echo "  --method METHOD        Installation method: npm, curl, or manual (default: npm)"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Installation Methods:"
            echo "  npm     - Install via npm (requires Node.js)"
            echo "  curl    - Install via official install script"
            echo "  manual  - Manual installation from GitHub releases"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" != "aarch64" ]]; then
        log_error "This script requires ARM64 architecture (aarch64)"
        log_error "Current architecture: $(uname -m)"
        exit 1
    fi
    
    # Check if running on Raspberry Pi
    if ! grep -q "Raspberry Pi" /proc/device-tree/model 2>/dev/null; then
        log_warning "Not running on Raspberry Pi - proceeding anyway"
    fi
    
    # Validate port range
    if [[ $VSCODE_PORT -lt 1024 || $VSCODE_PORT -gt 65535 ]]; then
        log_error "Invalid port: $VSCODE_PORT (must be 1024-65535)"
        exit 1
    fi
    
    # Check if port is already in use
    if ss -tlnp | grep -q ":$VSCODE_PORT "; then
        log_error "Port $VSCODE_PORT is already in use"
        exit 1
    fi
    
    # Check installation method requirements
    case $INSTALL_METHOD in
        npm)
            if ! command -v npm >/dev/null 2>&1; then
                log_error "npm is required for npm installation method"
                log_error "Install Node.js first or use --method curl"
                exit 1
            fi
            ;;
        curl)
            if ! command -v curl >/dev/null 2>&1; then
                log_error "curl is required for curl installation method"
                exit 1
            fi
            ;;
        manual)
            if ! command -v wget >/dev/null 2>&1 && ! command -v curl >/dev/null 2>&1; then
                log_error "wget or curl is required for manual installation method"
                exit 1
            fi
            ;;
        *)
            log_error "Invalid installation method: $INSTALL_METHOD"
            log_error "Valid methods: npm, curl, manual"
            exit 1
            ;;
    esac
    
    # Generate password if not provided
    if [[ -z "$VSCODE_PASSWORD" ]]; then
        VSCODE_PASSWORD=$(openssl rand -base64 12 2>/dev/null || date +%s | sha256sum | head -c 12)
        log_info "Generated random password for code-server"
    fi
    
    log_info "Prerequisites check completed"
}

# Install code-server via npm
install_via_npm() {
    log_info "Installing code-server via npm..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install code-server via: npm install -g code-server"
        return 0
    fi
    
    # Install code-server globally
    if npm install -g code-server; then
        log_success "code-server installed successfully via npm"
    else
        log_error "Failed to install code-server via npm"
        log_error "This may be due to node-gyp compilation issues on ARM64"
        log_info "Try using --method curl instead"
        exit 1
    fi
    
    # Verify installation
    if command -v code-server >/dev/null 2>&1; then
        local version
        version=$(code-server --version | head -1)
        log_info "Installed version: $version"
    else
        log_error "code-server command not found after installation"
        exit 1
    fi
}

# Install code-server via official script
install_via_curl() {
    log_info "Installing code-server via official install script..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install code-server via official curl script"
        return 0
    fi
    
    # Download and run official install script
    if curl -fsSL https://code-server.dev/install.sh | sh; then
        log_success "code-server installed successfully via official script"
    else
        log_error "Failed to install code-server via official script"
        exit 1
    fi
    
    # Verify installation
    if command -v code-server >/dev/null 2>&1; then
        local version
        version=$(code-server --version | head -1)
        log_info "Installed version: $version"
    else
        log_error "code-server command not found after installation"
        exit 1
    fi
}

# Install code-server manually from GitHub releases
install_via_manual() {
    log_info "Installing code-server manually from GitHub releases..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install code-server manually from GitHub"
        return 0
    fi
    
    # Get latest release info
    local latest_url="https://api.github.com/repos/coder/code-server/releases/latest"
    local download_url
    
    if command -v curl >/dev/null 2>&1; then
        download_url=$(curl -s "$latest_url" | grep "browser_download_url.*linux-arm64.tar.gz" | cut -d '"' -f 4)
    elif command -v wget >/dev/null 2>&1; then
        download_url=$(wget -qO- "$latest_url" | grep "browser_download_url.*linux-arm64.tar.gz" | cut -d '"' -f 4)
    else
        log_error "Neither curl nor wget available for download"
        exit 1
    fi
    
    if [[ -z "$download_url" ]]; then
        log_error "Could not find ARM64 download URL"
        exit 1
    fi
    
    log_info "Downloading from: $download_url"
    
    # Download and extract
    local temp_dir
    temp_dir=$(mktemp -d)
    cd "$temp_dir"
    
    if command -v curl >/dev/null 2>&1; then
        curl -L "$download_url" -o code-server.tar.gz
    else
        wget "$download_url" -O code-server.tar.gz
    fi
    
    tar -xzf code-server.tar.gz
    
    # Find extracted directory
    local extracted_dir
    extracted_dir=$(find . -name "code-server-*" -type d | head -1)
    
    if [[ -z "$extracted_dir" ]]; then
        log_error "Could not find extracted code-server directory"
        exit 1
    fi
    
    # Install to /usr/local/bin
    sudo cp "$extracted_dir/bin/code-server" /usr/local/bin/
    sudo chmod +x /usr/local/bin/code-server
    
    # Clean up
    cd /
    rm -rf "$temp_dir"
    
    log_success "code-server installed manually to /usr/local/bin/"
    
    # Verify installation
    if command -v code-server >/dev/null 2>&1; then
        local version
        version=$(code-server --version | head -1)
        log_info "Installed version: $version"
    else
        log_error "code-server command not found after installation"
        exit 1
    fi
}

# Create configuration directory and files
create_configuration() {
    log_info "Creating code-server configuration..."
    
    local config_dir="$HOME/.config/code-server"
    local config_file="$config_dir/config.yaml"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create configuration in $config_dir"
        return 0
    fi
    
    # Create config directory
    mkdir -p "$config_dir"
    
    # Create configuration file
    cat > "$config_file" << EOF
bind-addr: 0.0.0.0:$VSCODE_PORT
auth: password
password: $VSCODE_PASSWORD
cert: false
disable-telemetry: true
disable-update-check: true
EOF
    
    # Set proper permissions
    chmod 600 "$config_file"
    
    log_success "Configuration created at $config_file"
}

# Create systemd service
create_systemd_service() {
    log_info "Creating systemd service for code-server..."
    
    local service_file="/etc/systemd/system/code-server@.service"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create systemd service at $service_file"
        return 0
    fi
    
    # Create service file
    sudo tee "$service_file" > /dev/null << EOF
[Unit]
Description=code-server
After=network.target

[Service]
Type=exec
ExecStart=/usr/local/bin/code-server
Restart=always
RestartSec=10
User=%i
Environment=HOME=/home/%i

[Install]
WantedBy=multi-user.target
EOF
    
    # Reload systemd and enable service
    sudo systemctl daemon-reload
    sudo systemctl enable "code-server@$SERVICE_USER"
    
    log_success "Systemd service created and enabled"
}

# Install essential extensions
install_extensions() {
    log_info "Installing essential VS Code extensions..."
    
    local extensions=(
        "ms-vscode.vscode-typescript-next"
        "bradlc.vscode-tailwindcss"
        "esbenp.prettier-vscode"
        "ms-vscode.vscode-json"
        "ms-vscode-remote.remote-ssh"
    )
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install extensions: ${extensions[*]}"
        return 0
    fi
    
    for extension in "${extensions[@]}"; do
        log_info "Installing extension: $extension"
        if code-server --install-extension "$extension" >/dev/null 2>&1; then
            log_info "Installed: $extension"
        else
            log_warning "Failed to install: $extension"
        fi
    done
    
    log_success "Extension installation completed"
}

# Configure firewall
configure_firewall() {
    log_info "Configuring firewall for code-server..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure firewall for port $VSCODE_PORT"
        return 0
    fi
    
    # Check if UFW is available and active
    if command -v ufw >/dev/null 2>&1; then
        if ufw status | grep -q "Status: active"; then
            ufw allow "$VSCODE_PORT/tcp"
            log_info "UFW rule added for port $VSCODE_PORT"
        else
            log_warning "UFW is not active - firewall rule not added"
        fi
    else
        log_warning "UFW not available - configure firewall manually if needed"
    fi
}

# Start code-server service
start_service() {
    log_info "Starting code-server service..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would start code-server service"
        return 0
    fi
    
    # Start the service
    if sudo systemctl start "code-server@$SERVICE_USER"; then
        log_success "code-server service started"
    else
        log_error "Failed to start code-server service"
        exit 1
    fi
    
    # Check service status
    sleep 3
    if systemctl is-active --quiet "code-server@$SERVICE_USER"; then
        log_success "code-server service is running"
    else
        log_error "code-server service is not running"
        log_info "Check service status: systemctl status code-server@$SERVICE_USER"
        exit 1
    fi
    
    # Verify port is listening
    if ss -tlnp | grep -q ":$VSCODE_PORT "; then
        log_success "code-server is listening on port $VSCODE_PORT"
    else
        log_error "code-server is not listening on port $VSCODE_PORT"
        exit 1
    fi
}

# Display access information
display_access_info() {
    local ip_address
    ip_address=$(hostname -I | awk '{print $1}')
    
    log_info "=== VS Code Server Installation Summary ==="
    log_info "Installation Method: $INSTALL_METHOD"
    log_info "Service User: $SERVICE_USER"
    log_info "Port: $VSCODE_PORT"
    log_info "Password: $VSCODE_PASSWORD"
    log_info ""
    log_info "=== Access Information ==="
    log_info "Local Access: http://localhost:$VSCODE_PORT"
    log_info "Network Access: http://$ip_address:$VSCODE_PORT"
    log_info ""
    log_info "=== Service Management ==="
    log_info "Start: sudo systemctl start code-server@$SERVICE_USER"
    log_info "Stop: sudo systemctl stop code-server@$SERVICE_USER"
    log_info "Status: systemctl status code-server@$SERVICE_USER"
    log_info "Logs: journalctl -u code-server@$SERVICE_USER -f"
    log_info ""
    log_info "=== Configuration ==="
    log_info "Config File: $HOME/.config/code-server/config.yaml"
    log_info "Data Directory: $HOME/.local/share/code-server"
    log_info ""
    log_warning "IMPORTANT: Change the default password in the config file!"
}

# Main execution function
main() {
    log_info "Starting VS Code Server installation for Raspberry Pi 5..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Installation method: $INSTALL_METHOD"
    log_info "Port: $VSCODE_PORT"
    log_info "Service user: $SERVICE_USER"
    
    check_prerequisites
    
    # Install based on selected method
    case $INSTALL_METHOD in
        npm)
            install_via_npm
            ;;
        curl)
            install_via_curl
            ;;
        manual)
            install_via_manual
            ;;
    esac
    
    create_configuration
    create_systemd_service
    install_extensions
    configure_firewall
    start_service
    
    log_success "VS Code Server installation completed successfully!"
    display_access_info
    
    log_info "Log file: $LOG_FILE"
}

# Execute main function
main "$@"