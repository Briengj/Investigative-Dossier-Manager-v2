# Raspberry Pi 5 Hardware Optimizations

This guide covers ARM64-specific optimizations and hardware tuning for maximum development performance on Raspberry Pi 5.

## Hardware Overview

### Raspberry Pi 5 Specifications
- **CPU**: Quad-core ARM Cortex-A76 @ 2.4 GHz (64-bit)
- **Architecture**: ARM64 (AArch64)
- **Memory**: 4GB or 8GB LPDDR4X-4267 SDRAM
- **Storage**: MicroSD + NVMe SSD via PCIe 2.0
- **GPU**: VideoCore VII @ 800 MHz
- **Network**: Gigabit Ethernet, Wi-Fi 6, Bluetooth 5.0

### Performance Characteristics
- **CPU Performance**: ~2.5x faster than Pi 4
- **Memory Bandwidth**: ~2x improvement over Pi 4
- **Storage**: NVMe SSD up to 1,000 MB/s (vs 50 MB/s microSD)
- **Power Consumption**: 5-12W depending on workload

## ARM64 Architecture Optimizations

### Memory Management Optimizations

**16KB Page Size Configuration**
```bash
# Applied by pi5_os_optimization.sh
# Provides up to 7% performance improvement
echo 'vm.nr_hugepages=128' | sudo tee -a /etc/sysctl.conf
echo 'kernel.shmmax=134217728' | sudo tee -a /etc/sysctl.conf

# Verify page size
getconf PAGESIZE
# Should show: 16384 (16KB)
```

**NUMA Emulation**
```bash
# Applied by pi5_os_optimization.sh
# Up to 18% performance boost for multi-threaded workloads
echo 'numa=fake=2' | sudo tee -a /boot/firmware/cmdline.txt

# Verify NUMA configuration
numactl --hardware
```

**Memory Allocation Optimization**
```bash
# Optimize memory allocation for development workloads
echo 'vm.swappiness=10' | sudo tee -a /etc/sysctl.conf
echo 'vm.vfs_cache_pressure=50' | sudo tee -a /etc/sysctl.conf
echo 'vm.dirty_ratio=15' | sudo tee -a /etc/sysctl.conf
echo 'vm.dirty_background_ratio=5' | sudo tee -a /etc/sysctl.conf
```

### CPU Optimizations

**CPU Governor Configuration**
```bash
# Performance governor for development workloads
echo 'performance' | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor

# Verify governor setting
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor

# Monitor CPU frequency
watch -n 1 'cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq'
```

**CPU Affinity for Node.js**
```bash
# Bind Node.js processes to specific CPU cores
# Applied automatically by PM2 configuration
export UV_THREADPOOL_SIZE=8
export NODE_OPTIONS="--max-old-space-size=2048"

# CPU affinity in PM2 ecosystem
# ecosystem.config.js:
# exec_mode: 'cluster',
# instances: 4,
# node_args: '--max-old-space-size=1024'
```

**ARM64 Compiler Optimizations**
```bash
# GCC flags for ARM64 optimization
export CFLAGS="-march=armv8-a+crc -mtune=cortex-a76 -O3"
export CXXFLAGS="-march=armv8-a+crc -mtune=cortex-a76 -O3"

# Node.js native module compilation
export CC="gcc"
export CXX="g++"
export AR="ar"
```

### SDRAM Timing Optimizations

**Memory Frequency Tuning**
```bash
# Applied by pi5_os_optimization.sh
# 10-20% speed boost at 2.4 GHz
echo 'arm_freq=2400' | sudo tee -a /boot/firmware/config.txt
echo 'over_voltage=6' | sudo tee -a /boot/firmware/config.txt
echo 'arm_boost=1' | sudo tee -a /boot/firmware/config.txt

# Memory timing optimization
echo 'sdram_freq=3200' | sudo tee -a /boot/firmware/config.txt
echo 'sdram_schmoo=0x02000020' | sudo tee -a /boot/firmware/config.txt
```

**Memory Controller Optimization**
```bash
# L2 cache optimization
echo 'disable_l2cache=0' | sudo tee -a /boot/firmware/config.txt

# Memory split optimization for headless operation
echo 'gpu_mem=64' | sudo tee -a /boot/firmware/config.txt
```

## NVMe Storage Optimizations

### PCIe Configuration

**PCIe Gen 3 Enable**
```bash
# Applied by nvme_setup.sh
# Enable PCIe Gen 3 for maximum NVMe performance
echo 'dtparam=pciex1_gen=3' | sudo tee -a /boot/firmware/config.txt

# Verify PCIe speed
sudo lspci -vv | grep -A 10 "Non-Volatile memory controller"
```

**NVMe Power Management**
```bash
# Disable ASPM for consistent performance
echo 'pcie_aspm=off' | sudo tee -a /boot/firmware/cmdline.txt

# NVMe power state optimization
echo 'nvme_core.default_ps_max_latency_us=0' | sudo tee -a /boot/firmware/cmdline.txt
```

### File System Optimizations

**ext4 Mount Options**
```bash
# Applied by nvme_setup.sh
# Optimized mount options for NVMe SSD
/dev/nvme0n1p1 / ext4 defaults,noatime,discard,commit=60,barrier=0 0 1

# Verify mount options
mount | grep nvme0n1p1
```

**I/O Scheduler Optimization**
```bash
# Use mq-deadline scheduler for NVMe
echo 'mq-deadline' | sudo tee /sys/block/nvme0n1/queue/scheduler

# Verify scheduler
cat /sys/block/nvme0n1/queue/scheduler

# Queue depth optimization
echo '32' | sudo tee /sys/block/nvme0n1/queue/nr_requests
```

**TRIM Support**
```bash
# Enable periodic TRIM for SSD longevity
sudo systemctl enable fstrim.timer
sudo systemctl start fstrim.timer

# Manual TRIM
sudo fstrim -av
```

## Network Optimizations

### Ethernet Configuration

**Network Buffer Tuning**
```bash
# Optimize network buffers for development workloads
echo 'net.core.rmem_default = 262144' | sudo tee -a /etc/sysctl.conf
echo 'net.core.rmem_max = 16777216' | sudo tee -a /etc/sysctl.conf
echo 'net.core.wmem_default = 262144' | sudo tee -a /etc/sysctl.conf
echo 'net.core.wmem_max = 16777216' | sudo tee -a /etc/sysctl.conf

# TCP optimization
echo 'net.ipv4.tcp_rmem = 4096 65536 16777216' | sudo tee -a /etc/sysctl.conf
echo 'net.ipv4.tcp_wmem = 4096 65536 16777216' | sudo tee -a /etc/sysctl.conf
```

**Network Interface Optimization**
```bash
# Ethernet interface tuning
sudo ethtool -G eth0 rx 512 tx 512
sudo ethtool -K eth0 gso on tso on

# Verify settings
sudo ethtool -g eth0
sudo ethtool -k eth0
```

## Node.js ARM64 Optimizations

### V8 Engine Tuning

**ARM64-Specific V8 Flags**
```bash
# Optimized V8 flags for ARM64
export NODE_OPTIONS="
  --max-old-space-size=2048
  --optimize-for-size
  --max-semi-space-size=128
  --initial-old-space-size=1024
  --gc-interval=100
"

# ARM64 JIT optimization
export V8_FLAGS="
  --optimize-for-size
  --max-opt-count=10000
  --always-opt
"
```

**Memory Management**
```bash
# Conservative memory limits for ARM64
export NODE_MAX_OLD_SPACE_SIZE=2048
export NODE_MAX_SEMI_SPACE_SIZE=128

# Garbage collection tuning
export NODE_GC_INTERVAL=100
export NODE_DISABLE_COLORS=1
```

### Cluster Mode Optimization

**Multi-Core Utilization**
```javascript
// ecosystem.config.js - PM2 configuration
module.exports = {
  apps: [{
    name: 'nestjs-api',
    script: './dist/main.js',
    instances: 4, // Utilize all 4 cores
    exec_mode: 'cluster',
    max_memory_restart: '512M',
    node_args: [
      '--max-old-space-size=512',
      '--optimize-for-size'
    ],
    env: {
      NODE_ENV: 'production',
      UV_THREADPOOL_SIZE: '8'
    }
  }]
};
```

## PostgreSQL ARM64 Optimizations

### Memory Configuration

**ARM64-Optimized PostgreSQL Settings**
```sql
-- Applied by postgresql_install.sh
-- Optimized for Pi 5 with 4-8GB RAM

-- Memory settings
shared_buffers = 256MB                    -- 25% of RAM for 1GB available
effective_cache_size = 1GB                -- 75% of available RAM
work_mem = 4MB                           -- Conservative for ARM64
maintenance_work_mem = 64MB              -- For VACUUM, CREATE INDEX

-- Connection settings
max_connections = 100                     -- Reasonable for development
shared_preload_libraries = 'pg_stat_statements'

-- ARM64 performance settings
random_page_cost = 1.1                   -- Optimized for NVMe SSD
effective_io_concurrency = 200           -- NVMe concurrent I/O
checkpoint_completion_target = 0.9       -- Spread checkpoint I/O
wal_buffers = 16MB                       -- Write-ahead log buffers
```

### Storage Optimization

**WAL and Checkpoint Tuning**
```sql
-- Write-ahead log optimization
wal_level = replica
max_wal_size = 1GB
min_wal_size = 80MB
checkpoint_timeout = 15min
checkpoint_completion_target = 0.9

-- Background writer optimization
bgwriter_delay = 200ms
bgwriter_lru_maxpages = 100
bgwriter_lru_multiplier = 2.0
```

## Development Tool Optimizations

### VS Code Server

**ARM64 Extensions**
```bash
# Install ARM64-compatible extensions
code-server --install-extension ms-vscode.vscode-typescript-next
code-server --install-extension bradlc.vscode-tailwindcss
code-server --install-extension esbenp.prettier-vscode

# Optimize VS Code Server settings
cat > ~/.local/share/code-server/User/settings.json << EOF
{
  "typescript.preferences.includePackageJsonAutoImports": "off",
  "typescript.suggest.autoImports": false,
  "files.watcherExclude": {
    "**/node_modules/**": true,
    "**/.git/**": true,
    "**/dist/**": true
  },
  "search.exclude": {
    "**/node_modules": true,
    "**/dist": true
  }
}
EOF
```

### Git Optimization

**Git Configuration for NVMe**
```bash
# Optimize Git for NVMe storage
git config --global core.preloadindex true
git config --global core.fscache true
git config --global gc.auto 256

# Use faster diff algorithm
git config --global diff.algorithm patience
```

## Performance Monitoring

### Hardware Monitoring

**Temperature Monitoring**
```bash
# Monitor CPU temperature
vcgencmd measure_temp

# Continuous temperature monitoring
watch -n 1 'vcgencmd measure_temp'

# Temperature with frequency
watch -n 1 'echo "Temp: $(vcgencmd measure_temp)" && echo "Freq: $(vcgencmd measure_clock arm)"'
```

**Performance Counters**
```bash
# CPU performance monitoring
perf stat -e cycles,instructions,cache-references,cache-misses node app.js

# Memory bandwidth monitoring
sudo perf stat -e node:mem_load,node:mem_store node app.js
```

### Benchmarking

**CPU Benchmark**
```bash
# Sysbench CPU test
sysbench cpu --cpu-max-prime=20000 --threads=4 run

# Node.js benchmark
node -e "
const start = Date.now();
let sum = 0;
for(let i = 0; i < 1000000000; i++) sum += i;
console.log('Time:', Date.now() - start, 'ms');
"
```

**Storage Benchmark**
```bash
# NVMe sequential read/write
sudo hdparm -tT /dev/nvme0n1

# Random I/O benchmark
sudo fio --name=random-rw --ioengine=libaio --iodepth=32 --rw=randrw \
  --bs=4k --direct=1 --size=1G --numjobs=4 --runtime=60 \
  --filename=/dev/nvme0n1p1
```

**Network Benchmark**
```bash
# Network throughput test
iperf3 -c speedtest.net -p 5201 -t 30

# Local network test
iperf3 -s &  # On server
iperf3 -c localhost -t 30  # On client
```

## Power Management

### Thermal Management

**Cooling Optimization**
```bash
# Monitor thermal throttling
vcgencmd get_throttled

# Check for under-voltage
vcgencmd get_throttled
# 0x0 = OK, 0x50000 = throttled, 0x50005 = under-voltage

# Fan control (if using active cooling)
echo 'dtoverlay=gpio-fan,gpiopin=18,temp=65000' | sudo tee -a /boot/firmware/config.txt
```

**Power State Management**
```bash
# CPU idle states
cat /sys/devices/system/cpu/cpu*/cpuidle/state*/name

# Disable CPU idle for consistent performance (if needed)
echo 'processor.max_cstate=1' | sudo tee -a /boot/firmware/cmdline.txt
```

## Optimization Verification

### Performance Testing

**System Performance Test**
```bash
# Run comprehensive performance test
./monitoring/system_monitor.sh --action snapshot

# Expected results for optimized Pi 5:
# - CPU usage: <50% under normal load
# - Memory usage: <70% with full stack
# - Temperature: <65°C under load
# - NVMe read/write: >500 MB/s
```

**Application Performance Test**
```bash
# Node.js performance test
./monitoring/app_performance_monitor.sh --action snapshot --app node

# Database performance test
./debugging/database_debug.sh --action performance

# Expected results:
# - Node.js startup: <2 seconds
# - API response time: <100ms
# - Database queries: <50ms average
```

### Optimization Impact

**Before/After Comparison**
```bash
# Baseline measurement (before optimization)
./monitoring/system_monitor.sh --action snapshot > baseline.txt

# Apply optimizations
sudo ./system/pi5_os_optimization.sh
sudo ./system/nvme_setup.sh --optimize
./deployment/production_optimizer.sh --action performance

# Performance measurement (after optimization)
./monitoring/system_monitor.sh --action snapshot > optimized.txt

# Compare results
diff baseline.txt optimized.txt
```

**Expected Performance Improvements**
- **CPU Performance**: 7-18% improvement with ARM64 optimizations
- **Memory Bandwidth**: 10-20% improvement with SDRAM tuning
- **Storage Performance**: 10-20x improvement with NVMe vs microSD
- **Network Throughput**: 5-10% improvement with buffer tuning
- **Application Startup**: 30-50% faster with optimized Node.js settings
- **Database Performance**: 20-40% improvement with PostgreSQL tuning

## Troubleshooting Optimizations

### Common Issues

**High Temperature**
```bash
# Check thermal throttling
vcgencmd get_throttled

# Reduce CPU frequency if needed
echo 'arm_freq=2000' | sudo tee -a /boot/firmware/config.txt

# Improve cooling
# - Add heatsink
# - Add fan
# - Improve case ventilation
```

**Memory Issues**
```bash
# Check memory usage
free -h

# Reduce memory usage
echo 'gpu_mem=64' | sudo tee -a /boot/firmware/config.txt

# Optimize swap
sudo dphys-swapfile swapoff
sudo sed -i 's/CONF_SWAPSIZE=100/CONF_SWAPSIZE=2048/' /etc/dphys-swapfile
sudo dphys-swapfile setup
sudo dphys-swapfile swapon
```

**Storage Performance Issues**
```bash
# Check NVMe health
sudo nvme smart-log /dev/nvme0n1

# Verify PCIe speed
sudo lspci -vv | grep -A 10 "Non-Volatile memory controller"

# Test storage performance
sudo hdparm -tT /dev/nvme0n1
```

## Maintenance

### Regular Optimization Checks

**Weekly Maintenance**
```bash
#!/bin/bash
# weekly_optimization_check.sh

echo "Running weekly optimization check..."

# Check system performance
./monitoring/system_monitor.sh --action report --period weekly

# Check thermal performance
echo "Temperature: $(vcgencmd measure_temp)"
echo "Throttling: $(vcgencmd get_throttled)"

# Check storage health
sudo nvme smart-log /dev/nvme0n1 | grep -E "temperature|percentage_used"

# Check memory usage trends
free -h

# Optimize if needed
sudo fstrim -av
echo 3 | sudo tee /proc/sys/vm/drop_caches

echo "Optimization check complete."
```

**Performance Regression Detection**
```bash
# Monitor performance trends
./monitoring/app_performance_monitor.sh --action report --compare-baseline

# Alert on performance degradation
if [ $? -ne 0 ]; then
    echo "Performance regression detected!"
    ./debugging/network_diagnostics.sh --action diagnose
    ./debugging/database_debug.sh --action performance
fi
```