# Development Workflow Examples

This document provides practical examples of common development workflows using the Raspberry Pi 5 development scripts.

## Complete Setup Workflow

### Initial System Setup

**Step 1: Full Installation**
```bash
# Clone or download the development scripts
cd ~/
git clone <repository-url> development-scripts
cd development-scripts

# Run complete installation
./install.sh --mode full

# Verify installation
./monitoring/system_monitor.sh --action status
./debugging/network_diagnostics.sh --action services
```

**Step 2: System Optimization**
```bash
# Optimize OS for development
sudo ./system/pi5_os_optimization.sh

# Setup NVMe storage
sudo ./system/nvme_setup.sh --optimize

# Harden SSH security
sudo ./system/ssh_hardening.sh --port 2222 --key-only

# Install VS Code Server
./system/vscode_server_install.sh --port 8080
```

**Step 3: Development Environment**
```bash
# Setup Node.js 20 LTS
./environment/nodejs_nvm_setup.sh --version 20 --global-packages

# Optimize npm configuration
./environment/npm_optimization.sh --cache-size 512 --optimize

# Setup TypeScript
./environment/typescript_setup.sh --version 5.8.3 --global
```

## Full-Stack Project Creation

### React Frontend + NestJS Backend

**Step 1: Create Project Structure**
```bash
# Create workspace directory
mkdir -p ~/development/projects/my-fullstack-app
cd ~/development/projects/my-fullstack-app

# Create React frontend
../../../project/init_react_project.sh \
  --project-name frontend \
  --template typescript \
  --directory ./

# Create NestJS backend
../../../project/init_nestjs_project.sh \
  --project-name backend \
  --database postgresql \
  --directory ./
```

**Step 2: Database Setup**
```bash
# Install and configure PostgreSQL
sudo ./database/postgresql_install.sh --version 17 --secure-install --optimize

# Create project database
sudo -u postgres createdb my_fullstack_app

# Create database user
sudo -u postgres psql -c "CREATE USER app_user WITH PASSWORD 'secure_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE my_fullstack_app TO app_user;"
```

**Step 3: Configure Environment**
```bash
# Frontend environment
cat > frontend/.env.local << EOF
REACT_APP_API_URL=http://localhost:3001/api
REACT_APP_ENV=development
EOF

# Backend environment
cat > backend/.env << EOF
NODE_ENV=development
PORT=3001
DATABASE_URL=postgresql://app_user:secure_password@localhost:5432/my_fullstack_app
JWT_SECRET=your_jwt_secret_here
CORS_ORIGIN=http://localhost:3000
EOF
```

**Step 4: Setup Development Workflow**
```bash
# Configure hot reload for both projects
./workflow/hot_reload_setup.sh --project-type both

# Setup PM2 ecosystem
./workflow/pm2_manager.sh --action setup

# Reserve development ports
./workflow/port_manager.sh --action reserve --port 3000 --service react
./workflow/port_manager.sh --action reserve --port 3001 --service nestjs
```

## Development Workflow

### Daily Development Routine

**Step 1: Start Development Environment**
```bash
# Check system status
./monitoring/system_monitor.sh --action status

# Start all services
./workflow/pm2_manager.sh --action start --env development

# Start log monitoring
./workflow/log_monitor.sh --action monitor --follow &
LOG_MONITOR_PID=$!

# Start system monitoring
./monitoring/system_monitor.sh --action monitor --continuous &
SYSTEM_MONITOR_PID=$!
```

**Step 2: Development Work**
```bash
# Create feature branch
./workflow/git_workflow.sh --action branch --branch feature/user-authentication

# Monitor application performance
./monitoring/app_performance_monitor.sh --action monitor --app all &
APP_MONITOR_PID=$!

# Your development work here...
# Edit files, test features, etc.

# Run tests during development
./project/test_runner.sh --test-type unit --watch --project-path ./frontend &
./project/test_runner.sh --test-type unit --watch --project-path ./backend &
```

**Step 3: Code Quality and Testing**
```bash
# Run code quality checks
./project/code_quality.sh --project-path ./frontend
./project/code_quality.sh --project-path ./backend

# Run comprehensive tests
./project/test_runner.sh --test-type all --coverage --project-path ./frontend
./project/test_runner.sh --test-type all --coverage --project-path ./backend

# Build for testing
./project/build_automation.sh --project-type react --environment development
./project/build_automation.sh --project-type nestjs --environment development
```

**Step 4: Commit and Push**
```bash
# Commit with automated tests
./workflow/git_workflow.sh \
  --action commit \
  --message "Add user authentication feature" \
  --run-tests \
  --auto-push
```

**Step 5: Cleanup**
```bash
# Stop monitoring processes
kill $LOG_MONITOR_PID $SYSTEM_MONITOR_PID $APP_MONITOR_PID

# Stop development services
./workflow/pm2_manager.sh --action stop
```

## Testing Workflows

### Comprehensive Testing Pipeline

**Step 1: Unit Testing**
```bash
# Frontend unit tests
./project/test_runner.sh \
  --test-type unit \
  --coverage \
  --project-path ./frontend \
  --reporter html

# Backend unit tests
./project/test_runner.sh \
  --test-type unit \
  --coverage \
  --project-path ./backend \
  --reporter html
```

**Step 2: Integration Testing**
```bash
# Start test database
sudo -u postgres createdb my_fullstack_app_test

# Configure test environment
export NODE_ENV=test
export DATABASE_URL=postgresql://app_user:secure_password@localhost:5432/my_fullstack_app_test

# Run integration tests
./project/test_runner.sh \
  --test-type integration \
  --project-path ./backend
```

**Step 3: End-to-End Testing**
```bash
# Start application in test mode
./workflow/pm2_manager.sh --action start --env test

# Wait for services to be ready
./deployment/health_checker.sh --service all --timeout 60

# Run E2E tests
./project/test_runner.sh \
  --test-type e2e \
  --project-path ./frontend

# Cleanup test environment
./workflow/pm2_manager.sh --action stop
sudo -u postgres dropdb my_fullstack_app_test
```

## Deployment Workflows

### Staging Deployment

**Step 1: Pre-deployment Checks**
```bash
# Run full test suite
./project/test_runner.sh --test-type all --coverage --project-path ./frontend
./project/test_runner.sh --test-type all --coverage --project-path ./backend

# Code quality validation
./project/code_quality.sh --check-only --project-path ./frontend
./project/code_quality.sh --check-only --project-path ./backend

# Security audit
./project/dependency_manager.sh --action audit --project-path ./frontend
./project/dependency_manager.sh --action audit --project-path ./backend
```

**Step 2: Build for Staging**
```bash
# Build frontend for staging
./project/build_automation.sh \
  --project-type react \
  --environment staging \
  --optimize

# Build backend for staging
./project/build_automation.sh \
  --project-type nestjs \
  --environment staging
```

**Step 3: Deploy to Staging**
```bash
# Switch to staging environment
./deployment/environment_switcher.sh \
  --action switch \
  --environment staging

# Deploy application
./deployment/deploy_pipeline.sh \
  --environment staging \
  --branch develop

# Verify deployment
./deployment/health_checker.sh --service all
```

### Production Deployment

**Step 1: System Optimization**
```bash
# Optimize system for production
./deployment/production_optimizer.sh --action all --profile performance

# Create backup
./deployment/environment_switcher.sh \
  --action backup \
  --backup-name pre-production-$(date +%Y%m%d_%H%M%S)

# Database backup
./database/backup_restore_utils.sh \
  --action backup \
  --database my_fullstack_app \
  --compress
```

**Step 2: Production Build**
```bash
# Build for production
./project/build_automation.sh \
  --project-type react \
  --environment production \
  --optimize \
  --analyze

./project/build_automation.sh \
  --project-type nestjs \
  --environment production
```

**Step 3: Deploy to Production**
```bash
# Switch to production environment
./deployment/environment_switcher.sh \
  --action switch \
  --environment production

# Deploy with rollback capability
./deployment/deploy_pipeline.sh \
  --environment production \
  --branch main \
  --backup

# Verify deployment health
./deployment/health_checker.sh --service all --continuous &
HEALTH_CHECK_PID=$!

# Monitor system during deployment
./monitoring/system_monitor.sh --action monitor --continuous &
MONITOR_PID=$!

# Wait for deployment verification
sleep 300

# Stop monitoring
kill $HEALTH_CHECK_PID $MONITOR_PID

# Generate deployment report
./monitoring/app_performance_monitor.sh --action report
```

## Monitoring and Maintenance

### Daily Monitoring Routine

**Step 1: System Health Check**
```bash
# Morning system check
./monitoring/system_monitor.sh --action status
./deployment/health_checker.sh --service all
./debugging/database_debug.sh --action performance
```

**Step 2: Performance Analysis**
```bash
# Generate performance reports
./monitoring/system_monitor.sh --action report --period daily
./monitoring/app_performance_monitor.sh --action report --period daily

# Check for alerts
./monitoring/system_monitor.sh --action alerts
```

**Step 3: Log Analysis**
```bash
# Analyze logs for errors
./workflow/log_monitor.sh --action analyze --service all

# Check for performance issues
./workflow/log_monitor.sh --action search --filter "slow\|timeout\|error"

# Rotate logs if needed
./workflow/log_monitor.sh --action rotate
```

### Weekly Maintenance

**Step 1: System Updates**
```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Update Node.js dependencies
./project/dependency_manager.sh --action update --project-path ./frontend
./project/dependency_manager.sh --action update --project-path ./backend

# Security audit
./project/dependency_manager.sh --action audit --project-path ./frontend
./project/dependency_manager.sh --action audit --project-path ./backend
```

**Step 2: Database Maintenance**
```bash
# Database backup
./database/backup_restore_utils.sh \
  --action backup \
  --database my_fullstack_app \
  --compress

# Database optimization
./debugging/database_debug.sh --action performance
sudo -u postgres psql my_fullstack_app -c "VACUUM ANALYZE;"
```

**Step 3: Performance Optimization**
```bash
# System optimization check
./deployment/production_optimizer.sh --action performance --dry-run

# Clean up old logs and files
find ~/development/logs -name "*.log" -mtime +30 -delete
npm cache clean --force
```

## Troubleshooting Workflows

### Performance Issue Investigation

**Step 1: Identify the Problem**
```bash
# Check system resources
./monitoring/system_monitor.sh --action snapshot

# Check application performance
./monitoring/app_performance_monitor.sh --action snapshot --app all

# Check network connectivity
./debugging/network_diagnostics.sh --action diagnose
```

**Step 2: Deep Dive Analysis**
```bash
# Database performance analysis
./debugging/database_debug.sh --action slow-queries --threshold 1000
./debugging/database_debug.sh --action locks

# Application log analysis
./workflow/log_monitor.sh --action analyze --service all

# System resource analysis
top -p $(pgrep -d',' node)
```

**Step 3: Apply Fixes**
```bash
# Restart services if needed
./workflow/pm2_manager.sh --action restart

# Optimize database if needed
sudo -u postgres psql -c "REINDEX DATABASE my_fullstack_app;"

# Clear caches
npm cache clean --force
sudo sync && echo 3 | sudo tee /proc/sys/vm/drop_caches
```

### Emergency Recovery

**Step 1: Immediate Response**
```bash
# Check system status
./monitoring/system_monitor.sh --action status

# Check service health
./deployment/health_checker.sh --service all

# If services are down, restart
./workflow/pm2_manager.sh --action restart
```

**Step 2: Rollback if Necessary**
```bash
# Rollback deployment
./deployment/deploy_pipeline.sh --environment production --rollback

# Restore environment
./deployment/environment_switcher.sh \
  --action restore \
  --backup-name pre-production-latest

# Restore database if needed
./database/backup_restore_utils.sh \
  --action restore \
  --backup-name latest
```

**Step 3: Post-Recovery Analysis**
```bash
# Generate incident report
./monitoring/system_monitor.sh --action report --period incident
./workflow/log_monitor.sh --action analyze --service all

# Check system integrity
./debugging/network_diagnostics.sh --action diagnose
./debugging/database_debug.sh --action diagnose
```

## Custom Workflow Examples

### Automated Development Setup Script

```bash
#!/bin/bash
# automated_dev_setup.sh

echo "Starting automated development setup..."

# System check
./monitoring/system_monitor.sh --action status

# Start services
./workflow/pm2_manager.sh --action start --env development

# Check health
./deployment/health_checker.sh --service all

# Start monitoring
./workflow/log_monitor.sh --action monitor --follow &
./monitoring/system_monitor.sh --action monitor --continuous &

echo "Development environment ready!"
echo "Frontend: http://localhost:3000"
echo "Backend API: http://localhost:3001"
echo "VS Code Server: http://localhost:8080"
```

### Automated Testing Pipeline

```bash
#!/bin/bash
# automated_test_pipeline.sh

echo "Running automated test pipeline..."

# Code quality checks
./project/code_quality.sh --check-only --project-path ./frontend
./project/code_quality.sh --check-only --project-path ./backend

# Unit tests
./project/test_runner.sh --test-type unit --coverage --project-path ./frontend
./project/test_runner.sh --test-type unit --coverage --project-path ./backend

# Integration tests
./project/test_runner.sh --test-type integration --project-path ./backend

# Security audit
./project/dependency_manager.sh --action audit --project-path ./frontend
./project/dependency_manager.sh --action audit --project-path ./backend

echo "Test pipeline completed!"
```

### Performance Monitoring Dashboard

```bash
#!/bin/bash
# performance_dashboard.sh

echo "Performance Monitoring Dashboard"
echo "================================"

# System metrics
echo "System Status:"
./monitoring/system_monitor.sh --action status

echo -e "\nApplication Performance:"
./monitoring/app_performance_monitor.sh --action snapshot --app all

echo -e "\nDatabase Performance:"
./debugging/database_debug.sh --action performance

echo -e "\nNetwork Status:"
./debugging/network_diagnostics.sh --action services

echo -e "\nService Health:"
./deployment/health_checker.sh --service all
```