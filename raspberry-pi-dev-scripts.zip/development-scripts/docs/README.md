# Documentation Index

This directory contains comprehensive documentation for the Raspberry Pi 5 Development Scripts collection.

## Documentation Structure

### Usage Guides
Detailed usage documentation for each script category:

- **[System Scripts](usage-guides/system-scripts.md)** - OS optimization, hardware configuration, and security hardening
- **[Project Scripts](usage-guides/project-scripts.md)** - React and NestJS project creation and management
- **[Monitoring Scripts](usage-guides/monitoring-scripts.md)** - System and application monitoring tools
- **[Workflow Scripts](usage-guides/workflow-scripts.md)** - Development workflow automation
- **[Deployment Scripts](usage-guides/deployment-scripts.md)** - Production deployment and environment management
- **[Debugging Scripts](usage-guides/debugging-scripts.md)** - Network and database troubleshooting tools

### Troubleshooting
Problem-solving guides and common issue resolution:

- **[Common Issues](troubleshooting/common-issues.md)** - Comprehensive troubleshooting guide for all components

### API Reference
Complete parameter and configuration reference:

- **[Script Parameters](api-reference/script-parameters.md)** - All script parameters, options, and configurations

### Examples
Practical usage examples and workflows:

- **[Development Workflows](examples/development-workflows.md)** - Complete workflow examples and use cases

### Hardware Optimization
Raspberry Pi 5 specific optimizations:

- **[Hardware Optimizations](hardware-optimization/raspberry-pi5-optimizations.md)** - ARM64 and Pi 5 performance tuning

### Security
Security configurations and best practices:

- **[Security Best Practices](security/security-best-practices.md)** - Comprehensive security hardening guide

## Quick Navigation

### Getting Started
1. Read the main [README.md](../README.md) for project overview
2. Follow [System Scripts Usage](usage-guides/system-scripts.md) for initial setup
3. Review [Hardware Optimizations](hardware-optimization/raspberry-pi5-optimizations.md) for performance tuning

### Development Setup
1. Use [Project Scripts](usage-guides/project-scripts.md) for creating React/NestJS projects
2. Configure [Workflow Scripts](usage-guides/workflow-scripts.md) for development automation
3. Set up [Monitoring Scripts](usage-guides/monitoring-scripts.md) for system oversight

### Production Deployment
1. Follow [Deployment Scripts](usage-guides/deployment-scripts.md) for production setup
2. Implement [Security Best Practices](security/security-best-practices.md) for hardening
3. Use [Monitoring Scripts](usage-guides/monitoring-scripts.md) for production oversight

### Troubleshooting
1. Check [Common Issues](troubleshooting/common-issues.md) for known problems
2. Use [Debugging Scripts](usage-guides/debugging-scripts.md) for diagnostics
3. Reference [API Documentation](api-reference/script-parameters.md) for parameter details

## Documentation Features

### Comprehensive Coverage
- All 28 scripts documented with real parameters and examples
- Complete workflow examples from development to production
- Hardware-specific optimizations for Raspberry Pi 5
- Security hardening procedures and best practices

### Practical Examples
- Real-world development workflows
- Complete project setup procedures
- Production deployment pipelines
- Troubleshooting scenarios with solutions

### Technical Depth
- ARM64 architecture optimizations
- PostgreSQL 17 performance tuning
- Node.js 20 LTS configuration
- React 19.1.0 and NestJS 11.1.3 setup

### Maintenance Information
- Regular maintenance procedures
- Performance monitoring guidelines
- Security compliance checklists
- Update and upgrade procedures

## Technology Stack Coverage

### Core Technologies
- **Node.js**: 20.9.0 LTS (Iron) - ARM64 optimized
- **React**: 19.1.0 - Latest stable with enhanced debugging
- **NestJS**: 11.1.3 - Express v5 default, ARM64 compatible
- **TypeScript**: 5.8.3 - ECMAScript 2024 support
- **PostgreSQL**: 17.5 - ARM64 optimized
- **Vite**: 7.0.4 - AI-powered optimization engine

### Development Tools
- **PM2**: Process management and monitoring
- **VS Code Server**: Remote development environment
- **Git**: Version control with workflow automation
- **ESLint/Prettier**: Code quality and formatting

### System Tools
- **htop/iotop**: System resource monitoring
- **nethogs**: Network bandwidth monitoring
- **nmap**: Network diagnostics and port scanning
- **PostgreSQL monitoring**: Query performance analysis

## Hardware Specifications

### Raspberry Pi 5 Optimizations
- **ARM64 Architecture**: Cortex-A76 quad-core @ 2.4 GHz
- **Memory**: 4GB/8GB LPDDR4X-4267 SDRAM
- **Storage**: NVMe SSD via PCIe 2.0 (up to 1,000 MB/s)
- **16KB Page Size**: Up to 7% performance increase
- **NUMA Emulation**: Up to 18% performance boost
- **SDRAM Tuning**: 10-20% speed boost at 2.4 GHz

## Support and Maintenance

### Documentation Updates
This documentation is maintained alongside the script collection and updated with:
- New script features and parameters
- Performance optimization discoveries
- Security best practice updates
- Community feedback and improvements

### Version Compatibility
- Scripts tested on Raspberry Pi OS Bookworm (64-bit)
- Compatible with Kernel 6.12+
- Optimized for Raspberry Pi 5 hardware
- ARM64 architecture specific optimizations

### Community Resources
- Troubleshooting guides based on real-world usage
- Performance benchmarks and optimization results
- Security configurations tested in development environments
- Integration examples with popular development tools

## File Organization

```
docs/
├── README.md                           # This index file
├── requirements.md                     # Technology stack research
├── usage-guides/                       # Detailed usage documentation
│   ├── system-scripts.md              # System setup and configuration
│   ├── project-scripts.md             # Project management tools
│   ├── monitoring-scripts.md          # Monitoring and performance
│   ├── workflow-scripts.md            # Development workflow
│   ├── deployment-scripts.md          # Production deployment
│   └── debugging-scripts.md           # Troubleshooting tools
├── troubleshooting/                    # Problem resolution guides
│   └── common-issues.md               # Comprehensive troubleshooting
├── api-reference/                      # Technical reference
│   └── script-parameters.md           # Complete parameter reference
├── examples/                           # Practical usage examples
│   └── development-workflows.md       # Workflow examples
├── hardware-optimization/              # Hardware-specific guides
│   └── raspberry-pi5-optimizations.md # Pi 5 performance tuning
└── security/                           # Security documentation
    └── security-best-practices.md     # Security hardening guide
```

## Contributing to Documentation

### Documentation Standards
- All examples use real script parameters and verified configurations
- Hardware specifications based on official Raspberry Pi 5 documentation
- Performance metrics from actual testing on Pi 5 hardware
- Security configurations follow industry best practices

### Update Procedures
- Documentation updated with each script modification
- Performance benchmarks re-verified with hardware changes
- Security recommendations updated with threat landscape changes
- Examples tested with latest software versions

---

For the most up-to-date information, always refer to the individual script help messages using the `--help` parameter, and check the main project [README.md](../README.md) for the latest project status and updates.