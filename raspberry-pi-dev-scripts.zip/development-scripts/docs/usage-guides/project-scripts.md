# Project Management Scripts Usage Guide

This guide covers the project creation and management scripts for React 19.1.0 and NestJS 11.1.3 development on Raspberry Pi 5.

## Overview

The project scripts handle project initialization, dependency management, build automation, testing, and code quality for modern web development stack.

## Scripts

### init_react_project.sh

Creates new React 19.1.0 projects with Vite 7.0.4 and TypeScript 5.8.3, optimized for ARM64 architecture.

**Usage:**
```bash
./project/init_react_project.sh [--dry-run] [--project-name NAME] [--template TYPE]
```

**Parameters:**
- `--dry-run`: Show what would be done without making changes
- `--project-name NAME`: Specify project name
- `--template TYPE`: Project template (typescript, javascript)
- `-h, --help`: Show help message

**Prerequisites:**
- Node.js 20 LTS installed via NVM
- npm with global packages (create-react-app, vite)
- TypeScript 5.8.3 globally available
- Internet connection for package downloads

**Features:**
- React 19.1.0 project creation with Vite 7.0.4
- TypeScript 5.8.3 configuration
- ESLint and Prettier setup
- Git workflow automation with Husky
- ARM64 optimized configurations
- Development environment integration

**Examples:**
```bash
# Create TypeScript React project
./project/init_react_project.sh --project-name my-react-app --template typescript

# Dry run to see what would be created
./project/init_react_project.sh --dry-run --project-name test-app

# Create JavaScript React project
./project/init_react_project.sh --project-name simple-app --template javascript
```

### init_nestjs_project.sh

Creates new NestJS 11.1.3 projects with PostgreSQL integration and ARM64 optimizations.

**Usage:**
```bash
./project/init_nestjs_project.sh [--project-name NAME] [--database TYPE]
```

**Parameters:**
- `--project-name NAME`: Specify project name
- `--database TYPE`: Database type (postgresql, mysql, sqlite)
- `--dry-run`: Show what would be done without making changes

**Features:**
- NestJS 11.1.3 project creation
- Express v5 default configuration
- PostgreSQL 17 integration
- TypeScript 5.8.3 setup
- ARM64 compatible dependencies
- Development workflow integration

**Examples:**
```bash
# Create NestJS project with PostgreSQL
./project/init_nestjs_project.sh --project-name my-api --database postgresql

# Create with SQLite for development
./project/init_nestjs_project.sh --project-name dev-api --database sqlite
```

### dependency_manager.sh

Manages project dependencies with ARM64 compatibility checks and optimization.

**Usage:**
```bash
./project/dependency_manager.sh [--action ACTION] [--project-path PATH]
```

**Features:**
- ARM64 compatibility verification
- Dependency vulnerability scanning
- Package optimization for Pi 5
- Automated dependency updates

### build_automation.sh

Automates build processes for React and NestJS projects with ARM64 optimizations.

**Usage:**
```bash
./project/build_automation.sh [--project-type TYPE] [--environment ENV]
```

**Features:**
- Optimized build configurations for ARM64
- Environment-specific builds
- Asset optimization
- Build performance monitoring

### test_runner.sh

Executes test suites with ARM64 optimized configurations.

**Usage:**
```bash
./project/test_runner.sh [--test-type TYPE] [--coverage]
```

**Features:**
- Jest configuration for ARM64
- Coverage reporting
- Performance testing
- Integration test support

### code_quality.sh

Runs code quality checks and formatting tools.

**Usage:**
```bash
./project/code_quality.sh [--fix] [--check-only]
```

**Features:**
- ESLint with ARM64 optimizations
- Prettier formatting
- TypeScript type checking
- Code complexity analysis

## Common Workflows

### Full Stack Project Setup
```bash
# 1. Create React frontend
./project/init_react_project.sh --project-name frontend --template typescript

# 2. Create NestJS backend
./project/init_nestjs_project.sh --project-name backend --database postgresql

# 3. Setup dependencies
./project/dependency_manager.sh --action install --project-path ./frontend
./project/dependency_manager.sh --action install --project-path ./backend
```

### Development Workflow
```bash
# 1. Run code quality checks
./project/code_quality.sh --check-only

# 2. Run tests
./project/test_runner.sh --test-type unit --coverage

# 3. Build for development
./project/build_automation.sh --project-type react --environment development
```

### Production Build
```bash
# 1. Update dependencies
./project/dependency_manager.sh --action update

# 2. Run full test suite
./project/test_runner.sh --test-type all --coverage

# 3. Build for production
./project/build_automation.sh --project-type react --environment production
```

## Project Structure

### React Project Structure
```
my-react-app/
├── src/
├── public/
├── package.json
├── tsconfig.json
├── vite.config.ts
├── .eslintrc.js
├── .prettierrc
└── .gitignore
```

### NestJS Project Structure
```
my-api/
├── src/
├── test/
├── package.json
├── tsconfig.json
├── nest-cli.json
├── .eslintrc.js
└── .env.template
```

## Configuration

### Default Project Settings
- **Node.js**: 20 LTS (Iron)
- **TypeScript**: 5.8.3
- **React**: 19.1.0
- **NestJS**: 11.1.3
- **Vite**: 7.0.4
- **PostgreSQL**: 17.5

### ARM64 Optimizations
- Native ARM64 dependencies when available
- Optimized build configurations
- Memory-efficient bundling
- Performance monitoring integration

## Troubleshooting

### Common Issues

**Project Creation Fails:**
```bash
# Check Node.js version
node --version

# Verify npm configuration
npm config list

# Check available disk space
df -h
```

**Dependency Installation Issues:**
```bash
# Clear npm cache
npm cache clean --force

# Check ARM64 compatibility
./project/dependency_manager.sh --action check-compatibility
```

**Build Failures:**
```bash
# Check build logs
./project/build_automation.sh --project-type react --verbose

# Verify TypeScript configuration
tsc --noEmit
```

## Log Files

- Project creation: `~/development/logs/react_project_init.log`
- Build logs: `~/development/logs/build_automation.log`
- Test results: `~/development/logs/test_results.log`
- Code quality: `~/development/logs/code_quality.log`