# Workflow Scripts Usage Guide

This guide covers the development workflow automation scripts for React/Node.js/PostgreSQL development on Raspberry Pi 5.

## Overview

The workflow scripts automate common development tasks including hot reload setup, process management, log monitoring, port management, and Git workflow automation.

## Scripts

### hot_reload_setup.sh

Configures hot reload functionality for React and NestJS development with ARM64 optimizations.

**Usage:**
```bash
./workflow/hot_reload_setup.sh [--project-type TYPE] [--port PORT]
```

**Parameters:**
- `--project-type TYPE`: Project type (react, nestjs, both)
- `--port PORT`: Development server port
- `--watch-extensions EXT`: File extensions to watch
- `--exclude-dirs DIRS`: Directories to exclude from watching

**Features:**
- Optimized file watching for ARM64
- Memory-efficient hot reload
- Multi-project hot reload support
- Integration with Vite and NestJS dev servers

**Examples:**
```bash
# Setup hot reload for React project
./workflow/hot_reload_setup.sh --project-type react --port 3000

# Setup for NestJS API
./workflow/hot_reload_setup.sh --project-type nestjs --port 3001

# Setup for full-stack development
./workflow/hot_reload_setup.sh --project-type both
```

### port_manager.sh

Manages development server ports and prevents conflicts in multi-project environments.

**Usage:**
```bash
./workflow/port_manager.sh [--action ACTION] [--port PORT] [--service SERVICE]
```

**Parameters:**
- `--action ACTION`: Action to perform (check, reserve, release, list, kill)
- `--port PORT`: Specific port number
- `--service SERVICE`: Service name (react, nestjs, postgresql, vscode)
- `--range START-END`: Port range to check

**Features:**
- Port availability checking
- Service port reservation
- Automatic port conflict resolution
- Integration with PM2 and development servers

**Examples:**
```bash
# Check if port is available
./workflow/port_manager.sh --action check --port 3000

# Reserve port for service
./workflow/port_manager.sh --action reserve --port 3000 --service react

# List all reserved ports
./workflow/port_manager.sh --action list

# Kill process on specific port
./workflow/port_manager.sh --action kill --port 3000
```

### log_monitor.sh

Monitors and analyzes logs from development services with real-time filtering and alerting.

**Usage:**
```bash
./workflow/log_monitor.sh [--action ACTION] [--service SERVICE] [--follow]
```

**Parameters:**
- `--action ACTION`: Action to perform (monitor, analyze, search, tail)
- `--service SERVICE`: Service to monitor (react, nestjs, postgresql, pm2, all)
- `--follow`: Follow logs in real-time
- `--filter PATTERN`: Filter logs by pattern
- `--level LEVEL`: Log level filter (error, warn, info, debug)

**Features:**
- Real-time log monitoring
- Multi-service log aggregation
- Error pattern detection
- Log analysis and reporting
- Integration with system monitoring

**Examples:**
```bash
# Monitor all service logs
./workflow/log_monitor.sh --action monitor --follow

# Analyze logs for errors
./workflow/log_monitor.sh --action analyze

# Search logs for patterns
./workflow/log_monitor.sh --action search --filter "error"

# Monitor specific service
./workflow/log_monitor.sh --action monitor --service nestjs --follow
```

### pm2_manager.sh

Manages PM2 processes for development and production environments with ARM64 optimizations.

**Usage:**
```bash
./workflow/pm2_manager.sh [--action ACTION] [--app APPLICATION] [--env ENVIRONMENT]
```

**Parameters:**
- `--action ACTION`: Action to perform (setup, start, stop, restart, monitor, logs, delete)
- `--app APPLICATION`: Specific application name
- `--env ENVIRONMENT`: Environment (development, production, staging)
- `--instances COUNT`: Number of instances to run

**Features:**
- PM2 ecosystem configuration
- ARM64 optimized process management
- Environment-specific configurations
- Automatic restart and monitoring
- Integration with system monitoring

**Examples:**
```bash
# Setup PM2 ecosystem
./workflow/pm2_manager.sh --action setup

# Start all applications
./workflow/pm2_manager.sh --action start

# Monitor processes
./workflow/pm2_manager.sh --action monitor

# Restart specific app
./workflow/pm2_manager.sh --action restart --app nestjs-api

# View logs
./workflow/pm2_manager.sh --action logs --app react-app
```

### git_workflow.sh

Automates Git workflow operations including branch management, commit automation, and deployment triggers.

**Usage:**
```bash
./workflow/git_workflow.sh [--action ACTION] [--branch BRANCH] [--message MESSAGE]
```

**Parameters:**
- `--action ACTION`: Action to perform (init, commit, push, pull, branch, merge, deploy)
- `--branch BRANCH`: Branch name
- `--message MESSAGE`: Commit message
- `--auto-push`: Automatically push after commit
- `--run-tests`: Run tests before commit

**Features:**
- Automated commit workflows
- Branch management
- Pre-commit hooks integration
- Deployment trigger automation
- Code quality checks integration

**Examples:**
```bash
# Initialize Git workflow
./workflow/git_workflow.sh --action init

# Auto-commit with tests
./workflow/git_workflow.sh --action commit --message "Feature update" --run-tests

# Create and switch to new branch
./workflow/git_workflow.sh --action branch --branch feature/new-component

# Deploy to production
./workflow/git_workflow.sh --action deploy --branch main
```

## Common Workflow Patterns

### Development Startup Sequence
```bash
# 1. Check and reserve ports
./workflow/port_manager.sh --action check --range 3000-3010

# 2. Setup hot reload
./workflow/hot_reload_setup.sh --project-type both

# 3. Start PM2 processes
./workflow/pm2_manager.sh --action start --env development

# 4. Start log monitoring
./workflow/log_monitor.sh --action monitor --follow &

# 5. Monitor system resources
./monitoring/system_monitor.sh --action monitor --continuous &
```

### Code Development Workflow
```bash
# 1. Create feature branch
./workflow/git_workflow.sh --action branch --branch feature/user-auth

# 2. Start development servers
./workflow/pm2_manager.sh --action start --app react-dev
./workflow/pm2_manager.sh --action start --app nestjs-dev

# 3. Monitor logs during development
./workflow/log_monitor.sh --action monitor --service all --follow

# 4. Commit changes with tests
./workflow/git_workflow.sh --action commit --message "Add user authentication" --run-tests
```

### Production Deployment Workflow
```bash
# 1. Run tests and quality checks
./project/test_runner.sh --test-type all --coverage
./project/code_quality.sh --check-only

# 2. Build for production
./project/build_automation.sh --environment production

# 3. Deploy via Git workflow
./workflow/git_workflow.sh --action deploy --branch main

# 4. Start production processes
./workflow/pm2_manager.sh --action start --env production

# 5. Monitor deployment
./deployment/health_checker.sh --service all
```

## Configuration

### PM2 Ecosystem Configuration
```javascript
// ecosystem.config.js
module.exports = {
  apps: [
    {
      name: 'react-app',
      script: 'npm',
      args: 'run dev',
      cwd: './frontend',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'development',
        PORT: 3000
      }
    },
    {
      name: 'nestjs-api',
      script: 'npm',
      args: 'run start:dev',
      cwd: './backend',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'development',
        PORT: 3001
      }
    }
  ]
};
```

### Port Reservations
```bash
# Default port assignments
REACT_DEV_PORT=3000
NESTJS_DEV_PORT=3001
POSTGRESQL_PORT=5432
VSCODE_SERVER_PORT=8080
MONITORING_PORT=9090
```

### Log Configuration
```bash
# Log levels and locations
LOG_LEVEL=info
LOG_DIR="$HOME/development/logs"
LOG_ROTATION=daily
LOG_RETENTION=30
```

## Integration Points

### System Monitoring Integration
```bash
# Start workflow with monitoring
./workflow/pm2_manager.sh --action start
./monitoring/system_monitor.sh --action monitor --continuous &
./workflow/log_monitor.sh --action monitor --follow &
```

### Deployment Integration
```bash
# Automated deployment pipeline
./workflow/git_workflow.sh --action deploy --branch main
./deployment/deploy_pipeline.sh --environment production
./deployment/health_checker.sh --service all
```

### Development Environment Integration
```bash
# Complete development setup
./environment/nodejs_nvm_setup.sh --version 20
./workflow/hot_reload_setup.sh --project-type both
./workflow/pm2_manager.sh --action setup
```

## Troubleshooting

### Common Issues

**Port Conflicts:**
```bash
# Check what's using a port
./workflow/port_manager.sh --action check --port 3000

# Kill process on port
./workflow/port_manager.sh --action kill --port 3000

# Find alternative port
./workflow/port_manager.sh --action check --range 3000-3010
```

**PM2 Process Issues:**
```bash
# Check PM2 status
./workflow/pm2_manager.sh --action monitor

# Restart all processes
./workflow/pm2_manager.sh --action restart

# View process logs
./workflow/pm2_manager.sh --action logs
```

**Hot Reload Not Working:**
```bash
# Check file watching limits
echo fs.inotify.max_user_watches=524288 | sudo tee -a /etc/sysctl.conf

# Restart hot reload setup
./workflow/hot_reload_setup.sh --project-type react --port 3000
```

**Git Workflow Issues:**
```bash
# Check Git status
git status

# Reset workflow
./workflow/git_workflow.sh --action init

# Check branch status
./workflow/git_workflow.sh --action status
```

## Log Files

- PM2 processes: `~/.pm2/logs/`
- Workflow logs: `~/development/logs/workflow/`
- Git operations: `~/development/logs/git_workflow.log`
- Port management: `~/development/logs/port_manager.log`
- Hot reload: `~/development/logs/hot_reload.log`

## Performance Considerations

### ARM64 Optimizations
- Optimized file watching for ARM64 architecture
- Memory-efficient process management
- Reduced CPU overhead for hot reload
- Optimized Git operations for NVMe storage

### Resource Management
- Automatic process cleanup
- Memory leak detection
- CPU usage monitoring
- Disk I/O optimization