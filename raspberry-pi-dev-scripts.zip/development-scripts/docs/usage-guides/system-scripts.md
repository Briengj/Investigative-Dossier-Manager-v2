# System Scripts Usage Guide

This guide covers the system setup and configuration scripts for Raspberry Pi 5 development environment.

## Overview

The system scripts handle OS optimization, hardware configuration, and security hardening specifically for Raspberry Pi 5 with ARM64 architecture.

## Scripts

### pi5_os_optimization.sh

Optimizes Raspberry Pi OS (Bookworm/Debian 12) for development workloads with ARM64 architecture optimizations.

**Usage:**
```bash
sudo ./system/pi5_os_optimization.sh [--dry-run]
```

**Parameters:**
- `--dry-run`: Show what would be done without making changes
- `-h, --help`: Show help message

**Prerequisites:**
- Raspberry Pi 5 with Raspberry Pi OS Bookworm (64-bit)
- Root privileges for system modifications
- Internet connection for package updates

**Features:**
- Memory and CPU optimization (16KB page size, NUMA emulation)
- SDRAM timing optimizations
- System package updates
- Performance monitoring setup
- Comprehensive logging and error handling

**Example:**
```bash
# Dry run to see what changes would be made
sudo ./system/pi5_os_optimization.sh --dry-run

# Apply optimizations
sudo ./system/pi5_os_optimization.sh
```

### nvme_setup.sh

Configures NVMe SSD storage for optimal performance on Raspberry Pi 5.

**Usage:**
```bash
sudo ./system/nvme_setup.sh [options]
```

**Features:**
- NVMe PCIe Gen 3 configuration
- File system optimization for SSD
- TRIM support configuration
- Performance tuning for development workloads

### ssh_hardening.sh

Implements SSH security hardening with best practices for development environments.

**Usage:**
```bash
sudo ./system/ssh_hardening.sh [options]
```

**Features:**
- Key-based authentication setup
- Custom SSH port configuration
- Fail2ban integration
- Strong encryption algorithms
- Network security monitoring

### vscode_server_install.sh

Installs and configures VS Code Server for remote development on Raspberry Pi 5.

**Usage:**
```bash
./system/vscode_server_install.sh [options]
```

**Features:**
- ARM64 optimized VS Code Server installation
- Extension management
- Remote development configuration
- Integration with development workflow

## Common Usage Patterns

### Initial System Setup
```bash
# 1. Optimize OS for development
sudo ./system/pi5_os_optimization.sh

# 2. Configure NVMe storage
sudo ./system/nvme_setup.sh

# 3. Harden SSH security
sudo ./system/ssh_hardening.sh

# 4. Install VS Code Server
./system/vscode_server_install.sh
```

### Verification
```bash
# Check system optimization status
./monitoring/system_monitor.sh --action status

# Verify SSH configuration
ssh -T localhost

# Test VS Code Server
code-server --version
```

## Troubleshooting

### Common Issues

**Permission Denied:**
```bash
# Ensure scripts are executable
chmod +x ./system/*.sh

# Run with appropriate privileges
sudo ./system/pi5_os_optimization.sh
```

**Network Issues:**
```bash
# Test connectivity
./debugging/network_diagnostics.sh --action connectivity

# Check SSH configuration
./debugging/network_diagnostics.sh --action services
```

## Log Files

- System optimization: `/var/log/pi5_optimization.log`
- SSH hardening: `/var/log/ssh_hardening.log`
- VS Code Server: `~/.local/share/code-server/logs/`

## Performance Impact

- **OS Optimization**: 7-18% performance improvement
- **NVMe Setup**: Up to 1,000 MB/s storage performance
- **SSH Hardening**: Minimal performance impact with enhanced security