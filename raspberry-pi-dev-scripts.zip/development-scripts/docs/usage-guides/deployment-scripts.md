# Deployment Scripts Usage Guide

This guide covers the production deployment scripts for React/Node.js/PostgreSQL applications on Raspberry Pi 5.

## Overview

The deployment scripts handle production deployment pipelines, environment management, health checking, and production optimization for ARM64 architecture.

## Scripts

### deploy_pipeline.sh

Automated deployment pipeline for React and NestJS applications with comprehensive testing and rollback capabilities.

**Usage:**
```bash
./deployment/deploy_pipeline.sh [--environment ENV] [--branch BRANCH] [--rollback]
```

**Parameters:**
- `--environment ENV`: Target environment (staging, production)
- `--branch BRANCH`: Git branch to deploy (default: main)
- `--rollback`: Rollback to previous deployment
- `--dry-run`: Show deployment steps without executing
- `--skip-tests`: Skip test execution (not recommended)

**Features:**
- Automated build and test execution
- Zero-downtime deployment
- Automatic rollback on failure
- Environment-specific configurations
- Health check integration
- Deployment logging and monitoring

**Examples:**
```bash
# Deploy to staging
./deployment/deploy_pipeline.sh --environment staging --branch develop

# Deploy to production
./deployment/deploy_pipeline.sh --environment production --branch main

# Rollback production deployment
./deployment/deploy_pipeline.sh --environment production --rollback

# Dry run deployment
./deployment/deploy_pipeline.sh --environment production --dry-run
```

### environment_switcher.sh

Manages environment configurations and switches between development, staging, and production environments.

**Usage:**
```bash
./deployment/environment_switcher.sh [--action ACTION] [--environment ENV]
```

**Parameters:**
- `--action ACTION`: Action to perform (switch, list, backup, restore, validate)
- `--environment ENV`: Target environment (development, staging, production)
- `--backup-name NAME`: Name for environment backup
- `--force`: Force environment switch without confirmation

**Features:**
- Environment configuration management
- Database connection switching
- Service configuration updates
- Environment variable management
- Configuration backup and restore

**Examples:**
```bash
# Switch to production environment
./deployment/environment_switcher.sh --action switch --environment production

# List available environments
./deployment/environment_switcher.sh --action list

# Backup current environment
./deployment/environment_switcher.sh --action backup --backup-name pre-deploy

# Validate environment configuration
./deployment/environment_switcher.sh --action validate --environment production
```

### health_checker.sh

Comprehensive health monitoring for deployed applications with endpoint testing and service validation.

**Usage:**
```bash
./deployment/health_checker.sh [--service SERVICE] [--endpoint URL] [--timeout SECONDS]
```

**Parameters:**
- `--service SERVICE`: Service to check (react, nestjs, postgresql, all)
- `--endpoint URL`: Specific endpoint to test
- `--timeout SECONDS`: Request timeout (default: 30)
- `--continuous`: Continuous health monitoring
- `--alert-on-failure`: Send alerts on health check failures

**Features:**
- HTTP endpoint health checks
- Database connectivity testing
- Service dependency validation
- Performance metrics collection
- Alert generation on failures
- Integration with monitoring systems

**Examples:**
```bash
# Check all services
./deployment/health_checker.sh --service all

# Check specific service
./deployment/health_checker.sh --service nestjs

# Test specific endpoint
./deployment/health_checker.sh --endpoint http://localhost:3001/api/health

# Continuous monitoring
./deployment/health_checker.sh --service all --continuous
```

### production_optimizer.sh

Optimizes system and application configurations for production workloads on Raspberry Pi 5.

**Usage:**
```bash
./deployment/production_optimizer.sh [--action ACTION] [--component COMPONENT]
```

**Parameters:**
- `--action ACTION`: Action to perform (optimize, performance, security, all)
- `--component COMPONENT`: Component to optimize (system, nodejs, postgresql, nginx)
- `--profile PROFILE`: Optimization profile (balanced, performance, memory)
- `--dry-run`: Show optimizations without applying

**Features:**
- System-level performance tuning
- Node.js production optimizations
- PostgreSQL performance tuning
- Memory and CPU optimization
- Security hardening for production
- ARM64-specific optimizations

**Examples:**
```bash
# Full production optimization
./deployment/production_optimizer.sh --action all

# Optimize specific component
./deployment/production_optimizer.sh --action optimize --component nodejs

# Performance-focused optimization
./deployment/production_optimizer.sh --action performance --profile performance

# Security hardening
./deployment/production_optimizer.sh --action security
```

## Deployment Workflows

### Complete Production Deployment
```bash
# 1. Pre-deployment validation
./project/test_runner.sh --test-type all --coverage
./project/code_quality.sh --check-only

# 2. Environment preparation
./deployment/environment_switcher.sh --action backup --backup-name pre-deploy
./deployment/environment_switcher.sh --action switch --environment production

# 3. System optimization
./deployment/production_optimizer.sh --action all

# 4. Application deployment
./deployment/deploy_pipeline.sh --environment production --branch main

# 5. Health verification
./deployment/health_checker.sh --service all

# 6. Performance monitoring
./monitoring/system_monitor.sh --action monitor --continuous &
./monitoring/app_performance_monitor.sh --action monitor &
```

### Staging Deployment and Testing
```bash
# 1. Deploy to staging
./deployment/deploy_pipeline.sh --environment staging --branch develop

# 2. Run integration tests
./project/test_runner.sh --test-type integration --environment staging

# 3. Performance testing
./monitoring/app_performance_monitor.sh --action snapshot --app all

# 4. Health checks
./deployment/health_checker.sh --service all --continuous &

# 5. Load testing (if applicable)
# Run your load testing tools here

# 6. Promote to production if tests pass
./deployment/deploy_pipeline.sh --environment production --branch main
```

### Emergency Rollback Procedure
```bash
# 1. Immediate rollback
./deployment/deploy_pipeline.sh --environment production --rollback

# 2. Restore previous environment
./deployment/environment_switcher.sh --action restore --backup-name pre-deploy

# 3. Verify system health
./deployment/health_checker.sh --service all

# 4. Check system status
./monitoring/system_monitor.sh --action status
./debugging/network_diagnostics.sh --action diagnose
```

## Environment Configurations

### Development Environment
```bash
# Environment variables
NODE_ENV=development
DATABASE_URL=postgresql://dev:password@localhost:5432/devdb
API_PORT=3001
CLIENT_PORT=3000
LOG_LEVEL=debug
ENABLE_HOT_RELOAD=true
```

### Staging Environment
```bash
# Environment variables
NODE_ENV=staging
DATABASE_URL=postgresql://staging:password@localhost:5432/stagingdb
API_PORT=3001
CLIENT_PORT=3000
LOG_LEVEL=info
ENABLE_MONITORING=true
```

### Production Environment
```bash
# Environment variables
NODE_ENV=production
DATABASE_URL=postgresql://prod:secure_password@localhost:5432/proddb
API_PORT=3001
CLIENT_PORT=80
LOG_LEVEL=warn
ENABLE_MONITORING=true
ENABLE_ALERTS=true
```

## Health Check Endpoints

### Application Health Checks
```bash
# React application
curl http://localhost:3000/health

# NestJS API
curl http://localhost:3001/api/health

# Database connectivity
curl http://localhost:3001/api/health/database

# System resources
curl http://localhost:3001/api/health/system
```

### Health Check Response Format
```json
{
  "status": "healthy",
  "timestamp": "2025-07-16T13:09:01Z",
  "services": {
    "database": {
      "status": "healthy",
      "response_time": 15,
      "connections": 5
    },
    "api": {
      "status": "healthy",
      "response_time": 8,
      "memory_usage": "45%"
    }
  },
  "system": {
    "cpu_usage": 35.2,
    "memory_usage": 62.8,
    "disk_usage": 45.1,
    "temperature": 58.4
  }
}
```

## Production Optimizations

### System-Level Optimizations
- **CPU Governor**: Performance mode for production workloads
- **Memory Management**: Optimized swap and cache settings
- **File System**: Optimized mount options for NVMe
- **Network**: TCP/IP stack tuning for web applications

### Node.js Optimizations
```bash
# Production Node.js flags
NODE_OPTIONS="--max-old-space-size=2048 --optimize-for-size"
UV_THREADPOOL_SIZE=8
NODE_ENV=production
```

### PostgreSQL Optimizations
```sql
-- Production PostgreSQL settings
shared_buffers = 512MB
effective_cache_size = 2GB
work_mem = 8MB
maintenance_work_mem = 128MB
checkpoint_completion_target = 0.9
wal_buffers = 16MB
```

## Monitoring and Alerts

### Deployment Monitoring
```bash
# Monitor deployment progress
tail -f ~/development/logs/deployment.log

# Check deployment status
./deployment/health_checker.sh --service all --continuous

# Monitor system resources during deployment
./monitoring/system_monitor.sh --action monitor --interval 10
```

### Alert Configuration
```bash
# Alert thresholds for production
CPU_ALERT_THRESHOLD=70
MEMORY_ALERT_THRESHOLD=80
DISK_ALERT_THRESHOLD=85
RESPONSE_TIME_THRESHOLD=2000
ERROR_RATE_THRESHOLD=2
```

## Security Considerations

### Production Security
- SSL/TLS certificate configuration
- Firewall rules for production ports
- Database access restrictions
- API rate limiting
- Security headers configuration

### Environment Security
```bash
# Secure environment variables
chmod 600 .env.production
chown app:app .env.production

# Database security
./database/postgresql_install.sh --secure-install
```

## Troubleshooting

### Common Deployment Issues

**Deployment Failures:**
```bash
# Check deployment logs
tail -f ~/development/logs/deployment.log

# Verify environment configuration
./deployment/environment_switcher.sh --action validate --environment production

# Test connectivity
./debugging/network_diagnostics.sh --action connectivity
```

**Health Check Failures:**
```bash
# Detailed health check
./deployment/health_checker.sh --service all --timeout 60

# Check service logs
./workflow/log_monitor.sh --action analyze --service all

# System diagnostics
./debugging/network_diagnostics.sh --action diagnose
```

**Performance Issues:**
```bash
# System performance check
./monitoring/system_monitor.sh --action status

# Application performance analysis
./monitoring/app_performance_monitor.sh --action report

# Production optimization
./deployment/production_optimizer.sh --action performance
```

## Log Files and Monitoring

### Deployment Logs
- Deployment pipeline: `~/development/logs/deployment.log`
- Environment switching: `~/development/logs/environment_switcher.log`
- Health checks: `~/development/logs/health_checker.log`
- Production optimization: `~/development/logs/production_optimizer.log`

### Monitoring Integration
```bash
# Start comprehensive monitoring for production
./monitoring/system_monitor.sh --action monitor --continuous &
./monitoring/app_performance_monitor.sh --action monitor &
./deployment/health_checker.sh --service all --continuous &
```