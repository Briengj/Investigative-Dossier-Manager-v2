# Monitoring Scripts Usage Guide

This guide covers the system and application monitoring scripts for Raspberry Pi 5 development environment.

## Overview

The monitoring scripts provide real-time system resource monitoring, application performance tracking, and alert generation optimized for ARM64 architecture and development workloads.

## Scripts

### system_monitor.sh

Monitors CPU, memory, disk, network, and temperature metrics on ARM64 architecture with integration to development workflow.

**Usage:**
```bash
./monitoring/system_monitor.sh [--dry-run] [--action ACTION] [--interval SECONDS]
```

**Parameters:**
- `--dry-run`: Show what would be done without making changes
- `--action ACTION`: Action to perform (monitor, snapshot, alerts, status, report)
- `--interval SECONDS`: Monitoring interval in seconds (default: 5)
- `--continuous`: Enable continuous monitoring mode
- `-h, --help`: Show help message

**Prerequisites:**
- htop, iotop, nethogs, smartmontools installed
- vcgencmd available (Raspberry Pi OS)
- Write access to log directory
- ARM64 architecture (Raspberry Pi 5)

**Features:**
- Real-time system resource monitoring
- Temperature and hardware health monitoring
- Network bandwidth monitoring by process
- Disk I/O performance tracking
- Memory usage analysis with leak detection
- CPU utilization and load average tracking
- Alert generation for resource thresholds
- Integration with PM2 and application monitoring

**Alert Thresholds:**
- CPU usage: 80%
- Memory usage: 85%
- Disk usage: 90%
- Temperature: 70°C

**Examples:**
```bash
# Start continuous system monitoring
./monitoring/system_monitor.sh --action monitor --continuous

# Take system snapshot
./monitoring/system_monitor.sh --action snapshot

# Check system alerts
./monitoring/system_monitor.sh --action alerts

# Generate system status report
./monitoring/system_monitor.sh --action status

# Custom monitoring interval
./monitoring/system_monitor.sh --action monitor --interval 10
```

### app_performance_monitor.sh

Monitors application performance for React, NestJS, and PostgreSQL components.

**Usage:**
```bash
./monitoring/app_performance_monitor.sh [--action ACTION] [--app APPLICATION]
```

**Parameters:**
- `--action ACTION`: Action to perform (monitor, report, snapshot, alerts)
- `--app APPLICATION`: Specific application to monitor (react, nestjs, postgresql, all)
- `--interval SECONDS`: Monitoring interval
- `--output FORMAT`: Output format (json, text, html)

**Features:**
- Node.js process monitoring
- Database performance tracking
- HTTP endpoint response times
- Error rate monitoring
- Memory leak detection
- Performance regression analysis

**Examples:**
```bash
# Monitor all applications
./monitoring/app_performance_monitor.sh --action monitor

# Monitor specific application
./monitoring/app_performance_monitor.sh --action monitor --app nestjs

# Generate performance report
./monitoring/app_performance_monitor.sh --action report

# Application-specific snapshot
./monitoring/app_performance_monitor.sh --action snapshot --app react
```

## Monitoring Workflows

### Continuous System Monitoring
```bash
# Start comprehensive monitoring
./monitoring/system_monitor.sh --action monitor --continuous &

# Monitor application performance
./monitoring/app_performance_monitor.sh --action monitor &

# Check alerts periodically
watch -n 60 './monitoring/system_monitor.sh --action alerts'
```

### Performance Analysis
```bash
# Take baseline snapshot
./monitoring/system_monitor.sh --action snapshot
./monitoring/app_performance_monitor.sh --action snapshot

# Run workload or tests
# ... your development work ...

# Compare performance
./monitoring/system_monitor.sh --action report
./monitoring/app_performance_monitor.sh --action report
```

### Development Workflow Integration
```bash
# Pre-development check
./monitoring/system_monitor.sh --action status

# Start monitoring during development
./monitoring/system_monitor.sh --action monitor --interval 30 &
MONITOR_PID=$!

# Your development work
npm run dev &
npm run test

# Stop monitoring and generate report
kill $MONITOR_PID
./monitoring/system_monitor.sh --action report
```

## Metrics and Data

### System Metrics
- **CPU**: Usage percentage, load average, core temperatures
- **Memory**: Used/available RAM, swap usage, memory leaks
- **Disk**: I/O operations, read/write speeds, disk usage
- **Network**: Bandwidth usage by process, connection counts
- **Temperature**: CPU, GPU, and system temperatures

### Application Metrics
- **Node.js**: Heap usage, event loop lag, garbage collection
- **React**: Bundle size, render times, component performance
- **NestJS**: Request/response times, endpoint performance, error rates
- **PostgreSQL**: Query performance, connection pool, cache hit rates

### Alert Conditions
- CPU usage > 80% for 5 minutes
- Memory usage > 85% for 3 minutes
- Disk usage > 90%
- Temperature > 70°C for 2 minutes
- Application response time > 5000ms
- Error rate > 5% over 10 minutes

## Output Formats

### JSON Output
```json
{
  "timestamp": "2025-07-16T13:09:01Z",
  "system": {
    "cpu_usage": 45.2,
    "memory_usage": 62.8,
    "temperature": 58.4,
    "disk_io": {
      "read_mb_s": 125.3,
      "write_mb_s": 89.7
    }
  },
  "alerts": []
}
```

### Text Report
```
System Status Report - 2025-07-16 13:09:01
==========================================
CPU Usage: 45.2% (Normal)
Memory Usage: 62.8% (Normal)
Temperature: 58.4°C (Normal)
Disk I/O: Read 125.3 MB/s, Write 89.7 MB/s
Network: 15.2 Mbps down, 8.4 Mbps up
Active Alerts: None
```

## Configuration

### Environment Variables
```bash
# Monitoring configuration
export MONITOR_INTERVAL=5
export CPU_ALERT_THRESHOLD=80
export MEMORY_ALERT_THRESHOLD=85
export TEMP_ALERT_THRESHOLD=70
export DISK_ALERT_THRESHOLD=90

# Output configuration
export MONITOR_LOG_DIR="$HOME/development/logs"
export METRICS_FORMAT="json"
export ALERT_EMAIL="admin@example.com"
```

### Configuration Files
- System monitor config: `~/development/config/system_monitor.conf`
- Application monitor config: `~/development/config/app_monitor.conf`
- Alert rules: `~/development/config/alert_rules.json`

## Integration

### PM2 Integration
```bash
# Monitor PM2 processes
./monitoring/app_performance_monitor.sh --action monitor --app pm2

# PM2 ecosystem monitoring
pm2 monit
```

### Log Integration
```bash
# Monitor logs in real-time
./workflow/log_monitor.sh --action monitor --follow &

# Correlate with system metrics
./monitoring/system_monitor.sh --action monitor --continuous
```

## Troubleshooting

### Common Issues

**High CPU Usage:**
```bash
# Identify CPU-intensive processes
./monitoring/system_monitor.sh --action snapshot | grep -A5 "cpu"

# Check for runaway processes
top -p $(pgrep -d',' node)
```

**Memory Leaks:**
```bash
# Monitor memory usage over time
./monitoring/app_performance_monitor.sh --action monitor --app node

# Generate memory report
./monitoring/system_monitor.sh --action report | grep -A10 "memory"
```

**Performance Degradation:**
```bash
# Compare current vs baseline performance
./monitoring/app_performance_monitor.sh --action report --compare-baseline

# Check system bottlenecks
./debugging/network_diagnostics.sh --action diagnose
```

## Log Files and Reports

### Log Locations
- System monitoring: `~/development/logs/system_monitor.log`
- Application monitoring: `~/development/logs/app_performance.log`
- System reports: `~/development/logs/system_reports/`
- Metrics data: `~/development/logs/system_reports/system_metrics.json`

### Report Generation
```bash
# Daily system report
./monitoring/system_monitor.sh --action report --period daily

# Weekly performance summary
./monitoring/app_performance_monitor.sh --action report --period weekly

# Custom date range
./monitoring/system_monitor.sh --action report --from 2025-07-15 --to 2025-07-16
```