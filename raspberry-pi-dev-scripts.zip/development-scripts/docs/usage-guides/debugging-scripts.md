# Debugging Scripts Usage Guide

This guide covers the troubleshooting and diagnostic tools for React/Node.js/PostgreSQL development on Raspberry Pi 5.

## Overview

The debugging scripts provide comprehensive network diagnostics, database debugging utilities, and system troubleshooting tools optimized for ARM64 architecture and development workflows.

## Scripts

### network_diagnostics.sh

Comprehensive network troubleshooting and diagnostic tool for development services and connectivity issues.

**Usage:**
```bash
./debugging/network_diagnostics.sh [--action ACTION] [--target TARGET] [--port PORT]
```

**Parameters:**
- `--action ACTION`: Action to perform (diagnose, connectivity, services, troubleshoot, scan, trace)
- `--target TARGET`: Target host or IP address
- `--port PORT`: Specific port to test
- `--timeout SECONDS`: Connection timeout (default: 10)
- `--verbose`: Enable verbose output
- `--save-report`: Save diagnostic report to file

**Features:**
- Full network diagnostics suite
- Connectivity testing to external hosts
- Development service port checking
- Network interface analysis
- DNS resolution testing
- Bandwidth testing
- Interactive troubleshooting mode

**Examples:**
```bash
# Full network diagnostics
./debugging/network_diagnostics.sh --action diagnose

# Test connectivity to specific host
./debugging/network_diagnostics.sh --action connectivity --target google.com

# Check development services
./debugging/network_diagnostics.sh --action services

# Interactive troubleshooting
./debugging/network_diagnostics.sh --action troubleshoot

# Port scan for development services
./debugging/network_diagnostics.sh --action scan --target localhost

# Network trace to external host
./debugging/network_diagnostics.sh --action trace --target github.com
```

### database_debug.sh

Database debugging and performance analysis tool for PostgreSQL development and production environments.

**Usage:**
```bash
./debugging/database_debug.sh [--action ACTION] [--database DB] [--query QUERY]
```

**Parameters:**
- `--action ACTION`: Action to perform (diagnose, performance, slow-queries, locks, connections, analyze)
- `--database DB`: Specific database to analyze
- `--query QUERY`: Specific query to analyze
- `--threshold MS`: Slow query threshold in milliseconds
- `--export FORMAT`: Export format (json, csv, html)
- `--save-report`: Save analysis report

**Features:**
- Comprehensive database diagnostics
- Query performance analysis
- Slow query identification and optimization
- Database lock analysis
- Connection pool monitoring
- Index usage analysis
- Database health checking

**Examples:**
```bash
# Full database diagnostics
./debugging/database_debug.sh --action diagnose

# Check query performance
./debugging/database_debug.sh --action performance

# Analyze slow queries
./debugging/database_debug.sh --action slow-queries --threshold 1000

# Check database locks
./debugging/database_debug.sh --action locks

# Connection analysis
./debugging/database_debug.sh --action connections

# Analyze specific query
./debugging/database_debug.sh --action analyze --query "SELECT * FROM users WHERE active = true"
```

## Diagnostic Workflows

### Complete System Diagnostics
```bash
# 1. System resource check
./monitoring/system_monitor.sh --action status

# 2. Network diagnostics
./debugging/network_diagnostics.sh --action diagnose

# 3. Database diagnostics
./debugging/database_debug.sh --action diagnose

# 4. Service health check
./deployment/health_checker.sh --service all

# 5. Application performance check
./monitoring/app_performance_monitor.sh --action snapshot
```

### Network Troubleshooting Workflow
```bash
# 1. Basic connectivity test
./debugging/network_diagnostics.sh --action connectivity --target google.com

# 2. Check local services
./debugging/network_diagnostics.sh --action services

# 3. Port availability check
./workflow/port_manager.sh --action list

# 4. Network interface analysis
./debugging/network_diagnostics.sh --action diagnose --verbose

# 5. DNS resolution test
nslookup google.com
```

### Database Performance Troubleshooting
```bash
# 1. Check database connectivity
./debugging/database_debug.sh --action connections

# 2. Identify slow queries
./debugging/database_debug.sh --action slow-queries --threshold 500

# 3. Analyze query performance
./debugging/database_debug.sh --action performance

# 4. Check for locks
./debugging/database_debug.sh --action locks

# 5. Database health check
./deployment/health_checker.sh --service postgresql
```

### Application Performance Debugging
```bash
# 1. Check system resources
./monitoring/system_monitor.sh --action snapshot

# 2. Analyze application logs
./workflow/log_monitor.sh --action analyze --service all

# 3. Check network connectivity
./debugging/network_diagnostics.sh --action services

# 4. Database performance check
./debugging/database_debug.sh --action performance

# 5. Application-specific monitoring
./monitoring/app_performance_monitor.sh --action monitor --app nestjs
```

## Network Diagnostics Details

### Connectivity Testing
```bash
# Test external connectivity
./debugging/network_diagnostics.sh --action connectivity --target google.com
./debugging/network_diagnostics.sh --action connectivity --target github.com
./debugging/network_diagnostics.sh --action connectivity --target npmjs.com

# Test local services
./debugging/network_diagnostics.sh --action connectivity --target localhost --port 3000
./debugging/network_diagnostics.sh --action connectivity --target localhost --port 3001
./debugging/network_diagnostics.sh --action connectivity --target localhost --port 5432
```

### Service Port Analysis
```bash
# Check all development service ports
./debugging/network_diagnostics.sh --action services

# Expected services and ports:
# - React Dev Server: 3000
# - NestJS API: 3001
# - PostgreSQL: 5432
# - VS Code Server: 8080
# - PM2 Monitoring: 9615
```

### Network Interface Information
```bash
# Network interface details
ip addr show
ip route show

# Network statistics
netstat -tuln
ss -tuln

# Bandwidth monitoring
./monitoring/system_monitor.sh --action monitor | grep -A5 "network"
```

## Database Debugging Details

### Query Performance Analysis
```sql
-- Enable query logging (run as postgres user)
ALTER SYSTEM SET log_statement = 'all';
ALTER SYSTEM SET log_min_duration_statement = 1000;
SELECT pg_reload_conf();

-- Check slow queries
SELECT query, mean_time, calls, total_time
FROM pg_stat_statements
ORDER BY mean_time DESC
LIMIT 10;
```

### Connection Monitoring
```bash
# Check active connections
./debugging/database_debug.sh --action connections

# PostgreSQL connection details
sudo -u postgres psql -c "SELECT * FROM pg_stat_activity;"

# Connection pool status (if using connection pooling)
sudo -u postgres psql -c "SHOW pool_status;" # For PgBouncer
```

### Lock Analysis
```bash
# Check for database locks
./debugging/database_debug.sh --action locks

# Manual lock checking
sudo -u postgres psql -c "
SELECT 
    blocked_locks.pid AS blocked_pid,
    blocked_activity.usename AS blocked_user,
    blocking_locks.pid AS blocking_pid,
    blocking_activity.usename AS blocking_user,
    blocked_activity.query AS blocked_statement,
    blocking_activity.query AS current_statement_in_blocking_process
FROM pg_catalog.pg_locks blocked_locks
JOIN pg_catalog.pg_stat_activity blocked_activity ON blocked_activity.pid = blocked_locks.pid
JOIN pg_catalog.pg_locks blocking_locks ON blocking_locks.locktype = blocked_locks.locktype
JOIN pg_catalog.pg_stat_activity blocking_activity ON blocking_activity.pid = blocking_locks.pid
WHERE NOT blocked_locks.granted;
"
```

## Common Issues and Solutions

### Network Issues

**Cannot Connect to External Services:**
```bash
# Check internet connectivity
ping -c 4 8.8.8.8

# Check DNS resolution
nslookup google.com

# Check firewall rules
sudo ufw status

# Test with different DNS
echo "nameserver 8.8.8.8" | sudo tee /etc/resolv.conf.backup
```

**Development Server Not Accessible:**
```bash
# Check if service is running
./workflow/pm2_manager.sh --action monitor

# Check port availability
./workflow/port_manager.sh --action check --port 3000

# Check firewall rules
sudo ufw allow 3000/tcp

# Test local connectivity
curl http://localhost:3000/health
```

**Slow Network Performance:**
```bash
# Check network interface statistics
./debugging/network_diagnostics.sh --action diagnose --verbose

# Monitor network usage
sudo nethogs

# Check for network errors
ip -s link show
```

### Database Issues

**Connection Refused:**
```bash
# Check PostgreSQL service status
sudo systemctl status postgresql

# Check PostgreSQL configuration
sudo -u postgres psql -c "SHOW listen_addresses;"
sudo -u postgres psql -c "SHOW port;"

# Check pg_hba.conf
sudo cat /etc/postgresql/*/main/pg_hba.conf
```

**Slow Query Performance:**
```bash
# Analyze slow queries
./debugging/database_debug.sh --action slow-queries --threshold 1000

# Check database statistics
sudo -u postgres psql -c "SELECT * FROM pg_stat_database;"

# Analyze table statistics
sudo -u postgres psql -c "SELECT * FROM pg_stat_user_tables;"
```

**Database Locks:**
```bash
# Check for locks
./debugging/database_debug.sh --action locks

# Kill blocking queries (use with caution)
sudo -u postgres psql -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE state = 'active' AND pid != pg_backend_pid();"
```

### Application Issues

**High Memory Usage:**
```bash
# Check memory usage by process
./monitoring/system_monitor.sh --action snapshot | grep -A10 "memory"

# Check Node.js heap usage
./monitoring/app_performance_monitor.sh --action monitor --app node

# Check for memory leaks
node --inspect your-app.js
```

**High CPU Usage:**
```bash
# Identify CPU-intensive processes
top -p $(pgrep -d',' node)

# Check system load
./monitoring/system_monitor.sh --action status

# Profile Node.js application
node --prof your-app.js
```

**Application Crashes:**
```bash
# Check application logs
./workflow/log_monitor.sh --action analyze --service all

# Check PM2 logs
./workflow/pm2_manager.sh --action logs

# Check system logs
sudo journalctl -u your-service -f
```

## Diagnostic Reports

### Network Diagnostic Report
```bash
# Generate comprehensive network report
./debugging/network_diagnostics.sh --action diagnose --save-report

# Report includes:
# - Network interface configuration
# - Routing table
# - DNS configuration
# - Port scan results
# - Connectivity test results
# - Bandwidth measurements
```

### Database Diagnostic Report
```bash
# Generate database analysis report
./debugging/database_debug.sh --action diagnose --save-report --export html

# Report includes:
# - Database configuration
# - Performance statistics
# - Slow query analysis
# - Index usage statistics
# - Connection pool status
# - Lock analysis
```

## Log Files and Monitoring

### Debug Log Locations
- Network diagnostics: `~/development/logs/network_diagnostics.log`
- Database debugging: `~/development/logs/database_debug.log`
- System diagnostics: `~/development/logs/system_diagnostics.log`
- Application debugging: `~/development/logs/app_debug.log`

### Continuous Monitoring
```bash
# Start continuous debugging monitoring
./debugging/network_diagnostics.sh --action services --continuous &
./debugging/database_debug.sh --action performance --continuous &
./monitoring/system_monitor.sh --action monitor --continuous &
```

## Integration with Development Workflow

### Pre-Development Diagnostics
```bash
# Run before starting development
./debugging/network_diagnostics.sh --action services
./debugging/database_debug.sh --action connections
./monitoring/system_monitor.sh --action status
```

### Post-Deployment Diagnostics
```bash
# Run after deployment
./deployment/health_checker.sh --service all
./debugging/network_diagnostics.sh --action diagnose
./debugging/database_debug.sh --action performance
```

### Automated Troubleshooting
```bash
# Automated diagnostic script
#!/bin/bash
echo "Running automated diagnostics..."
./debugging/network_diagnostics.sh --action diagnose
./debugging/database_debug.sh --action diagnose
./monitoring/system_monitor.sh --action alerts
./deployment/health_checker.sh --service all
echo "Diagnostics complete. Check logs for details."
```