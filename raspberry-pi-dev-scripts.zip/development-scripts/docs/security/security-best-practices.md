# Security Best Practices and Configurations

This guide covers security configurations, best practices, and hardening procedures for the Raspberry Pi 5 development environment.

## System Security

### SSH Hardening

**SSH Configuration (Applied by ssh_hardening.sh)**
```bash
# /etc/ssh/sshd_config optimizations
Port 2222                          # Custom port (not default 22)
Protocol 2                         # SSH protocol version 2 only
PermitRootLogin no                 # Disable root login
PasswordAuthentication no          # Key-based authentication only
PubkeyAuthentication yes           # Enable public key authentication
AuthorizedKeysFile .ssh/authorized_keys
PermitEmptyPasswords no            # No empty passwords
ChallengeResponseAuthentication no # Disable challenge-response
UsePAM yes                         # Use PAM for authentication
X11Forwarding no                   # Disable X11 forwarding
PrintMotd no                       # Disable message of the day
AcceptEnv LANG LC_*               # Accept locale environment variables
Subsystem sftp /usr/lib/openssh/sftp-server

# Connection limits
MaxAuthTries 3                     # Maximum authentication attempts
MaxSessions 2                      # Maximum concurrent sessions
ClientAliveInterval 300            # Keep-alive interval
ClientAliveCountMax 2              # Maximum keep-alive messages
```

**SSH Key Management**
```bash
# Generate secure SSH key pair
ssh-keygen -t ed25519 -b 4096 -C "pi5-dev-$(date +%Y%m%d)"

# Set proper permissions
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
chmod 600 ~/.ssh/id_ed25519
chmod 644 ~/.ssh/id_ed25519.pub

# Add public key to authorized_keys
cat ~/.ssh/id_ed25519.pub >> ~/.ssh/authorized_keys
```

**Fail2Ban Configuration**
```bash
# /etc/fail2ban/jail.local
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3
backend = systemd

[sshd]
enabled = true
port = 2222
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
bantime = 3600

# Enable and start fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### Firewall Configuration

**UFW (Uncomplicated Firewall) Setup**
```bash
# Applied by ssh_hardening.sh
sudo ufw --force reset
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Allow SSH on custom port
sudo ufw allow 2222/tcp comment 'SSH'

# Allow development services
sudo ufw allow 3000/tcp comment 'React Dev Server'
sudo ufw allow 3001/tcp comment 'NestJS API'
sudo ufw allow 8080/tcp comment 'VS Code Server'

# Allow PostgreSQL (local only)
sudo ufw allow from 127.0.0.1 to any port 5432 comment 'PostgreSQL Local'

# Enable firewall
sudo ufw --force enable

# Verify rules
sudo ufw status verbose
```

**Advanced Firewall Rules**
```bash
# Rate limiting for SSH
sudo ufw limit 2222/tcp comment 'SSH Rate Limit'

# Allow specific IP ranges for development
sudo ufw allow from 192.168.1.0/24 to any port 3000 comment 'Local Network React'
sudo ufw allow from 192.168.1.0/24 to any port 3001 comment 'Local Network API'

# Block common attack ports
sudo ufw deny 23/tcp comment 'Block Telnet'
sudo ufw deny 135/tcp comment 'Block RPC'
sudo ufw deny 445/tcp comment 'Block SMB'
```

### System Hardening

**User Account Security**
```bash
# Create dedicated development user
sudo useradd -m -s /bin/bash -G sudo,gpio,i2c,spi developer
sudo passwd developer

# Lock unused accounts
sudo passwd -l pi  # If not using default pi user
sudo passwd -l root

# Set password policies
sudo apt install libpam-pwquality
echo 'password requisite pam_pwquality.so retry=3 minlen=12 difok=3' | sudo tee -a /etc/pam.d/common-password
```

**File System Security**
```bash
# Secure mount options in /etc/fstab
/dev/nvme0n1p1 / ext4 defaults,noatime,nodev,nosuid 0 1
tmpfs /tmp tmpfs defaults,nodev,nosuid,noexec,size=1G 0 0
tmpfs /var/tmp tmpfs defaults,nodev,nosuid,noexec,size=512M 0 0

# Set secure permissions
sudo chmod 700 /root
sudo chmod 755 /home
sudo chmod 700 /home/developer

# Secure log files
sudo chmod 640 /var/log/auth.log
sudo chmod 640 /var/log/syslog
```

**Kernel Security**
```bash
# /etc/sysctl.conf security settings
# Network security
net.ipv4.ip_forward=0
net.ipv4.conf.all.send_redirects=0
net.ipv4.conf.default.send_redirects=0
net.ipv4.conf.all.accept_redirects=0
net.ipv4.conf.default.accept_redirects=0
net.ipv4.conf.all.accept_source_route=0
net.ipv4.conf.default.accept_source_route=0
net.ipv4.conf.all.log_martians=1
net.ipv4.conf.default.log_martians=1
net.ipv4.icmp_echo_ignore_broadcasts=1
net.ipv4.icmp_ignore_bogus_error_responses=1
net.ipv4.tcp_syncookies=1

# Memory protection
kernel.dmesg_restrict=1
kernel.kptr_restrict=2
kernel.yama.ptrace_scope=1
```

## Application Security

### Node.js Security

**Environment Variable Security**
```bash
# Secure .env file permissions
chmod 600 .env
chmod 600 .env.local
chmod 600 .env.production

# Environment variable validation
cat > .env.example << EOF
# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/database
DB_HOST=localhost
DB_PORT=5432
DB_USERNAME=your_username
DB_PASSWORD=your_secure_password

# JWT Configuration
JWT_SECRET=your_very_long_and_secure_jwt_secret_here
JWT_EXPIRES_IN=1h

# API Configuration
API_PORT=3001
CORS_ORIGIN=http://localhost:3000

# Security Headers
HELMET_ENABLED=true
RATE_LIMIT_ENABLED=true
RATE_LIMIT_MAX=100
EOF
```

**Package Security**
```bash
# Regular security audits
npm audit
npm audit fix

# Check for vulnerabilities
./project/dependency_manager.sh --action audit --project-path ./frontend
./project/dependency_manager.sh --action audit --project-path ./backend

# Use npm ci for production
npm ci --only=production
```

**NestJS Security Configuration**
```typescript
// main.ts - Security middleware
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import helmet from 'helmet';
import * as compression from 'compression';
import rateLimit from 'express-rate-limit';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  // Security headers
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", "data:", "https:"],
      },
    },
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
      preload: true
    }
  }));
  
  // Rate limiting
  app.use(rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP'
  }));
  
  // Compression
  app.use(compression());
  
  // CORS configuration
  app.enableCors({
    origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization']
  });
  
  await app.listen(process.env.API_PORT || 3001);
}
bootstrap();
```

### Database Security

**PostgreSQL Security Configuration**
```sql
-- Applied by postgresql_install.sh --secure-install

-- Create application user with limited privileges
CREATE USER app_user WITH PASSWORD 'secure_random_password';
CREATE DATABASE app_database OWNER app_user;

-- Grant minimal required privileges
GRANT CONNECT ON DATABASE app_database TO app_user;
GRANT USAGE ON SCHEMA public TO app_user;
GRANT CREATE ON SCHEMA public TO app_user;

-- Revoke unnecessary privileges
REVOKE ALL ON DATABASE postgres FROM app_user;
REVOKE ALL ON SCHEMA information_schema FROM app_user;
REVOKE ALL ON SCHEMA pg_catalog FROM app_user;
```

**PostgreSQL Configuration Security**
```bash
# /etc/postgresql/17/main/postgresql.conf
listen_addresses = 'localhost'          # Only local connections
port = 5432                            # Default port
max_connections = 100                  # Limit connections
shared_preload_libraries = 'pg_stat_statements'
log_statement = 'mod'                  # Log modifications
log_min_duration_statement = 1000      # Log slow queries
log_connections = on                   # Log connections
log_disconnections = on                # Log disconnections
log_checkpoints = on                   # Log checkpoints
```

**Database Connection Security**
```bash
# /etc/postgresql/17/main/pg_hba.conf
# TYPE  DATABASE        USER            ADDRESS                 METHOD
local   all             postgres                                peer
local   all             app_user                                md5
host    all             app_user        127.0.0.1/32            md5
host    all             app_user        ::1/128                 md5

# Reject all other connections
host    all             all             0.0.0.0/0               reject
```

### Web Application Security

**React Security Best Practices**
```typescript
// Security configurations for React
// .env.local
REACT_APP_API_URL=http://localhost:3001/api
GENERATE_SOURCEMAP=false  # Disable source maps in production

// Content Security Policy
const cspMeta = document.createElement('meta');
cspMeta.httpEquiv = 'Content-Security-Policy';
cspMeta.content = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:;";
document.head.appendChild(cspMeta);
```

**HTTP Security Headers**
```nginx
# Nginx security headers (if using reverse proxy)
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
add_header Content-Security-Policy "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';" always;
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
```

## Development Security

### VS Code Server Security

**VS Code Server Configuration**
```bash
# ~/.config/code-server/config.yaml
bind-addr: 127.0.0.1:8080
auth: password
password: your_secure_password_here
cert: false
disable-telemetry: true
disable-update-check: true

# Secure permissions
chmod 600 ~/.config/code-server/config.yaml
```

**Extension Security**
```bash
# Only install trusted extensions
code-server --install-extension ms-vscode.vscode-typescript-next
code-server --install-extension esbenp.prettier-vscode
code-server --install-extension bradlc.vscode-tailwindcss

# Disable automatic extension updates
# settings.json
{
  "extensions.autoUpdate": false,
  "extensions.autoCheckUpdates": false,
  "telemetry.enableTelemetry": false,
  "telemetry.enableCrashReporter": false
}
```

### Git Security

**Git Configuration Security**
```bash
# Secure Git configuration
git config --global user.signingkey YOUR_GPG_KEY_ID
git config --global commit.gpgsign true
git config --global tag.gpgsign true

# Secure remote URLs (use SSH)
git remote set-url origin git@github.com:username/repository.git

# Git hooks for security
cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
# Check for secrets in commits
if git diff --cached --name-only | xargs grep -l "password\|secret\|key\|token" 2>/dev/null; then
    echo "Warning: Potential secrets found in commit"
    exit 1
fi
EOF
chmod +x .git/hooks/pre-commit
```

## Monitoring and Logging

### Security Monitoring

**Log Monitoring for Security Events**
```bash
# Monitor authentication logs
sudo tail -f /var/log/auth.log | grep -E "Failed|Invalid|Accepted"

# Monitor SSH connections
sudo journalctl -u ssh -f

# Monitor firewall logs
sudo tail -f /var/log/ufw.log

# Automated security monitoring
cat > ~/security_monitor.sh << 'EOF'
#!/bin/bash
# Security monitoring script

echo "Security Status Report - $(date)"
echo "================================"

# Failed SSH attempts
echo "Recent failed SSH attempts:"
sudo grep "Failed password" /var/log/auth.log | tail -5

# UFW blocks
echo -e "\nRecent firewall blocks:"
sudo grep "BLOCK" /var/log/ufw.log | tail -5

# System logins
echo -e "\nRecent successful logins:"
last -n 5

# Process monitoring
echo -e "\nSuspicious processes:"
ps aux | grep -E "nc|netcat|nmap|tcpdump" | grep -v grep

echo -e "\nSecurity check complete."
EOF
chmod +x ~/security_monitor.sh
```

**Intrusion Detection**
```bash
# Install and configure AIDE (Advanced Intrusion Detection Environment)
sudo apt install aide
sudo aideinit
sudo mv /var/lib/aide/aide.db.new /var/lib/aide/aide.db

# Create daily check
cat > /etc/cron.daily/aide-check << 'EOF'
#!/bin/bash
/usr/bin/aide --check | /usr/bin/mail -s "AIDE Report $(hostname)" admin@example.com
EOF
chmod +x /etc/cron.daily/aide-check
```

### Security Logging

**Centralized Logging Configuration**
```bash
# Configure rsyslog for security events
cat > /etc/rsyslog.d/50-security.conf << 'EOF'
# Security-related logs
auth,authpriv.*                 /var/log/auth.log
kern.*                          /var/log/kern.log
mail.*                          /var/log/mail.log
user.*                          /var/log/user.log
*.emerg                         :omusrmsg:*
EOF

sudo systemctl restart rsyslog
```

**Log Rotation Security**
```bash
# /etc/logrotate.d/security
/var/log/auth.log {
    weekly
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 640 root adm
    postrotate
        /usr/lib/rsyslog/rsyslog-rotate
    endscript
}
```

## Backup and Recovery Security

### Secure Backup Procedures

**Database Backup Security**
```bash
# Encrypted database backups
./database/backup_restore_utils.sh --action backup --database app_database --compress

# Encrypt backup files
gpg --cipher-algo AES256 --compress-algo 1 --s2k-cipher-algo AES256 \
    --s2k-digest-algo SHA512 --s2k-mode 3 --s2k-count 65011712 \
    --symmetric backup_file.sql.gz

# Secure backup storage permissions
chmod 600 ~/backups/*.gpg
```

**Configuration Backup Security**
```bash
# Backup security configurations
tar -czf security_config_backup_$(date +%Y%m%d).tar.gz \
    /etc/ssh/sshd_config \
    /etc/ufw/ \
    /etc/fail2ban/ \
    ~/.ssh/authorized_keys

# Encrypt configuration backup
gpg --symmetric security_config_backup_$(date +%Y%m%d).tar.gz
rm security_config_backup_$(date +%Y%m%d).tar.gz
```

## Security Incident Response

### Incident Detection

**Automated Threat Detection**
```bash
# Create security alert script
cat > ~/security_alerts.sh << 'EOF'
#!/bin/bash
# Security alert monitoring

# Check for multiple failed SSH attempts
FAILED_SSH=$(sudo grep "Failed password" /var/log/auth.log | grep "$(date '+%b %d')" | wc -l)
if [ $FAILED_SSH -gt 10 ]; then
    echo "ALERT: $FAILED_SSH failed SSH attempts today"
fi

# Check for new users
NEW_USERS=$(sudo grep "new user" /var/log/auth.log | grep "$(date '+%b %d')" | wc -l)
if [ $NEW_USERS -gt 0 ]; then
    echo "ALERT: $NEW_USERS new users created today"
fi

# Check for privilege escalation
SUDO_USAGE=$(sudo grep "sudo:" /var/log/auth.log | grep "$(date '+%b %d')" | wc -l)
if [ $SUDO_USAGE -gt 50 ]; then
    echo "ALERT: High sudo usage: $SUDO_USAGE commands today"
fi

# Check system integrity
if [ -f /var/lib/aide/aide.db ]; then
    AIDE_CHANGES=$(sudo aide --check 2>/dev/null | grep "changed:" | wc -l)
    if [ $AIDE_CHANGES -gt 0 ]; then
        echo "ALERT: $AIDE_CHANGES file system changes detected"
    fi
fi
EOF
chmod +x ~/security_alerts.sh

# Run hourly
echo "0 * * * * /home/developer/security_alerts.sh" | crontab -
```

### Incident Response Procedures

**Emergency Response Script**
```bash
cat > ~/emergency_response.sh << 'EOF'
#!/bin/bash
# Emergency security response

echo "EMERGENCY SECURITY RESPONSE ACTIVATED"
echo "====================================="

# 1. Block all incoming connections
sudo ufw --force reset
sudo ufw default deny incoming
sudo ufw default deny outgoing
sudo ufw allow out 53  # Allow DNS
sudo ufw --force enable

# 2. Kill all user sessions except current
who | grep -v "$(whoami)" | awk '{print $2}' | xargs -I {} sudo pkill -t {}

# 3. Stop all services
sudo systemctl stop postgresql
./workflow/pm2_manager.sh --action stop

# 4. Create incident log
echo "$(date): Emergency response activated by $(whoami)" >> ~/incident.log
echo "Active connections:" >> ~/incident.log
ss -tuln >> ~/incident.log
echo "Recent auth events:" >> ~/incident.log
sudo tail -50 /var/log/auth.log >> ~/incident.log

# 5. Backup critical data
./database/backup_restore_utils.sh --action backup --database app_database

echo "Emergency response complete. Check ~/incident.log for details."
EOF
chmod +x ~/emergency_response.sh
```

## Security Maintenance

### Regular Security Tasks

**Weekly Security Maintenance**
```bash
cat > ~/weekly_security_maintenance.sh << 'EOF'
#!/bin/bash
# Weekly security maintenance

echo "Weekly Security Maintenance - $(date)"
echo "===================================="

# Update system packages
sudo apt update && sudo apt upgrade -y

# Update Node.js dependencies
./project/dependency_manager.sh --action audit --project-path ./frontend
./project/dependency_manager.sh --action audit --project-path ./backend

# Check for rootkits
sudo chkrootkit

# Update AIDE database
sudo aide --update
sudo mv /var/lib/aide/aide.db.new /var/lib/aide/aide.db

# Rotate logs
sudo logrotate -f /etc/logrotate.conf

# Check file permissions
find /home/developer -type f -perm /o+w -exec ls -l {} \;

# Generate security report
~/security_monitor.sh > ~/security_report_$(date +%Y%m%d).txt

echo "Security maintenance complete."
EOF
chmod +x ~/weekly_security_maintenance.sh

# Schedule weekly execution
echo "0 2 * * 0 /home/developer/weekly_security_maintenance.sh" | crontab -
```

### Security Compliance

**Security Checklist**
```bash
# Create security compliance checker
cat > ~/security_compliance_check.sh << 'EOF'
#!/bin/bash
# Security compliance checker

echo "Security Compliance Check - $(date)"
echo "=================================="

# SSH Configuration
echo "1. SSH Security:"
if grep -q "PasswordAuthentication no" /etc/ssh/sshd_config; then
    echo "   ✓ Password authentication disabled"
else
    echo "   ✗ Password authentication enabled"
fi

if grep -q "PermitRootLogin no" /etc/ssh/sshd_config; then
    echo "   ✓ Root login disabled"
else
    echo "   ✗ Root login enabled"
fi

# Firewall Status
echo "2. Firewall:"
if sudo ufw status | grep -q "Status: active"; then
    echo "   ✓ UFW firewall active"
else
    echo "   ✗ UFW firewall inactive"
fi

# Fail2Ban Status
echo "3. Intrusion Prevention:"
if systemctl is-active --quiet fail2ban; then
    echo "   ✓ Fail2Ban active"
else
    echo "   ✗ Fail2Ban inactive"
fi

# File Permissions
echo "4. File Permissions:"
if [ "$(stat -c %a ~/.ssh)" = "700" ]; then
    echo "   ✓ SSH directory permissions correct"
else
    echo "   ✗ SSH directory permissions incorrect"
fi

# System Updates
echo "5. System Updates:"
UPDATES=$(apt list --upgradable 2>/dev/null | wc -l)
if [ $UPDATES -le 1 ]; then
    echo "   ✓ System up to date"
else
    echo "   ✗ $((UPDATES-1)) updates available"
fi

echo "Compliance check complete."
EOF
chmod +x ~/security_compliance_check.sh
```

## Security Resources

### Security Tools

**Essential Security Tools**
```bash
# Install security tools
sudo apt install -y \
    fail2ban \
    ufw \
    aide \
    chkrootkit \
    rkhunter \
    lynis \
    nmap \
    tcpdump \
    wireshark-common

# Security scanning with Lynis
sudo lynis audit system
```

### Security Documentation

**Security Policy Template**
```markdown
# Security Policy

## Access Control
- All access must use SSH key authentication
- No password-based authentication allowed
- Multi-factor authentication required for production

## Network Security
- Firewall must be enabled and configured
- Only required ports should be open
- Regular network security scans required

## Application Security
- All dependencies must be regularly audited
- Security headers must be implemented
- Input validation required for all user inputs

## Data Protection
- Database connections must be encrypted
- Sensitive data must be encrypted at rest
- Regular backups with encryption required

## Incident Response
- Security incidents must be logged
- Emergency response procedures must be followed
- Post-incident analysis required
```

This comprehensive security guide ensures that your Raspberry Pi 5 development environment follows security best practices while maintaining development productivity.