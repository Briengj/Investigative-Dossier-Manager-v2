# Common Issues and Troubleshooting Guide

This guide covers common issues encountered when using the Raspberry Pi 5 development scripts and their solutions.

## System Issues

### Installation Problems

**Issue: Permission denied during installation**
```bash
# Error message
./install.sh: Permission denied

# Solution
chmod +x ./install.sh
sudo ./install.sh
```

**Issue: Package installation fails**
```bash
# Error message
E: Unable to locate package nodejs

# Solution - Update package lists
sudo apt update
sudo apt upgrade

# Check internet connectivity
./debugging/network_diagnostics.sh --action connectivity --target google.com

# Retry installation
./install.sh --mode development
```

**Issue: NVMe SSD not detected**
```bash
# Check if NVMe is detected
lsblk | grep nvme

# If not detected, check PCIe
lspci | grep -i nvme

# Run NVMe setup with diagnostics
sudo ./system/nvme_setup.sh --diagnose

# Check system logs
sudo dmesg | grep nvme
```

### Performance Issues

**Issue: High CPU temperature (>70°C)**
```bash
# Check current temperature
vcgencmd measure_temp

# Monitor temperature continuously
./monitoring/system_monitor.sh --action monitor --continuous

# Solutions:
# 1. Ensure proper cooling/heatsink
# 2. Check CPU governor
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor

# 3. Reduce CPU frequency if needed
echo "powersave" | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
```

**Issue: High memory usage (>85%)**
```bash
# Check memory usage
./monitoring/system_monitor.sh --action snapshot | grep -A5 "memory"

# Identify memory-intensive processes
ps aux --sort=-%mem | head -10

# Solutions:
# 1. Restart memory-intensive services
./workflow/pm2_manager.sh --action restart

# 2. Clear system cache
sudo sync && echo 3 | sudo tee /proc/sys/vm/drop_caches

# 3. Check for memory leaks
./monitoring/app_performance_monitor.sh --action monitor --app node
```

**Issue: Slow disk I/O performance**
```bash
# Test disk performance
sudo hdparm -tT /dev/nvme0n1

# Check disk usage
df -h

# Monitor disk I/O
sudo iotop

# Solutions:
# 1. Enable TRIM for SSD
sudo fstrim -av

# 2. Check file system
sudo fsck /dev/nvme0n1p1

# 3. Optimize mount options
sudo ./system/nvme_setup.sh --optimize
```

## Network Issues

### Connectivity Problems

**Issue: Cannot connect to external services**
```bash
# Test basic connectivity
ping -c 4 8.8.8.8

# Test DNS resolution
nslookup google.com

# Run comprehensive network diagnostics
./debugging/network_diagnostics.sh --action diagnose

# Solutions:
# 1. Check network interface
ip addr show

# 2. Restart networking
sudo systemctl restart networking

# 3. Check firewall rules
sudo ufw status
```

**Issue: Development servers not accessible**
```bash
# Check if services are running
./workflow/pm2_manager.sh --action monitor

# Check port availability
./workflow/port_manager.sh --action list

# Test local connectivity
curl http://localhost:3000/health
curl http://localhost:3001/api/health

# Solutions:
# 1. Restart development servers
./workflow/pm2_manager.sh --action restart

# 2. Check port conflicts
./workflow/port_manager.sh --action check --port 3000

# 3. Check firewall rules
sudo ufw allow 3000/tcp
sudo ufw allow 3001/tcp
```

**Issue: SSH connection refused**
```bash
# Check SSH service status
sudo systemctl status ssh

# Check SSH configuration
sudo sshd -t

# Solutions:
# 1. Restart SSH service
sudo systemctl restart ssh

# 2. Check SSH port
grep Port /etc/ssh/sshd_config

# 3. Re-run SSH hardening
sudo ./system/ssh_hardening.sh --reset
```

### Port Conflicts

**Issue: Port already in use**
```bash
# Error message
Error: listen EADDRINUSE: address already in use :::3000

# Check what's using the port
./workflow/port_manager.sh --action check --port 3000

# Solutions:
# 1. Kill process using the port
./workflow/port_manager.sh --action kill --port 3000

# 2. Use alternative port
./workflow/port_manager.sh --action check --range 3000-3010

# 3. Configure application to use different port
export PORT=3002
npm run dev
```

## Database Issues

### PostgreSQL Connection Problems

**Issue: Connection refused to PostgreSQL**
```bash
# Error message
FATAL: password authentication failed for user "postgres"

# Check PostgreSQL status
sudo systemctl status postgresql

# Test connection
./debugging/database_debug.sh --action connections

# Solutions:
# 1. Reset PostgreSQL password
sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'newpassword';"

# 2. Check pg_hba.conf
sudo cat /etc/postgresql/*/main/pg_hba.conf

# 3. Restart PostgreSQL
sudo systemctl restart postgresql
```

**Issue: Database performance problems**
```bash
# Check slow queries
./debugging/database_debug.sh --action slow-queries --threshold 1000

# Check database locks
./debugging/database_debug.sh --action locks

# Solutions:
# 1. Analyze and optimize slow queries
./debugging/database_debug.sh --action analyze --query "YOUR_SLOW_QUERY"

# 2. Update database statistics
sudo -u postgres psql -c "ANALYZE;"

# 3. Reindex tables if needed
sudo -u postgres psql -c "REINDEX DATABASE your_database;"
```

**Issue: Database connection pool exhausted**
```bash
# Error message
remaining connection slots are reserved for non-replication superuser connections

# Check active connections
./debugging/database_debug.sh --action connections

# Solutions:
# 1. Kill idle connections
sudo -u postgres psql -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE state = 'idle';"

# 2. Increase max_connections
sudo -u postgres psql -c "ALTER SYSTEM SET max_connections = 200;"
sudo systemctl restart postgresql

# 3. Implement connection pooling
# Configure PgBouncer or similar
```

## Application Issues

### Node.js and npm Problems

**Issue: Node.js version conflicts**
```bash
# Check current Node.js version
node --version

# Check available versions
nvm list

# Solutions:
# 1. Switch to correct version
nvm use 20

# 2. Reinstall Node.js
./environment/nodejs_nvm_setup.sh --version 20 --force

# 3. Clear npm cache
npm cache clean --force
```

**Issue: npm package installation fails**
```bash
# Error message
npm ERR! code EACCES

# Solutions:
# 1. Fix npm permissions
./environment/npm_optimization.sh --fix-permissions

# 2. Clear npm cache
npm cache clean --force

# 3. Use different registry
npm config set registry https://registry.npmjs.org/

# 4. Install with different user
sudo chown -R $(whoami) ~/.npm
```

**Issue: Build failures**
```bash
# Error message
Module build failed: Error: ENOSPC: no space left on device

# Check disk space
df -h

# Solutions:
# 1. Clean build artifacts
npm run clean
rm -rf node_modules package-lock.json
npm install

# 2. Increase file watchers
echo fs.inotify.max_user_watches=524288 | sudo tee -a /etc/sysctl.conf
sudo sysctl -p

# 3. Free up disk space
sudo apt autoremove
sudo apt autoclean
```

### React Development Issues

**Issue: Hot reload not working**
```bash
# Solutions:
# 1. Restart development server
./workflow/pm2_manager.sh --action restart --app react-dev

# 2. Reconfigure hot reload
./workflow/hot_reload_setup.sh --project-type react --port 3000

# 3. Check file watching limits
echo fs.inotify.max_user_watches=524288 | sudo tee -a /etc/sysctl.conf
sudo sysctl -p

# 4. Clear browser cache
# Ctrl+Shift+R in browser
```

**Issue: React build optimization warnings**
```bash
# Warning message
WARNING in asset size limit: The following asset(s) exceed the recommended size limit

# Solutions:
# 1. Analyze bundle size
npm run build -- --analyze

# 2. Optimize imports
# Use tree shaking and code splitting

# 3. Configure build optimization
./project/build_automation.sh --project-type react --optimize
```

### NestJS API Issues

**Issue: NestJS application won't start**
```bash
# Error message
Error: Cannot find module '@nestjs/core'

# Solutions:
# 1. Reinstall dependencies
cd backend
rm -rf node_modules package-lock.json
npm install

# 2. Check TypeScript compilation
npm run build

# 3. Restart with debugging
./workflow/pm2_manager.sh --action restart --app nestjs-api --debug
```

**Issue: Database connection in NestJS**
```bash
# Error message
Unable to connect to the database

# Solutions:
# 1. Check database configuration
cat backend/.env | grep DATABASE

# 2. Test database connection
./debugging/database_debug.sh --action connections

# 3. Update connection string
# Edit backend/.env with correct DATABASE_URL
```

## PM2 Process Management Issues

**Issue: PM2 processes not starting**
```bash
# Check PM2 status
./workflow/pm2_manager.sh --action monitor

# Solutions:
# 1. Reset PM2
pm2 kill
./workflow/pm2_manager.sh --action setup

# 2. Check PM2 logs
./workflow/pm2_manager.sh --action logs

# 3. Restart specific application
./workflow/pm2_manager.sh --action restart --app your-app
```

**Issue: PM2 memory leaks**
```bash
# Monitor PM2 memory usage
./monitoring/app_performance_monitor.sh --action monitor --app pm2

# Solutions:
# 1. Restart PM2 processes
./workflow/pm2_manager.sh --action restart

# 2. Configure memory limits
# Edit ecosystem.config.js:
# max_memory_restart: '500M'

# 3. Enable PM2 monitoring
pm2 install pm2-server-monit
```

## VS Code Server Issues

**Issue: VS Code Server won't start**
```bash
# Check VS Code Server status
ps aux | grep code-server

# Solutions:
# 1. Reinstall VS Code Server
./system/vscode_server_install.sh --reinstall

# 2. Check port availability
./workflow/port_manager.sh --action check --port 8080

# 3. Check logs
tail -f ~/.local/share/code-server/logs/code-server.log
```

## Git Workflow Issues

**Issue: Git authentication failures**
```bash
# Error message
Permission denied (publickey)

# Solutions:
# 1. Check SSH key
ssh -T git@github.com

# 2. Generate new SSH key
ssh-keygen -t ed25519 -C "your_email@example.com"

# 3. Add SSH key to agent
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519
```

**Issue: Git workflow automation fails**
```bash
# Check Git configuration
./workflow/git_workflow.sh --action status

# Solutions:
# 1. Reset Git workflow
./workflow/git_workflow.sh --action init

# 2. Check Git hooks
ls -la .git/hooks/

# 3. Fix permissions
chmod +x .git/hooks/*
```

## Monitoring and Logging Issues

**Issue: Log files growing too large**
```bash
# Check log file sizes
du -sh ~/development/logs/*

# Solutions:
# 1. Rotate logs
./workflow/log_monitor.sh --action rotate

# 2. Clean old logs
find ~/development/logs -name "*.log" -mtime +30 -delete

# 3. Configure log rotation
sudo logrotate -f /etc/logrotate.conf
```

**Issue: Monitoring alerts not working**
```bash
# Check monitoring status
./monitoring/system_monitor.sh --action status

# Solutions:
# 1. Restart monitoring
./monitoring/system_monitor.sh --action monitor --continuous &

# 2. Check alert thresholds
grep THRESHOLD ~/development/config/monitoring.conf

# 3. Test alert system
./monitoring/system_monitor.sh --action alerts --test
```

## Emergency Recovery Procedures

### System Recovery

**Complete system freeze:**
```bash
# 1. Hard reboot (last resort)
sudo reboot

# 2. After reboot, check system
./monitoring/system_monitor.sh --action diagnose

# 3. Check file system
sudo fsck /dev/nvme0n1p1

# 4. Restart services
./install.sh --mode recovery
```

**Database corruption:**
```bash
# 1. Stop PostgreSQL
sudo systemctl stop postgresql

# 2. Check database integrity
sudo -u postgres pg_checksums --check /var/lib/postgresql/*/main

# 3. Restore from backup
./database/backup_restore_utils.sh --action restore --backup latest

# 4. Restart PostgreSQL
sudo systemctl start postgresql
```

### Application Recovery

**All services down:**
```bash
# 1. Check system resources
./monitoring/system_monitor.sh --action status

# 2. Restart all services
./workflow/pm2_manager.sh --action restart

# 3. Check health
./deployment/health_checker.sh --service all

# 4. If still failing, full restart
sudo reboot
```

## Getting Help

### Diagnostic Information Collection

**Collect system information:**
```bash
# Create diagnostic report
mkdir -p ~/diagnostic_report
./monitoring/system_monitor.sh --action report > ~/diagnostic_report/system.txt
./debugging/network_diagnostics.sh --action diagnose > ~/diagnostic_report/network.txt
./debugging/database_debug.sh --action diagnose > ~/diagnostic_report/database.txt
./workflow/pm2_manager.sh --action monitor > ~/diagnostic_report/pm2.txt

# System information
uname -a > ~/diagnostic_report/system_info.txt
lscpu >> ~/diagnostic_report/system_info.txt
free -h >> ~/diagnostic_report/system_info.txt
df -h >> ~/diagnostic_report/system_info.txt

# Create archive
tar -czf ~/diagnostic_report_$(date +%Y%m%d_%H%M%S).tar.gz ~/diagnostic_report/
```

### Log Analysis

**Analyze recent errors:**
```bash
# System logs
sudo journalctl --since "1 hour ago" --priority=err

# Application logs
./workflow/log_monitor.sh --action analyze --service all

# Database logs
sudo tail -100 /var/log/postgresql/postgresql-*-main.log
```

### Support Resources

1. **Check documentation**: Review relevant usage guides in `docs/usage-guides/`
2. **Run diagnostics**: Use debugging scripts to identify issues
3. **Check logs**: Analyze log files for error messages
4. **System status**: Verify system resources and health
5. **Community support**: Search for similar issues online

### Prevention

**Regular maintenance:**
```bash
# Weekly maintenance script
#!/bin/bash
./monitoring/system_monitor.sh --action report
./debugging/database_debug.sh --action performance
./workflow/log_monitor.sh --action rotate
sudo apt update && sudo apt upgrade -y
./database/backup_restore_utils.sh --action backup
```