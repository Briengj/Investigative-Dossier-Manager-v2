# Script Parameters and API Reference

This document provides a comprehensive reference for all script parameters, options, and configuration settings.

## Master Installation Script

### install.sh

**Synopsis:**
```bash
./install.sh [--dry-run] [--mode MODE] [--skip COMPONENT] [--non-interactive] [--force]
```

**Parameters:**
- `--dry-run`: Show what would be done without making changes
- `--mode MODE`: Installation mode (full, minimal, development, production)
- `--skip COMPONENT`: Skip components (comma-separated list)
- `--non-interactive`: Run without user prompts
- `--force`: Force reinstallation of existing components
- `-h, --help`: Show help message

**Installation Modes:**
- `full`: Complete installation (all components)
- `minimal`: Basic system setup and Node.js environment only
- `development`: Development tools, monitoring, and debugging utilities
- `production`: Production-ready deployment with monitoring and optimization

**Components:**
- `system`: System optimization and security hardening
- `environment`: Node.js, TypeScript, and development environment
- `database`: PostgreSQL 17 installation and configuration
- `projects`: Project initialization and build tools
- `workflow`: Development workflow and process management
- `deployment`: Production deployment and optimization
- `monitoring`: System and application monitoring
- `debugging`: Debugging and troubleshooting tools

**Examples:**
```bash
# Full installation
./install.sh --mode full

# Development mode without database
./install.sh --mode development --skip database

# Dry run to see what would be installed
./install.sh --dry-run --mode full

# Non-interactive production installation
./install.sh --mode production --non-interactive
```

## System Scripts

### pi5_os_optimization.sh

**Synopsis:**
```bash
sudo ./system/pi5_os_optimization.sh [--dry-run]
```

**Parameters:**
- `--dry-run`: Show what would be done without making changes
- `-h, --help`: Show help message

**Features:**
- Memory and CPU optimization (16KB page size, NUMA emulation)
- SDRAM timing optimizations
- System package updates
- Performance monitoring setup

### nvme_setup.sh

**Synopsis:**
```bash
sudo ./system/nvme_setup.sh [--device DEVICE] [--format] [--optimize]
```

**Parameters:**
- `--device DEVICE`: NVMe device path (default: /dev/nvme0n1)
- `--format`: Format the NVMe device (destructive)
- `--optimize`: Apply performance optimizations
- `--dry-run`: Show what would be done without making changes

### ssh_hardening.sh

**Synopsis:**
```bash
sudo ./system/ssh_hardening.sh [--port PORT] [--key-only] [--reset]
```

**Parameters:**
- `--port PORT`: Custom SSH port (default: 22)
- `--key-only`: Disable password authentication
- `--reset`: Reset SSH configuration to defaults
- `--dry-run`: Show what would be done without making changes

### vscode_server_install.sh

**Synopsis:**
```bash
./system/vscode_server_install.sh [--port PORT] [--password PASSWORD] [--reinstall]
```

**Parameters:**
- `--port PORT`: VS Code Server port (default: 8080)
- `--password PASSWORD`: Access password
- `--reinstall`: Force reinstallation
- `--extensions`: Install recommended extensions

## Environment Scripts

### nodejs_nvm_setup.sh

**Synopsis:**
```bash
./environment/nodejs_nvm_setup.sh [--version VERSION] [--force] [--global-packages]
```

**Parameters:**
- `--version VERSION`: Node.js version to install (default: 20)
- `--force`: Force reinstallation
- `--global-packages`: Install global npm packages
- `--dry-run`: Show what would be done without making changes

### npm_optimization.sh

**Synopsis:**
```bash
./environment/npm_optimization.sh [--cache-size SIZE] [--fix-permissions] [--registry URL]
```

**Parameters:**
- `--cache-size SIZE`: npm cache size in MB (default: 512)
- `--fix-permissions`: Fix npm permission issues
- `--registry URL`: Set npm registry URL
- `--optimize`: Apply performance optimizations

### typescript_setup.sh

**Synopsis:**
```bash
./environment/typescript_setup.sh [--version VERSION] [--global] [--config-only]
```

**Parameters:**
- `--version VERSION`: TypeScript version (default: 5.8.3)
- `--global`: Install TypeScript globally
- `--config-only`: Only setup configuration files
- `--strict`: Enable strict TypeScript configuration

## Database Scripts

### postgresql_install.sh

**Synopsis:**
```bash
sudo ./database/postgresql_install.sh [--version VERSION] [--secure-install] [--optimize]
```

**Parameters:**
- `--version VERSION`: PostgreSQL version (default: 17)
- `--secure-install`: Apply security hardening
- `--optimize`: Apply ARM64 performance optimizations
- `--create-user USER`: Create database user
- `--create-db DATABASE`: Create database

### backup_restore_utils.sh

**Synopsis:**
```bash
./database/backup_restore_utils.sh --action ACTION [--database DB] [--backup-name NAME]
```

**Parameters:**
- `--action ACTION`: Action to perform (backup, restore, list, cleanup)
- `--database DB`: Database name (default: all databases)
- `--backup-name NAME`: Backup file name
- `--compress`: Compress backup files
- `--schedule`: Setup automated backups

## Project Scripts

### init_react_project.sh

**Synopsis:**
```bash
./project/init_react_project.sh [--project-name NAME] [--template TYPE] [--directory DIR]
```

**Parameters:**
- `--project-name NAME`: Project name (required)
- `--template TYPE`: Project template (typescript, javascript)
- `--directory DIR`: Project directory (default: ~/development/projects)
- `--vite`: Use Vite build tool (default: true)
- `--git`: Initialize Git repository (default: true)
- `--install-deps`: Install dependencies (default: true)
- `--dry-run`: Show what would be done without making changes

### init_nestjs_project.sh

**Synopsis:**
```bash
./project/init_nestjs_project.sh [--project-name NAME] [--database TYPE] [--directory DIR]
```

**Parameters:**
- `--project-name NAME`: Project name (required)
- `--database TYPE`: Database type (postgresql, mysql, sqlite)
- `--directory DIR`: Project directory (default: ~/development/projects)
- `--package-manager MANAGER`: Package manager (npm, yarn, pnpm)
- `--git`: Initialize Git repository (default: true)
- `--dry-run`: Show what would be done without making changes

### dependency_manager.sh

**Synopsis:**
```bash
./project/dependency_manager.sh --action ACTION [--project-path PATH] [--package PACKAGE]
```

**Parameters:**
- `--action ACTION`: Action (install, update, audit, check-compatibility, clean)
- `--project-path PATH`: Project directory path
- `--package PACKAGE`: Specific package name
- `--dev`: Install as development dependency
- `--global`: Install globally

### build_automation.sh

**Synopsis:**
```bash
./project/build_automation.sh [--project-type TYPE] [--environment ENV] [--optimize]
```

**Parameters:**
- `--project-type TYPE`: Project type (react, nestjs, both)
- `--environment ENV`: Build environment (development, production)
- `--optimize`: Enable build optimizations
- `--analyze`: Analyze bundle size
- `--watch`: Watch mode for development

### test_runner.sh

**Synopsis:**
```bash
./project/test_runner.sh [--test-type TYPE] [--coverage] [--watch] [--project-path PATH]
```

**Parameters:**
- `--test-type TYPE`: Test type (unit, integration, e2e, all)
- `--coverage`: Generate coverage report
- `--watch`: Watch mode
- `--project-path PATH`: Project directory
- `--reporter REPORTER`: Test reporter (default, json, html)

### code_quality.sh

**Synopsis:**
```bash
./project/code_quality.sh [--fix] [--check-only] [--project-path PATH] [--config CONFIG]
```

**Parameters:**
- `--fix`: Automatically fix issues
- `--check-only`: Only check, don't fix
- `--project-path PATH`: Project directory
- `--config CONFIG`: Configuration file path
- `--strict`: Use strict quality rules

## Workflow Scripts

### hot_reload_setup.sh

**Synopsis:**
```bash
./workflow/hot_reload_setup.sh [--project-type TYPE] [--port PORT] [--watch-extensions EXT]
```

**Parameters:**
- `--project-type TYPE`: Project type (react, nestjs, both)
- `--port PORT`: Development server port
- `--watch-extensions EXT`: File extensions to watch (comma-separated)
- `--exclude-dirs DIRS`: Directories to exclude from watching
- `--polling`: Use polling instead of native file watching

### port_manager.sh

**Synopsis:**
```bash
./workflow/port_manager.sh --action ACTION [--port PORT] [--service SERVICE] [--range RANGE]
```

**Parameters:**
- `--action ACTION`: Action (check, reserve, release, list, kill)
- `--port PORT`: Specific port number
- `--service SERVICE`: Service name (react, nestjs, postgresql, vscode)
- `--range RANGE`: Port range (e.g., 3000-3010)
- `--timeout SECONDS`: Connection timeout

### log_monitor.sh

**Synopsis:**
```bash
./workflow/log_monitor.sh --action ACTION [--service SERVICE] [--follow] [--filter PATTERN]
```

**Parameters:**
- `--action ACTION`: Action (monitor, analyze, search, tail, rotate)
- `--service SERVICE`: Service to monitor (react, nestjs, postgresql, pm2, all)
- `--follow`: Follow logs in real-time
- `--filter PATTERN`: Filter logs by pattern
- `--level LEVEL`: Log level filter (error, warn, info, debug)
- `--lines COUNT`: Number of lines to show

### pm2_manager.sh

**Synopsis:**
```bash
./workflow/pm2_manager.sh --action ACTION [--app APPLICATION] [--env ENVIRONMENT]
```

**Parameters:**
- `--action ACTION`: Action (setup, start, stop, restart, monitor, logs, delete)
- `--app APPLICATION`: Specific application name
- `--env ENVIRONMENT`: Environment (development, production, staging)
- `--instances COUNT`: Number of instances to run
- `--watch`: Enable file watching

### git_workflow.sh

**Synopsis:**
```bash
./workflow/git_workflow.sh --action ACTION [--branch BRANCH] [--message MESSAGE]
```

**Parameters:**
- `--action ACTION`: Action (init, commit, push, pull, branch, merge, deploy)
- `--branch BRANCH`: Branch name
- `--message MESSAGE`: Commit message
- `--auto-push`: Automatically push after commit
- `--run-tests`: Run tests before commit
- `--force`: Force operation

## Deployment Scripts

### deploy_pipeline.sh

**Synopsis:**
```bash
./deployment/deploy_pipeline.sh [--environment ENV] [--branch BRANCH] [--rollback]
```

**Parameters:**
- `--environment ENV`: Target environment (staging, production)
- `--branch BRANCH`: Git branch to deploy (default: main)
- `--rollback`: Rollback to previous deployment
- `--dry-run`: Show deployment steps without executing
- `--skip-tests`: Skip test execution
- `--backup`: Create backup before deployment

### environment_switcher.sh

**Synopsis:**
```bash
./deployment/environment_switcher.sh --action ACTION [--environment ENV] [--backup-name NAME]
```

**Parameters:**
- `--action ACTION`: Action (switch, list, backup, restore, validate)
- `--environment ENV`: Target environment (development, staging, production)
- `--backup-name NAME`: Name for environment backup
- `--force`: Force environment switch without confirmation

### health_checker.sh

**Synopsis:**
```bash
./deployment/health_checker.sh [--service SERVICE] [--endpoint URL] [--timeout SECONDS]
```

**Parameters:**
- `--service SERVICE`: Service to check (react, nestjs, postgresql, all)
- `--endpoint URL`: Specific endpoint to test
- `--timeout SECONDS`: Request timeout (default: 30)
- `--continuous`: Continuous health monitoring
- `--alert-on-failure`: Send alerts on health check failures
- `--retry COUNT`: Number of retries on failure

### production_optimizer.sh

**Synopsis:**
```bash
./deployment/production_optimizer.sh --action ACTION [--component COMPONENT] [--profile PROFILE]
```

**Parameters:**
- `--action ACTION`: Action (optimize, performance, security, all)
- `--component COMPONENT`: Component (system, nodejs, postgresql, nginx)
- `--profile PROFILE`: Optimization profile (balanced, performance, memory)
- `--dry-run`: Show optimizations without applying

## Monitoring Scripts

### system_monitor.sh

**Synopsis:**
```bash
./monitoring/system_monitor.sh [--action ACTION] [--interval SECONDS] [--continuous]
```

**Parameters:**
- `--action ACTION`: Action (monitor, snapshot, alerts, status, report)
- `--interval SECONDS`: Monitoring interval (default: 5)
- `--continuous`: Enable continuous monitoring mode
- `--output FORMAT`: Output format (text, json, html)
- `--save-report`: Save report to file
- `--dry-run`: Show what would be done without making changes

**Alert Thresholds:**
- `ALERT_THRESHOLD_CPU`: CPU usage threshold (default: 80%)
- `ALERT_THRESHOLD_MEMORY`: Memory usage threshold (default: 85%)
- `ALERT_THRESHOLD_DISK`: Disk usage threshold (default: 90%)
- `ALERT_THRESHOLD_TEMP`: Temperature threshold (default: 70°C)

### app_performance_monitor.sh

**Synopsis:**
```bash
./monitoring/app_performance_monitor.sh --action ACTION [--app APPLICATION] [--interval SECONDS]
```

**Parameters:**
- `--action ACTION`: Action (monitor, report, snapshot, alerts)
- `--app APPLICATION`: Application (react, nestjs, postgresql, all)
- `--interval SECONDS`: Monitoring interval
- `--output FORMAT`: Output format (json, text, html)
- `--baseline`: Set performance baseline
- `--compare-baseline`: Compare with baseline

## Debugging Scripts

### network_diagnostics.sh

**Synopsis:**
```bash
./debugging/network_diagnostics.sh --action ACTION [--target TARGET] [--port PORT]
```

**Parameters:**
- `--action ACTION`: Action (diagnose, connectivity, services, troubleshoot, scan, trace)
- `--target TARGET`: Target host or IP address
- `--port PORT`: Specific port to test
- `--timeout SECONDS`: Connection timeout (default: 10)
- `--verbose`: Enable verbose output
- `--save-report`: Save diagnostic report to file

### database_debug.sh

**Synopsis:**
```bash
./debugging/database_debug.sh --action ACTION [--database DB] [--query QUERY]
```

**Parameters:**
- `--action ACTION`: Action (diagnose, performance, slow-queries, locks, connections, analyze)
- `--database DB`: Specific database to analyze
- `--query QUERY`: Specific query to analyze
- `--threshold MS`: Slow query threshold in milliseconds
- `--export FORMAT`: Export format (json, csv, html)
- `--save-report`: Save analysis report

## Configuration Files

### Environment Variables

**System Configuration:**
```bash
# Monitoring thresholds
CPU_ALERT_THRESHOLD=80
MEMORY_ALERT_THRESHOLD=85
TEMP_ALERT_THRESHOLD=70
DISK_ALERT_THRESHOLD=90

# Development settings
NODE_ENV=development
LOG_LEVEL=info
ENABLE_HOT_RELOAD=true

# Database settings
DATABASE_URL=postgresql://user:pass@localhost:5432/dbname
POSTGRES_USER=postgres
POSTGRES_PASSWORD=secure_password
```

**Port Assignments:**
```bash
# Default port assignments
REACT_DEV_PORT=3000
NESTJS_DEV_PORT=3001
POSTGRESQL_PORT=5432
VSCODE_SERVER_PORT=8080
MONITORING_PORT=9090
```

### Configuration Templates

**environment_template.env:**
```bash
# Node.js Configuration
NODE_ENV=development
PORT=3000
HOST=localhost

# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/database_name
DB_HOST=localhost
DB_PORT=5432
DB_USERNAME=postgres
DB_PASSWORD=your_password
DB_DATABASE=your_database

# Monitoring Configuration
ENABLE_MONITORING=true
LOG_LEVEL=info
METRICS_PORT=9090

# Security Configuration
JWT_SECRET=your_jwt_secret_here
CORS_ORIGIN=http://localhost:3000
```

**postgresql_template.conf:**
```sql
# PostgreSQL 17 ARM64 Optimizations
shared_buffers = 256MB
effective_cache_size = 1GB
work_mem = 4MB
maintenance_work_mem = 64MB
random_page_cost = 1.1
effective_io_concurrency = 200
max_connections = 100
```

## Return Codes

All scripts use standard exit codes:
- `0`: Success
- `1`: General error
- `2`: Misuse of shell command
- `126`: Command invoked cannot execute
- `127`: Command not found
- `128+n`: Fatal error signal "n"

## Environment Variables

**Global Environment Variables:**
- `SCRIPT_DEBUG`: Enable debug output (true/false)
- `LOG_LEVEL`: Logging level (debug, info, warn, error)
- `DRY_RUN`: Global dry run mode (true/false)
- `FORCE_YES`: Skip confirmation prompts (true/false)

**Script-Specific Variables:**
- `INSTALL_MODE`: Installation mode for install.sh
- `PROJECT_DIR`: Default project directory
- `LOG_DIR`: Log file directory
- `CONFIG_DIR`: Configuration file directory