#!/bin/bash
#
# Application Performance Monitoring Script for React 19.1.0 and NestJS 11.1.3
# Monitors Node.js 20 LTS applications, PostgreSQL 17, and PM2 processes on ARM64
# Integrates with existing development workflow and health checking infrastructure
#
# Usage: ./app_performance_monitor.sh [--dry-run] [--action ACTION] [--app APP]
# 
# Prerequisites:
# - Node.js 20 LTS applications running
# - PM2 process manager configured
# - PostgreSQL 17 database running
# - curl for HTTP endpoint monitoring
# - psql for database monitoring
#
# Features:
# - Node.js application performance tracking
# - Memory leak detection and heap profiling
# - PostgreSQL query performance monitoring
# - PM2 process health and resource tracking
# - HTTP endpoint response time monitoring
# - Error rate and availability tracking
# - Performance metrics collection and alerting
# - Integration with existing log monitoring
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/app_performance_monitor.log"
DRY_RUN=false
ACTION="monitor"
TARGET_APP="all"
MONITOR_INTERVAL=30
PERFORMANCE_REPORT_DIR="$HOME/development/logs/performance_reports"
METRICS_FILE="$PERFORMANCE_REPORT_DIR/app_metrics.json"
ALERT_THRESHOLD_RESPONSE_TIME=5000  # milliseconds
ALERT_THRESHOLD_ERROR_RATE=5        # percentage
ALERT_THRESHOLD_MEMORY_GROWTH=20    # percentage per hour

# Application configurations
declare -A APP_CONFIGS=(
    ["react"]="http://localhost:5173"
    ["nestjs"]="http://localhost:3000"
    ["nginx"]="http://localhost:80"
)

# Health check endpoints
declare -A HEALTH_ENDPOINTS=(
    ["nestjs"]="/api/health"
    ["react"]="/"
)

# Database configuration
DB_HOST="localhost"
DB_PORT="5432"
DB_NAME="postgres"
DB_USER="postgres"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --action)
            ACTION="$2"
            shift 2
            ;;
        --app)
            TARGET_APP="$2"
            shift 2
            ;;
        --interval)
            MONITOR_INTERVAL="$2"
            shift 2
            ;;
        --response-time-threshold)
            ALERT_THRESHOLD_RESPONSE_TIME="$2"
            shift 2
            ;;
        --error-rate-threshold)
            ALERT_THRESHOLD_ERROR_RATE="$2"
            shift 2
            ;;
        --memory-growth-threshold)
            ALERT_THRESHOLD_MEMORY_GROWTH="$2"
            shift 2
            ;;
        --db-host)
            DB_HOST="$2"
            shift 2
            ;;
        --db-port)
            DB_PORT="$2"
            shift 2
            ;;
        --db-name)
            DB_NAME="$2"
            shift 2
            ;;
        --db-user)
            DB_USER="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--action ACTION] [--app APP]"
            echo "Monitors application performance for React and NestJS applications"
            echo ""
            echo "Options:"
            echo "  --dry-run                    Show what would be done without making changes"
            echo "  --action ACTION              Action to perform (default: monitor)"
            echo "  --app APP                    Target application: react, nestjs, all"
            echo "  --interval SECONDS           Monitoring interval (default: 30)"
            echo "  --response-time-threshold MS Response time alert threshold (default: 5000)"
            echo "  --error-rate-threshold %     Error rate alert threshold (default: 5)"
            echo "  --memory-growth-threshold %  Memory growth alert threshold (default: 20)"
            echo "  --db-host HOST               Database host (default: localhost)"
            echo "  --db-port PORT               Database port (default: 5432)"
            echo "  --db-name NAME               Database name (default: postgres)"
            echo "  --db-user USER               Database user (default: postgres)"
            echo "  -h, --help                   Show this help message"
            echo ""
            echo "Actions:"
            echo "  monitor                      Real-time application monitoring"
            echo "  snapshot                     Take performance snapshot"
            echo "  nodejs                       Monitor Node.js specific metrics"
            echo "  database                     Monitor PostgreSQL performance"
            echo "  endpoints                    Monitor HTTP endpoint performance"
            echo "  pm2                          Monitor PM2 process metrics"
            echo "  memory                       Monitor memory usage and leaks"
            echo "  report                       Generate performance report"
            echo "  alerts                       Check performance alerts"
            echo "  status                       Show application status"
            echo ""
            echo "Examples:"
            echo "  $0 --action monitor --app nestjs"
            echo "  $0 --action nodejs --interval 60"
            echo "  $0 --action database"
            echo "  $0 --action memory --app react"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create directories
mkdir -p "$(dirname "$LOG_FILE")" "$PERFORMANCE_REPORT_DIR"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_alert() {
    echo "[ALERT] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
    logger -t "app_performance_monitor" "ALERT: $*"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Node.js
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        exit 1
    fi
    
    local node_version
    node_version=$(node --version | sed 's/v//')
    local node_major_version
    node_major_version=$(echo "$node_version" | cut -d. -f1)
    
    if [[ "$node_major_version" -lt 20 ]]; then
        log_warning "Node.js 20 LTS recommended, found: v$node_version"
    else
        log_info "Node.js version: v$node_version ✓"
    fi
    
    # Check PM2
    if ! command -v pm2 >/dev/null 2>&1 && ! npx pm2 --version >/dev/null 2>&1; then
        log_warning "PM2 not found - some monitoring features will be limited"
    else
        log_info "PM2 available ✓"
    fi
    
    # Check curl for HTTP monitoring
    if ! command -v curl >/dev/null 2>&1; then
        log_error "curl is required for HTTP endpoint monitoring"
        exit 1
    fi
    
    # Check PostgreSQL client
    if ! command -v psql >/dev/null 2>&1; then
        log_warning "psql not found - database monitoring will be limited"
    else
        log_info "PostgreSQL client available ✓"
    fi
    
    # Check jq for JSON processing
    if ! command -v jq >/dev/null 2>&1; then
        log_error "jq is required for JSON processing - install with: sudo apt install jq"
        exit 1
    fi
    
    log_info "Prerequisites check completed"
}

# Get PM2 command (handle global vs local installation)
get_pm2_command() {
    if command -v pm2 >/dev/null 2>&1; then
        echo "pm2"
    else
        echo "npx pm2"
    fi
}

# Monitor Node.js specific metrics
monitor_nodejs_metrics() {
    log_info "Collecting Node.js performance metrics..."
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    # Get PM2 process information
    local pm2_processes
    if pm2_processes=$($pm2_cmd jlist 2>/dev/null); then
        echo "$pm2_processes" | jq -r '.[] | select(.pm2_env.status == "online") | {
            name: .name,
            pid: .pid,
            cpu: .monit.cpu,
            memory: .monit.memory,
            uptime: .pm2_env.pm_uptime,
            restarts: .pm2_env.restart_time,
            status: .pm2_env.status
        }'
    else
        echo '[]'
    fi
}

# Monitor HTTP endpoint performance
monitor_endpoint_performance() {
    local app_name=$1
    local base_url=$2
    local endpoint=${3:-"/"}
    
    local full_url="${base_url}${endpoint}"
    local response_time=0
    local status_code=0
    local success=false
    
    # Measure response time and get status code
    local start_time
    start_time=$(date +%s%3N)
    
    if status_code=$(curl -o /dev/null -s -w "%{http_code}" --connect-timeout 10 --max-time 30 "$full_url" 2>/dev/null); then
        local end_time
        end_time=$(date +%s%3N)
        response_time=$((end_time - start_time))
        
        if [[ "$status_code" -ge 200 && "$status_code" -lt 400 ]]; then
            success=true
        fi
    fi
    
    echo "{\"app\":\"$app_name\",\"endpoint\":\"$endpoint\",\"response_time\":$response_time,\"status_code\":$status_code,\"success\":$success}"
}

# Monitor PostgreSQL performance
monitor_database_performance() {
    log_info "Collecting PostgreSQL performance metrics..."
    
    if ! command -v psql >/dev/null 2>&1; then
        log_warning "psql not available - skipping database monitoring"
        return 0
    fi
    
    local db_metrics="{}"
    
    # Test database connection
    if psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -c "SELECT 1;" >/dev/null 2>&1; then
        # Get database statistics
        local db_stats
        db_stats=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c "
            SELECT json_build_object(
                'connections', (SELECT count(*) FROM pg_stat_activity),
                'active_connections', (SELECT count(*) FROM pg_stat_activity WHERE state = 'active'),
                'database_size', pg_size_pretty(pg_database_size('$DB_NAME')),
                'cache_hit_ratio', round((sum(blks_hit) * 100.0 / sum(blks_hit + blks_read))::numeric, 2)
            FROM pg_stat_database WHERE datname = '$DB_NAME';
        " 2>/dev/null | tr -d ' \n' || echo '{}')
        
        # Get slow queries (queries running longer than 1 second)
        local slow_queries
        slow_queries=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c "
            SELECT count(*) FROM pg_stat_activity 
            WHERE state = 'active' AND query_start < now() - interval '1 second';
        " 2>/dev/null | tr -d ' \n' || echo '0')
        
        # Get table statistics for main tables
        local table_stats
        table_stats=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -c "
            SELECT json_agg(json_build_object(
                'table_name', schemaname||'.'||tablename,
                'size', pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)),
                'seq_scan', seq_scan,
                'seq_tup_read', seq_tup_read,
                'idx_scan', idx_scan,
                'idx_tup_fetch', idx_tup_fetch
            )) FROM pg_stat_user_tables LIMIT 10;
        " 2>/dev/null | tr -d ' \n' || echo '[]')
        
        db_metrics=$(echo '{}' | jq --argjson stats "$db_stats" --arg slow_queries "$slow_queries" --argjson table_stats "$table_stats" '
            . + $stats + {"slow_queries": ($slow_queries | tonumber), "table_stats": $table_stats}
        ')
    else
        log_warning "Cannot connect to PostgreSQL database"
        db_metrics='{"error": "connection_failed"}'
    fi
    
    echo "$db_metrics"
}

# Monitor memory usage and detect potential leaks
monitor_memory_usage() {
    log_info "Monitoring memory usage and potential leaks..."
    
    local memory_metrics="{}"
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    # Get Node.js process memory usage from PM2
    if pm2_processes=$($pm2_cmd jlist 2>/dev/null); then
        local app_memory
        app_memory=$(echo "$pm2_processes" | jq '[.[] | select(.pm2_env.status == "online") | {
            name: .name,
            pid: .pid,
            memory_mb: (.monit.memory / 1024 / 1024 | round),
            heap_used: (.pm2_env.axm_monitor.heap_used?.value // 0),
            heap_total: (.pm2_env.axm_monitor.heap_total?.value // 0),
            external: (.pm2_env.axm_monitor.external?.value // 0)
        }]')
        
        memory_metrics=$(echo '{}' | jq --argjson apps "$app_memory" '. + {"applications": $apps}')
    fi
    
    # Get system memory usage
    local system_memory
    system_memory=$(free -m | awk 'NR==2{printf "{\"total\":%s,\"used\":%s,\"free\":%s,\"usage_percent\":%.1f}", $2,$3,$4,($3/$2)*100}')
    
    memory_metrics=$(echo "$memory_metrics" | jq --argjson system "$system_memory" '. + {"system": $system}')
    
    echo "$memory_metrics"
}

# Take performance snapshot
take_performance_snapshot() {
    log_info "Taking application performance snapshot..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would take performance snapshot"
        return 0
    fi
    
    local timestamp
    timestamp=$(date '+%Y-%m-%d_%H-%M-%S')
    local snapshot_file="$PERFORMANCE_REPORT_DIR/performance_snapshot_$timestamp.json"
    
    log_info "Collecting performance metrics..."
    
    # Collect Node.js metrics
    local nodejs_metrics
    nodejs_metrics=$(monitor_nodejs_metrics)
    
    # Collect endpoint performance
    local endpoint_metrics=[]
    for app in "${!APP_CONFIGS[@]}"; do
        if [[ "$TARGET_APP" == "all" || "$TARGET_APP" == "$app" ]]; then
            local base_url="${APP_CONFIGS[$app]}"
            local endpoint="${HEALTH_ENDPOINTS[$app]:-"/"}"
            local endpoint_data
            endpoint_data=$(monitor_endpoint_performance "$app" "$base_url" "$endpoint")
            endpoint_metrics=$(echo "$endpoint_metrics" | jq --argjson new "$endpoint_data" '. + [$new]')
        fi
    done
    
    # Collect database metrics
    local database_metrics
    database_metrics=$(monitor_database_performance)
    
    # Collect memory metrics
    local memory_metrics
    memory_metrics=$(monitor_memory_usage)
    
    # Create comprehensive snapshot
    cat > "$snapshot_file" << EOF
{
  "timestamp": "$(date -Iseconds)",
  "hostname": "$(hostname)",
  "node_version": "$(node --version)",
  "nodejs_processes": $nodejs_metrics,
  "endpoint_performance": $endpoint_metrics,
  "database": $database_metrics,
  "memory": $memory_metrics
}
EOF
    
    log_success "Performance snapshot saved: $snapshot_file"
    
    # Update current metrics file
    cp "$snapshot_file" "$METRICS_FILE"
}

# Check performance alerts
check_performance_alerts() {
    log_info "Checking performance alerts..."
    
    if [[ ! -f "$METRICS_FILE" ]]; then
        log_warning "No metrics file found - taking snapshot first"
        take_performance_snapshot
        return 0
    fi
    
    local alerts_triggered=false
    
    # Check endpoint response times
    local slow_endpoints
    slow_endpoints=$(jq -r --arg threshold "$ALERT_THRESHOLD_RESPONSE_TIME" '
        .endpoint_performance[] | select(.response_time > ($threshold | tonumber)) | 
        "\(.app): \(.response_time)ms (threshold: \($threshold)ms)"
    ' "$METRICS_FILE" 2>/dev/null || echo "")
    
    if [[ -n "$slow_endpoints" ]]; then
        while IFS= read -r line; do
            if [[ -n "$line" ]]; then
                log_alert "Slow endpoint response: $line"
                alerts_triggered=true
            fi
        done <<< "$slow_endpoints"
    fi
    
    # Check error rates
    local failed_endpoints
    failed_endpoints=$(jq -r '
        .endpoint_performance[] | select(.success == false) | 
        "\(.app): HTTP \(.status_code)"
    ' "$METRICS_FILE" 2>/dev/null || echo "")
    
    if [[ -n "$failed_endpoints" ]]; then
        while IFS= read -r line; do
            if [[ -n "$line" ]]; then
                log_alert "Endpoint failure: $line"
                alerts_triggered=true
            fi
        done <<< "$failed_endpoints"
    fi
    
    # Check memory usage
    local high_memory_apps
    high_memory_apps=$(jq -r '
        .memory.applications[]? | select(.memory_mb > 500) | 
        "\(.name): \(.memory_mb)MB"
    ' "$METRICS_FILE" 2>/dev/null || echo "")
    
    if [[ -n "$high_memory_apps" ]]; then
        while IFS= read -r line; do
            if [[ -n "$line" ]]; then
                log_alert "High memory usage: $line"
                alerts_triggered=true
            fi
        done <<< "$high_memory_apps"
    fi
    
    # Check database slow queries
    local slow_queries
    slow_queries=$(jq -r '.database.slow_queries // 0' "$METRICS_FILE" 2>/dev/null || echo "0")
    if [[ "$slow_queries" -gt 0 ]]; then
        log_alert "Database slow queries detected: $slow_queries"
        alerts_triggered=true
    fi
    
    if [[ "$alerts_triggered" == "false" ]]; then
        log_info "No performance alerts triggered - applications performing within normal parameters"
    fi
}

# Monitor applications continuously
monitor_applications() {
    log_info "Starting continuous application monitoring..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would start continuous monitoring"
        return 0
    fi
    
    log_info "Application monitoring started (Ctrl+C to stop)"
    log_info "Interval: ${MONITOR_INTERVAL}s"
    log_info "Target: $TARGET_APP"
    
    # Setup signal handler for graceful shutdown
    trap 'log_info "Stopping application monitoring..."; exit 0' INT
    
    while true; do
        clear
        echo "=== Application Performance Monitor ==="
        echo "Time: $(date)"
        echo "Target: $TARGET_APP"
        echo ""
        
        # Take snapshot and check alerts
        take_performance_snapshot >/dev/null 2>&1
        
        if [[ -f "$METRICS_FILE" ]]; then
            # Display Node.js processes
            echo "=== Node.js Processes ==="
            jq -r '.nodejs_processes[]? | "Name: \(.name) | PID: \(.pid) | CPU: \(.cpu)% | Memory: \((.memory/1024/1024)|floor)MB | Status: \(.status)"' "$METRICS_FILE" 2>/dev/null || echo "No PM2 processes found"
            echo ""
            
            # Display endpoint performance
            echo "=== Endpoint Performance ==="
            jq -r '.endpoint_performance[] | "App: \(.app) | Response: \(.response_time)ms | Status: \(.status_code) | Success: \(.success)"' "$METRICS_FILE" 2>/dev/null || echo "No endpoint data"
            echo ""
            
            # Display database status
            echo "=== Database Status ==="
            local db_connections
            db_connections=$(jq -r '.database.connections // "N/A"' "$METRICS_FILE" 2>/dev/null)
            local db_size
            db_size=$(jq -r '.database.database_size // "N/A"' "$METRICS_FILE" 2>/dev/null)
            local cache_hit_ratio
            cache_hit_ratio=$(jq -r '.database.cache_hit_ratio // "N/A"' "$METRICS_FILE" 2>/dev/null)
            echo "Connections: $db_connections"
            echo "Database Size: $db_size"
            echo "Cache Hit Ratio: $cache_hit_ratio%"
            echo ""
            
            # Display memory usage
            echo "=== Memory Usage ==="
            local system_memory_usage
            system_memory_usage=$(jq -r '.memory.system.usage_percent // "N/A"' "$METRICS_FILE" 2>/dev/null)
            echo "System Memory: $system_memory_usage%"
            jq -r '.memory.applications[]? | "App: \(.name) | Memory: \(.memory_mb)MB"' "$METRICS_FILE" 2>/dev/null || echo "No application memory data"
        fi
        
        echo ""
        echo "=== Alerts ==="
        check_performance_alerts 2>/dev/null | grep "ALERT" | tail -3 || echo "No recent alerts"
        
        sleep "$MONITOR_INTERVAL"
    done
}

# Generate performance report
generate_performance_report() {
    log_info "Generating performance report..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would generate performance report"
        return 0
    fi
    
    local timestamp
    timestamp=$(date '+%Y-%m-%d_%H-%M-%S')
    local report_file="$PERFORMANCE_REPORT_DIR/performance_report_$timestamp.html"
    
    # Take a snapshot first
    take_performance_snapshot
    
    # Generate HTML report
    cat > "$report_file" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>Application Performance Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #f0f0f0; padding: 10px; border-radius: 5px; }
        .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .metric { display: inline-block; margin: 10px; padding: 10px; background-color: #f9f9f9; border-radius: 3px; }
        .alert { color: red; font-weight: bold; }
        .normal { color: green; }
        .warning { color: orange; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
EOF
    
    # Add report content
    cat >> "$report_file" << EOF
    <div class="header">
        <h1>Application Performance Report</h1>
        <p>Generated: $(date)</p>
        <p>Hostname: $(hostname)</p>
        <p>Node.js Version: $(node --version)</p>
    </div>
EOF
    
    # Add performance metrics from snapshot
    if [[ -f "$METRICS_FILE" ]]; then
        # Endpoint performance section
        cat >> "$report_file" << 'EOF'
    <div class="section">
        <h2>Endpoint Performance</h2>
        <table>
            <tr><th>Application</th><th>Response Time</th><th>Status Code</th><th>Success</th></tr>
EOF
        
        jq -r '.endpoint_performance[] | 
            "<tr><td>\(.app)</td><td class=\"" + 
            (if .response_time > 5000 then "alert" elif .response_time > 2000 then "warning" else "normal" end) + 
            "\">\(.response_time)ms</td><td>\(.status_code)</td><td>" + 
            (if .success then "✓" else "✗" end) + "</td></tr>"' "$METRICS_FILE" >> "$report_file" 2>/dev/null || echo "<tr><td colspan='4'>No data available</td></tr>" >> "$report_file"
        
        cat >> "$report_file" << 'EOF'
        </table>
    </div>
EOF
        
        # Memory usage section
        cat >> "$report_file" << 'EOF'
    <div class="section">
        <h2>Memory Usage</h2>
        <table>
            <tr><th>Application</th><th>Memory (MB)</th><th>PID</th><th>Status</th></tr>
EOF
        
        jq -r '.memory.applications[]? | 
            "<tr><td>\(.name)</td><td class=\"" + 
            (if .memory_mb > 500 then "alert" elif .memory_mb > 250 then "warning" else "normal" end) + 
            "\">\(.memory_mb)MB</td><td>\(.pid)</td><td>Running</td></tr>"' "$METRICS_FILE" >> "$report_file" 2>/dev/null || echo "<tr><td colspan='4'>No data available</td></tr>" >> "$report_file"
        
        cat >> "$report_file" << 'EOF'
        </table>
    </div>
EOF
    fi
    
    # Close HTML
    cat >> "$report_file" << 'EOF'
</body>
</html>
EOF
    
    log_success "Performance report generated: $report_file"
}

# Show application status
show_application_status() {
    log_info "=== Application Status ==="
    
    # Take a fresh snapshot
    take_performance_snapshot >/dev/null 2>&1
    
    if [[ -f "$METRICS_FILE" ]]; then
        echo "=== Node.js Processes ==="
        jq -r '.nodejs_processes[]? | "Name: \(.name)\n  PID: \(.pid)\n  CPU: \(.cpu)%\n  Memory: \((.memory/1024/1024)|floor)MB\n  Uptime: \(.uptime)\n  Restarts: \(.restarts)\n  Status: \(.status)\n"' "$METRICS_FILE" 2>/dev/null || echo "No PM2 processes found"
        
        echo "=== Endpoint Health ==="
        jq -r '.endpoint_performance[] | "App: \(.app)\n  Endpoint: \(.endpoint)\n  Response Time: \(.response_time)ms\n  Status Code: \(.status_code)\n  Success: \(.success)\n"' "$METRICS_FILE" 2>/dev/null || echo "No endpoint data"
        
        echo "=== Database Status ==="
        local db_error
        db_error=$(jq -r '.database.error // empty' "$METRICS_FILE" 2>/dev/null)
        if [[ -n "$db_error" ]]; then
            echo "Database Error: $db_error"
        else
            echo "Connections: $(jq -r '.database.connections // "N/A"' "$METRICS_FILE" 2>/dev/null)"
            echo "Active Connections: $(jq -r '.database.active_connections // "N/A"' "$METRICS_FILE" 2>/dev/null)"
            echo "Database Size: $(jq -r '.database.database_size // "N/A"' "$METRICS_FILE" 2>/dev/null)"
            echo "Cache Hit Ratio: $(jq -r '.database.cache_hit_ratio // "N/A"' "$METRICS_FILE" 2>/dev/null)%"
            echo "Slow Queries: $(jq -r '.database.slow_queries // "N/A"' "$METRICS_FILE" 2>/dev/null)"
        fi
        
        echo ""
        echo "=== Memory Summary ==="
        echo "System Memory Usage: $(jq -r '.memory.system.usage_percent // "N/A"' "$METRICS_FILE" 2>/dev/null)%"
        echo "Total System Memory: $(jq -r '.memory.system.total // "N/A"' "$METRICS_FILE" 2>/dev/null)MB"
        echo "Free System Memory: $(jq -r '.memory.system.free // "N/A"' "$METRICS_FILE" 2>/dev/null)MB"
    else
        echo "No metrics data available - run with --action snapshot first"
    fi
}

# Execute action
execute_action() {
    case "$ACTION" in
        "monitor")
            monitor_applications
            ;;
        "snapshot")
            take_performance_snapshot
            ;;
        "nodejs")
            monitor_nodejs_metrics
            ;;
        "database")
            monitor_database_performance
            ;;
        "endpoints")
            for app in "${!APP_CONFIGS[@]}"; do
                if [[ "$TARGET_APP" == "all" || "$TARGET_APP" == "$app" ]]; then
                    local base_url="${APP_CONFIGS[$app]}"
                    local endpoint="${HEALTH_ENDPOINTS[$app]:-"/"}"
                    monitor_endpoint_performance "$app" "$base_url" "$endpoint"
                fi
            done
            ;;
        "pm2")
            monitor_nodejs_metrics
            ;;
        "memory")
            monitor_memory_usage
            ;;
        "report")
            generate_performance_report
            ;;
        "alerts")
            check_performance_alerts
            ;;
        "status")
            show_application_status
            ;;
        *)
            log_error "Unknown action: $ACTION"
            log_error "Valid actions: monitor, snapshot, nodejs, database, endpoints, pm2, memory, report, alerts, status"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== Application Performance Monitor Summary ==="
    log_info "Action: $ACTION"
    log_info "Target Application: $TARGET_APP"
    log_info "Monitor Interval: ${MONITOR_INTERVAL}s"
    log_info "Alert Thresholds:"
    log_info "  Response Time: ${ALERT_THRESHOLD_RESPONSE_TIME}ms"
    log_info "  Error Rate: ${ALERT_THRESHOLD_ERROR_RATE}%"
    log_info "  Memory Growth: ${ALERT_THRESHOLD_MEMORY_GROWTH}%"
    log_info "Report Directory: $PERFORMANCE_REPORT_DIR"
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting application performance monitoring..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Action: $ACTION"
    
    check_prerequisites
    execute_action
    
    log_success "Application performance monitoring completed successfully!"
    display_summary
}

# Execute main function
main "$@"