#!/bin/bash
#
# System Resource Monitoring Script for Raspberry Pi 5 Development Environment
# Monitors CPU, memory, disk, network, and temperature metrics on ARM64 architecture
# Integrates with existing development workflow and logging infrastructure
#
# Usage: ./system_monitor.sh [--dry-run] [--action ACTION] [--interval SECONDS]
# 
# Prerequisites:
# - htop, iotop, nethogs, smartmontools installed
# - vcgencmd available (Raspberry Pi OS)
# - Write access to log directory
# - ARM64 architecture (Raspberry Pi 5)
#
# Features:
# - Real-time system resource monitoring
# - Temperature and hardware health monitoring
# - Network bandwidth monitoring by process
# - Disk I/O performance tracking
# - Memory usage analysis with leak detection
# - CPU utilization and load average tracking
# - Alert generation for resource thresholds
# - Integration with PM2 and application monitoring
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/system_monitor.log"
DRY_RUN=false
ACTION="monitor"
MONITOR_INTERVAL=5
ALERT_THRESHOLD_CPU=80
ALERT_THRESHOLD_MEMORY=85
ALERT_THRESHOLD_DISK=90
ALERT_THRESHOLD_TEMP=70
CONTINUOUS_MODE=false
REPORT_DIR="$HOME/development/logs/system_reports"
METRICS_FILE="$REPORT_DIR/system_metrics.json"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --action)
            ACTION="$2"
            shift 2
            ;;
        --interval)
            MONITOR_INTERVAL="$2"
            shift 2
            ;;
        --cpu-threshold)
            ALERT_THRESHOLD_CPU="$2"
            shift 2
            ;;
        --memory-threshold)
            ALERT_THRESHOLD_MEMORY="$2"
            shift 2
            ;;
        --disk-threshold)
            ALERT_THRESHOLD_DISK="$2"
            shift 2
            ;;
        --temp-threshold)
            ALERT_THRESHOLD_TEMP="$2"
            shift 2
            ;;
        --continuous)
            CONTINUOUS_MODE=true
            shift
            ;;
        --report-dir)
            REPORT_DIR="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--action ACTION] [--interval SECONDS]"
            echo "Monitors system resources on Raspberry Pi 5"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --action ACTION        Action to perform (default: monitor)"
            echo "  --interval SECONDS     Monitoring interval (default: 5)"
            echo "  --cpu-threshold N      CPU usage alert threshold % (default: 80)"
            echo "  --memory-threshold N   Memory usage alert threshold % (default: 85)"
            echo "  --disk-threshold N     Disk usage alert threshold % (default: 90)"
            echo "  --temp-threshold N     Temperature alert threshold °C (default: 70)"
            echo "  --continuous           Run in continuous monitoring mode"
            echo "  --report-dir DIR       Directory for reports (default: ~/development/logs/system_reports)"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Actions:"
            echo "  monitor                Real-time system monitoring"
            echo "  snapshot               Take system snapshot"
            echo "  report                 Generate system report"
            echo "  alerts                 Check and generate alerts"
            echo "  temperature            Monitor temperature only"
            echo "  network                Monitor network activity"
            echo "  disk                   Monitor disk I/O"
            echo "  processes              Monitor top processes"
            echo "  status                 Show current system status"
            echo ""
            echo "Examples:"
            echo "  $0 --action monitor --continuous"
            echo "  $0 --action snapshot"
            echo "  $0 --action temperature --interval 10"
            echo "  $0 --action report"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create directories
mkdir -p "$(dirname "$LOG_FILE")" "$REPORT_DIR"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_alert() {
    echo "[ALERT] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
    # Also log to system log for critical alerts
    logger -t "system_monitor" "ALERT: $*"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check required tools
    local required_tools=("htop" "iotop" "nethogs" "smartctl" "vcgencmd")
    local missing_tools=()
    
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" >/dev/null 2>&1; then
            missing_tools+=("$tool")
        fi
    done
    
    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        log_warning "Missing tools: ${missing_tools[*]}"
        log_info "Install with: sudo apt install htop iotop nethogs smartmontools"
        
        # Check if we can continue without some tools
        local critical_missing=false
        for tool in "${missing_tools[@]}"; do
            if [[ "$tool" == "vcgencmd" ]]; then
                log_warning "vcgencmd not available - temperature monitoring may be limited"
            elif [[ "$tool" == "htop" || "$tool" == "iotop" ]]; then
                critical_missing=true
            fi
        done
        
        if [[ "$critical_missing" == "true" ]]; then
            log_error "Critical monitoring tools missing"
            exit 1
        fi
    else
        log_info "All required tools available ✓"
    fi
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" == "aarch64" ]]; then
        log_info "ARM64 architecture detected ✓"
    else
        log_warning "Not running on ARM64 architecture: $(uname -m)"
    fi
    
    # Check Raspberry Pi 5 specific features
    if [[ -f "/proc/device-tree/model" ]]; then
        local pi_model
        pi_model=$(cat /proc/device-tree/model 2>/dev/null | tr -d '\0')
        if [[ "$pi_model" == *"Raspberry Pi 5"* ]]; then
            log_info "Raspberry Pi 5 detected: $pi_model ✓"
        else
            log_warning "Not running on Raspberry Pi 5: $pi_model"
        fi
    fi
    
    log_info "Prerequisites check completed"
}

# Get CPU information and usage
get_cpu_info() {
    local cpu_usage
    cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | sed 's/%us,//')
    
    local load_avg
    load_avg=$(uptime | awk -F'load average:' '{print $2}' | sed 's/^ *//')
    
    local cpu_temp="N/A"
    if command -v vcgencmd >/dev/null 2>&1; then
        cpu_temp=$(vcgencmd measure_temp 2>/dev/null | sed 's/temp=//' | sed 's/°C//' || echo "N/A")
    fi
    
    local cpu_freq="N/A"
    if [[ -f "/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq" ]]; then
        local freq_khz
        freq_khz=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq 2>/dev/null || echo "0")
        cpu_freq=$((freq_khz / 1000))
    fi
    
    echo "{\"usage\":\"$cpu_usage\",\"load_avg\":\"$load_avg\",\"temperature\":\"$cpu_temp\",\"frequency\":\"$cpu_freq\"}"
}

# Get memory information
get_memory_info() {
    local mem_info
    mem_info=$(free -m | awk 'NR==2{printf "{\"total\":\"%s\",\"used\":\"%s\",\"free\":\"%s\",\"usage_percent\":\"%.1f\"}", $2,$3,$4,($3/$2)*100}')
    
    # Add swap information
    local swap_info
    swap_info=$(free -m | awk 'NR==3{printf ",\"swap_total\":\"%s\",\"swap_used\":\"%s\",\"swap_free\":\"%s\"", $2,$3,$4}')
    
    echo "${mem_info}${swap_info}}"
}

# Get disk information
get_disk_info() {
    local disk_usage
    disk_usage=$(df -h / | awk 'NR==2{printf "{\"filesystem\":\"%s\",\"size\":\"%s\",\"used\":\"%s\",\"available\":\"%s\",\"usage_percent\":\"%s\"}", $1,$2,$3,$4,$5}')
    
    # Add I/O statistics if available
    local io_stats=""
    if [[ -f "/proc/diskstats" ]]; then
        local root_device
        root_device=$(df / | awk 'NR==2{print $1}' | sed 's|/dev/||' | sed 's|[0-9]*$||')
        if [[ -n "$root_device" ]]; then
            io_stats=$(awk -v dev="$root_device" '$3==dev{printf ",\"reads\":\"%s\",\"writes\":\"%s\"", $4,$8}' /proc/diskstats)
        fi
    fi
    
    echo "${disk_usage}${io_stats}}"
}

# Get network information
get_network_info() {
    local network_stats=""
    
    # Get network interface statistics
    if [[ -f "/proc/net/dev" ]]; then
        # Find primary network interface (excluding lo)
        local primary_interface
        primary_interface=$(ip route | grep default | awk '{print $5}' | head -1)
        
        if [[ -n "$primary_interface" ]]; then
            network_stats=$(awk -v iface="$primary_interface" '
                $1 == iface":" {
                    printf "{\"interface\":\"%s\",\"rx_bytes\":\"%s\",\"tx_bytes\":\"%s\",\"rx_packets\":\"%s\",\"tx_packets\":\"%s\"}", 
                    iface, $2, $10, $3, $11
                }' /proc/net/dev)
        fi
    fi
    
    if [[ -z "$network_stats" ]]; then
        network_stats='{"interface":"unknown","rx_bytes":"0","tx_bytes":"0","rx_packets":"0","tx_packets":"0"}'
    fi
    
    echo "$network_stats"
}

# Get process information
get_process_info() {
    local top_processes
    top_processes=$(ps aux --sort=-%cpu | head -6 | tail -5 | awk '{printf "%s:%s:%s ", $11, $3, $4}')
    
    local process_count
    process_count=$(ps aux | wc -l)
    
    echo "{\"count\":\"$process_count\",\"top_cpu\":\"$top_processes\"}"
}

# Get system uptime and load
get_system_info() {
    local uptime_info
    uptime_info=$(uptime -p | sed 's/up //')
    
    local kernel_version
    kernel_version=$(uname -r)
    
    local os_info
    if [[ -f "/etc/os-release" ]]; then
        os_info=$(grep PRETTY_NAME /etc/os-release | cut -d'"' -f2)
    else
        os_info=$(uname -s)
    fi
    
    echo "{\"uptime\":\"$uptime_info\",\"kernel\":\"$kernel_version\",\"os\":\"$os_info\"}"
}

# Take system snapshot
take_snapshot() {
    log_info "Taking system snapshot..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would take system snapshot"
        return 0
    fi
    
    local timestamp
    timestamp=$(date '+%Y-%m-%d_%H-%M-%S')
    local snapshot_file="$REPORT_DIR/snapshot_$timestamp.json"
    
    log_info "Collecting system metrics..."
    
    # Collect all metrics
    local cpu_info
    cpu_info=$(get_cpu_info)
    
    local memory_info
    memory_info=$(get_memory_info)
    
    local disk_info
    disk_info=$(get_disk_info)
    
    local network_info
    network_info=$(get_network_info)
    
    local process_info
    process_info=$(get_process_info)
    
    local system_info
    system_info=$(get_system_info)
    
    # Create JSON snapshot
    cat > "$snapshot_file" << EOF
{
  "timestamp": "$(date -Iseconds)",
  "hostname": "$(hostname)",
  "architecture": "$(uname -m)",
  "cpu": $cpu_info,
  "memory": $memory_info,
  "disk": $disk_info,
  "network": $network_info,
  "processes": $process_info,
  "system": $system_info
}
EOF
    
    log_success "System snapshot saved: $snapshot_file"
    
    # Also update current metrics file
    cp "$snapshot_file" "$METRICS_FILE"
}

# Check for alerts
check_alerts() {
    log_info "Checking system alerts..."
    
    local alerts_triggered=false
    
    # CPU usage alert
    local cpu_usage
    cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | sed 's/%us,//' | sed 's/\..*//')
    if [[ "$cpu_usage" -gt "$ALERT_THRESHOLD_CPU" ]]; then
        log_alert "High CPU usage: ${cpu_usage}% (threshold: ${ALERT_THRESHOLD_CPU}%)"
        alerts_triggered=true
    fi
    
    # Memory usage alert
    local memory_usage
    memory_usage=$(free | awk 'NR==2{printf "%.0f", ($3/$2)*100}')
    if [[ "$memory_usage" -gt "$ALERT_THRESHOLD_MEMORY" ]]; then
        log_alert "High memory usage: ${memory_usage}% (threshold: ${ALERT_THRESHOLD_MEMORY}%)"
        alerts_triggered=true
    fi
    
    # Disk usage alert
    local disk_usage
    disk_usage=$(df / | awk 'NR==2{print $5}' | sed 's/%//')
    if [[ "$disk_usage" -gt "$ALERT_THRESHOLD_DISK" ]]; then
        log_alert "High disk usage: ${disk_usage}% (threshold: ${ALERT_THRESHOLD_DISK}%)"
        alerts_triggered=true
    fi
    
    # Temperature alert
    if command -v vcgencmd >/dev/null 2>&1; then
        local cpu_temp
        cpu_temp=$(vcgencmd measure_temp 2>/dev/null | sed 's/temp=//' | sed 's/°C//' | sed 's/\..*//' || echo "0")
        if [[ "$cpu_temp" -gt "$ALERT_THRESHOLD_TEMP" ]]; then
            log_alert "High CPU temperature: ${cpu_temp}°C (threshold: ${ALERT_THRESHOLD_TEMP}°C)"
            alerts_triggered=true
        fi
    fi
    
    # Load average alert (5-minute load > number of CPUs)
    local cpu_count
    cpu_count=$(nproc)
    local load_5min
    load_5min=$(uptime | awk -F'load average:' '{print $2}' | awk -F',' '{print $2}' | sed 's/^ *//' | sed 's/\..*//')
    if [[ "$load_5min" -gt "$cpu_count" ]]; then
        log_alert "High system load: ${load_5min} (CPU count: ${cpu_count})"
        alerts_triggered=true
    fi
    
    if [[ "$alerts_triggered" == "false" ]]; then
        log_info "No alerts triggered - system within normal parameters"
    fi
}

# Monitor temperature only
monitor_temperature() {
    log_info "Starting temperature monitoring..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would monitor temperature"
        return 0
    fi
    
    if ! command -v vcgencmd >/dev/null 2>&1; then
        log_error "vcgencmd not available - cannot monitor temperature"
        return 1
    fi
    
    log_info "Temperature monitoring (Ctrl+C to stop):"
    log_info "Threshold: ${ALERT_THRESHOLD_TEMP}°C"
    
    while true; do
        local cpu_temp
        cpu_temp=$(vcgencmd measure_temp 2>/dev/null | sed 's/temp=//' || echo "temp=N/A")
        
        local temp_value
        temp_value=$(echo "$cpu_temp" | sed 's/°C//' | sed 's/\..*//')
        
        echo "$(date '+%H:%M:%S') - CPU Temperature: $cpu_temp"
        
        if [[ "$temp_value" != "N/A" ]] && [[ "$temp_value" -gt "$ALERT_THRESHOLD_TEMP" ]]; then
            log_alert "Temperature threshold exceeded: $cpu_temp"
        fi
        
        sleep "$MONITOR_INTERVAL"
    done
}

# Monitor network activity
monitor_network() {
    log_info "Starting network monitoring..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would monitor network activity"
        return 0
    fi
    
    if ! command -v nethogs >/dev/null 2>&1; then
        log_error "nethogs not available - install with: sudo apt install nethogs"
        return 1
    fi
    
    log_info "Network activity monitoring (requires sudo):"
    log_info "Press Ctrl+C to stop"
    
    # Run nethogs with delay to show per-process network usage
    sudo nethogs -d "$MONITOR_INTERVAL"
}

# Monitor disk I/O
monitor_disk_io() {
    log_info "Starting disk I/O monitoring..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would monitor disk I/O"
        return 0
    fi
    
    if ! command -v iotop >/dev/null 2>&1; then
        log_error "iotop not available - install with: sudo apt install iotop"
        return 1
    fi
    
    log_info "Disk I/O monitoring (requires sudo):"
    log_info "Press Ctrl+C to stop"
    
    # Run iotop with delay
    sudo iotop -d "$MONITOR_INTERVAL"
}

# Monitor top processes
monitor_processes() {
    log_info "Starting process monitoring..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would monitor processes"
        return 0
    fi
    
    log_info "Process monitoring (Ctrl+C to stop):"
    
    if command -v htop >/dev/null 2>&1; then
        htop
    else
        top
    fi
}

# Real-time system monitoring
monitor_system() {
    log_info "Starting real-time system monitoring..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would start real-time monitoring"
        return 0
    fi
    
    log_info "System monitoring started (Ctrl+C to stop)"
    log_info "Interval: ${MONITOR_INTERVAL}s"
    log_info "Thresholds - CPU: ${ALERT_THRESHOLD_CPU}%, Memory: ${ALERT_THRESHOLD_MEMORY}%, Disk: ${ALERT_THRESHOLD_DISK}%, Temp: ${ALERT_THRESHOLD_TEMP}°C"
    
    # Setup signal handler for graceful shutdown
    trap 'log_info "Stopping system monitoring..."; exit 0' INT
    
    while true; do
        clear
        echo "=== Raspberry Pi 5 System Monitor ==="
        echo "Time: $(date)"
        echo "Hostname: $(hostname)"
        echo ""
        
        # CPU Information
        echo "=== CPU ==="
        local cpu_info
        cpu_info=$(get_cpu_info)
        echo "Usage: $(echo "$cpu_info" | jq -r '.usage')%"
        echo "Load Average: $(echo "$cpu_info" | jq -r '.load_avg')"
        echo "Temperature: $(echo "$cpu_info" | jq -r '.temperature')°C"
        echo "Frequency: $(echo "$cpu_info" | jq -r '.frequency')MHz"
        echo ""
        
        # Memory Information
        echo "=== Memory ==="
        local memory_info
        memory_info=$(get_memory_info)
        echo "Total: $(echo "$memory_info" | jq -r '.total')MB"
        echo "Used: $(echo "$memory_info" | jq -r '.used')MB ($(echo "$memory_info" | jq -r '.usage_percent')%)"
        echo "Free: $(echo "$memory_info" | jq -r '.free')MB"
        echo ""
        
        # Disk Information
        echo "=== Disk ==="
        local disk_info
        disk_info=$(get_disk_info)
        echo "Size: $(echo "$disk_info" | jq -r '.size')"
        echo "Used: $(echo "$disk_info" | jq -r '.used') ($(echo "$disk_info" | jq -r '.usage_percent')"
        echo "Available: $(echo "$disk_info" | jq -r '.available')"
        echo ""
        
        # Network Information
        echo "=== Network ==="
        local network_info
        network_info=$(get_network_info)
        echo "Interface: $(echo "$network_info" | jq -r '.interface')"
        echo "RX: $(echo "$network_info" | jq -r '.rx_bytes') bytes"
        echo "TX: $(echo "$network_info" | jq -r '.tx_bytes') bytes"
        echo ""
        
        # Process Information
        echo "=== Top Processes (CPU) ==="
        ps aux --sort=-%cpu | head -6 | tail -5 | awk '{printf "%-20s %5s%% %5s%%\n", $11, $3, $4}'
        echo ""
        
        # Check for alerts
        check_alerts
        
        if [[ "$CONTINUOUS_MODE" == "false" ]]; then
            break
        fi
        
        sleep "$MONITOR_INTERVAL"
    done
}

# Generate system report
generate_report() {
    log_info "Generating system report..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would generate system report"
        return 0
    fi
    
    local timestamp
    timestamp=$(date '+%Y-%m-%d_%H-%M-%S')
    local report_file="$REPORT_DIR/system_report_$timestamp.html"
    
    # Take a snapshot first
    take_snapshot
    
    # Generate HTML report
    cat > "$report_file" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>Raspberry Pi 5 System Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #f0f0f0; padding: 10px; border-radius: 5px; }
        .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .metric { display: inline-block; margin: 10px; padding: 10px; background-color: #f9f9f9; border-radius: 3px; }
        .alert { color: red; font-weight: bold; }
        .normal { color: green; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
EOF
    
    # Add report content
    cat >> "$report_file" << EOF
    <div class="header">
        <h1>Raspberry Pi 5 System Report</h1>
        <p>Generated: $(date)</p>
        <p>Hostname: $(hostname)</p>
        <p>Architecture: $(uname -m)</p>
    </div>
EOF
    
    # Add system metrics from snapshot
    if [[ -f "$METRICS_FILE" ]]; then
        local cpu_usage
        cpu_usage=$(jq -r '.cpu.usage' "$METRICS_FILE" | sed 's/%//')
        
        local memory_usage
        memory_usage=$(jq -r '.memory.usage_percent' "$METRICS_FILE")
        
        local disk_usage
        disk_usage=$(jq -r '.disk.usage_percent' "$METRICS_FILE" | sed 's/%//')
        
        cat >> "$report_file" << EOF
    <div class="section">
        <h2>Current System Status</h2>
        <div class="metric">
            <strong>CPU Usage:</strong> 
            <span class="$(if (( $(echo "$cpu_usage" | sed 's/\..*//' || echo 0) > ALERT_THRESHOLD_CPU )); then echo "alert"; else echo "normal"; fi)">
                ${cpu_usage}%
            </span>
        </div>
        <div class="metric">
            <strong>Memory Usage:</strong> 
            <span class="$(if (( $(echo "$memory_usage" | sed 's/\..*//' || echo 0) > ALERT_THRESHOLD_MEMORY )); then echo "alert"; else echo "normal"; fi)">
                ${memory_usage}%
            </span>
        </div>
        <div class="metric">
            <strong>Disk Usage:</strong> 
            <span class="$(if (( $(echo "$disk_usage" | sed 's/\..*//' || echo 0) > ALERT_THRESHOLD_DISK )); then echo "alert"; else echo "normal"; fi)">
                ${disk_usage}%
            </span>
        </div>
    </div>
EOF
    fi
    
    # Close HTML
    cat >> "$report_file" << 'EOF'
</body>
</html>
EOF
    
    log_success "System report generated: $report_file"
}

# Show current system status
show_status() {
    log_info "=== System Status ==="
    
    # Basic system information
    echo "Hostname: $(hostname)"
    echo "Architecture: $(uname -m)"
    echo "Kernel: $(uname -r)"
    echo "Uptime: $(uptime -p)"
    echo ""
    
    # CPU status
    echo "=== CPU ==="
    local cpu_info
    cpu_info=$(get_cpu_info)
    echo "Usage: $(echo "$cpu_info" | jq -r '.usage')%"
    echo "Temperature: $(echo "$cpu_info" | jq -r '.temperature')°C"
    echo "Frequency: $(echo "$cpu_info" | jq -r '.frequency')MHz"
    echo ""
    
    # Memory status
    echo "=== Memory ==="
    local memory_info
    memory_info=$(get_memory_info)
    echo "Total: $(echo "$memory_info" | jq -r '.total')MB"
    echo "Used: $(echo "$memory_info" | jq -r '.used')MB ($(echo "$memory_info" | jq -r '.usage_percent')%)"
    echo "Free: $(echo "$memory_info" | jq -r '.free')MB"
    echo ""
    
    # Disk status
    echo "=== Disk ==="
    df -h /
    echo ""
    
    # Network status
    echo "=== Network ==="
    ip addr show | grep -E "^[0-9]+:|inet " | head -10
    echo ""
    
    # Process count
    echo "=== Processes ==="
    echo "Total processes: $(ps aux | wc -l)"
    echo "Top CPU consumers:"
    ps aux --sort=-%cpu | head -6 | tail -5 | awk '{printf "  %-20s %5s%%\n", $11, $3}'
}

# Execute action
execute_action() {
    case "$ACTION" in
        "monitor")
            monitor_system
            ;;
        "snapshot")
            take_snapshot
            ;;
        "report")
            generate_report
            ;;
        "alerts")
            check_alerts
            ;;
        "temperature")
            monitor_temperature
            ;;
        "network")
            monitor_network
            ;;
        "disk")
            monitor_disk_io
            ;;
        "processes")
            monitor_processes
            ;;
        "status")
            show_status
            ;;
        *)
            log_error "Unknown action: $ACTION"
            log_error "Valid actions: monitor, snapshot, report, alerts, temperature, network, disk, processes, status"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== System Monitor Summary ==="
    log_info "Action: $ACTION"
    log_info "Monitor Interval: ${MONITOR_INTERVAL}s"
    log_info "Alert Thresholds:"
    log_info "  CPU: ${ALERT_THRESHOLD_CPU}%"
    log_info "  Memory: ${ALERT_THRESHOLD_MEMORY}%"
    log_info "  Disk: ${ALERT_THRESHOLD_DISK}%"
    log_info "  Temperature: ${ALERT_THRESHOLD_TEMP}°C"
    log_info "Report Directory: $REPORT_DIR"
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting system monitoring..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Action: $ACTION"
    
    check_prerequisites
    execute_action
    
    log_success "System monitoring completed successfully!"
    display_summary
}

# Execute main function
main "$@"