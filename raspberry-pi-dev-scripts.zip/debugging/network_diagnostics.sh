#!/bin/bash
#
# Network Diagnostics and Troubleshooting Script for Raspberry Pi 5
# Comprehensive network analysis, port scanning, and connectivity testing
# Optimized for ARM64 architecture and development environment debugging
#
# Usage: ./network_diagnostics.sh [--dry-run] [--action ACTION] [--target TARGET]
# 
# Prerequisites:
# - netstat, ss, nmap, curl, ping utilities
# - nethogs for process-based network monitoring
# - tcpdump for packet analysis (requires sudo)
# - Network interfaces configured
#
# Features:
# - Network connectivity testing
# - Port scanning and service detection
# - Process-based network usage monitoring
# - Network interface analysis
# - DNS resolution testing
# - Firewall and routing diagnostics
# - Application-specific network debugging
# - Performance and latency analysis
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/network_diagnostics.log"
DRY_RUN=false
ACTION="diagnose"
TARGET_HOST=""
TARGET_PORT=""
INTERFACE=""
TIMEOUT=10
REPORT_DIR="$HOME/development/logs/network_reports"
VERBOSE=false

# Common ports for development services
declare -A COMMON_PORTS=(
    ["ssh"]="22"
    ["http"]="80"
    ["https"]="443"
    ["react-dev"]="5173"
    ["nestjs"]="3000"
    ["postgresql"]="5432"
    ["nginx"]="80,443"
    ["pm2-web"]="9615"
)

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --action)
            ACTION="$2"
            shift 2
            ;;
        --target)
            TARGET_HOST="$2"
            shift 2
            ;;
        --port)
            TARGET_PORT="$2"
            shift 2
            ;;
        --interface)
            INTERFACE="$2"
            shift 2
            ;;
        --timeout)
            TIMEOUT="$2"
            shift 2
            ;;
        --verbose)
            VERBOSE=true
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--action ACTION] [--target TARGET]"
            echo "Network diagnostics and troubleshooting for Raspberry Pi 5"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --action ACTION        Action to perform (default: diagnose)"
            echo "  --target TARGET        Target host or IP address"
            echo "  --port PORT            Target port number"
            echo "  --interface IFACE      Network interface to analyze"
            echo "  --timeout SECONDS      Connection timeout (default: 10)"
            echo "  --verbose              Enable verbose output"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Actions:"
            echo "  diagnose               Full network diagnostics"
            echo "  connectivity           Test basic connectivity"
            echo "  ports                  Scan ports and services"
            echo "  interfaces             Analyze network interfaces"
            echo "  dns                    Test DNS resolution"
            echo "  routing                Check routing table and gateway"
            echo "  firewall               Analyze firewall rules"
            echo "  processes              Show network processes"
            echo "  monitor                Monitor network traffic"
            echo "  performance            Test network performance"
            echo "  services               Check development services"
            echo "  troubleshoot           Interactive troubleshooting"
            echo ""
            echo "Examples:"
            echo "  $0 --action diagnose"
            echo "  $0 --action connectivity --target google.com"
            echo "  $0 --action ports --target localhost"
            echo "  $0 --action services"
            echo "  $0 --action monitor --interface eth0"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create directories
mkdir -p "$(dirname "$LOG_FILE")" "$REPORT_DIR"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_debug() {
    if [[ "$VERBOSE" == "true" ]]; then
        echo "[DEBUG] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
    fi
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check required network tools
    local required_tools=("ping" "curl" "netstat" "ss")
    local optional_tools=("nmap" "nethogs" "tcpdump" "iptables")
    local missing_required=()
    local missing_optional=()
    
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" >/dev/null 2>&1; then
            missing_required+=("$tool")
        fi
    done
    
    for tool in "${optional_tools[@]}"; do
        if ! command -v "$tool" >/dev/null 2>&1; then
            missing_optional+=("$tool")
        fi
    done
    
    if [[ ${#missing_required[@]} -gt 0 ]]; then
        log_error "Missing required tools: ${missing_required[*]}"
        log_error "Install with: sudo apt install ${missing_required[*]}"
        exit 1
    fi
    
    if [[ ${#missing_optional[@]} -gt 0 ]]; then
        log_warning "Missing optional tools: ${missing_optional[*]}"
        log_info "Install with: sudo apt install ${missing_optional[*]}"
        log_info "Some features may be limited"
    fi
    
    log_info "Required network tools available ✓"
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" == "aarch64" ]]; then
        log_info "ARM64 architecture detected ✓"
    else
        log_warning "Not running on ARM64 architecture: $(uname -m)"
    fi
    
    log_info "Prerequisites check completed"
}

# Get network interface information
get_network_interfaces() {
    log_debug "Getting network interface information..."
    
    echo "=== Network Interfaces ==="
    
    # Get interface list with IP addresses
    ip addr show | grep -E "^[0-9]+:|inet " | while read -r line; do
        if [[ "$line" =~ ^[0-9]+: ]]; then
            echo "$line"
        else
            echo "  $line"
        fi
    done
    
    echo ""
    echo "=== Interface Statistics ==="
    cat /proc/net/dev | head -2
    cat /proc/net/dev | tail -n +3 | grep -v "lo:" | head -5
    
    echo ""
    echo "=== Routing Table ==="
    ip route show
    
    echo ""
    echo "=== Default Gateway ==="
    ip route | grep default
}

# Test basic connectivity
test_connectivity() {
    local target=${TARGET_HOST:-"8.8.8.8"}
    
    log_info "Testing connectivity to $target..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would test connectivity to $target"
        return 0
    fi
    
    echo "=== Ping Test ==="
    if ping -c 4 -W "$TIMEOUT" "$target" 2>/dev/null; then
        log_success "Ping to $target successful"
    else
        log_error "Ping to $target failed"
    fi
    
    echo ""
    echo "=== Traceroute ==="
    if command -v traceroute >/dev/null 2>&1; then
        traceroute -m 10 "$target" 2>/dev/null || log_warning "Traceroute failed or not available"
    else
        log_warning "Traceroute not available - install with: sudo apt install traceroute"
    fi
    
    # Test HTTP connectivity if target looks like a domain
    if [[ "$target" =~ ^[a-zA-Z] ]]; then
        echo ""
        echo "=== HTTP Connectivity Test ==="
        local http_status
        http_status=$(curl -o /dev/null -s -w "%{http_code}" --connect-timeout "$TIMEOUT" "http://$target" 2>/dev/null || echo "000")
        
        if [[ "$http_status" != "000" ]]; then
            log_success "HTTP connection to $target successful (status: $http_status)"
        else
            log_warning "HTTP connection to $target failed"
        fi
        
        # Test HTTPS
        local https_status
        https_status=$(curl -o /dev/null -s -w "%{http_code}" --connect-timeout "$TIMEOUT" "https://$target" 2>/dev/null || echo "000")
        
        if [[ "$https_status" != "000" ]]; then
            log_success "HTTPS connection to $target successful (status: $https_status)"
        else
            log_warning "HTTPS connection to $target failed"
        fi
    fi
}

# Scan ports and detect services
scan_ports() {
    local target=${TARGET_HOST:-"localhost"}
    
    log_info "Scanning ports on $target..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would scan ports on $target"
        return 0
    fi
    
    echo "=== Port Scan Results ==="
    
    # Use nmap if available, otherwise use basic port checking
    if command -v nmap >/dev/null 2>&1; then
        log_info "Using nmap for comprehensive port scan..."
        nmap -sT -O --top-ports 100 "$target" 2>/dev/null || {
            log_warning "Full nmap scan failed, trying basic scan..."
            nmap -sT --top-ports 20 "$target" 2>/dev/null || log_error "Nmap scan failed"
        }
    else
        log_info "Using basic port checking (nmap not available)..."
        
        # Check common development ports
        for service in "${!COMMON_PORTS[@]}"; do
            local ports="${COMMON_PORTS[$service]}"
            IFS=',' read -ra PORT_ARRAY <<< "$ports"
            
            for port in "${PORT_ARRAY[@]}"; do
                if timeout "$TIMEOUT" bash -c "</dev/tcp/$target/$port" 2>/dev/null; then
                    echo "$port/tcp open  $service"
                else
                    echo "$port/tcp closed $service"
                fi
            done
        done
    fi
    
    echo ""
    echo "=== Listening Services ==="
    if command -v ss >/dev/null 2>&1; then
        ss -tuln | head -20
    else
        netstat -tuln | head -20
    fi
}

# Test DNS resolution
test_dns() {
    log_info "Testing DNS resolution..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would test DNS resolution"
        return 0
    fi
    
    echo "=== DNS Configuration ==="
    if [[ -f "/etc/resolv.conf" ]]; then
        echo "DNS servers:"
        grep nameserver /etc/resolv.conf
    fi
    
    echo ""
    echo "=== DNS Resolution Tests ==="
    
    local test_domains=("google.com" "github.com" "localhost")
    
    for domain in "${test_domains[@]}"; do
        echo "Testing $domain:"
        
        # Test with nslookup
        if command -v nslookup >/dev/null 2>&1; then
            nslookup "$domain" 2>/dev/null | grep -E "Address:|Name:" || echo "  nslookup failed"
        fi
        
        # Test with dig if available
        if command -v dig >/dev/null 2>&1; then
            dig +short "$domain" 2>/dev/null || echo "  dig failed"
        fi
        
        # Test with host if available
        if command -v host >/dev/null 2>&1; then
            host "$domain" 2>/dev/null | head -2 || echo "  host failed"
        fi
        
        echo ""
    done
}

# Check routing and gateway
check_routing() {
    log_info "Checking routing configuration..."
    
    echo "=== Routing Table ==="
    ip route show
    
    echo ""
    echo "=== Default Gateway ==="
    local gateway
    gateway=$(ip route | grep default | awk '{print $3}' | head -1)
    
    if [[ -n "$gateway" ]]; then
        echo "Default gateway: $gateway"
        
        echo ""
        echo "=== Gateway Connectivity ==="
        if ping -c 3 -W 5 "$gateway" >/dev/null 2>&1; then
            log_success "Gateway $gateway is reachable"
        else
            log_error "Gateway $gateway is not reachable"
        fi
    else
        log_error "No default gateway found"
    fi
    
    echo ""
    echo "=== ARP Table ==="
    ip neigh show | head -10
}

# Analyze firewall rules
analyze_firewall() {
    log_info "Analyzing firewall configuration..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would analyze firewall rules"
        return 0
    fi
    
    echo "=== Firewall Status ==="
    
    # Check ufw status
    if command -v ufw >/dev/null 2>&1; then
        echo "UFW Status:"
        sudo ufw status verbose 2>/dev/null || echo "UFW status check failed"
        echo ""
    fi
    
    # Check iptables rules
    if command -v iptables >/dev/null 2>&1; then
        echo "IPTables Rules (INPUT):"
        sudo iptables -L INPUT -n --line-numbers 2>/dev/null | head -20 || echo "Cannot read iptables rules"
        echo ""
        
        echo "IPTables Rules (OUTPUT):"
        sudo iptables -L OUTPUT -n --line-numbers 2>/dev/null | head -10 || echo "Cannot read iptables rules"
        echo ""
    fi
    
    # Check for common firewall services
    echo "=== Firewall Services ==="
    systemctl is-active ufw 2>/dev/null && echo "UFW: active" || echo "UFW: inactive"
    systemctl is-active iptables 2>/dev/null && echo "IPTables: active" || echo "IPTables: inactive"
    systemctl is-active firewalld 2>/dev/null && echo "FirewallD: active" || echo "FirewallD: inactive"
}

# Show network processes
show_network_processes() {
    log_info "Showing network processes..."
    
    echo "=== Network Connections by Process ==="
    if command -v ss >/dev/null 2>&1; then
        ss -tulpn | head -20
    else
        netstat -tulpn | head -20
    fi
    
    echo ""
    echo "=== Top Network Processes ==="
    if command -v nethogs >/dev/null 2>&1; then
        log_info "Running nethogs for 10 seconds (requires sudo)..."
        timeout 10 sudo nethogs -d 1 2>/dev/null || log_warning "Nethogs failed or requires sudo"
    else
        log_warning "Nethogs not available - install with: sudo apt install nethogs"
        
        # Alternative: show processes with network connections
        echo "Processes with network connections:"
        lsof -i 2>/dev/null | head -20 || echo "lsof not available or no network connections"
    fi
}

# Monitor network traffic
monitor_network_traffic() {
    local interface=${INTERFACE:-$(ip route | grep default | awk '{print $5}' | head -1)}
    
    log_info "Monitoring network traffic on interface: $interface"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would monitor network traffic on $interface"
        return 0
    fi
    
    if [[ -z "$interface" ]]; then
        log_error "No network interface specified or detected"
        return 1
    fi
    
    echo "=== Network Interface Statistics ==="
    echo "Interface: $interface"
    
    # Show current statistics
    if [[ -f "/sys/class/net/$interface/statistics/rx_bytes" ]]; then
        local rx_bytes
        rx_bytes=$(cat "/sys/class/net/$interface/statistics/rx_bytes")
        local tx_bytes
        tx_bytes=$(cat "/sys/class/net/$interface/statistics/tx_bytes")
        
        echo "RX Bytes: $rx_bytes"
        echo "TX Bytes: $tx_bytes"
    fi
    
    echo ""
    echo "=== Real-time Traffic Monitoring ==="
    log_info "Monitoring for 30 seconds (Ctrl+C to stop)..."
    
    # Use tcpdump if available
    if command -v tcpdump >/dev/null 2>&1; then
        timeout 30 sudo tcpdump -i "$interface" -c 50 2>/dev/null || log_warning "tcpdump failed or requires sudo"
    else
        # Alternative: monitor /proc/net/dev
        log_info "Using /proc/net/dev for monitoring..."
        for i in {1..10}; do
            echo "Sample $i:"
            grep "$interface" /proc/net/dev
            sleep 3
        done
    fi
}

# Test network performance
test_network_performance() {
    local target=${TARGET_HOST:-"8.8.8.8"}
    
    log_info "Testing network performance to $target..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would test network performance to $target"
        return 0
    fi
    
    echo "=== Latency Test ==="
    ping -c 10 -i 0.2 "$target" 2>/dev/null | tail -1 || log_error "Ping test failed"
    
    echo ""
    echo "=== Bandwidth Test (HTTP) ==="
    if [[ "$target" =~ ^[a-zA-Z] ]]; then
        # Test download speed with curl
        local download_speed
        download_speed=$(curl -o /dev/null -s -w "%{speed_download}" --max-time 30 "http://$target" 2>/dev/null || echo "0")
        
        if [[ "$download_speed" != "0" ]]; then
            local speed_mbps
            speed_mbps=$(echo "scale=2; $download_speed / 1024 / 1024 * 8" | bc 2>/dev/null || echo "N/A")
            echo "Download speed: ${speed_mbps} Mbps"
        else
            echo "Download speed test failed"
        fi
    fi
    
    echo ""
    echo "=== Connection Quality ==="
    # Test packet loss
    local packet_loss
    packet_loss=$(ping -c 20 -i 0.2 "$target" 2>/dev/null | grep "packet loss" | awk '{print $6}' || echo "unknown")
    echo "Packet loss: $packet_loss"
    
    # Test jitter (if mtr is available)
    if command -v mtr >/dev/null 2>&1; then
        echo "Network path analysis:"
        mtr -r -c 5 "$target" 2>/dev/null | head -10 || echo "MTR analysis failed"
    fi
}

# Check development services
check_development_services() {
    log_info "Checking development services..."
    
    echo "=== Development Service Status ==="
    
    for service in "${!COMMON_PORTS[@]}"; do
        local ports="${COMMON_PORTS[$service]}"
        IFS=',' read -ra PORT_ARRAY <<< "$ports"
        
        echo "Checking $service:"
        
        for port in "${PORT_ARRAY[@]}"; do
            if timeout 5 bash -c "</dev/tcp/localhost/$port" 2>/dev/null; then
                echo "  Port $port: OPEN"
                
                # Try to get service information
                if command -v ss >/dev/null 2>&1; then
                    local process_info
                    process_info=$(ss -tulpn | grep ":$port " | awk '{print $7}' | head -1)
                    if [[ -n "$process_info" ]]; then
                        echo "    Process: $process_info"
                    fi
                fi
                
                # Test HTTP endpoints for web services
                if [[ "$service" =~ (react|nestjs|nginx|http) ]]; then
                    local http_status
                    http_status=$(curl -o /dev/null -s -w "%{http_code}" --connect-timeout 5 "http://localhost:$port" 2>/dev/null || echo "000")
                    echo "    HTTP Status: $http_status"
                fi
            else
                echo "  Port $port: CLOSED"
            fi
        done
        echo ""
    done
    
    echo "=== PM2 Process Status ==="
    if command -v pm2 >/dev/null 2>&1; then
        pm2 status 2>/dev/null || echo "PM2 not running or no processes"
    elif command -v npx >/dev/null 2>&1; then
        npx pm2 status 2>/dev/null || echo "PM2 not available"
    else
        echo "PM2 not found"
    fi
}

# Interactive troubleshooting
interactive_troubleshooting() {
    log_info "Starting interactive network troubleshooting..."
    
    echo "=== Network Troubleshooting Assistant ==="
    echo ""
    
    # Step 1: Basic connectivity
    echo "Step 1: Testing basic connectivity..."
    if ping -c 2 8.8.8.8 >/dev/null 2>&1; then
        log_success "Internet connectivity: OK"
    else
        log_error "Internet connectivity: FAILED"
        echo "Checking local network..."
        
        local gateway
        gateway=$(ip route | grep default | awk '{print $3}' | head -1)
        if [[ -n "$gateway" ]] && ping -c 2 "$gateway" >/dev/null 2>&1; then
            log_warning "Local network: OK, but internet access failed"
            echo "Possible issues: DNS, firewall, or ISP problems"
        else
            log_error "Local network: FAILED"
            echo "Check network cables, WiFi connection, or network configuration"
        fi
    fi
    
    echo ""
    
    # Step 2: DNS resolution
    echo "Step 2: Testing DNS resolution..."
    if nslookup google.com >/dev/null 2>&1; then
        log_success "DNS resolution: OK"
    else
        log_error "DNS resolution: FAILED"
        echo "Check /etc/resolv.conf or try alternative DNS servers"
    fi
    
    echo ""
    
    # Step 3: Development services
    echo "Step 3: Checking development services..."
    local services_running=0
    
    for service in "${!COMMON_PORTS[@]}"; do
        local ports="${COMMON_PORTS[$service]}"
        IFS=',' read -ra PORT_ARRAY <<< "$ports"
        
        for port in "${PORT_ARRAY[@]}"; do
            if timeout 2 bash -c "</dev/tcp/localhost/$port" 2>/dev/null; then
                echo "✓ $service (port $port) is running"
                ((services_running++))
            fi
        done
    done
    
    if [[ $services_running -eq 0 ]]; then
        log_warning "No development services detected"
        echo "Start your applications with PM2 or directly"
    else
        log_success "$services_running development services are running"
    fi
    
    echo ""
    echo "=== Troubleshooting Summary ==="
    echo "For more detailed analysis, run:"
    echo "  $0 --action diagnose"
    echo "  $0 --action services"
    echo "  $0 --action connectivity --target <hostname>"
}

# Full network diagnostics
full_diagnostics() {
    log_info "Running full network diagnostics..."
    
    local timestamp
    timestamp=$(date '+%Y-%m-%d_%H-%M-%S')
    local report_file="$REPORT_DIR/network_diagnostics_$timestamp.txt"
    
    {
        echo "=== Network Diagnostics Report ==="
        echo "Generated: $(date)"
        echo "Hostname: $(hostname)"
        echo "Architecture: $(uname -m)"
        echo ""
        
        get_network_interfaces
        echo ""
        
        test_connectivity
        echo ""
        
        scan_ports
        echo ""
        
        test_dns
        echo ""
        
        check_routing
        echo ""
        
        analyze_firewall
        echo ""
        
        show_network_processes
        echo ""
        
        check_development_services
        echo ""
        
    } | tee "$report_file"
    
    log_success "Full diagnostics report saved: $report_file"
}

# Execute action
execute_action() {
    case "$ACTION" in
        "diagnose")
            full_diagnostics
            ;;
        "connectivity")
            test_connectivity
            ;;
        "ports")
            scan_ports
            ;;
        "interfaces")
            get_network_interfaces
            ;;
        "dns")
            test_dns
            ;;
        "routing")
            check_routing
            ;;
        "firewall")
            analyze_firewall
            ;;
        "processes")
            show_network_processes
            ;;
        "monitor")
            monitor_network_traffic
            ;;
        "performance")
            test_network_performance
            ;;
        "services")
            check_development_services
            ;;
        "troubleshoot")
            interactive_troubleshooting
            ;;
        *)
            log_error "Unknown action: $ACTION"
            log_error "Valid actions: diagnose, connectivity, ports, interfaces, dns, routing, firewall, processes, monitor, performance, services, troubleshoot"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== Network Diagnostics Summary ==="
    log_info "Action: $ACTION"
    log_info "Target Host: ${TARGET_HOST:-"default"}"
    log_info "Target Port: ${TARGET_PORT:-"N/A"}"
    log_info "Interface: ${INTERFACE:-"auto-detect"}"
    log_info "Timeout: ${TIMEOUT}s"
    log_info "Report Directory: $REPORT_DIR"
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting network diagnostics..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Action: $ACTION"
    
    check_prerequisites
    execute_action
    
    log_success "Network diagnostics completed successfully!"
    display_summary
}

# Execute main function
main "$@"