#!/bin/bash
#
# Database Debugging and Analysis Script for PostgreSQL 17 on Raspberry Pi 5
# Comprehensive database diagnostics, query analysis, and performance troubleshooting
# Optimized for ARM64 architecture and PostgreSQL 17 features
#
# Usage: ./database_debug.sh [--dry-run] [--action ACTION] [--database DB]
# 
# Prerequisites:
# - PostgreSQL 17 server running
# - psql client installed and configured
# - Database connection credentials configured
# - pg_stat_statements extension (recommended)
#
# Features:
# - Connection testing and diagnostics
# - Query performance analysis
# - Lock detection and resolution
# - Index usage analysis
# - Database statistics and health checks
# - Slow query identification
# - Memory and resource usage analysis
# - ARM64-specific performance monitoring
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/database_debug.log"
DRY_RUN=false
ACTION="diagnose"
DB_HOST="localhost"
DB_PORT="5432"
DB_NAME="postgres"
DB_USER="postgres"
DB_PASSWORD=""
QUERY_TIMEOUT=30
REPORT_DIR="$HOME/development/logs/database_reports"
VERBOSE=false

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --action)
            ACTION="$2"
            shift 2
            ;;
        --host)
            DB_HOST="$2"
            shift 2
            ;;
        --port)
            DB_PORT="$2"
            shift 2
            ;;
        --database)
            DB_NAME="$2"
            shift 2
            ;;
        --user)
            DB_USER="$2"
            shift 2
            ;;
        --password)
            DB_PASSWORD="$2"
            shift 2
            ;;
        --timeout)
            QUERY_TIMEOUT="$2"
            shift 2
            ;;
        --verbose)
            VERBOSE=true
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--action ACTION] [--database DB]"
            echo "Database debugging and analysis for PostgreSQL 17"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --action ACTION        Action to perform (default: diagnose)"
            echo "  --host HOST            Database host (default: localhost)"
            echo "  --port PORT            Database port (default: 5432)"
            echo "  --database DB          Database name (default: postgres)"
            echo "  --user USER            Database user (default: postgres)"
            echo "  --password PASS        Database password (use PGPASSWORD env var instead)"
            echo "  --timeout SECONDS      Query timeout (default: 30)"
            echo "  --verbose              Enable verbose output"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Actions:"
            echo "  diagnose               Full database diagnostics"
            echo "  connection             Test database connection"
            echo "  performance            Analyze query performance"
            echo "  locks                  Check for locks and blocking queries"
            echo "  indexes                Analyze index usage and efficiency"
            echo "  statistics             Show database statistics"
            echo "  slow-queries           Identify slow running queries"
            echo "  connections            Analyze active connections"
            echo "  tables                 Analyze table statistics"
            echo "  vacuum                 Check vacuum and autovacuum status"
            echo "  replication            Check replication status"
            echo "  config                 Show important configuration settings"
            echo "  health                 Overall database health check"
            echo ""
            echo "Examples:"
            echo "  $0 --action diagnose"
            echo "  $0 --action performance --database myapp"
            echo "  $0 --action slow-queries --verbose"
            echo "  $0 --action locks"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create directories
mkdir -p "$(dirname "$LOG_FILE")" "$REPORT_DIR"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_debug() {
    if [[ "$VERBOSE" == "true" ]]; then
        echo "[DEBUG] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
    fi
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check PostgreSQL client
    if ! command -v psql >/dev/null 2>&1; then
        log_error "psql client is not installed"
        log_error "Install with: sudo apt install postgresql-client"
        exit 1
    fi
    
    local psql_version
    psql_version=$(psql --version | awk '{print $3}' | cut -d. -f1)
    log_info "PostgreSQL client version: $psql_version"
    
    # Check for required utilities
    local required_tools=("awk" "sed" "grep" "sort")
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" >/dev/null 2>&1; then
            log_error "Required tool not found: $tool"
            exit 1
        fi
    done
    
    log_info "Required tools available ✓"
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" == "aarch64" ]]; then
        log_info "ARM64 architecture detected ✓"
    else
        log_warning "Not running on ARM64 architecture: $(uname -m)"
    fi
    
    log_info "Prerequisites check completed"
}

# Execute PostgreSQL query with error handling
execute_query() {
    local query="$1"
    local description="${2:-"Query"}"
    
    log_debug "Executing: $description"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would execute: $description"
        return 0
    fi
    
    local psql_cmd="psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -t -c"
    
    # Set password if provided
    if [[ -n "$DB_PASSWORD" ]]; then
        export PGPASSWORD="$DB_PASSWORD"
    fi
    
    # Execute query with timeout
    if timeout "$QUERY_TIMEOUT" $psql_cmd "$query" 2>/dev/null; then
        return 0
    else
        log_error "$description failed"
        return 1
    fi
}

# Test database connection
test_connection() {
    log_info "Testing database connection..."
    
    echo "=== Connection Test ==="
    echo "Host: $DB_HOST"
    echo "Port: $DB_PORT"
    echo "Database: $DB_NAME"
    echo "User: $DB_USER"
    echo ""
    
    if execute_query "SELECT version();" "Connection test"; then
        log_success "Database connection successful"
        
        # Get PostgreSQL version
        local pg_version
        pg_version=$(execute_query "SELECT version();" "Version check" | head -1 | awk '{print $2}')
        echo "PostgreSQL Version: $pg_version"
        
        # Check if it's PostgreSQL 17
        if [[ "$pg_version" =~ ^17\. ]]; then
            log_success "PostgreSQL 17 detected ✓"
        else
            log_warning "PostgreSQL 17 recommended, found: $pg_version"
        fi
        
        # Get server uptime
        local uptime
        uptime=$(execute_query "SELECT date_trunc('second', now() - pg_postmaster_start_time()) as uptime;" "Uptime check" | tr -d ' ')
        echo "Server Uptime: $uptime"
        
    else
        log_error "Database connection failed"
        echo "Check connection parameters and ensure PostgreSQL is running"
        return 1
    fi
}

# Analyze query performance
analyze_performance() {
    log_info "Analyzing query performance..."
    
    echo "=== Query Performance Analysis ==="
    
    # Check if pg_stat_statements is available
    local has_pg_stat_statements
    has_pg_stat_statements=$(execute_query "SELECT count(*) FROM pg_extension WHERE extname = 'pg_stat_statements';" "Check pg_stat_statements" | tr -d ' ')
    
    if [[ "$has_pg_stat_statements" == "1" ]]; then
        log_success "pg_stat_statements extension available"
        
        echo ""
        echo "=== Top 10 Slowest Queries ==="
        execute_query "
            SELECT 
                round(total_exec_time::numeric, 2) as total_time_ms,
                calls,
                round(mean_exec_time::numeric, 2) as avg_time_ms,
                round((100 * total_exec_time / sum(total_exec_time) OVER())::numeric, 2) as percent_total,
                left(query, 80) as query_snippet
            FROM pg_stat_statements 
            ORDER BY total_exec_time DESC 
            LIMIT 10;
        " "Top slowest queries"
        
        echo ""
        echo "=== Most Frequently Called Queries ==="
        execute_query "
            SELECT 
                calls,
                round(total_exec_time::numeric, 2) as total_time_ms,
                round(mean_exec_time::numeric, 2) as avg_time_ms,
                left(query, 80) as query_snippet
            FROM pg_stat_statements 
            ORDER BY calls DESC 
            LIMIT 10;
        " "Most frequent queries"
        
    else
        log_warning "pg_stat_statements extension not available"
        log_info "Enable with: CREATE EXTENSION pg_stat_statements;"
    fi
    
    echo ""
    echo "=== Current Query Activity ==="
    execute_query "
        SELECT 
            pid,
            state,
            round(extract(epoch from (now() - query_start))::numeric, 2) as duration_seconds,
            left(query, 100) as current_query
        FROM pg_stat_activity 
        WHERE state != 'idle' 
        AND query != '<IDLE>'
        AND pid != pg_backend_pid()
        ORDER BY query_start;
    " "Current active queries"
}

# Check for locks and blocking queries
check_locks() {
    log_info "Checking for locks and blocking queries..."
    
    echo "=== Lock Analysis ==="
    
    # Check for blocking queries
    execute_query "
        SELECT 
            blocked_locks.pid AS blocked_pid,
            blocked_activity.usename AS blocked_user,
            blocking_locks.pid AS blocking_pid,
            blocking_activity.usename AS blocking_user,
            blocked_activity.query AS blocked_statement,
            blocking_activity.query AS blocking_statement,
            blocked_activity.application_name AS blocked_application,
            blocking_activity.application_name AS blocking_application
        FROM pg_catalog.pg_locks blocked_locks
        JOIN pg_catalog.pg_stat_activity blocked_activity ON blocked_activity.pid = blocked_locks.pid
        JOIN pg_catalog.pg_locks blocking_locks 
            ON blocking_locks.locktype = blocked_locks.locktype
            AND blocking_locks.database IS NOT DISTINCT FROM blocked_locks.database
            AND blocking_locks.relation IS NOT DISTINCT FROM blocked_locks.relation
            AND blocking_locks.page IS NOT DISTINCT FROM blocked_locks.page
            AND blocking_locks.tuple IS NOT DISTINCT FROM blocked_locks.tuple
            AND blocking_locks.virtualxid IS NOT DISTINCT FROM blocked_locks.virtualxid
            AND blocking_locks.transactionid IS NOT DISTINCT FROM blocked_locks.transactionid
            AND blocking_locks.classid IS NOT DISTINCT FROM blocked_locks.classid
            AND blocking_locks.objid IS NOT DISTINCT FROM blocked_locks.objid
            AND blocking_locks.objsubid IS NOT DISTINCT FROM blocked_locks.objsubid
            AND blocking_locks.pid != blocked_locks.pid
        JOIN pg_catalog.pg_stat_activity blocking_activity ON blocking_activity.pid = blocking_locks.pid
        WHERE NOT blocked_locks.granted;
    " "Blocking queries check"
    
    echo ""
    echo "=== Current Locks ==="
    execute_query "
        SELECT 
            locktype,
            database,
            relation::regclass,
            mode,
            granted,
            pid
        FROM pg_locks 
        WHERE NOT granted 
        ORDER BY pid;
    " "Current locks"
    
    echo ""
    echo "=== Long Running Transactions ==="
    execute_query "
        SELECT 
            pid,
            state,
            round(extract(epoch from (now() - xact_start))::numeric, 2) as transaction_duration_seconds,
            round(extract(epoch from (now() - query_start))::numeric, 2) as query_duration_seconds,
            left(query, 100) as current_query
        FROM pg_stat_activity 
        WHERE xact_start IS NOT NULL
        AND extract(epoch from (now() - xact_start)) > 60
        ORDER BY xact_start;
    " "Long running transactions"
}

# Analyze index usage
analyze_indexes() {
    log_info "Analyzing index usage and efficiency..."
    
    echo "=== Index Usage Analysis ==="
    
    # Unused indexes
    echo "=== Unused Indexes ==="
    execute_query "
        SELECT 
            schemaname,
            tablename,
            indexname,
            pg_size_pretty(pg_relation_size(indexrelid)) as size
        FROM pg_stat_user_indexes 
        WHERE idx_scan = 0
        AND schemaname NOT IN ('information_schema', 'pg_catalog')
        ORDER BY pg_relation_size(indexrelid) DESC;
    " "Unused indexes"
    
    echo ""
    echo "=== Index Efficiency ==="
    execute_query "
        SELECT 
            schemaname,
            tablename,
            indexname,
            idx_scan as index_scans,
            idx_tup_read as tuples_read,
            idx_tup_fetch as tuples_fetched,
            pg_size_pretty(pg_relation_size(indexrelid)) as size
        FROM pg_stat_user_indexes 
        WHERE schemaname NOT IN ('information_schema', 'pg_catalog')
        ORDER BY idx_scan DESC
        LIMIT 20;
    " "Index efficiency"
    
    echo ""
    echo "=== Missing Indexes (Tables with High Sequential Scans) ==="
    execute_query "
        SELECT 
            schemaname,
            tablename,
            seq_scan,
            seq_tup_read,
            idx_scan,
            seq_tup_read / seq_scan as avg_seq_read,
            pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as table_size
        FROM pg_stat_user_tables 
        WHERE seq_scan > 0
        AND schemaname NOT IN ('information_schema', 'pg_catalog')
        ORDER BY seq_tup_read DESC
        LIMIT 10;
    " "Sequential scan analysis"
}

# Show database statistics
show_statistics() {
    log_info "Showing database statistics..."
    
    echo "=== Database Statistics ==="
    
    # Database size and connections
    execute_query "
        SELECT 
            datname as database,
            pg_size_pretty(pg_database_size(datname)) as size,
            numbackends as connections
        FROM pg_stat_database 
        WHERE datname NOT IN ('template0', 'template1')
        ORDER BY pg_database_size(datname) DESC;
    " "Database sizes"
    
    echo ""
    echo "=== Cache Hit Ratio ==="
    execute_query "
        SELECT 
            datname as database,
            round((blks_hit * 100.0 / (blks_hit + blks_read))::numeric, 2) as cache_hit_ratio
        FROM pg_stat_database 
        WHERE blks_read > 0
        AND datname NOT IN ('template0', 'template1')
        ORDER BY cache_hit_ratio DESC;
    " "Cache hit ratios"
    
    echo ""
    echo "=== Transaction Statistics ==="
    execute_query "
        SELECT 
            datname as database,
            xact_commit as commits,
            xact_rollback as rollbacks,
            round((xact_commit * 100.0 / (xact_commit + xact_rollback))::numeric, 2) as commit_ratio
        FROM pg_stat_database 
        WHERE xact_commit + xact_rollback > 0
        AND datname NOT IN ('template0', 'template1')
        ORDER BY xact_commit DESC;
    " "Transaction statistics"
}

# Identify slow queries
identify_slow_queries() {
    log_info "Identifying slow running queries..."
    
    echo "=== Slow Query Analysis ==="
    
    # Current slow queries
    echo "=== Currently Running Slow Queries ==="
    execute_query "
        SELECT 
            pid,
            state,
            round(extract(epoch from (now() - query_start))::numeric, 2) as duration_seconds,
            left(query, 150) as query_snippet
        FROM pg_stat_activity 
        WHERE state = 'active'
        AND query_start < now() - interval '5 seconds'
        AND query != '<IDLE>'
        AND pid != pg_backend_pid()
        ORDER BY query_start;
    " "Current slow queries"
    
    # Log-based slow query analysis (if log_min_duration_statement is set)
    echo ""
    echo "=== Slow Query Configuration ==="
    execute_query "
        SELECT 
            name,
            setting,
            unit,
            context
        FROM pg_settings 
        WHERE name IN ('log_min_duration_statement', 'log_statement', 'log_duration')
        ORDER BY name;
    " "Slow query logging settings"
}

# Analyze active connections
analyze_connections() {
    log_info "Analyzing active connections..."
    
    echo "=== Connection Analysis ==="
    
    # Connection summary
    execute_query "
        SELECT 
            state,
            count(*) as connection_count
        FROM pg_stat_activity 
        GROUP BY state
        ORDER BY connection_count DESC;
    " "Connection states"
    
    echo ""
    echo "=== Connections by Database ==="
    execute_query "
        SELECT 
            datname as database,
            count(*) as connections,
            max(extract(epoch from (now() - backend_start))) as oldest_connection_seconds
        FROM pg_stat_activity 
        WHERE datname IS NOT NULL
        GROUP BY datname
        ORDER BY connections DESC;
    " "Connections by database"
    
    echo ""
    echo "=== Connection Limits ==="
    execute_query "
        SELECT 
            setting as max_connections,
            (SELECT count(*) FROM pg_stat_activity) as current_connections,
            round((SELECT count(*) FROM pg_stat_activity) * 100.0 / setting::int, 2) as usage_percent
        FROM pg_settings 
        WHERE name = 'max_connections';
    " "Connection usage"
}

# Analyze table statistics
analyze_tables() {
    log_info "Analyzing table statistics..."
    
    echo "=== Table Analysis ==="
    
    # Largest tables
    echo "=== Largest Tables ==="
    execute_query "
        SELECT 
            schemaname,
            tablename,
            pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as total_size,
            pg_size_pretty(pg_relation_size(schemaname||'.'||tablename)) as table_size,
            pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename) - pg_relation_size(schemaname||'.'||tablename)) as index_size
        FROM pg_stat_user_tables 
        ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC
        LIMIT 10;
    " "Largest tables"
    
    echo ""
    echo "=== Table Activity ==="
    execute_query "
        SELECT 
            schemaname,
            tablename,
            seq_scan,
            seq_tup_read,
            idx_scan,
            idx_tup_fetch,
            n_tup_ins as inserts,
            n_tup_upd as updates,
            n_tup_del as deletes
        FROM pg_stat_user_tables 
        ORDER BY (seq_tup_read + idx_tup_fetch) DESC
        LIMIT 10;
    " "Table activity"
}

# Check vacuum and autovacuum status
check_vacuum_status() {
    log_info "Checking vacuum and autovacuum status..."
    
    echo "=== Vacuum Status ==="
    
    # Autovacuum settings
    echo "=== Autovacuum Configuration ==="
    execute_query "
        SELECT 
            name,
            setting,
            unit
        FROM pg_settings 
        WHERE name LIKE '%autovacuum%'
        AND name IN ('autovacuum', 'autovacuum_max_workers', 'autovacuum_naptime', 'autovacuum_vacuum_threshold')
        ORDER BY name;
    " "Autovacuum settings"
    
    echo ""
    echo "=== Tables Needing Vacuum ==="
    execute_query "
        SELECT 
            schemaname,
            tablename,
            n_dead_tup as dead_tuples,
            n_live_tup as live_tuples,
            round((n_dead_tup * 100.0 / GREATEST(n_live_tup, 1))::numeric, 2) as dead_tuple_percent,
            last_vacuum,
            last_autovacuum
        FROM pg_stat_user_tables 
        WHERE n_dead_tup > 0
        ORDER BY dead_tuple_percent DESC
        LIMIT 10;
    " "Tables needing vacuum"
    
    echo ""
    echo "=== Recent Vacuum Activity ==="
    execute_query "
        SELECT 
            schemaname,
            tablename,
            last_vacuum,
            last_autovacuum,
            vacuum_count,
            autovacuum_count
        FROM pg_stat_user_tables 
        WHERE last_vacuum IS NOT NULL OR last_autovacuum IS NOT NULL
        ORDER BY GREATEST(last_vacuum, last_autovacuum) DESC NULLS LAST
        LIMIT 10;
    " "Recent vacuum activity"
}

# Check replication status
check_replication() {
    log_info "Checking replication status..."
    
    echo "=== Replication Status ==="
    
    # Check if this is a primary or standby
    execute_query "SELECT pg_is_in_recovery();" "Recovery status check"
    
    local is_standby
    is_standby=$(execute_query "SELECT pg_is_in_recovery();" "Recovery status" | tr -d ' ')
    
    if [[ "$is_standby" == "t" ]]; then
        echo "This is a standby server"
        
        # Standby status
        execute_query "
            SELECT 
                now() - pg_last_xact_replay_timestamp() as replication_lag
        " "Replication lag"
        
    else
        echo "This is a primary server"
        
        # Replication slots
        execute_query "
            SELECT 
                slot_name,
                slot_type,
                database,
                active,
                pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn)) as lag_size
            FROM pg_replication_slots;
        " "Replication slots"
        
        # WAL senders
        execute_query "
            SELECT 
                client_addr,
                state,
                sent_lsn,
                write_lsn,
                flush_lsn,
                replay_lsn,
                sync_state
            FROM pg_stat_replication;
        " "WAL senders"
    fi
}

# Show important configuration
show_config() {
    log_info "Showing important configuration settings..."
    
    echo "=== Important Configuration Settings ==="
    
    # Memory settings
    echo "=== Memory Settings ==="
    execute_query "
        SELECT 
            name,
            setting,
            unit,
            context
        FROM pg_settings 
        WHERE name IN (
            'shared_buffers',
            'effective_cache_size',
            'work_mem',
            'maintenance_work_mem',
            'max_connections'
        )
        ORDER BY name;
    " "Memory configuration"
    
    echo ""
    echo "=== Performance Settings ==="
    execute_query "
        SELECT 
            name,
            setting,
            unit,
            context
        FROM pg_settings 
        WHERE name IN (
            'random_page_cost',
            'seq_page_cost',
            'cpu_tuple_cost',
            'cpu_index_tuple_cost',
            'effective_io_concurrency'
        )
        ORDER BY name;
    " "Performance configuration"
    
    echo ""
    echo "=== WAL Settings ==="
    execute_query "
        SELECT 
            name,
            setting,
            unit,
            context
        FROM pg_settings 
        WHERE name IN (
            'wal_level',
            'max_wal_size',
            'min_wal_size',
            'checkpoint_completion_target',
            'wal_buffers'
        )
        ORDER BY name;
    " "WAL configuration"
}

# Overall database health check
health_check() {
    log_info "Performing overall database health check..."
    
    echo "=== Database Health Check ==="
    
    local health_score=100
    local issues=()
    
    # Check connection
    if ! execute_query "SELECT 1;" "Health check connection" >/dev/null 2>&1; then
        issues+=("Database connection failed")
        health_score=$((health_score - 50))
    fi
    
    # Check for blocking queries
    local blocking_queries
    blocking_queries=$(execute_query "SELECT count(*) FROM pg_locks WHERE NOT granted;" "Blocking queries count" | tr -d ' ')
    if [[ "$blocking_queries" -gt 0 ]]; then
        issues+=("$blocking_queries blocking queries detected")
        health_score=$((health_score - 10))
    fi
    
    # Check connection usage
    local connection_usage
    connection_usage=$(execute_query "
        SELECT round((SELECT count(*) FROM pg_stat_activity) * 100.0 / 
               (SELECT setting::int FROM pg_settings WHERE name = 'max_connections'), 2);
    " "Connection usage" | tr -d ' ')
    
    if (( $(echo "$connection_usage > 80" | bc -l) )); then
        issues+=("High connection usage: ${connection_usage}%")
        health_score=$((health_score - 15))
    fi
    
    # Check for long running queries
    local long_queries
    long_queries=$(execute_query "
        SELECT count(*) FROM pg_stat_activity 
        WHERE state = 'active' 
        AND query_start < now() - interval '5 minutes'
        AND pid != pg_backend_pid();
    " "Long running queries count" | tr -d ' ')
    
    if [[ "$long_queries" -gt 0 ]]; then
        issues+=("$long_queries long-running queries detected")
        health_score=$((health_score - 10))
    fi
    
    # Display health summary
    echo "Health Score: $health_score/100"
    
    if [[ ${#issues[@]} -eq 0 ]]; then
        log_success "Database health check passed - no issues detected"
    else
        log_warning "Database health issues detected:"
        for issue in "${issues[@]}"; do
            echo "  - $issue"
        done
    fi
    
    # Recommendations
    echo ""
    echo "=== Recommendations ==="
    if [[ "$health_score" -lt 70 ]]; then
        echo "- Immediate attention required"
        echo "- Check blocking queries and long-running transactions"
        echo "- Monitor connection usage"
    elif [[ "$health_score" -lt 90 ]]; then
        echo "- Minor issues detected"
        echo "- Consider performance tuning"
        echo "- Monitor resource usage"
    else
        echo "- Database is healthy"
        echo "- Continue regular monitoring"
    fi
}

# Full database diagnostics
full_diagnostics() {
    log_info "Running full database diagnostics..."
    
    local timestamp
    timestamp=$(date '+%Y-%m-%d_%H-%M-%S')
    local report_file="$REPORT_DIR/database_diagnostics_$timestamp.txt"
    
    {
        echo "=== Database Diagnostics Report ==="
        echo "Generated: $(date)"
        echo "Hostname: $(hostname)"
        echo "Database: $DB_NAME@$DB_HOST:$DB_PORT"
        echo ""
        
        test_connection
        echo ""
        
        analyze_performance
        echo ""
        
        check_locks
        echo ""
        
        analyze_indexes
        echo ""
        
        show_statistics
        echo ""
        
        analyze_connections
        echo ""
        
        analyze_tables
        echo ""
        
        check_vacuum_status
        echo ""
        
        show_config
        echo ""
        
        health_check
        echo ""
        
    } | tee "$report_file"
    
    log_success "Full diagnostics report saved: $report_file"
}

# Execute action
execute_action() {
    case "$ACTION" in
        "diagnose")
            full_diagnostics
            ;;
        "connection")
            test_connection
            ;;
        "performance")
            analyze_performance
            ;;
        "locks")
            check_locks
            ;;
        "indexes")
            analyze_indexes
            ;;
        "statistics")
            show_statistics
            ;;
        "slow-queries")
            identify_slow_queries
            ;;
        "connections")
            analyze_connections
            ;;
        "tables")
            analyze_tables
            ;;
        "vacuum")
            check_vacuum_status
            ;;
        "replication")
            check_replication
            ;;
        "config")
            show_config
            ;;
        "health")
            health_check
            ;;
        *)
            log_error "Unknown action: $ACTION"
            log_error "Valid actions: diagnose, connection, performance, locks, indexes, statistics, slow-queries, connections, tables, vacuum, replication, config, health"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== Database Debug Summary ==="
    log_info "Action: $ACTION"
    log_info "Database: $DB_NAME@$DB_HOST:$DB_PORT"
    log_info "User: $DB_USER"
    log_info "Query Timeout: ${QUERY_TIMEOUT}s"
    log_info "Report Directory: $REPORT_DIR"
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting database debugging..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Action: $ACTION"
    
    check_prerequisites
    execute_action
    
    log_success "Database debugging completed successfully!"
    display_summary
}

# Execute main function
main "$@"