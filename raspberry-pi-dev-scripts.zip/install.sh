#!/bin/bash
#
# Master Installation Script for Raspberry Pi 5 Development Environment
# Orchestrates setup of React 19.1.0, NestJS 11.1.3, PostgreSQL 17, and monitoring tools
# Optimized for ARM64 architecture with comprehensive dependency resolution
#
# Usage: ./install.sh [--dry-run] [--mode MODE] [--skip-component COMPONENT]
# 
# Prerequisites:
# - Raspberry Pi 5 with Raspberry Pi OS Bookworm (64-bit)
# - Internet connection for package downloads
# - Sudo privileges for system configuration
# - At least 4GB RAM (8GB recommended)
#
# Features:
# - Automated dependency resolution and prerequisite checking
# - Modular installation with component selection
# - Progress tracking and error recovery
# - Interactive configuration options
# - Comprehensive logging and reporting
# - ARM64 optimization and validation
# - Integration with all development workflow scripts
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="$HOME/development/logs/master_install.log"
DRY_RUN=false
INSTALL_MODE="full"
INTERACTIVE=true
SKIP_COMPONENTS=()
FORCE_REINSTALL=false

# Installation components
declare -A COMPONENTS=(
    ["system"]="System optimization and security hardening"
    ["environment"]="Node.js, TypeScript, and development environment"
    ["database"]="PostgreSQL 17 installation and configuration"
    ["projects"]="Project initialization and build tools"
    ["workflow"]="Development workflow and process management"
    ["deployment"]="Production deployment and optimization"
    ["monitoring"]="System and application monitoring"
    ["debugging"]="Debugging and troubleshooting tools"
)

# Component dependencies
declare -A DEPENDENCIES=(
    ["environment"]="system"
    ["database"]="system"
    ["projects"]="environment"
    ["workflow"]="environment projects"
    ["deployment"]="environment projects database"
    ["monitoring"]="system environment"
    ["debugging"]="system environment database"
)

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --mode)
            INSTALL_MODE="$2"
            shift 2
            ;;
        --skip)
            IFS=',' read -ra SKIP_ARRAY <<< "$2"
            SKIP_COMPONENTS+=("${SKIP_ARRAY[@]}")
            shift 2
            ;;
        --non-interactive)
            INTERACTIVE=false
            shift
            ;;
        --force)
            FORCE_REINSTALL=true
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--mode MODE] [--skip COMPONENT]"
            echo "Master installation script for Raspberry Pi 5 development environment"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --mode MODE            Installation mode: full, minimal, development, production"
            echo "  --skip COMPONENT       Skip components (comma-separated): system,environment,database,etc."
            echo "  --non-interactive      Run without user prompts"
            echo "  --force                Force reinstallation of existing components"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Installation Modes:"
            echo "  full                   Complete installation (all components)"
            echo "  minimal                Basic system setup and environment"
            echo "  development            Development tools and workflow"
            echo "  production             Production-ready deployment setup"
            echo ""
            echo "Components:"
            for component in "${!COMPONENTS[@]}"; do
                echo "  $component: ${COMPONENTS[$component]}"
            done
            echo ""
            echo "Examples:"
            echo "  $0                                    # Full interactive installation"
            echo "  $0 --mode development                 # Development setup only"
            echo "  $0 --skip database --non-interactive  # Skip database, no prompts"
            echo "  $0 --dry-run                         # Preview installation steps"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_step() {
    echo ""
    echo "=== $* ===" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Installation failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
        log_info "You can resume installation by running this script again"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Progress tracking
show_progress() {
    local current=$1
    local total=$2
    local component=$3
    
    local percent=$((current * 100 / total))
    local bar_length=50
    local filled_length=$((percent * bar_length / 100))
    
    printf "\r["
    printf "%*s" $filled_length | tr ' ' '='
    printf "%*s" $((bar_length - filled_length)) | tr ' ' '-'
    printf "] %d%% - %s" $percent "$component"
    
    if [[ $current -eq $total ]]; then
        echo ""
    fi
}

# System validation
validate_system() {
    log_step "System Validation"
    
    # Check Raspberry Pi 5
    if [[ -f "/proc/device-tree/model" ]]; then
        local pi_model
        pi_model=$(cat /proc/device-tree/model 2>/dev/null | tr -d '\0')
        if [[ "$pi_model" == *"Raspberry Pi 5"* ]]; then
            log_success "Raspberry Pi 5 detected: $pi_model"
        else
            log_warning "Not running on Raspberry Pi 5: $pi_model"
            if [[ "$INTERACTIVE" == "true" ]]; then
                read -p "Continue anyway? (y/N): " -n 1 -r
                echo
                if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                    exit 1
                fi
            fi
        fi
    else
        log_warning "Cannot detect Raspberry Pi model"
    fi
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" == "aarch64" ]]; then
        log_success "ARM64 architecture confirmed"
    else
        log_error "ARM64 architecture required, found: $(uname -m)"
        exit 1
    fi
    
    # Check OS version
    if [[ -f "/etc/os-release" ]]; then
        local os_info
        os_info=$(grep PRETTY_NAME /etc/os-release | cut -d'"' -f2)
        log_info "Operating System: $os_info"
        
        if [[ "$os_info" == *"Bookworm"* ]]; then
            log_success "Raspberry Pi OS Bookworm detected"
        else
            log_warning "Raspberry Pi OS Bookworm recommended"
        fi
    fi
    
    # Check available memory
    local total_memory
    total_memory=$(free -m | awk 'NR==2{print $2}')
    if [[ $total_memory -ge 7000 ]]; then
        log_success "Memory: ${total_memory}MB (8GB model recommended)"
    elif [[ $total_memory -ge 3000 ]]; then
        log_info "Memory: ${total_memory}MB (sufficient for development)"
    else
        log_warning "Memory: ${total_memory}MB (may be insufficient for full development stack)"
    fi
    
    # Check available disk space
    local available_space
    available_space=$(df / | awk 'NR==2{print $4}')
    local available_gb=$((available_space / 1024 / 1024))
    if [[ $available_gb -ge 10 ]]; then
        log_success "Available disk space: ${available_gb}GB"
    else
        log_warning "Available disk space: ${available_gb}GB (may be insufficient)"
    fi
    
    # Check internet connectivity
    if ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        log_success "Internet connectivity confirmed"
    else
        log_error "Internet connectivity required for installation"
        exit 1
    fi
    
    # Check sudo privileges
    if sudo -n true 2>/dev/null; then
        log_success "Sudo privileges confirmed"
    else
        log_info "Sudo privileges required - you may be prompted for password"
    fi
}

# Component selection based on mode
select_components() {
    log_step "Component Selection"
    
    local selected_components=()
    
    case "$INSTALL_MODE" in
        "minimal")
            selected_components=("system" "environment")
            ;;
        "development")
            selected_components=("system" "environment" "database" "projects" "workflow" "monitoring" "debugging")
            ;;
        "production")
            selected_components=("system" "environment" "database" "projects" "deployment" "monitoring")
            ;;
        "full")
            selected_components=("${!COMPONENTS[@]}")
            ;;
        *)
            log_error "Unknown installation mode: $INSTALL_MODE"
            exit 1
            ;;
    esac
    
    # Remove skipped components
    for skip in "${SKIP_COMPONENTS[@]}"; do
        selected_components=("${selected_components[@]/$skip}")
    done
    
    # Clean up array (remove empty elements)
    local cleaned_components=()
    for component in "${selected_components[@]}"; do
        if [[ -n "$component" ]]; then
            cleaned_components+=("$component")
        fi
    done
    
    log_info "Selected installation mode: $INSTALL_MODE"
    log_info "Components to install:"
    for component in "${cleaned_components[@]}"; do
        log_info "  - $component: ${COMPONENTS[$component]}"
    done
    
    if [[ "$INTERACTIVE" == "true" ]]; then
        echo ""
        read -p "Proceed with installation? (Y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Nn]$ ]]; then
            log_info "Installation cancelled by user"
            exit 0
        fi
    fi
    
    echo "${cleaned_components[@]}"
}

# Resolve component dependencies
resolve_dependencies() {
    local components=("$@")
    local resolved=()
    local visited=()
    
    resolve_component() {
        local component=$1
        
        # Check if already visited (circular dependency detection)
        for v in "${visited[@]}"; do
            if [[ "$v" == "$component" ]]; then
                log_error "Circular dependency detected: $component"
                exit 1
            fi
        done
        
        visited+=("$component")
        
        # Resolve dependencies first
        if [[ -n "${DEPENDENCIES[$component]:-}" ]]; then
            local deps
            read -ra deps <<< "${DEPENDENCIES[$component]}"
            for dep in "${deps[@]}"; do
                resolve_component "$dep"
            done
        fi
        
        # Add component if not already resolved
        local already_resolved=false
        for r in "${resolved[@]}"; do
            if [[ "$r" == "$component" ]]; then
                already_resolved=true
                break
            fi
        done
        
        if [[ "$already_resolved" == "false" ]]; then
            resolved+=("$component")
        fi
        
        # Remove from visited
        visited=("${visited[@]/$component}")
    }
    
    for component in "${components[@]}"; do
        resolve_component "$component"
    done
    
    echo "${resolved[@]}"
}

# Execute component installation
install_component() {
    local component=$1
    local script_path=""
    
    log_step "Installing Component: $component"
    
    case "$component" in
        "system")
            # System scripts
            if [[ -f "$SCRIPT_DIR/system/pi5_os_optimization.sh" ]]; then
                log_info "Running OS optimization..."
                if [[ "$DRY_RUN" == "true" ]]; then
                    log_info "[DRY RUN] Would run: $SCRIPT_DIR/system/pi5_os_optimization.sh"
                else
                    bash "$SCRIPT_DIR/system/pi5_os_optimization.sh" --non-interactive
                fi
            fi
            
            if [[ -f "$SCRIPT_DIR/system/ssh_hardening.sh" ]]; then
                log_info "Running SSH hardening..."
                if [[ "$DRY_RUN" == "true" ]]; then
                    log_info "[DRY RUN] Would run: $SCRIPT_DIR/system/ssh_hardening.sh"
                else
                    bash "$SCRIPT_DIR/system/ssh_hardening.sh" --non-interactive
                fi
            fi
            
            if [[ -f "$SCRIPT_DIR/system/nvme_setup.sh" ]]; then
                log_info "Setting up NVMe storage..."
                if [[ "$DRY_RUN" == "true" ]]; then
                    log_info "[DRY RUN] Would run: $SCRIPT_DIR/system/nvme_setup.sh"
                else
                    bash "$SCRIPT_DIR/system/nvme_setup.sh" --auto-detect
                fi
            fi
            ;;
            
        "environment")
            # Environment scripts
            if [[ -f "$SCRIPT_DIR/environment/nodejs_nvm_setup.sh" ]]; then
                log_info "Setting up Node.js environment..."
                if [[ "$DRY_RUN" == "true" ]]; then
                    log_info "[DRY RUN] Would run: $SCRIPT_DIR/environment/nodejs_nvm_setup.sh"
                else
                    bash "$SCRIPT_DIR/environment/nodejs_nvm_setup.sh" --version 20
                fi
            fi
            
            if [[ -f "$SCRIPT_DIR/environment/typescript_setup.sh" ]]; then
                log_info "Setting up TypeScript..."
                if [[ "$DRY_RUN" == "true" ]]; then
                    log_info "[DRY RUN] Would run: $SCRIPT_DIR/environment/typescript_setup.sh"
                else
                    bash "$SCRIPT_DIR/environment/typescript_setup.sh"
                fi
            fi
            
            if [[ -f "$SCRIPT_DIR/system/vscode_server_install.sh" ]]; then
                log_info "Setting up VS Code Server..."
                if [[ "$DRY_RUN" == "true" ]]; then
                    log_info "[DRY RUN] Would run: $SCRIPT_DIR/system/vscode_server_install.sh"
                else
                    bash "$SCRIPT_DIR/system/vscode_server_install.sh"
                fi
            fi
            ;;
            
        "database")
            # Database scripts
            if [[ -f "$SCRIPT_DIR/database/postgresql_install.sh" ]]; then
                log_info "Installing PostgreSQL 17..."
                if [[ "$DRY_RUN" == "true" ]]; then
                    log_info "[DRY RUN] Would run: $SCRIPT_DIR/database/postgresql_install.sh"
                else
                    bash "$SCRIPT_DIR/database/postgresql_install.sh" --version 17
                fi
            fi
            ;;
            
        "projects")
            # Project management scripts
            if [[ -f "$SCRIPT_DIR/project/dependency_manager.sh" ]]; then
                log_info "Setting up dependency management..."
                if [[ "$DRY_RUN" == "true" ]]; then
                    log_info "[DRY RUN] Would run: $SCRIPT_DIR/project/dependency_manager.sh"
                else
                    bash "$SCRIPT_DIR/project/dependency_manager.sh" --action setup
                fi
            fi
            ;;
            
        "workflow")
            # Workflow scripts
            if [[ -f "$SCRIPT_DIR/workflow/pm2_manager.sh" ]]; then
                log_info "Setting up PM2 process management..."
                if [[ "$DRY_RUN" == "true" ]]; then
                    log_info "[DRY RUN] Would run: $SCRIPT_DIR/workflow/pm2_manager.sh"
                else
                    bash "$SCRIPT_DIR/workflow/pm2_manager.sh" --action setup
                fi
            fi
            ;;
            
        "deployment")
            # Deployment scripts
            if [[ -f "$SCRIPT_DIR/deployment/production_optimizer.sh" ]]; then
                log_info "Setting up production optimization..."
                if [[ "$DRY_RUN" == "true" ]]; then
                    log_info "[DRY RUN] Would run: $SCRIPT_DIR/deployment/production_optimizer.sh"
                else
                    bash "$SCRIPT_DIR/deployment/production_optimizer.sh" --action setup
                fi
            fi
            ;;
            
        "monitoring")
            # Monitoring scripts setup
            log_info "Setting up monitoring tools..."
            if [[ "$DRY_RUN" == "true" ]]; then
                log_info "[DRY RUN] Would install monitoring dependencies"
            else
                # Install monitoring dependencies
                sudo apt update
                sudo apt install -y htop iotop nethogs smartmontools jq bc
                
                # Make monitoring scripts executable
                if [[ -f "$SCRIPT_DIR/monitoring/system_monitor.sh" ]]; then
                    chmod +x "$SCRIPT_DIR/monitoring/system_monitor.sh"
                fi
                if [[ -f "$SCRIPT_DIR/monitoring/app_performance_monitor.sh" ]]; then
                    chmod +x "$SCRIPT_DIR/monitoring/app_performance_monitor.sh"
                fi
            fi
            ;;
            
        "debugging")
            # Debugging tools setup
            log_info "Setting up debugging tools..."
            if [[ "$DRY_RUN" == "true" ]]; then
                log_info "[DRY RUN] Would install debugging dependencies"
            else
                # Install debugging dependencies
                sudo apt update
                sudo apt install -y gdb strace perf-tools-unstable nmap traceroute mtr-tiny lsof
                
                # Make debugging scripts executable
                if [[ -f "$SCRIPT_DIR/debugging/network_diagnostics.sh" ]]; then
                    chmod +x "$SCRIPT_DIR/debugging/network_diagnostics.sh"
                fi
                if [[ -f "$SCRIPT_DIR/debugging/database_debug.sh" ]]; then
                    chmod +x "$SCRIPT_DIR/debugging/database_debug.sh"
                fi
            fi
            ;;
            
        *)
            log_warning "Unknown component: $component"
            return 1
            ;;
    esac
    
    log_success "Component '$component' installed successfully"
}

# Post-installation configuration
post_install_config() {
    log_step "Post-Installation Configuration"
    
    # Create development directory structure
    log_info "Creating development directory structure..."
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create development directories"
    else
        mkdir -p "$HOME/development/"{projects,logs,backups,scripts}
        mkdir -p "$HOME/development/logs/"{system_reports,performance_reports,network_reports,database_reports,health_reports}
    fi
    
    # Set up environment variables
    log_info "Configuring environment variables..."
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure environment variables"
    else
        # Add development paths to bashrc if not already present
        local bashrc_additions=""
        
        if ! grep -q "# Development Environment Setup" "$HOME/.bashrc" 2>/dev/null; then
            bashrc_additions="
# Development Environment Setup
export DEVELOPMENT_HOME=\"\$HOME/development\"
export PATH=\"\$DEVELOPMENT_HOME/scripts:\$PATH\"

# Node.js and NVM
export NVM_DIR=\"\$HOME/.nvm\"
[ -s \"\$NVM_DIR/nvm.sh\" ] && \. \"\$NVM_DIR/nvm.sh\"
[ -s \"\$NVM_DIR/bash_completion\" ] && \. \"\$NVM_DIR/bash_completion\"

# PostgreSQL
export PGDATA=\"/var/lib/postgresql/17/main\"

# Development aliases
alias dev-monitor='$SCRIPT_DIR/monitoring/system_monitor.sh --action monitor'
alias dev-logs='$SCRIPT_DIR/workflow/log_monitor.sh --action monitor'
alias dev-health='$SCRIPT_DIR/deployment/health_checker.sh'
alias dev-debug-net='$SCRIPT_DIR/debugging/network_diagnostics.sh --action diagnose'
alias dev-debug-db='$SCRIPT_DIR/debugging/database_debug.sh --action diagnose'
"
            echo "$bashrc_additions" >> "$HOME/.bashrc"
            log_success "Environment variables configured"
        else
            log_info "Environment variables already configured"
        fi
    fi
    
    # Make all scripts executable
    log_info "Setting script permissions..."
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would set script permissions"
    else
        find "$SCRIPT_DIR" -name "*.sh" -type f -exec chmod +x {} \;
        log_success "Script permissions set"
    fi
    
    # Create systemd service for monitoring (optional)
    if [[ "$INTERACTIVE" == "true" ]]; then
        read -p "Create systemd service for system monitoring? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            log_info "Creating systemd monitoring service..."
            if [[ "$DRY_RUN" == "true" ]]; then
                log_info "[DRY RUN] Would create systemd service"
            else
                sudo tee /etc/systemd/system/dev-monitor.service > /dev/null << EOF
[Unit]
Description=Development Environment Monitor
After=network.target

[Service]
Type=simple
User=$USER
ExecStart=$SCRIPT_DIR/monitoring/system_monitor.sh --action monitor --continuous --interval 60
Restart=always
RestartSec=30

[Install]
WantedBy=multi-user.target
EOF
                sudo systemctl daemon-reload
                sudo systemctl enable dev-monitor.service
                log_success "Systemd monitoring service created"
            fi
        fi
    fi
}

# Installation verification
verify_installation() {
    log_step "Installation Verification"
    
    local verification_passed=true
    
    # Check Node.js
    if command -v node >/dev/null 2>&1; then
        local node_version
        node_version=$(node --version)
        log_success "Node.js installed: $node_version"
    else
        log_error "Node.js not found"
        verification_passed=false
    fi
    
    # Check PostgreSQL
    if command -v psql >/dev/null 2>&1; then
        local pg_version
        pg_version=$(psql --version | awk '{print $3}')
        log_success "PostgreSQL client installed: $pg_version"
    else
        log_warning "PostgreSQL client not found"
    fi
    
    # Check PM2
    if command -v pm2 >/dev/null 2>&1 || command -v npx >/dev/null 2>&1; then
        log_success "PM2 process manager available"
    else
        log_warning "PM2 not found"
    fi
    
    # Check monitoring tools
    local monitoring_tools=("htop" "iotop" "nethogs")
    for tool in "${monitoring_tools[@]}"; do
        if command -v "$tool" >/dev/null 2>&1; then
            log_success "Monitoring tool available: $tool"
        else
            log_warning "Monitoring tool not found: $tool"
        fi
    done
    
    # Check debugging tools
    local debugging_tools=("gdb" "strace" "nmap")
    for tool in "${debugging_tools[@]}"; do
        if command -v "$tool" >/dev/null 2>&1; then
            log_success "Debugging tool available: $tool"
        else
            log_warning "Debugging tool not found: $tool"
        fi
    done
    
    # Test script accessibility
    local key_scripts=(
        "monitoring/system_monitor.sh"
        "monitoring/app_performance_monitor.sh"
        "debugging/network_diagnostics.sh"
        "debugging/database_debug.sh"
    )
    
    for script in "${key_scripts[@]}"; do
        if [[ -x "$SCRIPT_DIR/$script" ]]; then
            log_success "Script accessible: $script"
        else
            log_warning "Script not accessible: $script"
        fi
    done
    
    if [[ "$verification_passed" == "true" ]]; then
        log_success "Installation verification completed successfully"
    else
        log_warning "Installation verification completed with warnings"
    fi
}

# Generate installation report
generate_report() {
    log_step "Generating Installation Report"
    
    local timestamp
    timestamp=$(date '+%Y-%m-%d_%H-%M-%S')
    local report_file="$HOME/development/logs/installation_report_$timestamp.txt"
    
    {
        echo "=== Raspberry Pi 5 Development Environment Installation Report ==="
        echo "Generated: $(date)"
        echo "Hostname: $(hostname)"
        echo "Architecture: $(uname -m)"
        echo "Installation Mode: $INSTALL_MODE"
        echo "Dry Run: $DRY_RUN"
        echo ""
        
        echo "=== System Information ==="
        if [[ -f "/proc/device-tree/model" ]]; then
            echo "Device: $(cat /proc/device-tree/model | tr -d '\0')"
        fi
        echo "OS: $(grep PRETTY_NAME /etc/os-release | cut -d'"' -f2)"
        echo "Kernel: $(uname -r)"
        echo "Memory: $(free -h | awk 'NR==2{print $2}')"
        echo "Disk Space: $(df -h / | awk 'NR==2{print $4}') available"
        echo ""
        
        echo "=== Installed Components ==="
        echo "Node.js: $(command -v node >/dev/null 2>&1 && node --version || echo 'Not installed')"
        echo "npm: $(command -v npm >/dev/null 2>&1 && npm --version || echo 'Not installed')"
        echo "PostgreSQL: $(command -v psql >/dev/null 2>&1 && psql --version | awk '{print $3}' || echo 'Not installed')"
        echo "PM2: $(command -v pm2 >/dev/null 2>&1 && pm2 --version || echo 'Not installed')"
        echo ""
        
        echo "=== Available Scripts ==="
        find "$SCRIPT_DIR" -name "*.sh" -type f | sort
        echo ""
        
        echo "=== Quick Start Commands ==="
        echo "System monitoring: $SCRIPT_DIR/monitoring/system_monitor.sh --action monitor"
        echo "App performance: $SCRIPT_DIR/monitoring/app_performance_monitor.sh --action monitor"
        echo "Network diagnostics: $SCRIPT_DIR/debugging/network_diagnostics.sh --action diagnose"
        echo "Database debugging: $SCRIPT_DIR/debugging/database_debug.sh --action diagnose"
        echo "Health check: $SCRIPT_DIR/deployment/health_checker.sh"
        echo ""
        
        echo "=== Next Steps ==="
        echo "1. Source your bashrc: source ~/.bashrc"
        echo "2. Create your first project: $SCRIPT_DIR/project/init_react_project.sh or $SCRIPT_DIR/project/init_nestjs_project.sh"
        echo "3. Start monitoring: dev-monitor"
        echo "4. Check system health: dev-health"
        echo ""
        
        echo "=== Documentation ==="
        echo "Log files: $HOME/development/logs/"
        echo "Installation log: $LOG_FILE"
        echo "Report location: $report_file"
        
    } | tee "$report_file"
    
    log_success "Installation report generated: $report_file"
}

# Main installation function
main() {
    log_info "Starting Raspberry Pi 5 Development Environment Installation"
    log_info "Script: $SCRIPT_NAME"
    log_info "Mode: $INSTALL_MODE"
    log_info "Dry run: $DRY_RUN"
    log_info "Interactive: $INTERACTIVE"
    
    # System validation
    validate_system
    
    # Component selection
    local components
    read -ra components <<< "$(select_components)"
    
    # Dependency resolution
    local resolved_components
    read -ra resolved_components <<< "$(resolve_dependencies "${components[@]}")"
    
    log_info "Installation order: ${resolved_components[*]}"
    
    # Install components
    local total_components=${#resolved_components[@]}
    local current_component=0
    
    for component in "${resolved_components[@]}"; do
        ((current_component++))
        show_progress $current_component $total_components "$component"
        install_component "$component"
    done
    
    # Post-installation configuration
    post_install_config
    
    # Verification
    verify_installation
    
    # Generate report
    generate_report
    
    log_success "Installation completed successfully!"
    
    if [[ "$DRY_RUN" == "false" ]]; then
        echo ""
        echo "=== Installation Complete ==="
        echo "Your Raspberry Pi 5 development environment is ready!"
        echo ""
        echo "To get started:"
        echo "1. Reload your shell: source ~/.bashrc"
        echo "2. Check system status: dev-monitor"
        echo "3. View installation report: cat $HOME/development/logs/installation_report_*.txt"
        echo ""
        echo "Happy coding! 🚀"
    fi
}

# Execute main function
main "$@"