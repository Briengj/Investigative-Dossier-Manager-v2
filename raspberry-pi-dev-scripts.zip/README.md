# Raspberry Pi 5 Development Environment Scripts

A comprehensive collection of bash scripts to streamline development workflow for React 19.1.0, NestJS 11.1.3, and PostgreSQL 17 stack on Raspberry Pi 5 with ARM64 architecture.

## 🚀 Quick Start

```bash
# Clone or download the scripts
git clone <repository-url> development-scripts
cd development-scripts

# Run the master installation script
./install.sh

# Or for a specific installation mode
./install.sh --mode development
```

## 📋 Prerequisites

- **Hardware**: Raspberry Pi 5 (4GB RAM minimum, 8GB recommended)
- **OS**: Raspberry Pi OS Bookworm (64-bit) with Kernel 6.12+
- **Storage**: NVMe SSD recommended for optimal performance
- **Network**: Internet connection for package downloads
- **Permissions**: Sudo access for system configuration

## 🏗️ Project Structure

```
development-scripts/
├── docs/                        # Comprehensive documentation
├── system/                      # System setup and configuration scripts
│   ├── pi5_os_optimization.sh   # OS optimization for Pi 5
│   ├── nvme_setup.sh           # NVMe storage configuration
│   ├── ssh_hardening.sh        # SSH security hardening
│   └── vscode_server_install.sh # VS Code Server setup
├── environment/                 # Development environment scripts
│   ├── nodejs_nvm_setup.sh     # Node.js 20 LTS via NVM
│   ├── npm_optimization.sh     # NPM performance tuning
│   └── typescript_setup.sh     # TypeScript 5.8+ configuration
├── database/                    # Database management utilities
│   ├── postgresql_install.sh   # PostgreSQL 17 installation
│   └── backup_restore_utils.sh # Database backup/restore
├── project/                     # Project management scripts
│   ├── init_react_project.sh   # React 19.1.0 project setup
│   ├── init_nestjs_project.sh  # NestJS 11.1.3 project setup
│   ├── dependency_manager.sh   # Dependency management
│   ├── build_automation.sh     # Build process automation
│   ├── test_runner.sh          # Testing utilities
│   └── code_quality.sh         # Code quality checks
├── workflow/                    # Development workflow automation
│   ├── hot_reload_setup.sh     # Hot reload configuration
│   ├── port_manager.sh         # Port management utilities
│   ├── log_monitor.sh          # Log monitoring and analysis
│   ├── pm2_manager.sh          # PM2 process management
│   └── git_workflow.sh         # Git workflow automation
├── deployment/                  # Production deployment scripts
│   ├── deploy_pipeline.sh      # Deployment pipeline
│   ├── environment_switcher.sh # Environment management
│   ├── health_checker.sh       # Health monitoring
│   └── production_optimizer.sh # Production optimization
├── monitoring/                  # System and application monitoring
│   ├── system_monitor.sh       # System resource monitoring
│   └── app_performance_monitor.sh # Application performance tracking
├── debugging/                   # Troubleshooting and diagnostic tools
│   ├── network_diagnostics.sh  # Network troubleshooting
│   └── database_debug.sh       # Database debugging utilities
├── config/                      # Configuration templates
│   ├── environment_template.env # Environment variables template
│   ├── postgresql_template.conf # PostgreSQL configuration
│   └── ssh_config_template     # SSH configuration template
├── install.sh                   # Master installation script
└── README.md                    # This documentation
```

## 🔧 Installation Modes

### Full Installation (Recommended)
```bash
./install.sh --mode full
```
Installs all components for complete development environment.

### Development Mode
```bash
./install.sh --mode development
```
Installs development tools, monitoring, and debugging utilities.

### Minimal Mode
```bash
./install.sh --mode minimal
```
Basic system setup and Node.js environment only.

### Production Mode
```bash
./install.sh --mode production
```
Production-ready deployment with monitoring and optimization.

## 📊 Technology Stack

### Core Technologies
- **Node.js**: 20.9.0 LTS (Iron) - ARM64 optimized
- **React**: 19.1.0 - Latest stable with enhanced debugging
- **NestJS**: 11.1.3 - Express v5 default, ARM64 compatible
- **TypeScript**: 5.8.3 - ECMAScript 2024 support
- **PostgreSQL**: 17.5 - ARM64 optimized, ~200 TPS on Pi 5
- **Vite**: 7.0.4 - AI-powered optimization engine

### Development Tools
- **PM2**: Process management and monitoring
- **VS Code Server**: Remote development environment
- **Git**: Version control with workflow automation
- **ESLint/Prettier**: Code quality and formatting

### Monitoring & Debugging
- **htop/iotop**: System resource monitoring
- **nethogs**: Network bandwidth monitoring
- **nmap**: Network diagnostics and port scanning
- **gdb/strace**: Application debugging
- **PostgreSQL monitoring**: Query performance analysis

## 🖥️ System Monitoring

### Real-time System Monitoring
```bash
# Start continuous system monitoring
./monitoring/system_monitor.sh --action monitor --continuous

# Take system snapshot
./monitoring/system_monitor.sh --action snapshot

# Check system alerts
./monitoring/system_monitor.sh --action alerts
```

### Application Performance Monitoring
```bash
# Monitor all applications
./monitoring/app_performance_monitor.sh --action monitor

# Monitor specific application
./monitoring/app_performance_monitor.sh --action monitor --app nestjs

# Generate performance report
./monitoring/app_performance_monitor.sh --action report
```

## 🐛 Debugging & Troubleshooting

### Network Diagnostics
```bash
# Full network diagnostics
./debugging/network_diagnostics.sh --action diagnose

# Test connectivity to specific host
./debugging/network_diagnostics.sh --action connectivity --target google.com

# Check development services
./debugging/network_diagnostics.sh --action services

# Interactive troubleshooting
./debugging/network_diagnostics.sh --action troubleshoot
```

### Database Debugging
```bash
# Full database diagnostics
./debugging/database_debug.sh --action diagnose

# Check query performance
./debugging/database_debug.sh --action performance

# Analyze slow queries
./debugging/database_debug.sh --action slow-queries

# Check database locks
./debugging/database_debug.sh --action locks
```

## 🚀 Project Creation

### React 19.1.0 Project
```bash
./project/init_react_project.sh --name my-react-app --template typescript
```

### NestJS 11.1.3 Project
```bash
./project/init_nestjs_project.sh --name my-nestjs-api --database postgresql
```

## 🔄 Development Workflow

### Process Management with PM2
```bash
# Setup PM2 ecosystem
./workflow/pm2_manager.sh --action setup

# Start applications
./workflow/pm2_manager.sh --action start

# Monitor processes
./workflow/pm2_manager.sh --action monitor
```

### Log Monitoring
```bash
# Monitor all service logs
./workflow/log_monitor.sh --action monitor --follow

# Analyze logs for errors
./workflow/log_monitor.sh --action analyze

# Search logs for patterns
./workflow/log_monitor.sh --action search
```

## 🏭 Production Deployment

### Health Checking
```bash
# Comprehensive health check
./deployment/health_checker.sh --service all

# Check specific service
./deployment/health_checker.sh --service nestjs
```

### Production Optimization
```bash
# Optimize for production
./deployment/production_optimizer.sh --action optimize

# Performance tuning
./deployment/production_optimizer.sh --action performance
```

## ⚡ Performance Optimization

### ARM64 Specific Optimizations
- **16KB Page Size**: Up to 7% performance increase
- **SDRAM Tuning**: 10-20% speed boost at 2.4 GHz
- **NUMA Emulation**: Up to 18% performance boost for multi-threaded workloads
- **NVMe PCIe Gen 3**: Up to 1,000 MB/s storage performance

### Node.js Optimizations
- **Cluster Mode**: Optimized for Pi 5's quad-core ARM Cortex-A76
- **Memory Management**: Conservative memory limits for ARM64
- **V8 Flags**: ARM64-specific optimization flags

### PostgreSQL Tuning
- **ARM64 Configuration**: Optimized for Pi 5 memory and CPU
- **NVMe Storage**: Configured for high-performance SSD storage
- **Connection Pooling**: Optimized for development workloads

## 🔒 Security Features

### SSH Hardening
- Key-based authentication only
- Custom SSH port configuration
- Fail2ban integration
- Strong encryption algorithms

### System Security
- Firewall configuration (UFW)
- Automatic security updates
- User privilege management
- Network security monitoring

## 📈 Monitoring & Alerts

### System Metrics
- CPU usage and temperature monitoring
- Memory usage and leak detection
- Disk I/O and space monitoring
- Network bandwidth tracking

### Application Metrics
- Node.js process monitoring
- Database performance tracking
- HTTP endpoint response times
- Error rate monitoring

### Alert Thresholds
- CPU usage > 80%
- Memory usage > 85%
- Disk usage > 90%
- Temperature > 70°C
- Response time > 5000ms

## 🛠️ Configuration

### Environment Variables
```bash
# Development environment
export NODE_ENV=development
export DATABASE_URL=postgresql://user:pass@localhost:5432/dbname
export PORT=3000

# Monitoring thresholds
export CPU_ALERT_THRESHOLD=80
export MEMORY_ALERT_THRESHOLD=85
export TEMP_ALERT_THRESHOLD=70
```

### Database Configuration
```sql
-- PostgreSQL 17 ARM64 optimizations
shared_buffers = 256MB
effective_cache_size = 1GB
work_mem = 4MB
maintenance_work_mem = 64MB
random_page_cost = 1.1
effective_io_concurrency = 200
```

## 🔍 Troubleshooting

### Common Issues

#### Node.js Installation Issues
```bash
# Check Node.js version
node --version

# Reinstall Node.js via NVM
./environment/nodejs_nvm_setup.sh --version 20 --force
```

#### Database Connection Issues
```bash
# Test database connection
./debugging/database_debug.sh --action connection

# Check PostgreSQL service
sudo systemctl status postgresql
```

#### Performance Issues
```bash
# System performance check
./monitoring/system_monitor.sh --action status

# Application performance analysis
./monitoring/app_performance_monitor.sh --action snapshot
```

### Log Locations
- **System logs**: `~/development/logs/`
- **Application logs**: `~/.pm2/logs/`
- **PostgreSQL logs**: `/var/log/postgresql/`
- **System logs**: `/var/log/syslog`

## 📚 Documentation

### Script Documentation
Each script includes comprehensive inline documentation with:
- Usage examples
- Parameter descriptions
- Prerequisites
- Error handling
- Performance considerations

### API Documentation
- **Health Check Endpoints**: `/api/health`
- **Metrics Endpoints**: `/api/metrics`
- **Status Endpoints**: `/api/status`

## 🤝 Contributing

### Development Guidelines
1. Follow POSIX-compliant bash scripting
2. Include comprehensive error handling
3. Add detailed logging and comments
4. Test on ARM64 architecture
5. Validate with shellcheck

### Testing
```bash
# Dry run installation
./install.sh --dry-run

# Test individual components
./system/pi5_os_optimization.sh --dry-run
```

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Raspberry Pi Foundation for ARM64 optimization guidelines
- Node.js community for ARM64 support
- PostgreSQL community for ARM64 performance tuning
- Open source monitoring and debugging tools

## 📞 Support

For issues and questions:
1. Check the troubleshooting section
2. Review log files in `~/development/logs/`
3. Run diagnostic scripts for specific issues
4. Check system requirements and prerequisites

## 🔄 Updates

### Version 1.0 Features
- ✅ Complete ARM64 optimization
- ✅ React 19.1.0 support
- ✅ NestJS 11.1.3 integration
- ✅ PostgreSQL 17 configuration
- ✅ Comprehensive monitoring
- ✅ Advanced debugging tools
- ✅ Production deployment pipeline

### Roadmap
- [ ] Docker containerization support
- [ ] Kubernetes deployment scripts
- [ ] Advanced CI/CD integration
- [ ] Performance benchmarking suite
- [ ] Automated testing framework

---

**Happy coding on your Raspberry Pi 5! 🚀**