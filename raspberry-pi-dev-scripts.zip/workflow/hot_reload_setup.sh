#!/bin/bash
#
# Hot Reload Setup Script for React/NestJS Development on Raspberry Pi 5
# Configures development servers with hot reload for React 19.1.0 + Vite 7.0.4 and NestJS 11.1.3
# Optimized for ARM64 architecture and network development workflow
#
# Usage: ./hot_reload_setup.sh [--dry-run] [--project-type TYPE] [--port PORT]
# 
# Prerequisites:
# - Node.js 20 LTS installed via NVM
# - npm 10+ with proper configuration
# - React 19.1.0 + Vite 7.0.4 or NestJS 11.1.3 project
# - Project with package.json and development scripts
# - Network access for remote development
#
# Features:
# - Vite development server configuration for React
# - NestJS development server with hot reload
# - Network accessibility configuration
# - File watching optimization for ARM64
# - Port management and conflict resolution
# - Environment variable configuration
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/hot_reload_setup.log"
DRY_RUN=false
PROJECT_TYPE="auto"
PROJECT_PATH="$(pwd)"
DEV_PORT=""
HOST="0.0.0.0"
ENABLE_HTTPS=false
OPTIMIZE_WATCHING=true
SETUP_NETWORK_ACCESS=true

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --project-type)
            PROJECT_TYPE="$2"
            shift 2
            ;;
        --project-path)
            PROJECT_PATH="$2"
            shift 2
            ;;
        --port)
            DEV_PORT="$2"
            shift 2
            ;;
        --host)
            HOST="$2"
            shift 2
            ;;
        --https)
            ENABLE_HTTPS=true
            shift
            ;;
        --no-optimization)
            OPTIMIZE_WATCHING=false
            shift
            ;;
        --no-network)
            SETUP_NETWORK_ACCESS=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--project-type TYPE] [--port PORT]"
            echo "Configures hot reload development servers for React and NestJS projects"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --project-type TYPE    Project type: react, nestjs, auto (default: auto)"
            echo "  --project-path PATH    Project directory path (default: current directory)"
            echo "  --port PORT            Development server port (auto-assigned if not specified)"
            echo "  --host HOST            Server host address (default: 0.0.0.0)"
            echo "  --https                Enable HTTPS for development server"
            echo "  --no-optimization      Skip file watching optimizations"
            echo "  --no-network           Skip network accessibility setup"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Project Types:"
            echo "  react                  React 19.1.0 + Vite 7.0.4 project"
            echo "  nestjs                 NestJS 11.1.3 + TypeScript 5.8.3 project"
            echo "  auto                   Auto-detect project type (default)"
            echo ""
            echo "Examples:"
            echo "  $0                                    # Auto-detect and setup hot reload"
            echo "  $0 --project-type react --port 3000"
            echo "  $0 --project-type nestjs --https"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Node.js
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        exit 1
    fi
    
    local node_version
    node_version=$(node --version | sed 's/v//')
    local node_major_version
    node_major_version=$(echo "$node_version" | cut -d. -f1)
    
    if [[ "$node_major_version" -lt 18 ]]; then
        log_error "Node.js version 18+ required, found: v$node_version"
        exit 1
    fi
    
    log_info "Node.js version: v$node_version ✓"
    
    # Check npm
    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not available"
        exit 1
    fi
    
    local npm_version
    npm_version=$(npm --version)
    log_info "npm version: v$npm_version ✓"
    
    # Check project directory
    if [[ ! -d "$PROJECT_PATH" ]]; then
        log_error "Project directory does not exist: $PROJECT_PATH"
        exit 1
    fi
    
    # Check package.json
    if [[ ! -f "$PROJECT_PATH/package.json" ]]; then
        log_error "package.json not found in: $PROJECT_PATH"
        exit 1
    fi
    
    # Change to project directory
    cd "$PROJECT_PATH"
    log_info "Working in project directory: $(pwd)"
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" == "aarch64" ]]; then
        log_info "ARM64 architecture detected - applying optimizations"
    else
        log_warning "Not running on ARM64 architecture: $(uname -m)"
    fi
    
    log_info "Prerequisites check completed"
}

# Auto-detect project type
detect_project_type() {
    if [[ "$PROJECT_TYPE" != "auto" ]]; then
        log_info "Project type specified: $PROJECT_TYPE"
        return 0
    fi
    
    log_info "Auto-detecting project type..."
    
    # Check for React project indicators
    if grep -q '"react"' package.json 2>/dev/null; then
        if grep -q '"vite"' package.json 2>/dev/null; then
            PROJECT_TYPE="react"
            log_info "Detected React project with Vite"
            return 0
        fi
    fi
    
    # Check for NestJS project indicators
    if grep -q '"@nestjs/core"' package.json 2>/dev/null; then
        PROJECT_TYPE="nestjs"
        log_info "Detected NestJS project"
        return 0
    fi
    
    # Check for development scripts
    if grep -q '"vite"' package.json 2>/dev/null; then
        PROJECT_TYPE="react"
        log_info "Detected React/Vite project from dependencies"
        return 0
    fi
    
    if grep -q '"@nestjs/cli"' package.json 2>/dev/null; then
        PROJECT_TYPE="nestjs"
        log_info "Detected NestJS project from CLI dependency"
        return 0
    fi
    
    log_error "Could not auto-detect project type"
    log_error "Please specify --project-type react or --project-type nestjs"
    exit 1
}

# Find available port
find_available_port() {
    local start_port=$1
    local port=$start_port
    
    while [[ $port -le $((start_port + 100)) ]]; do
        if ! netstat -tuln 2>/dev/null | grep -q ":$port "; then
            echo "$port"
            return 0
        fi
        ((port++))
    done
    
    log_error "Could not find available port starting from $start_port"
    exit 1
}

# Assign development port
assign_dev_port() {
    if [[ -n "$DEV_PORT" ]]; then
        log_info "Using specified port: $DEV_PORT"
        
        # Check if port is available
        if netstat -tuln 2>/dev/null | grep -q ":$DEV_PORT "; then
            log_warning "Port $DEV_PORT is already in use"
            log_info "Finding alternative port..."
            DEV_PORT=$(find_available_port "$DEV_PORT")
            log_info "Using alternative port: $DEV_PORT"
        fi
        return 0
    fi
    
    # Assign default ports based on project type
    case "$PROJECT_TYPE" in
        "react")
            DEV_PORT=$(find_available_port 5173)  # Vite default
            ;;
        "nestjs")
            DEV_PORT=$(find_available_port 3000)  # NestJS default
            ;;
        *)
            DEV_PORT=$(find_available_port 3000)
            ;;
    esac
    
    log_info "Assigned development port: $DEV_PORT"
}

# Configure React hot reload with Vite
configure_react_hot_reload() {
    log_info "Configuring React hot reload with Vite..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure React hot reload"
        return 0
    fi
    
    # Create or update vite.config.ts
    local vite_config="vite.config.ts"
    if [[ ! -f "$vite_config" ]]; then
        vite_config="vite.config.js"
    fi
    
    log_info "Configuring Vite development server..."
    
    # Create Vite configuration
    cat > "$vite_config" << EOF
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: '$HOST',
    port: $DEV_PORT,
    strictPort: false,
    open: false,
    cors: true,
    hmr: {
      port: $((DEV_PORT + 1)),
    },
    watch: {
      usePolling: false,
      interval: 100,
    },
  },
  build: {
    target: 'es2020',
    outDir: 'dist',
    sourcemap: true,
  },
  optimizeDeps: {
    include: ['react', 'react-dom'],
  },
})
EOF
    
    # Update package.json scripts
    log_info "Updating development scripts..."
    
    # Update dev script
    npm pkg set scripts.dev="vite --host $HOST --port $DEV_PORT"
    npm pkg set scripts.preview="vite preview --host $HOST --port $((DEV_PORT + 2))"
    
    # Create environment file for development
    create_react_env_file
    
    log_success "React hot reload configured"
}

# Configure NestJS hot reload
configure_nestjs_hot_reload() {
    log_info "Configuring NestJS hot reload..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure NestJS hot reload"
        return 0
    fi
    
    # Check if @nestjs/cli is available
    if ! npm list @nestjs/cli --depth=0 >/dev/null 2>&1; then
        log_warning "@nestjs/cli not found, installing..."
        npm install --save-dev @nestjs/cli
    fi
    
    # Update package.json scripts for hot reload
    log_info "Updating development scripts..."
    
    npm pkg set scripts.start:dev="nest start --watch --preserveWatchOutput"
    npm pkg set scripts.start:debug="nest start --debug --watch --preserveWatchOutput"
    
    # Create nest-cli.json if it doesn't exist
    if [[ ! -f "nest-cli.json" ]]; then
        log_info "Creating nest-cli.json configuration..."
        cat > nest-cli.json << EOF
{
  "\$schema": "https://json.schemastore.org/nest-cli",
  "collection": "@nestjs/schematics",
  "sourceRoot": "src",
  "compilerOptions": {
    "deleteOutDir": true,
    "watchAssets": true,
    "assets": ["**/*.!(ts)"],
    "plugins": [
      {
        "name": "@nestjs/swagger",
        "options": {
          "classValidatorShim": false,
          "introspectComments": true
        }
      }
    ]
  }
}
EOF
    fi
    
    # Update main.ts for development
    update_nestjs_main_file
    
    # Create environment file for development
    create_nestjs_env_file
    
    log_success "NestJS hot reload configured"
}

# Update NestJS main.ts for development
update_nestjs_main_file() {
    log_info "Updating NestJS main.ts for development..."
    
    if [[ ! -f "src/main.ts" ]]; then
        log_warning "src/main.ts not found, skipping main file update"
        return 0
    fi
    
    # Backup original main.ts
    cp src/main.ts "src/main.ts.backup.$(date +%Y%m%d_%H%M%S)"
    
    # Create updated main.ts with development optimizations
    cat > src/main.ts << EOF
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  // Enable CORS for development
  app.enableCors({
    origin: process.env.NODE_ENV === 'development' ? true : process.env.CORS_ORIGIN?.split(','),
    credentials: true,
  });
  
  // Global validation pipe
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,
    forbidNonWhitelisted: true,
    transform: true,
  }));
  
  // API prefix
  app.setGlobalPrefix('api');
  
  // Swagger documentation (development only)
  if (process.env.NODE_ENV === 'development') {
    const config = new DocumentBuilder()
      .setTitle('API Documentation')
      .setDescription('Development API documentation')
      .setVersion('1.0')
      .addTag('api')
      .build();
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('api/docs', app, document);
  }
  
  const port = process.env.PORT || $DEV_PORT;
  const host = process.env.HOST || '$HOST';
  
  await app.listen(port, host);
  
  if (process.env.NODE_ENV === 'development') {
    console.log(\`🚀 Application is running on: http://\${host}:\${port}\`);
    console.log(\`📚 API Documentation: http://\${host}:\${port}/api/docs\`);
  }
}

bootstrap();
EOF
    
    log_info "NestJS main.ts updated for development"
}

# Create React environment file
create_react_env_file() {
    log_info "Creating React development environment file..."
    
    cat > .env.development << EOF
# React Development Environment
VITE_APP_TITLE=Pi5 Development App
VITE_API_URL=http://localhost:$DEV_PORT/api
VITE_APP_ENV=development

# Development Server Configuration
VITE_HOST=$HOST
VITE_PORT=$DEV_PORT

# Hot Reload Configuration
VITE_HMR_PORT=$((DEV_PORT + 1))

# Development Features
VITE_DEV_TOOLS=true
VITE_DEBUG=true

# File Watching (ARM64 Optimization)
CHOKIDAR_USEPOLLING=false
WATCHPACK_POLLING=false
EOF
    
    log_info "React environment file created"
}

# Create NestJS environment file
create_nestjs_env_file() {
    log_info "Creating NestJS development environment file..."
    
    cat > .env.development << EOF
# NestJS Development Environment
NODE_ENV=development
PORT=$DEV_PORT
HOST=$HOST

# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=development
DB_USER=developer
DB_PASSWORD=your_secure_password_here

# JWT Configuration
JWT_SECRET=your_jwt_secret_here
JWT_EXPIRES_IN=24h

# API Configuration
API_PREFIX=api
API_VERSION=v1

# CORS Configuration
CORS_ORIGIN=http://localhost:3000,http://localhost:5173,http://localhost:$DEV_PORT

# Swagger Documentation
SWAGGER_ENABLED=true
SWAGGER_PATH=api/docs

# Logging
LOG_LEVEL=debug

# Hot Reload Optimization (ARM64)
NEST_DEBUG=true
NEST_WATCH_ASSETS=true
EOF
    
    log_info "NestJS environment file created"
}

# Optimize file watching for ARM64
optimize_file_watching() {
    if [[ "$OPTIMIZE_WATCHING" != "true" ]]; then
        log_info "Skipping file watching optimization (--no-optimization specified)"
        return 0
    fi
    
    log_info "Optimizing file watching for ARM64..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would optimize file watching"
        return 0
    fi
    
    # Create .watchmanconfig for better file watching
    cat > .watchmanconfig << 'EOF'
{
  "ignore_dirs": [
    "node_modules",
    "dist",
    "build",
    ".git",
    "coverage",
    "logs"
  ]
}
EOF
    
    # Update package.json with ARM64 optimized settings
    npm pkg set config.watchOptions.ignored="[\"node_modules\", \"dist\", \"build\", \".git\"]"
    npm pkg set config.watchOptions.poll=false
    
    log_success "File watching optimized for ARM64"
}

# Setup network access
setup_network_access() {
    if [[ "$SETUP_NETWORK_ACCESS" != "true" ]]; then
        log_info "Skipping network access setup (--no-network specified)"
        return 0
    fi
    
    log_info "Setting up network access for development server..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would setup network access"
        return 0
    fi
    
    # Get local IP address
    local local_ip
    local_ip=$(hostname -I | awk '{print $1}' || echo "localhost")
    
    log_info "Local IP address: $local_ip"
    log_info "Development server will be accessible at:"
    log_info "  Local: http://localhost:$DEV_PORT"
    log_info "  Network: http://$local_ip:$DEV_PORT"
    
    # Create network access information file
    cat > network-access.md << EOF
# Development Server Network Access

## Server Information
- **Project Type**: $PROJECT_TYPE
- **Port**: $DEV_PORT
- **Host**: $HOST

## Access URLs
- **Local**: http://localhost:$DEV_PORT
- **Network**: http://$local_ip:$DEV_PORT

## Additional URLs
$(case "$PROJECT_TYPE" in
    "react")
        echo "- **Preview**: http://$local_ip:$((DEV_PORT + 2))"
        ;;
    "nestjs")
        echo "- **API Docs**: http://$local_ip:$DEV_PORT/api/docs"
        echo "- **Health Check**: http://$local_ip:$DEV_PORT/api/health"
        ;;
esac)

## Network Configuration
- CORS is enabled for development
- Server binds to all interfaces (0.0.0.0)
- Hot reload is configured for network access

## Firewall Notes
If you cannot access the server from other devices:
1. Check if port $DEV_PORT is open in firewall
2. Run: \`sudo ufw allow $DEV_PORT\`
3. Verify with: \`sudo ufw status\`

## VS Code Remote Development
To connect VS Code remotely:
1. Install "Remote - SSH" extension
2. Connect to: \`pi@$local_ip\`
3. Open project directory
4. Start development server

Generated on: $(date)
EOF
    
    log_success "Network access configured"
}

# Create development helper scripts
create_helper_scripts() {
    log_info "Creating development helper scripts..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create helper scripts"
        return 0
    fi
    
    # Create start script
    cat > start-dev.sh << EOF
#!/bin/bash
# Development Server Startup Script
# Generated by hot_reload_setup.sh

set -e

echo "🚀 Starting $PROJECT_TYPE development server..."
echo "📍 Port: $DEV_PORT"
echo "🌐 Host: $HOST"
echo ""

# Load environment variables
if [[ -f ".env.development" ]]; then
    export \$(cat .env.development | grep -v '^#' | xargs)
fi

# Start development server
case "$PROJECT_TYPE" in
    "react")
        echo "Starting React development server with Vite..."
        npm run dev
        ;;
    "nestjs")
        echo "Starting NestJS development server..."
        npm run start:dev
        ;;
esac
EOF
    
    chmod +x start-dev.sh
    
    # Create stop script
    cat > stop-dev.sh << 'EOF'
#!/bin/bash
# Development Server Stop Script

echo "🛑 Stopping development servers..."

# Kill processes on development ports
pkill -f "vite" || true
pkill -f "nest start" || true
pkill -f "node.*dist/main" || true

echo "✅ Development servers stopped"
EOF
    
    chmod +x stop-dev.sh
    
    log_success "Helper scripts created"
}

# Execute hot reload setup
execute_hot_reload_setup() {
    case "$PROJECT_TYPE" in
        "react")
            configure_react_hot_reload
            ;;
        "nestjs")
            configure_nestjs_hot_reload
            ;;
        *)
            log_error "Unknown project type: $PROJECT_TYPE"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== Hot Reload Setup Summary ==="
    log_info "Project Type: $PROJECT_TYPE"
    log_info "Project Path: $PROJECT_PATH"
    log_info "Development Port: $DEV_PORT"
    log_info "Host: $HOST"
    log_info "HTTPS Enabled: $ENABLE_HTTPS"
    log_info "File Watching Optimized: $OPTIMIZE_WATCHING"
    log_info ""
    
    local local_ip
    local_ip=$(hostname -I | awk '{print $1}' || echo "localhost")
    
    log_info "=== Access URLs ==="
    log_info "Local: http://localhost:$DEV_PORT"
    log_info "Network: http://$local_ip:$DEV_PORT"
    
    case "$PROJECT_TYPE" in
        "react")
            log_info "Preview: http://$local_ip:$((DEV_PORT + 2))"
            ;;
        "nestjs")
            log_info "API Docs: http://$local_ip:$DEV_PORT/api/docs"
            ;;
    esac
    
    log_info ""
    log_info "=== Next Steps ==="
    log_info "1. Start development server: ./start-dev.sh"
    log_info "2. Open browser to development URL"
    log_info "3. Begin development with hot reload"
    log_info "4. Stop server when done: ./stop-dev.sh"
    
    log_info ""
    log_info "=== Files Created ==="
    case "$PROJECT_TYPE" in
        "react")
            log_info "- vite.config.ts (Vite configuration)"
            ;;
        "nestjs")
            log_info "- nest-cli.json (NestJS CLI configuration)"
            log_info "- src/main.ts (updated for development)"
            ;;
    esac
    log_info "- .env.development (environment variables)"
    log_info "- start-dev.sh (startup script)"
    log_info "- stop-dev.sh (stop script)"
    log_info "- network-access.md (network information)"
    
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting hot reload setup..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Project type: $PROJECT_TYPE"
    
    check_prerequisites
    detect_project_type
    assign_dev_port
    execute_hot_reload_setup
    optimize_file_watching
    setup_network_access
    create_helper_scripts
    
    log_success "Hot reload setup completed successfully!"
    display_summary
}

# Execute main function
main "$@"