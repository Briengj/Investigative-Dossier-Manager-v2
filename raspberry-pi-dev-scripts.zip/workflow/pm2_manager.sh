#!/bin/bash
#
# PM2 Process Management Script for Node.js Applications on Raspberry Pi 5
# Manages PM2 processes for React 19.1.0 and NestJS 11.1.3 applications
# Optimized for ARM64 architecture and production deployment
#
# Usage: ./pm2_manager.sh [--dry-run] [--action ACTION] [--app APP]
# 
# Prerequisites:
# - Node.js 20 LTS installed via NVM
# - PM2 installed globally or locally
# - Application with ecosystem.config.js or package.json
# - Proper PM2 configuration files
#
# Features:
# - PM2 ecosystem configuration management
# - Process lifecycle management (start, stop, restart, reload)
# - Process monitoring and health checks
# - Log management and rotation
# - Cluster mode configuration for ARM64
# - Memory and CPU monitoring
# - Auto-restart and error recovery
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/pm2_manager.log"
DRY_RUN=false
ACTION="status"
TARGET_APP=""
PROJECT_PATH="$(pwd)"
ECOSYSTEM_FILE="ecosystem.config.js"
CLUSTER_MODE=true
MAX_MEMORY="512M"
INSTANCES="max"
WATCH_MODE=false

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --action)
            ACTION="$2"
            shift 2
            ;;
        --app)
            TARGET_APP="$2"
            shift 2
            ;;
        --project-path)
            PROJECT_PATH="$2"
            shift 2
            ;;
        --ecosystem-file)
            ECOSYSTEM_FILE="$2"
            shift 2
            ;;
        --no-cluster)
            CLUSTER_MODE=false
            shift
            ;;
        --max-memory)
            MAX_MEMORY="$2"
            shift 2
            ;;
        --instances)
            INSTANCES="$2"
            shift 2
            ;;
        --watch)
            WATCH_MODE=true
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--action ACTION] [--app APP]"
            echo "Manages PM2 processes for Node.js applications"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --action ACTION        Action to perform (default: status)"
            echo "  --app APP              Target specific application"
            echo "  --project-path PATH    Project directory path (default: current directory)"
            echo "  --ecosystem-file FILE  Ecosystem configuration file (default: ecosystem.config.js)"
            echo "  --no-cluster           Disable cluster mode"
            echo "  --max-memory SIZE      Maximum memory per process (default: 512M)"
            echo "  --instances N          Number of instances (default: max)"
            echo "  --watch                Enable file watching for development"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Actions:"
            echo "  status                 Show PM2 process status"
            echo "  start                  Start application(s)"
            echo "  stop                   Stop application(s)"
            echo "  restart                Restart application(s)"
            echo "  reload                 Graceful reload application(s)"
            echo "  delete                 Delete application(s) from PM2"
            echo "  logs                   Show application logs"
            echo "  monitor                Monitor application performance"
            echo "  setup                  Setup PM2 ecosystem configuration"
            echo "  startup                Configure PM2 startup script"
            echo "  save                   Save current PM2 process list"
            echo "  resurrect              Restore saved PM2 processes"
            echo "  flush                  Flush PM2 logs"
            echo "  reset                  Reset PM2 process counters"
            echo ""
            echo "Examples:"
            echo "  $0 --action status"
            echo "  $0 --action start --app my-nestjs-app"
            echo "  $0 --action setup --project-path /path/to/project"
            echo "  $0 --action monitor --app my-app"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Node.js
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        exit 1
    fi
    
    local node_version
    node_version=$(node --version | sed 's/v//')
    local node_major_version
    node_major_version=$(echo "$node_version" | cut -d. -f1)
    
    if [[ "$node_major_version" -lt 18 ]]; then
        log_error "Node.js version 18+ required, found: v$node_version"
        exit 1
    fi
    
    log_info "Node.js version: v$node_version ✓"
    
    # Check PM2
    if ! command -v pm2 >/dev/null 2>&1; then
        log_warning "PM2 not found globally, checking local installation..."
        if ! npx pm2 --version >/dev/null 2>&1; then
            log_error "PM2 not found. Install with: npm install -g pm2"
            exit 1
        else
            log_info "PM2 available via npx ✓"
        fi
    else
        local pm2_version
        pm2_version=$(pm2 --version)
        log_info "PM2 version: $pm2_version ✓"
    fi
    
    # Check project directory
    if [[ ! -d "$PROJECT_PATH" ]]; then
        log_error "Project directory does not exist: $PROJECT_PATH"
        exit 1
    fi
    
    # Change to project directory
    cd "$PROJECT_PATH"
    log_info "Working in project directory: $(pwd)"
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" == "aarch64" ]]; then
        log_info "ARM64 architecture detected - optimizing for Pi 5"
        # Adjust instances for ARM64 if set to max
        if [[ "$INSTANCES" == "max" ]]; then
            INSTANCES="2"  # Conservative for Pi 5
            log_info "Setting instances to $INSTANCES for ARM64 optimization"
        fi
    else
        log_warning "Not running on ARM64 architecture: $(uname -m)"
    fi
    
    log_info "Prerequisites check completed"
}

# Get PM2 command (handle global vs local installation)
get_pm2_command() {
    if command -v pm2 >/dev/null 2>&1; then
        echo "pm2"
    else
        echo "npx pm2"
    fi
}

# Detect project type
detect_project_type() {
    log_info "Detecting project type..."
    
    if [[ -f "package.json" ]]; then
        if grep -q '"@nestjs/core"' package.json 2>/dev/null; then
            echo "nestjs"
            return 0
        elif grep -q '"react"' package.json 2>/dev/null; then
            echo "react"
            return 0
        elif grep -q '"next"' package.json 2>/dev/null; then
            echo "nextjs"
            return 0
        fi
    fi
    
    echo "nodejs"
}

# Setup PM2 ecosystem configuration
setup_ecosystem() {
    log_info "Setting up PM2 ecosystem configuration..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create ecosystem configuration"
        return 0
    fi
    
    local project_type
    project_type=$(detect_project_type)
    
    local project_name
    project_name=$(basename "$PROJECT_PATH")
    
    if [[ -f "package.json" ]]; then
        project_name=$(node -p "require('./package.json').name" 2>/dev/null || echo "$project_name")
    fi
    
    log_info "Project type: $project_type"
    log_info "Project name: $project_name"
    
    # Create ecosystem configuration based on project type
    case "$project_type" in
        "nestjs")
            create_nestjs_ecosystem "$project_name"
            ;;
        "react")
            log_warning "React applications typically don't need PM2 in development"
            log_info "Consider using PM2 for serving built React applications"
            create_static_server_ecosystem "$project_name"
            ;;
        "nextjs")
            create_nextjs_ecosystem "$project_name"
            ;;
        *)
            create_generic_ecosystem "$project_name"
            ;;
    esac
    
    log_success "Ecosystem configuration created: $ECOSYSTEM_FILE"
}

# Create NestJS ecosystem configuration
create_nestjs_ecosystem() {
    local app_name=$1
    
    cat > "$ECOSYSTEM_FILE" << EOF
module.exports = {
  apps: [
    {
      name: '$app_name',
      script: 'dist/main.js',
      instances: $INSTANCES,
      exec_mode: '$(if [[ "$CLUSTER_MODE" == "true" ]]; then echo "cluster"; else echo "fork"; fi)',
      watch: $WATCH_MODE,
      max_memory_restart: '$MAX_MEMORY',
      env: {
        NODE_ENV: 'development',
        PORT: 3000,
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      error_file: './logs/err.log',
      out_file: './logs/out.log',
      log_file: './logs/combined.log',
      time: true,
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s',
      restart_delay: 4000,
      kill_timeout: 5000,
      listen_timeout: 3000,
      // ARM64 optimizations
      node_args: '--max-old-space-size=1024',
      // Health check
      health_check_grace_period: 3000,
      // Log rotation
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      // Monitoring
      pmx: true,
      // Development specific
      ignore_watch: [
        'node_modules',
        'logs',
        'dist',
        '.git'
      ],
      watch_options: {
        followSymlinks: false,
        usePolling: false
      }
    }
  ],
  
  deploy: {
    production: {
      user: 'pi',
      host: 'localhost',
      ref: 'origin/main',
      repo: 'git@github.com:username/repository.git',
      path: '/home/pi/production',
      'post-deploy': 'npm install && npm run build && pm2 reload ecosystem.config.js --env production'
    }
  }
};
EOF
    
    # Create logs directory
    mkdir -p logs
}

# Create static server ecosystem (for built React apps)
create_static_server_ecosystem() {
    local app_name=$1
    
    cat > "$ECOSYSTEM_FILE" << EOF
module.exports = {
  apps: [
    {
      name: '$app_name-server',
      script: 'serve',
      args: '-s dist -l 3000',
      instances: 1,
      exec_mode: 'fork',
      watch: false,
      max_memory_restart: '256M',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      error_file: './logs/err.log',
      out_file: './logs/out.log',
      log_file: './logs/combined.log',
      time: true,
      autorestart: true,
      max_restarts: 5,
      min_uptime: '5s'
    }
  ]
};
EOF
    
    # Install serve if not present
    if ! npm list serve >/dev/null 2>&1; then
        log_info "Installing serve package for static file serving..."
        npm install serve
    fi
    
    mkdir -p logs
}

# Create Next.js ecosystem configuration
create_nextjs_ecosystem() {
    local app_name=$1
    
    cat > "$ECOSYSTEM_FILE" << EOF
module.exports = {
  apps: [
    {
      name: '$app_name',
      script: 'npm',
      args: 'start',
      instances: $INSTANCES,
      exec_mode: '$(if [[ "$CLUSTER_MODE" == "true" ]]; then echo "cluster"; else echo "fork"; fi)',
      watch: false,
      max_memory_restart: '$MAX_MEMORY',
      env: {
        NODE_ENV: 'development',
        PORT: 3000,
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      error_file: './logs/err.log',
      out_file: './logs/out.log',
      log_file: './logs/combined.log',
      time: true,
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s'
    }
  ]
};
EOF
    
    mkdir -p logs
}

# Create generic Node.js ecosystem configuration
create_generic_ecosystem() {
    local app_name=$1
    
    # Try to detect main script
    local main_script="index.js"
    if [[ -f "package.json" ]]; then
        main_script=$(node -p "require('./package.json').main || 'index.js'" 2>/dev/null || echo "index.js")
    fi
    
    cat > "$ECOSYSTEM_FILE" << EOF
module.exports = {
  apps: [
    {
      name: '$app_name',
      script: '$main_script',
      instances: $INSTANCES,
      exec_mode: '$(if [[ "$CLUSTER_MODE" == "true" ]]; then echo "cluster"; else echo "fork"; fi)',
      watch: $WATCH_MODE,
      max_memory_restart: '$MAX_MEMORY',
      env: {
        NODE_ENV: 'development',
        PORT: 3000,
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      error_file: './logs/err.log',
      out_file: './logs/out.log',
      log_file: './logs/combined.log',
      time: true,
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s'
    }
  ]
};
EOF
    
    mkdir -p logs
}

# Start PM2 application
start_application() {
    log_info "Starting PM2 application..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would start PM2 application"
        return 0
    fi
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    if [[ -n "$TARGET_APP" ]]; then
        log_info "Starting specific app: $TARGET_APP"
        if $pm2_cmd start "$TARGET_APP"; then
            log_success "Application $TARGET_APP started"
        else
            log_error "Failed to start application $TARGET_APP"
            return 1
        fi
    elif [[ -f "$ECOSYSTEM_FILE" ]]; then
        log_info "Starting from ecosystem file: $ECOSYSTEM_FILE"
        if $pm2_cmd start "$ECOSYSTEM_FILE"; then
            log_success "Applications started from ecosystem file"
        else
            log_error "Failed to start applications from ecosystem file"
            return 1
        fi
    else
        log_error "No ecosystem file found and no specific app specified"
        return 1
    fi
}

# Stop PM2 application
stop_application() {
    log_info "Stopping PM2 application..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would stop PM2 application"
        return 0
    fi
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    if [[ -n "$TARGET_APP" ]]; then
        log_info "Stopping specific app: $TARGET_APP"
        if $pm2_cmd stop "$TARGET_APP"; then
            log_success "Application $TARGET_APP stopped"
        else
            log_warning "Failed to stop application $TARGET_APP (may not be running)"
        fi
    else
        log_info "Stopping all applications"
        if $pm2_cmd stop all; then
            log_success "All applications stopped"
        else
            log_warning "Failed to stop some applications"
        fi
    fi
}

# Restart PM2 application
restart_application() {
    log_info "Restarting PM2 application..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would restart PM2 application"
        return 0
    fi
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    if [[ -n "$TARGET_APP" ]]; then
        log_info "Restarting specific app: $TARGET_APP"
        if $pm2_cmd restart "$TARGET_APP"; then
            log_success "Application $TARGET_APP restarted"
        else
            log_error "Failed to restart application $TARGET_APP"
            return 1
        fi
    else
        log_info "Restarting all applications"
        if $pm2_cmd restart all; then
            log_success "All applications restarted"
        else
            log_error "Failed to restart some applications"
            return 1
        fi
    fi
}

# Graceful reload PM2 application
reload_application() {
    log_info "Gracefully reloading PM2 application..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would reload PM2 application"
        return 0
    fi
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    if [[ -n "$TARGET_APP" ]]; then
        log_info "Reloading specific app: $TARGET_APP"
        if $pm2_cmd reload "$TARGET_APP"; then
            log_success "Application $TARGET_APP reloaded"
        else
            log_error "Failed to reload application $TARGET_APP"
            return 1
        fi
    else
        log_info "Reloading all applications"
        if $pm2_cmd reload all; then
            log_success "All applications reloaded"
        else
            log_error "Failed to reload some applications"
            return 1
        fi
    fi
}

# Delete PM2 application
delete_application() {
    log_info "Deleting PM2 application..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would delete PM2 application"
        return 0
    fi
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    if [[ -n "$TARGET_APP" ]]; then
        log_info "Deleting specific app: $TARGET_APP"
        if $pm2_cmd delete "$TARGET_APP"; then
            log_success "Application $TARGET_APP deleted"
        else
            log_warning "Failed to delete application $TARGET_APP (may not exist)"
        fi
    else
        log_warning "No specific app specified for deletion"
        log_info "Use --app APP_NAME to delete a specific application"
        log_info "Or use 'pm2 delete all' to delete all applications"
    fi
}

# Show PM2 status
show_status() {
    log_info "Showing PM2 status..."
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    log_info "=== PM2 Process Status ==="
    $pm2_cmd status
    
    log_info ""
    log_info "=== PM2 System Information ==="
    $pm2_cmd info
}

# Show PM2 logs
show_logs() {
    log_info "Showing PM2 logs..."
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    if [[ -n "$TARGET_APP" ]]; then
        log_info "Showing logs for: $TARGET_APP"
        $pm2_cmd logs "$TARGET_APP" --lines 50
    else
        log_info "Showing logs for all applications"
        $pm2_cmd logs --lines 50
    fi
}

# Monitor PM2 applications
monitor_applications() {
    log_info "Starting PM2 monitoring..."
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    log_info "=== PM2 Real-time Monitoring ==="
    log_info "Press Ctrl+C to exit monitoring"
    
    $pm2_cmd monit
}

# Setup PM2 startup script
setup_startup() {
    log_info "Setting up PM2 startup script..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would setup PM2 startup script"
        return 0
    fi
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    log_info "Generating startup script..."
    local startup_cmd
    startup_cmd=$($pm2_cmd startup | grep "sudo" | head -1)
    
    if [[ -n "$startup_cmd" ]]; then
        log_info "Execute this command to enable PM2 startup:"
        log_info "$startup_cmd"
        log_warning "Note: This requires sudo privileges"
    else
        log_error "Failed to generate startup command"
        return 1
    fi
}

# Save PM2 process list
save_processes() {
    log_info "Saving PM2 process list..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would save PM2 process list"
        return 0
    fi
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    if $pm2_cmd save; then
        log_success "PM2 process list saved"
    else
        log_error "Failed to save PM2 process list"
        return 1
    fi
}

# Resurrect saved PM2 processes
resurrect_processes() {
    log_info "Resurrecting saved PM2 processes..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would resurrect PM2 processes"
        return 0
    fi
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    if $pm2_cmd resurrect; then
        log_success "PM2 processes resurrected"
    else
        log_error "Failed to resurrect PM2 processes"
        return 1
    fi
}

# Flush PM2 logs
flush_logs() {
    log_info "Flushing PM2 logs..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would flush PM2 logs"
        return 0
    fi
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    if $pm2_cmd flush; then
        log_success "PM2 logs flushed"
    else
        log_error "Failed to flush PM2 logs"
        return 1
    fi
}

# Reset PM2 counters
reset_counters() {
    log_info "Resetting PM2 process counters..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would reset PM2 counters"
        return 0
    fi
    
    local pm2_cmd
    pm2_cmd=$(get_pm2_command)
    
    if $pm2_cmd reset all; then
        log_success "PM2 counters reset"
    else
        log_error "Failed to reset PM2 counters"
        return 1
    fi
}

# Execute action
execute_action() {
    case "$ACTION" in
        "status")
            show_status
            ;;
        "start")
            start_application
            ;;
        "stop")
            stop_application
            ;;
        "restart")
            restart_application
            ;;
        "reload")
            reload_application
            ;;
        "delete")
            delete_application
            ;;
        "logs")
            show_logs
            ;;
        "monitor")
            monitor_applications
            ;;
        "setup")
            setup_ecosystem
            ;;
        "startup")
            setup_startup
            ;;
        "save")
            save_processes
            ;;
        "resurrect")
            resurrect_processes
            ;;
        "flush")
            flush_logs
            ;;
        "reset")
            reset_counters
            ;;
        *)
            log_error "Unknown action: $ACTION"
            log_error "Valid actions: status, start, stop, restart, reload, delete, logs, monitor, setup, startup, save, resurrect, flush, reset"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== PM2 Manager Summary ==="
    log_info "Action: $ACTION"
    log_info "Target App: ${TARGET_APP:-"all"}"
    log_info "Project Path: $PROJECT_PATH"
    log_info "Ecosystem File: $ECOSYSTEM_FILE"
    log_info "Cluster Mode: $CLUSTER_MODE"
    log_info "Max Memory: $MAX_MEMORY"
    log_info "Instances: $INSTANCES"
    log_info ""
    
    log_info "=== Common Commands ==="
    log_info "Show status: $0 --action status"
    log_info "Start app: $0 --action start"
    log_info "Monitor: $0 --action monitor"
    log_info "View logs: $0 --action logs --app my-app"
    log_info "Setup ecosystem: $0 --action setup"
    
    log_info ""
    log_info "=== PM2 Web Interface ==="
    log_info "For web monitoring, install: pm2 install pm2-server-monit"
    log_info "Then access: http://localhost:9615"
    
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting PM2 management..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Action: $ACTION"
    
    check_prerequisites
    execute_action
    
    log_success "PM2 management completed successfully!"
    display_summary
}

# Execute main function
main "$@"