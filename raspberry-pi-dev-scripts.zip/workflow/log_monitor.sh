#!/bin/bash
#
# Log Monitoring and Aggregation Script for Development Workflow on Raspberry Pi 5
# Monitors, collects, and analyzes logs from React 19.1.0, NestJS 11.1.3, and system services
# Optimized for ARM64 architecture and multi-service development environments
#
# Usage: ./log_monitor.sh [--dry-run] [--action ACTION] [--service SERVICE]
# 
# Prerequisites:
# - Development services running (React, NestJS, PostgreSQL, etc.)
# - Log files accessible in standard locations
# - tail, grep, awk utilities available
# - Write access to log aggregation directory
#
# Features:
# - Real-time log monitoring and tailing
# - Log aggregation from multiple services
# - Error detection and alerting
# - Log rotation and cleanup
# - Performance metrics extraction
# - ARM64 optimized log processing
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/log_monitor.log"
DRY_RUN=false
ACTION="monitor"
TARGET_SERVICE=""
LOG_DIR="$HOME/development/logs"
AGGREGATED_LOG="$LOG_DIR/aggregated.log"
FOLLOW_MODE=false
ERROR_THRESHOLD=10
WATCH_INTERVAL=5
MAX_LOG_SIZE="100M"
RETENTION_DAYS=7

# Service log locations
declare -A SERVICE_LOGS=(
    ["react"]="$LOG_DIR/react-dev.log"
    ["nestjs"]="$LOG_DIR/nestjs-dev.log"
    ["postgresql"]="/var/log/postgresql/postgresql-17-main.log"
    ["nginx"]="/var/log/nginx/access.log"
    ["system"]="/var/log/syslog"
    ["pm2"]="$HOME/.pm2/logs"
)

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --action)
            ACTION="$2"
            shift 2
            ;;
        --service)
            TARGET_SERVICE="$2"
            shift 2
            ;;
        --log-dir)
            LOG_DIR="$2"
            shift 2
            ;;
        --follow)
            FOLLOW_MODE=true
            shift
            ;;
        --error-threshold)
            ERROR_THRESHOLD="$2"
            shift 2
            ;;
        --interval)
            WATCH_INTERVAL="$2"
            shift 2
            ;;
        --retention-days)
            RETENTION_DAYS="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--action ACTION] [--service SERVICE]"
            echo "Monitors and aggregates logs from development services"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --action ACTION        Action to perform (default: monitor)"
            echo "  --service SERVICE      Target specific service"
            echo "  --log-dir DIR          Log directory path (default: ~/development/logs)"
            echo "  --follow               Follow logs in real-time"
            echo "  --error-threshold N    Error count threshold for alerts (default: 10)"
            echo "  --interval N           Watch interval in seconds (default: 5)"
            echo "  --retention-days N     Log retention period (default: 7)"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Actions:"
            echo "  monitor                Monitor logs in real-time"
            echo "  aggregate              Aggregate logs from all services"
            echo "  analyze                Analyze logs for errors and patterns"
            echo "  tail                   Tail specific service logs"
            echo "  search                 Search logs for patterns"
            echo "  rotate                 Rotate and compress old logs"
            echo "  cleanup                Clean up old log files"
            echo "  status                 Show log status and statistics"
            echo ""
            echo "Services:"
            echo "  react                  React development server logs"
            echo "  nestjs                 NestJS application logs"
            echo "  postgresql             PostgreSQL database logs"
            echo "  nginx                  Nginx web server logs"
            echo "  system                 System logs"
            echo "  pm2                    PM2 process manager logs"
            echo "  all                    All available services"
            echo ""
            echo "Examples:"
            echo "  $0 --action monitor --follow"
            echo "  $0 --action tail --service nestjs --follow"
            echo "  $0 --action analyze --service react"
            echo "  $0 --action search --service all"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$LOG_DIR"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check required utilities
    local required_tools=("tail" "grep" "awk" "sort" "uniq" "wc")
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" >/dev/null 2>&1; then
            log_error "Required tool not found: $tool"
            exit 1
        fi
    done
    
    log_info "Required utilities available ✓"
    
    # Check log directory
    if [[ ! -d "$LOG_DIR" ]]; then
        log_info "Creating log directory: $LOG_DIR"
        mkdir -p "$LOG_DIR"
    fi
    
    # Check write permissions
    if [[ ! -w "$LOG_DIR" ]]; then
        log_error "No write permission to log directory: $LOG_DIR"
        exit 1
    fi
    
    log_info "Log directory accessible ✓"
    
    # Check ARM64 architecture
    if [[ "$(uname -m)" == "aarch64" ]]; then
        log_info "ARM64 architecture detected"
    else
        log_warning "Not running on ARM64 architecture: $(uname -m)"
    fi
    
    log_info "Prerequisites check completed"
}

# Get available log files
get_available_logs() {
    local available_logs=()
    
    for service in "${!SERVICE_LOGS[@]}"; do
        local log_path="${SERVICE_LOGS[$service]}"
        
        if [[ "$service" == "pm2" ]]; then
            # PM2 has multiple log files
            if [[ -d "$log_path" ]]; then
                available_logs+=("$service")
            fi
        else
            if [[ -f "$log_path" ]] && [[ -r "$log_path" ]]; then
                available_logs+=("$service")
            fi
        fi
    done
    
    printf '%s\n' "${available_logs[@]}"
}

# Get log file path for service
get_log_path() {
    local service=$1
    
    if [[ -n "${SERVICE_LOGS[$service]:-}" ]]; then
        echo "${SERVICE_LOGS[$service]}"
    else
        log_error "Unknown service: $service"
        return 1
    fi
}

# Monitor logs in real-time
monitor_logs() {
    log_info "Starting log monitoring..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would monitor logs in real-time"
        return 0
    fi
    
    local services_to_monitor=()
    
    if [[ -n "$TARGET_SERVICE" ]] && [[ "$TARGET_SERVICE" != "all" ]]; then
        services_to_monitor=("$TARGET_SERVICE")
    else
        readarray -t services_to_monitor < <(get_available_logs)
    fi
    
    if [[ ${#services_to_monitor[@]} -eq 0 ]]; then
        log_warning "No log files available for monitoring"
        return 0
    fi
    
    log_info "Monitoring services: ${services_to_monitor[*]}"
    
    # Create named pipes for log aggregation
    local temp_dir
    temp_dir=$(mktemp -d)
    local aggregation_pipe="$temp_dir/log_pipe"
    mkfifo "$aggregation_pipe"
    
    # Start log aggregation in background
    {
        while IFS= read -r line; do
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] $line" | tee -a "$AGGREGATED_LOG"
            
            # Check for errors
            if echo "$line" | grep -qi "error\|exception\|fatal\|critical"; then
                log_warning "Error detected: $line"
            fi
        done < "$aggregation_pipe"
    } &
    local aggregator_pid=$!
    
    # Start monitoring each service
    local monitor_pids=()
    
    for service in "${services_to_monitor[@]}"; do
        local log_path
        log_path=$(get_log_path "$service")
        
        if [[ "$service" == "pm2" ]]; then
            # Monitor all PM2 logs
            {
                find "$log_path" -name "*.log" -type f | while read -r pm2_log; do
                    tail -f "$pm2_log" 2>/dev/null | sed "s/^/[$service:$(basename "$pm2_log")] /" >> "$aggregation_pipe" &
                done
            } &
            monitor_pids+=($!)
        else
            {
                tail -f "$log_path" 2>/dev/null | sed "s/^/[$service] /" >> "$aggregation_pipe" &
            } &
            monitor_pids+=($!)
        fi
    done
    
    log_info "Log monitoring started (PID: ${monitor_pids[*]})"
    log_info "Aggregated logs: $AGGREGATED_LOG"
    log_info "Press Ctrl+C to stop monitoring"
    
    # Wait for interrupt
    trap 'log_info "Stopping log monitoring..."; kill ${monitor_pids[@]} $aggregator_pid 2>/dev/null; rm -rf "$temp_dir"; exit 0' INT
    
    if [[ "$FOLLOW_MODE" == "true" ]]; then
        wait
    else
        sleep "$WATCH_INTERVAL"
        kill "${monitor_pids[@]}" "$aggregator_pid" 2>/dev/null
        rm -rf "$temp_dir"
    fi
}

# Aggregate logs from all services
aggregate_logs() {
    log_info "Aggregating logs from all services..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would aggregate logs"
        return 0
    fi
    
    local services_to_aggregate=()
    readarray -t services_to_aggregate < <(get_available_logs)
    
    if [[ ${#services_to_aggregate[@]} -eq 0 ]]; then
        log_warning "No log files available for aggregation"
        return 0
    fi
    
    local temp_aggregate
    temp_aggregate=$(mktemp)
    
    log_info "Aggregating from services: ${services_to_aggregate[*]}"
    
    for service in "${services_to_aggregate[@]}"; do
        local log_path
        log_path=$(get_log_path "$service")
        
        if [[ "$service" == "pm2" ]]; then
            # Aggregate all PM2 logs
            find "$log_path" -name "*.log" -type f | while read -r pm2_log; do
                if [[ -r "$pm2_log" ]]; then
                    sed "s/^/[$service:$(basename "$pm2_log")] /" "$pm2_log" >> "$temp_aggregate"
                fi
            done
        else
            if [[ -r "$log_path" ]]; then
                sed "s/^/[$service] /" "$log_path" >> "$temp_aggregate"
            fi
        fi
    done
    
    # Sort by timestamp and save
    sort "$temp_aggregate" > "$AGGREGATED_LOG"
    rm "$temp_aggregate"
    
    local line_count
    line_count=$(wc -l < "$AGGREGATED_LOG")
    log_success "Aggregated $line_count log entries to: $AGGREGATED_LOG"
}

# Analyze logs for errors and patterns
analyze_logs() {
    log_info "Analyzing logs for errors and patterns..."
    
    local target_log="$AGGREGATED_LOG"
    
    if [[ -n "$TARGET_SERVICE" ]] && [[ "$TARGET_SERVICE" != "all" ]]; then
        target_log=$(get_log_path "$TARGET_SERVICE")
    fi
    
    if [[ ! -f "$target_log" ]]; then
        log_error "Log file not found: $target_log"
        return 1
    fi
    
    log_info "Analyzing: $target_log"
    log_info "=== Log Analysis Report ==="
    
    # Basic statistics
    local total_lines
    total_lines=$(wc -l < "$target_log")
    log_info "Total log entries: $total_lines"
    
    # Error analysis
    local error_count
    error_count=$(grep -ci "error\|exception\|fatal\|critical" "$target_log" || echo "0")
    log_info "Error entries: $error_count"
    
    if [[ "$error_count" -gt "$ERROR_THRESHOLD" ]]; then
        log_warning "Error count ($error_count) exceeds threshold ($ERROR_THRESHOLD)"
    fi
    
    # Warning analysis
    local warning_count
    warning_count=$(grep -ci "warn\|warning" "$target_log" || echo "0")
    log_info "Warning entries: $warning_count"
    
    # Top error patterns
    log_info ""
    log_info "Top error patterns:"
    grep -i "error\|exception\|fatal\|critical" "$target_log" | \
        awk '{for(i=1;i<=NF;i++) if($i ~ /[Ee]rror|[Ee]xception|[Ff]atal|[Cc]ritical/) print $i}' | \
        sort | uniq -c | sort -nr | head -10 || log_info "No error patterns found"
    
    # Recent errors (last 100 lines)
    log_info ""
    log_info "Recent errors (last 100 entries):"
    tail -100 "$target_log" | grep -i "error\|exception\|fatal\|critical" | tail -5 || log_info "No recent errors"
    
    # Performance indicators
    log_info ""
    log_info "Performance indicators:"
    
    # Response time analysis (if available)
    if grep -q "response time\|duration\|took" "$target_log"; then
        log_info "Response time entries found - analyzing..."
        grep -i "response time\|duration\|took" "$target_log" | tail -10
    fi
    
    # Memory usage indicators
    if grep -q "memory\|heap\|gc" "$target_log"; then
        log_info "Memory-related entries found"
        grep -i "memory\|heap\|gc" "$target_log" | tail -5
    fi
}

# Tail specific service logs
tail_service_logs() {
    if [[ -z "$TARGET_SERVICE" ]]; then
        log_error "Service required for tail action (--service SERVICE)"
        exit 1
    fi
    
    log_info "Tailing logs for service: $TARGET_SERVICE"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would tail logs for $TARGET_SERVICE"
        return 0
    fi
    
    local log_path
    log_path=$(get_log_path "$TARGET_SERVICE")
    
    if [[ "$TARGET_SERVICE" == "pm2" ]]; then
        # Tail all PM2 logs
        log_info "Tailing all PM2 logs in: $log_path"
        find "$log_path" -name "*.log" -type f | while read -r pm2_log; do
            echo "=== $(basename "$pm2_log") ==="
            tail -f "$pm2_log" &
        done
        wait
    else
        if [[ ! -f "$log_path" ]]; then
            log_error "Log file not found: $log_path"
            return 1
        fi
        
        log_info "Tailing: $log_path"
        
        if [[ "$FOLLOW_MODE" == "true" ]]; then
            tail -f "$log_path"
        else
            tail -20 "$log_path"
        fi
    fi
}

# Search logs for patterns
search_logs() {
    log_info "Searching logs for patterns..."
    
    echo "Enter search pattern (regex supported):"
    read -r search_pattern
    
    if [[ -z "$search_pattern" ]]; then
        log_error "No search pattern provided"
        return 1
    fi
    
    log_info "Searching for pattern: $search_pattern"
    
    local services_to_search=()
    
    if [[ -n "$TARGET_SERVICE" ]] && [[ "$TARGET_SERVICE" != "all" ]]; then
        services_to_search=("$TARGET_SERVICE")
    else
        readarray -t services_to_search < <(get_available_logs)
    fi
    
    local total_matches=0
    
    for service in "${services_to_search[@]}"; do
        local log_path
        log_path=$(get_log_path "$service")
        
        if [[ "$service" == "pm2" ]]; then
            find "$log_path" -name "*.log" -type f | while read -r pm2_log; do
                local matches
                matches=$(grep -c "$search_pattern" "$pm2_log" 2>/dev/null || echo "0")
                if [[ "$matches" -gt 0 ]]; then
                    log_info "[$service:$(basename "$pm2_log")] $matches matches"
                    grep -n "$search_pattern" "$pm2_log" | head -5
                    ((total_matches += matches))
                fi
            done
        else
            if [[ -f "$log_path" ]]; then
                local matches
                matches=$(grep -c "$search_pattern" "$log_path" 2>/dev/null || echo "0")
                if [[ "$matches" -gt 0 ]]; then
                    log_info "[$service] $matches matches"
                    grep -n "$search_pattern" "$log_path" | head -5
                    ((total_matches += matches))
                fi
            fi
        fi
    done
    
    log_success "Total matches found: $total_matches"
}

# Rotate and compress old logs
rotate_logs() {
    log_info "Rotating and compressing old logs..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would rotate logs"
        return 0
    fi
    
    local rotated_count=0
    
    # Rotate aggregated log
    if [[ -f "$AGGREGATED_LOG" ]]; then
        local log_size
        log_size=$(du -h "$AGGREGATED_LOG" | cut -f1)
        
        if [[ $(du -b "$AGGREGATED_LOG" | cut -f1) -gt $((100*1024*1024)) ]]; then  # 100MB
            local rotated_name="${AGGREGATED_LOG}.$(date +%Y%m%d_%H%M%S)"
            mv "$AGGREGATED_LOG" "$rotated_name"
            gzip "$rotated_name"
            touch "$AGGREGATED_LOG"
            log_info "Rotated aggregated log ($log_size) to: ${rotated_name}.gz"
            ((rotated_count++))
        fi
    fi
    
    # Rotate service logs
    for service in "${!SERVICE_LOGS[@]}"; do
        local log_path="${SERVICE_LOGS[$service]}"
        
        if [[ "$service" == "pm2" ]]; then
            continue  # PM2 handles its own log rotation
        fi
        
        if [[ -f "$log_path" ]] && [[ -w "$(dirname "$log_path")" ]]; then
            if [[ $(du -b "$log_path" | cut -f1) -gt $((50*1024*1024)) ]]; then  # 50MB
                local rotated_name="${log_path}.$(date +%Y%m%d_%H%M%S)"
                cp "$log_path" "$rotated_name"
                > "$log_path"  # Truncate original
                gzip "$rotated_name"
                log_info "Rotated $service log to: ${rotated_name}.gz"
                ((rotated_count++))
            fi
        fi
    done
    
    log_success "Rotated $rotated_count log files"
}

# Clean up old log files
cleanup_logs() {
    log_info "Cleaning up old log files..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would cleanup logs older than $RETENTION_DAYS days"
        return 0
    fi
    
    local cleaned_count=0
    
    # Clean up rotated logs
    find "$LOG_DIR" -name "*.log.*.gz" -type f -mtime +$RETENTION_DAYS | while read -r old_log; do
        rm "$old_log"
        log_info "Removed old log: $(basename "$old_log")"
        ((cleaned_count++))
    done
    
    # Clean up temporary files
    find "$LOG_DIR" -name "*.tmp" -type f -mtime +1 | while read -r temp_file; do
        rm "$temp_file"
        ((cleaned_count++))
    done
    
    log_success "Cleaned up $cleaned_count old log files"
}

# Show log status and statistics
show_log_status() {
    log_info "=== Log Status and Statistics ==="
    
    # Available services
    local available_services=()
    readarray -t available_services < <(get_available_logs)
    log_info "Available log services: ${available_services[*]}"
    
    # Log directory statistics
    local total_size
    total_size=$(du -sh "$LOG_DIR" 2>/dev/null | cut -f1 || echo "Unknown")
    log_info "Log directory size: $total_size"
    
    local file_count
    file_count=$(find "$LOG_DIR" -type f -name "*.log*" | wc -l)
    log_info "Total log files: $file_count"
    
    # Individual service statistics
    log_info ""
    log_info "Service log details:"
    
    for service in "${available_services[@]}"; do
        local log_path
        log_path=$(get_log_path "$service")
        
        if [[ "$service" == "pm2" ]]; then
            local pm2_files
            pm2_files=$(find "$log_path" -name "*.log" -type f | wc -l)
            local pm2_size
            pm2_size=$(du -sh "$log_path" 2>/dev/null | cut -f1 || echo "Unknown")
            log_info "  $service: $pm2_files files, $pm2_size total"
        else
            if [[ -f "$log_path" ]]; then
                local file_size
                file_size=$(du -sh "$log_path" | cut -f1)
                local line_count
                line_count=$(wc -l < "$log_path")
                log_info "  $service: $file_size, $line_count lines"
            fi
        fi
    done
    
    # Recent activity
    log_info ""
    log_info "Recent log activity (last 24 hours):"
    
    find "$LOG_DIR" -name "*.log" -type f -newermt "24 hours ago" | while read -r recent_log; do
        local recent_size
        recent_size=$(du -sh "$recent_log" | cut -f1)
        log_info "  $(basename "$recent_log"): $recent_size (modified: $(stat -c %y "$recent_log" | cut -d. -f1))"
    done
}

# Execute action
execute_action() {
    case "$ACTION" in
        "monitor")
            monitor_logs
            ;;
        "aggregate")
            aggregate_logs
            ;;
        "analyze")
            analyze_logs
            ;;
        "tail")
            tail_service_logs
            ;;
        "search")
            search_logs
            ;;
        "rotate")
            rotate_logs
            ;;
        "cleanup")
            cleanup_logs
            ;;
        "status")
            show_log_status
            ;;
        *)
            log_error "Unknown action: $ACTION"
            log_error "Valid actions: monitor, aggregate, analyze, tail, search, rotate, cleanup, status"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== Log Monitor Summary ==="
    log_info "Action: $ACTION"
    log_info "Target Service: ${TARGET_SERVICE:-"all"}"
    log_info "Log Directory: $LOG_DIR"
    log_info "Aggregated Log: $AGGREGATED_LOG"
    log_info "Follow Mode: $FOLLOW_MODE"
    log_info "Error Threshold: $ERROR_THRESHOLD"
    log_info "Retention Days: $RETENTION_DAYS"
    log_info ""
    
    log_info "=== Common Commands ==="
    log_info "Monitor all: $0 --action monitor --follow"
    log_info "Tail service: $0 --action tail --service nestjs --follow"
    log_info "Analyze errors: $0 --action analyze"
    log_info "Search logs: $0 --action search"
    log_info "Show status: $0 --action status"
    
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting log monitoring..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Action: $ACTION"
    
    check_prerequisites
    execute_action
    
    log_success "Log monitoring completed successfully!"
    display_summary
}

# Execute main function
main "$@"