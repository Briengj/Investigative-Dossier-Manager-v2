#!/bin/bash
#
# Git Workflow Automation Script for Development Projects on Raspberry Pi 5
# Configures Git hooks, lint-staged, Husky, and automated workflow processes
# Optimized for React 19.1.0, NestJS 11.1.3, and TypeScript 5.8.3 projects
#
# Usage: ./git_workflow.sh [--dry-run] [--action ACTION] [--project-path PATH]
# 
# Prerequisites:
# - Git repository initialized
# - Node.js 20 LTS with npm
# - ESLint, Prettier, and other quality tools configured
# - package.json with proper scripts
#
# Features:
# - Husky Git hooks setup and management
# - lint-staged configuration for staged files
# - Commitlint for conventional commit messages
# - Pre-commit quality checks automation
# - Branch protection and workflow rules
# - Automated code formatting and linting
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/git_workflow.log"
DRY_RUN=false
ACTION="setup"
PROJECT_PATH="$(pwd)"
ENABLE_COMMITLINT=true
ENABLE_LINT_STAGED=true
ENABLE_PRE_PUSH=true
CONVENTIONAL_COMMITS=true

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --action)
            ACTION="$2"
            shift 2
            ;;
        --project-path)
            PROJECT_PATH="$2"
            shift 2
            ;;
        --no-commitlint)
            ENABLE_COMMITLINT=false
            shift
            ;;
        --no-lint-staged)
            ENABLE_LINT_STAGED=false
            shift
            ;;
        --no-pre-push)
            ENABLE_PRE_PUSH=false
            shift
            ;;
        --no-conventional)
            CONVENTIONAL_COMMITS=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--action ACTION] [--project-path PATH]"
            echo "Configures Git workflow automation for development projects"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --action ACTION        Action to perform (default: setup)"
            echo "  --project-path PATH    Project directory path (default: current directory)"
            echo "  --no-commitlint        Skip commitlint configuration"
            echo "  --no-lint-staged       Skip lint-staged configuration"
            echo "  --no-pre-push          Skip pre-push hook setup"
            echo "  --no-conventional      Disable conventional commit enforcement"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Actions:"
            echo "  setup                  Setup complete Git workflow automation"
            echo "  install-hooks          Install Git hooks with Husky"
            echo "  configure-lint         Configure lint-staged for quality checks"
            echo "  setup-commitlint       Setup commitlint for conventional commits"
            echo "  create-templates       Create commit and PR templates"
            echo "  validate               Validate current Git workflow setup"
            echo "  test-hooks             Test Git hooks functionality"
            echo "  remove-hooks           Remove Git hooks and cleanup"
            echo "  status                 Show Git workflow status"
            echo ""
            echo "Examples:"
            echo "  $0 --action setup"
            echo "  $0 --action install-hooks --project-path /path/to/project"
            echo "  $0 --action test-hooks"
            echo "  $0 --action validate"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Git
    if ! command -v git >/dev/null 2>&1; then
        log_error "Git is not installed"
        exit 1
    fi
    
    local git_version
    git_version=$(git --version | awk '{print $3}')
    log_info "Git version: $git_version ✓"
    
    # Check Node.js and npm
    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not in PATH"
        exit 1
    fi
    
    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not available"
        exit 1
    fi
    
    local node_version npm_version
    node_version=$(node --version)
    npm_version=$(npm --version)
    log_info "Node.js version: $node_version ✓"
    log_info "npm version: v$npm_version ✓"
    
    # Check project directory
    if [[ ! -d "$PROJECT_PATH" ]]; then
        log_error "Project directory does not exist: $PROJECT_PATH"
        exit 1
    fi
    
    # Change to project directory
    cd "$PROJECT_PATH"
    log_info "Working in project directory: $(pwd)"
    
    # Check if it's a Git repository
    if ! git rev-parse --git-dir >/dev/null 2>&1; then
        log_error "Not a Git repository. Initialize with: git init"
        exit 1
    fi
    
    log_info "Git repository detected ✓"
    
    # Check package.json
    if [[ ! -f "package.json" ]]; then
        log_error "package.json not found - Node.js project required"
        exit 1
    fi
    
    log_info "Node.js project detected ✓"
    
    log_info "Prerequisites check completed"
}

# Detect project type for appropriate configuration
detect_project_type() {
    log_info "Detecting project type..."
    
    local project_type="nodejs"
    
    if grep -q '"react"' package.json 2>/dev/null; then
        project_type="react"
    elif grep -q '"@nestjs/core"' package.json 2>/dev/null; then
        project_type="nestjs"
    elif grep -q '"next"' package.json 2>/dev/null; then
        project_type="nextjs"
    elif grep -q '"typescript"' package.json 2>/dev/null; then
        project_type="typescript"
    fi
    
    log_info "Project type detected: $project_type"
    echo "$project_type"
}

# Install required dependencies
install_dependencies() {
    log_info "Installing Git workflow dependencies..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would install dependencies"
        return 0
    fi
    
    local deps=("husky")
    
    if [[ "$ENABLE_LINT_STAGED" == "true" ]]; then
        deps+=("lint-staged")
    fi
    
    if [[ "$ENABLE_COMMITLINT" == "true" ]]; then
        deps+=("@commitlint/cli" "@commitlint/config-conventional")
    fi
    
    log_info "Installing dependencies: ${deps[*]}"
    
    if npm install --save-dev "${deps[@]}"; then
        log_success "Dependencies installed successfully"
    else
        log_error "Failed to install dependencies"
        return 1
    fi
}

# Setup Husky Git hooks
setup_husky() {
    log_info "Setting up Husky Git hooks..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would setup Husky"
        return 0
    fi
    
    # Initialize Husky
    if npx husky install; then
        log_success "Husky initialized"
    else
        log_error "Failed to initialize Husky"
        return 1
    fi
    
    # Add prepare script to package.json
    npm pkg set scripts.prepare="husky install"
    log_info "Added prepare script to package.json"
    
    # Create pre-commit hook
    if [[ "$ENABLE_LINT_STAGED" == "true" ]]; then
        npx husky add .husky/pre-commit "npx lint-staged"
        log_info "Created pre-commit hook with lint-staged"
    else
        npx husky add .husky/pre-commit "npm run lint && npm run format:check"
        log_info "Created pre-commit hook with basic linting"
    fi
    
    # Create commit-msg hook for commitlint
    if [[ "$ENABLE_COMMITLINT" == "true" ]]; then
        npx husky add .husky/commit-msg 'npx --no -- commitlint --edit ${1}'
        log_info "Created commit-msg hook with commitlint"
    fi
    
    # Create pre-push hook
    if [[ "$ENABLE_PRE_PUSH" == "true" ]]; then
        npx husky add .husky/pre-push "npm run test"
        log_info "Created pre-push hook with tests"
    fi
    
    log_success "Husky setup completed"
}

# Configure lint-staged
configure_lint_staged() {
    if [[ "$ENABLE_LINT_STAGED" != "true" ]]; then
        log_info "Skipping lint-staged configuration (disabled)"
        return 0
    fi
    
    log_info "Configuring lint-staged..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would configure lint-staged"
        return 0
    fi
    
    local project_type
    project_type=$(detect_project_type)
    
    # Configure lint-staged based on project type
    case "$project_type" in
        "react")
            npm pkg set lint-staged.*.{ts,tsx}="eslint --fix"
            npm pkg set lint-staged.*.{js,jsx}="eslint --fix"
            npm pkg set lint-staged.*.{ts,tsx,js,jsx,css,scss,json,md}="prettier --write"
            ;;
        "nestjs")
            npm pkg set lint-staged.*.ts="eslint --fix"
            npm pkg set lint-staged.*.{ts,js,json,md}="prettier --write"
            ;;
        "typescript")
            npm pkg set lint-staged.*.ts="eslint --fix"
            npm pkg set lint-staged.*.{ts,js,json,md}="prettier --write"
            ;;
        *)
            npm pkg set lint-staged.*.js="eslint --fix"
            npm pkg set lint-staged.*.{js,json,md}="prettier --write"
            ;;
    esac
    
    log_success "lint-staged configured for $project_type project"
}

# Setup commitlint
setup_commitlint() {
    if [[ "$ENABLE_COMMITLINT" != "true" ]]; then
        log_info "Skipping commitlint configuration (disabled)"
        return 0
    fi
    
    log_info "Setting up commitlint..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would setup commitlint"
        return 0
    fi
    
    # Create commitlint configuration
    cat > commitlint.config.js << 'EOF'
module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'type-enum': [
      2,
      'always',
      [
        'feat',     // New feature
        'fix',      // Bug fix
        'docs',     // Documentation changes
        'style',    // Code style changes (formatting, etc.)
        'refactor', // Code refactoring
        'perf',     // Performance improvements
        'test',     // Adding or updating tests
        'chore',    // Maintenance tasks
        'ci',       // CI/CD changes
        'build',    // Build system changes
        'revert'    // Revert previous commit
      ]
    ],
    'type-case': [2, 'always', 'lower-case'],
    'type-empty': [2, 'never'],
    'scope-case': [2, 'always', 'lower-case'],
    'subject-case': [2, 'never', ['sentence-case', 'start-case', 'pascal-case', 'upper-case']],
    'subject-empty': [2, 'never'],
    'subject-full-stop': [2, 'never', '.'],
    'header-max-length': [2, 'always', 72],
    'body-leading-blank': [1, 'always'],
    'body-max-line-length': [2, 'always', 100],
    'footer-leading-blank': [1, 'always'],
    'footer-max-line-length': [2, 'always', 100]
  }
};
EOF
    
    log_success "commitlint configuration created"
}

# Create commit and PR templates
create_templates() {
    log_info "Creating commit and PR templates..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would create templates"
        return 0
    fi
    
    # Create .gitmessage template
    cat > .gitmessage << 'EOF'
# <type>(<scope>): <subject>
#
# <body>
#
# <footer>

# Type should be one of the following:
# * feat: A new feature
# * fix: A bug fix
# * docs: Documentation only changes
# * style: Changes that do not affect the meaning of the code
# * refactor: A code change that neither fixes a bug nor adds a feature
# * perf: A code change that improves performance
# * test: Adding missing tests or correcting existing tests
# * chore: Changes to the build process or auxiliary tools
# * ci: Changes to CI configuration files and scripts
# * build: Changes that affect the build system or external dependencies
# * revert: Reverts a previous commit

# Scope is optional and should be the name of the package affected
# Subject should use imperative, present tense: "change" not "changed" nor "changes"
# Body should include motivation for the change and contrast with previous behavior
# Footer should contain any information about Breaking Changes and reference GitHub issues

# Examples:
# feat(auth): add OAuth2 authentication
# fix(api): resolve user data validation error
# docs(readme): update installation instructions
# style: fix code formatting issues
# refactor(utils): simplify date formatting function
# perf(db): optimize database query performance
# test(auth): add unit tests for login functionality
# chore(deps): update dependencies to latest versions
EOF
    
    # Configure Git to use the template
    git config commit.template .gitmessage
    log_info "Git commit template configured"
    
    # Create GitHub templates directory
    mkdir -p .github
    
    # Create pull request template
    cat > .github/pull_request_template.md << 'EOF'
## Description
Brief description of the changes in this PR.

## Type of Change
- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Code refactoring
- [ ] Performance improvement
- [ ] Test addition or update

## Testing
- [ ] Tests pass locally
- [ ] New tests added for new functionality
- [ ] Manual testing completed

## Checklist
- [ ] Code follows the project's style guidelines
- [ ] Self-review of code completed
- [ ] Code is commented, particularly in hard-to-understand areas
- [ ] Documentation updated if necessary
- [ ] No new warnings introduced
- [ ] Tests added that prove the fix is effective or that the feature works

## Related Issues
Closes #(issue number)

## Screenshots (if applicable)
Add screenshots to help explain your changes.

## Additional Notes
Any additional information or context about the PR.
EOF
    
    # Create issue templates
    mkdir -p .github/ISSUE_TEMPLATE
    
    cat > .github/ISSUE_TEMPLATE/bug_report.md << 'EOF'
---
name: Bug report
about: Create a report to help us improve
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description
A clear and concise description of what the bug is.

## Steps to Reproduce
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

## Expected Behavior
A clear and concise description of what you expected to happen.

## Actual Behavior
A clear and concise description of what actually happened.

## Screenshots
If applicable, add screenshots to help explain your problem.

## Environment
- OS: [e.g. Raspberry Pi OS]
- Node.js version: [e.g. 20.9.0]
- Browser: [e.g. Chrome, Safari]
- Version: [e.g. 22]

## Additional Context
Add any other context about the problem here.
EOF
    
    cat > .github/ISSUE_TEMPLATE/feature_request.md << 'EOF'
---
name: Feature request
about: Suggest an idea for this project
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

## Feature Description
A clear and concise description of what you want to happen.

## Problem Statement
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

## Proposed Solution
A clear and concise description of what you want to happen.

## Alternative Solutions
A clear and concise description of any alternative solutions or features you've considered.

## Additional Context
Add any other context or screenshots about the feature request here.

## Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3
EOF
    
    log_success "Templates created successfully"
}

# Validate Git workflow setup
validate_setup() {
    log_info "Validating Git workflow setup..."
    
    local validation_errors=0
    
    # Check Husky installation
    if [[ -d ".husky" ]]; then
        log_success "Husky directory exists"
    else
        log_error "Husky directory not found"
        ((validation_errors++))
    fi
    
    # Check pre-commit hook
    if [[ -f ".husky/pre-commit" ]]; then
        log_success "Pre-commit hook exists"
    else
        log_error "Pre-commit hook not found"
        ((validation_errors++))
    fi
    
    # Check commitlint if enabled
    if [[ "$ENABLE_COMMITLINT" == "true" ]]; then
        if [[ -f "commitlint.config.js" ]]; then
            log_success "Commitlint configuration exists"
        else
            log_error "Commitlint configuration not found"
            ((validation_errors++))
        fi
        
        if [[ -f ".husky/commit-msg" ]]; then
            log_success "Commit-msg hook exists"
        else
            log_error "Commit-msg hook not found"
            ((validation_errors++))
        fi
    fi
    
    # Check lint-staged if enabled
    if [[ "$ENABLE_LINT_STAGED" == "true" ]]; then
        if npm pkg get lint-staged >/dev/null 2>&1; then
            log_success "lint-staged configuration exists"
        else
            log_error "lint-staged configuration not found"
            ((validation_errors++))
        fi
    fi
    
    # Check dependencies
    local required_deps=("husky")
    if [[ "$ENABLE_LINT_STAGED" == "true" ]]; then
        required_deps+=("lint-staged")
    fi
    if [[ "$ENABLE_COMMITLINT" == "true" ]]; then
        required_deps+=("@commitlint/cli" "@commitlint/config-conventional")
    fi
    
    for dep in "${required_deps[@]}"; do
        if npm list "$dep" --depth=0 >/dev/null 2>&1; then
            log_success "Dependency $dep is installed"
        else
            log_error "Dependency $dep is missing"
            ((validation_errors++))
        fi
    done
    
    # Check templates
    if [[ -f ".gitmessage" ]]; then
        log_success "Git commit template exists"
    else
        log_warning "Git commit template not found"
    fi
    
    if [[ -f ".github/pull_request_template.md" ]]; then
        log_success "PR template exists"
    else
        log_warning "PR template not found"
    fi
    
    if [[ $validation_errors -eq 0 ]]; then
        log_success "Git workflow validation passed"
        return 0
    else
        log_error "Git workflow validation failed with $validation_errors errors"
        return 1
    fi
}

# Test Git hooks functionality
test_hooks() {
    log_info "Testing Git hooks functionality..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would test Git hooks"
        return 0
    fi
    
    # Create a test file
    local test_file="test_git_workflow.tmp"
    echo "// Test file for Git workflow" > "$test_file"
    
    # Add to staging
    git add "$test_file"
    
    # Test pre-commit hook (this will run lint-staged or other checks)
    log_info "Testing pre-commit hook..."
    if .husky/pre-commit; then
        log_success "Pre-commit hook executed successfully"
    else
        log_warning "Pre-commit hook failed (this may be expected if there are linting issues)"
    fi
    
    # Clean up
    git reset HEAD "$test_file"
    rm -f "$test_file"
    
    # Test commitlint if enabled
    if [[ "$ENABLE_COMMITLINT" == "true" ]] && [[ -f ".husky/commit-msg" ]]; then
        log_info "Testing commitlint..."
        
        # Create a temporary commit message file
        local temp_msg
        temp_msg=$(mktemp)
        echo "feat: test commit message" > "$temp_msg"
        
        if .husky/commit-msg "$temp_msg"; then
            log_success "Commitlint validation passed"
        else
            log_error "Commitlint validation failed"
        fi
        
        rm -f "$temp_msg"
    fi
    
    log_success "Git hooks testing completed"
}

# Remove Git hooks and cleanup
remove_hooks() {
    log_info "Removing Git hooks and cleaning up..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would remove Git hooks"
        return 0
    fi
    
    # Remove Husky directory
    if [[ -d ".husky" ]]; then
        rm -rf .husky
        log_info "Removed .husky directory"
    fi
    
    # Remove commitlint configuration
    if [[ -f "commitlint.config.js" ]]; then
        rm commitlint.config.js
        log_info "Removed commitlint configuration"
    fi
    
    # Remove Git commit template
    if [[ -f ".gitmessage" ]]; then
        rm .gitmessage
        git config --unset commit.template || true
        log_info "Removed Git commit template"
    fi
    
    # Remove lint-staged configuration from package.json
    npm pkg delete lint-staged 2>/dev/null || true
    
    # Remove prepare script
    npm pkg delete scripts.prepare 2>/dev/null || true
    
    log_success "Git hooks and configuration removed"
}

# Show Git workflow status
show_status() {
    log_info "=== Git Workflow Status ==="
    
    # Git repository info
    log_info "Repository: $(git remote get-url origin 2>/dev/null || echo "No remote configured")"
    log_info "Current branch: $(git branch --show-current)"
    log_info "Last commit: $(git log -1 --oneline)"
    
    # Husky status
    if [[ -d ".husky" ]]; then
        log_info "Husky: Installed ✓"
        log_info "Hooks:"
        find .husky -type f -executable | while read -r hook; do
            log_info "  - $(basename "$hook")"
        done
    else
        log_info "Husky: Not installed ✗"
    fi
    
    # Dependencies status
    log_info ""
    log_info "Dependencies:"
    local deps=("husky" "lint-staged" "@commitlint/cli" "@commitlint/config-conventional")
    for dep in "${deps[@]}"; do
        if npm list "$dep" --depth=0 >/dev/null 2>&1; then
            local version
            version=$(npm list "$dep" --depth=0 2>/dev/null | grep "$dep" | awk '{print $2}' || echo "unknown")
            log_info "  - $dep: $version ✓"
        else
            log_info "  - $dep: Not installed ✗"
        fi
    done
    
    # Configuration files
    log_info ""
    log_info "Configuration files:"
    [[ -f "commitlint.config.js" ]] && log_info "  - commitlint.config.js ✓" || log_info "  - commitlint.config.js ✗"
    [[ -f ".gitmessage" ]] && log_info "  - .gitmessage ✓" || log_info "  - .gitmessage ✗"
    [[ -f ".github/pull_request_template.md" ]] && log_info "  - PR template ✓" || log_info "  - PR template ✗"
    
    # lint-staged configuration
    if npm pkg get lint-staged >/dev/null 2>&1; then
        log_info "  - lint-staged configuration ✓"
    else
        log_info "  - lint-staged configuration ✗"
    fi
}

# Execute action
execute_action() {
    case "$ACTION" in
        "setup")
            install_dependencies
            setup_husky
            configure_lint_staged
            setup_commitlint
            create_templates
            validate_setup
            ;;
        "install-hooks")
            install_dependencies
            setup_husky
            ;;
        "configure-lint")
            configure_lint_staged
            ;;
        "setup-commitlint")
            setup_commitlint
            ;;
        "create-templates")
            create_templates
            ;;
        "validate")
            validate_setup
            ;;
        "test-hooks")
            test_hooks
            ;;
        "remove-hooks")
            remove_hooks
            ;;
        "status")
            show_status
            ;;
        *)
            log_error "Unknown action: $ACTION"
            log_error "Valid actions: setup, install-hooks, configure-lint, setup-commitlint, create-templates, validate, test-hooks, remove-hooks, status"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== Git Workflow Summary ==="
    log_info "Action: $ACTION"
    log_info "Project Path: $PROJECT_PATH"
    log_info "Commitlint Enabled: $ENABLE_COMMITLINT"
    log_info "lint-staged Enabled: $ENABLE_LINT_STAGED"
    log_info "Pre-push Hook: $ENABLE_PRE_PUSH"
    log_info "Conventional Commits: $CONVENTIONAL_COMMITS"
    log_info ""
    
    log_info "=== Git Workflow Features ==="
    log_info "✓ Pre-commit hooks with quality checks"
    log_info "✓ Automated code formatting and linting"
    log_info "✓ Conventional commit message enforcement"
    log_info "✓ Pull request and issue templates"
    log_info "✓ Automated testing before push"
    
    log_info ""
    log_info "=== Usage Examples ==="
    log_info "Commit with conventional format:"
    log_info "  git commit -m 'feat(auth): add OAuth2 authentication'"
    log_info ""
    log_info "Common commit types:"
    log_info "  feat: new feature"
    log_info "  fix: bug fix"
    log_info "  docs: documentation"
    log_info "  style: formatting"
    log_info "  refactor: code refactoring"
    log_info "  test: add tests"
    log_info "  chore: maintenance"
    
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting Git workflow automation..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Action: $ACTION"
    
    check_prerequisites
    execute_action
    
    log_success "Git workflow automation completed successfully!"
    display_summary
}

# Execute main function
main "$@"