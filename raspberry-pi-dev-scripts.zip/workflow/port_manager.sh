#!/bin/bash
#
# Port Management Utilities for Development Workflow on Raspberry Pi 5
# Manages port allocation, conflict detection, and service monitoring
# Optimized for React 19.1.0, NestJS 11.1.3, and multi-service development
#
# Usage: ./port_manager.sh [--dry-run] [--action ACTION] [--port PORT]
# 
# Prerequisites:
# - Linux system with netstat, ss, or lsof available
# - Development services running on various ports
# - Network utilities for port scanning
# - Write access to port registry file
#
# Features:
# - Port availability checking
# - Port conflict detection and resolution
# - Service port registry management
# - Port range allocation for projects
# - Network service monitoring
# - Firewall port management integration
#
# Author: Development Scripts Collection
# Version: 1.0
# Date: 2025-07-16

set -euo pipefail

# Global variables
SCRIPT_NAME="$(basename "$0")"
LOG_FILE="$HOME/development/logs/port_manager.log"
DRY_RUN=false
ACTION="status"
TARGET_PORT=""
SERVICE_NAME=""
PORT_REGISTRY="$HOME/development/config/port_registry.json"
PORT_RANGE_START=3000
PORT_RANGE_END=9999
RESERVED_PORTS=(22 80 443 5432 6379 8080)

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --action)
            ACTION="$2"
            shift 2
            ;;
        --port)
            TARGET_PORT="$2"
            shift 2
            ;;
        --service)
            SERVICE_NAME="$2"
            shift 2
            ;;
        --range-start)
            PORT_RANGE_START="$2"
            shift 2
            ;;
        --range-end)
            PORT_RANGE_END="$2"
            shift 2
            ;;
        --registry)
            PORT_REGISTRY="$2"
            shift 2
            ;;
        -h|--help)
            echo "Usage: $0 [--dry-run] [--action ACTION] [--port PORT]"
            echo "Manages development server ports and resolves conflicts"
            echo ""
            echo "Options:"
            echo "  --dry-run              Show what would be done without making changes"
            echo "  --action ACTION        Action to perform (default: status)"
            echo "  --port PORT            Target port number"
            echo "  --service SERVICE      Service name for port registration"
            echo "  --range-start N        Port range start (default: 3000)"
            echo "  --range-end N          Port range end (default: 9999)"
            echo "  --registry FILE        Port registry file path"
            echo "  -h, --help             Show this help message"
            echo ""
            echo "Actions:"
            echo "  status                 Show port usage status"
            echo "  check                  Check if specific port is available"
            echo "  find                   Find next available port"
            echo "  register               Register port for service"
            echo "  unregister             Unregister port from service"
            echo "  kill                   Kill process using specific port"
            echo "  scan                   Scan port range for usage"
            echo "  cleanup                Clean up stale port registrations"
            echo "  firewall               Manage firewall rules for ports"
            echo ""
            echo "Examples:"
            echo "  $0 --action status"
            echo "  $0 --action check --port 3000"
            echo "  $0 --action find --range-start 5000"
            echo "  $0 --action register --port 3000 --service react-app"
            echo "  $0 --action kill --port 3000"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Create registry directory
mkdir -p "$(dirname "$PORT_REGISTRY")"

# Logging functions
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2 | tee -a "$LOG_FILE"
}

log_warning() {
    echo "[WARNING] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

log_success() {
    echo "[SUCCESS] $(date '+%Y-%m-%d %H:%M:%S') $*" | tee -a "$LOG_FILE"
}

# Error handling
cleanup() {
    local exit_code=$?
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script failed with exit code $exit_code"
        log_error "Check $LOG_FILE for details"
    fi
    exit $exit_code
}

trap cleanup EXIT

# Validation functions
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check for network utilities
    local net_tools_available=false
    
    if command -v netstat >/dev/null 2>&1; then
        log_info "netstat available ✓"
        net_tools_available=true
    fi
    
    if command -v ss >/dev/null 2>&1; then
        log_info "ss available ✓"
        net_tools_available=true
    fi
    
    if command -v lsof >/dev/null 2>&1; then
        log_info "lsof available ✓"
        net_tools_available=true
    fi
    
    if [[ "$net_tools_available" != "true" ]]; then
        log_error "No network utilities found (netstat, ss, or lsof required)"
        log_error "Install with: sudo apt install net-tools lsof"
        exit 1
    fi
    
    # Check for jq (for JSON handling)
    if ! command -v jq >/dev/null 2>&1; then
        log_warning "jq not found - JSON registry features will be limited"
        log_info "Install with: sudo apt install jq"
    else
        log_info "jq available ✓"
    fi
    
    # Validate port range
    if [[ "$PORT_RANGE_START" -ge "$PORT_RANGE_END" ]]; then
        log_error "Invalid port range: $PORT_RANGE_START >= $PORT_RANGE_END"
        exit 1
    fi
    
    log_info "Prerequisites check completed"
}

# Initialize port registry
initialize_registry() {
    if [[ ! -f "$PORT_REGISTRY" ]]; then
        log_info "Creating port registry: $PORT_REGISTRY"
        
        if [[ "$DRY_RUN" == "true" ]]; then
            log_info "[DRY RUN] Would create port registry"
            return 0
        fi
        
        cat > "$PORT_REGISTRY" << 'EOF'
{
  "version": "1.0",
  "created": "",
  "last_updated": "",
  "ports": {},
  "reserved": [22, 80, 443, 5432, 6379, 8080],
  "ranges": {
    "development": {"start": 3000, "end": 3999},
    "testing": {"start": 4000, "end": 4999},
    "staging": {"start": 5000, "end": 5999},
    "services": {"start": 6000, "end": 6999}
  }
}
EOF
        
        # Update timestamps
        if command -v jq >/dev/null 2>&1; then
            local timestamp
            timestamp=$(date -Iseconds)
            jq --arg ts "$timestamp" '.created = $ts | .last_updated = $ts' "$PORT_REGISTRY" > "${PORT_REGISTRY}.tmp" && mv "${PORT_REGISTRY}.tmp" "$PORT_REGISTRY"
        fi
        
        log_success "Port registry created"
    else
        log_info "Port registry exists: $PORT_REGISTRY"
    fi
}

# Check if port is available
is_port_available() {
    local port=$1
    
    # Check with netstat
    if command -v netstat >/dev/null 2>&1; then
        if netstat -tuln 2>/dev/null | grep -q ":$port "; then
            return 1
        fi
    fi
    
    # Check with ss
    if command -v ss >/dev/null 2>&1; then
        if ss -tuln 2>/dev/null | grep -q ":$port "; then
            return 1
        fi
    fi
    
    # Check with lsof
    if command -v lsof >/dev/null 2>&1; then
        if lsof -i ":$port" >/dev/null 2>&1; then
            return 1
        fi
    fi
    
    return 0
}

# Get process using port
get_port_process() {
    local port=$1
    
    # Try lsof first (most detailed)
    if command -v lsof >/dev/null 2>&1; then
        lsof -i ":$port" 2>/dev/null | tail -n +2 | while read -r line; do
            echo "$line" | awk '{print $1 " (PID: " $2 ")"}'
        done
        return 0
    fi
    
    # Try netstat
    if command -v netstat >/dev/null 2>&1; then
        netstat -tulnp 2>/dev/null | grep ":$port " | while read -r line; do
            echo "$line" | awk '{print $7}' | sed 's|/| (PID: |; s|$|)|'
        done
        return 0
    fi
    
    # Try ss
    if command -v ss >/dev/null 2>&1; then
        ss -tulnp 2>/dev/null | grep ":$port " | while read -r line; do
            echo "$line" | awk '{print $6}' | sed 's|users:(("||; s|".*||'
        done
        return 0
    fi
    
    echo "Unknown process"
}

# Find next available port
find_available_port() {
    local start_port=${1:-$PORT_RANGE_START}
    local end_port=${2:-$PORT_RANGE_END}
    
    for ((port=start_port; port<=end_port; port++)); do
        # Skip reserved ports
        local is_reserved=false
        for reserved in "${RESERVED_PORTS[@]}"; do
            if [[ "$port" -eq "$reserved" ]]; then
                is_reserved=true
                break
            fi
        done
        
        if [[ "$is_reserved" == "true" ]]; then
            continue
        fi
        
        if is_port_available "$port"; then
            echo "$port"
            return 0
        fi
    done
    
    return 1
}

# Register port for service
register_port() {
    local port=$1
    local service=$2
    
    log_info "Registering port $port for service: $service"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would register port $port for $service"
        return 0
    fi
    
    initialize_registry
    
    if command -v jq >/dev/null 2>&1; then
        local timestamp
        timestamp=$(date -Iseconds)
        
        jq --arg port "$port" --arg service "$service" --arg ts "$timestamp" \
           '.ports[$port] = {"service": $service, "registered": $ts, "pid": null} | .last_updated = $ts' \
           "$PORT_REGISTRY" > "${PORT_REGISTRY}.tmp" && mv "${PORT_REGISTRY}.tmp" "$PORT_REGISTRY"
        
        log_success "Port $port registered for $service"
    else
        log_warning "jq not available - using simple registration"
        echo "Port $port: $service ($(date))" >> "${PORT_REGISTRY}.simple"
    fi
}

# Unregister port
unregister_port() {
    local port=$1
    
    log_info "Unregistering port: $port"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would unregister port $port"
        return 0
    fi
    
    if [[ ! -f "$PORT_REGISTRY" ]]; then
        log_warning "Port registry not found"
        return 0
    fi
    
    if command -v jq >/dev/null 2>&1; then
        local timestamp
        timestamp=$(date -Iseconds)
        
        jq --arg port "$port" --arg ts "$timestamp" \
           'del(.ports[$port]) | .last_updated = $ts' \
           "$PORT_REGISTRY" > "${PORT_REGISTRY}.tmp" && mv "${PORT_REGISTRY}.tmp" "$PORT_REGISTRY"
        
        log_success "Port $port unregistered"
    else
        log_warning "jq not available - manual cleanup required"
    fi
}

# Kill process using port
kill_port_process() {
    local port=$1
    
    log_info "Killing process using port: $port"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would kill process on port $port"
        return 0
    fi
    
    # Get PID using lsof
    if command -v lsof >/dev/null 2>&1; then
        local pids
        pids=$(lsof -ti ":$port" 2>/dev/null || true)
        
        if [[ -n "$pids" ]]; then
            for pid in $pids; do
                log_info "Killing process PID: $pid"
                if kill "$pid" 2>/dev/null; then
                    log_success "Process $pid killed"
                else
                    log_warning "Failed to kill process $pid (may require sudo)"
                fi
            done
        else
            log_warning "No process found using port $port"
        fi
    else
        log_error "lsof not available - cannot kill process"
        return 1
    fi
}

# Show port status
show_port_status() {
    log_info "=== Port Usage Status ==="
    
    # Show active ports in development range
    log_info "Active ports in development range ($PORT_RANGE_START-$PORT_RANGE_END):"
    
    local active_ports=()
    for ((port=PORT_RANGE_START; port<=PORT_RANGE_END; port++)); do
        if ! is_port_available "$port"; then
            active_ports+=("$port")
        fi
    done
    
    if [[ ${#active_ports[@]} -eq 0 ]]; then
        log_info "No active ports found in range"
    else
        for port in "${active_ports[@]}"; do
            local process_info
            process_info=$(get_port_process "$port")
            log_info "  Port $port: $process_info"
        done
    fi
    
    # Show registered ports
    if [[ -f "$PORT_REGISTRY" ]] && command -v jq >/dev/null 2>&1; then
        log_info ""
        log_info "Registered ports:"
        jq -r '.ports | to_entries[] | "  Port \(.key): \(.value.service) (registered: \(.value.registered))"' "$PORT_REGISTRY" 2>/dev/null || log_info "  No registered ports"
    fi
    
    # Show reserved ports
    log_info ""
    log_info "Reserved ports: ${RESERVED_PORTS[*]}"
}

# Check specific port
check_port() {
    local port=$1
    
    log_info "Checking port: $port"
    
    if is_port_available "$port"; then
        log_success "Port $port is available"
        return 0
    else
        local process_info
        process_info=$(get_port_process "$port")
        log_warning "Port $port is in use by: $process_info"
        return 1
    fi
}

# Scan port range
scan_port_range() {
    local start_port=${1:-$PORT_RANGE_START}
    local end_port=${2:-$PORT_RANGE_END}
    
    log_info "Scanning port range: $start_port-$end_port"
    
    local used_count=0
    local available_count=0
    
    for ((port=start_port; port<=end_port; port++)); do
        if is_port_available "$port"; then
            ((available_count++))
        else
            ((used_count++))
            if [[ $used_count -le 10 ]]; then  # Limit output
                local process_info
                process_info=$(get_port_process "$port")
                log_info "  Port $port: $process_info"
            fi
        fi
    done
    
    log_info "Scan results:"
    log_info "  Available ports: $available_count"
    log_info "  Used ports: $used_count"
    
    if [[ $used_count -gt 10 ]]; then
        log_info "  (showing first 10 used ports only)"
    fi
}

# Cleanup stale registrations
cleanup_registry() {
    log_info "Cleaning up stale port registrations..."
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would cleanup stale registrations"
        return 0
    fi
    
    if [[ ! -f "$PORT_REGISTRY" ]] || ! command -v jq >/dev/null 2>&1; then
        log_warning "Registry cleanup requires jq and existing registry"
        return 0
    fi
    
    local cleaned_count=0
    local timestamp
    timestamp=$(date -Iseconds)
    
    # Get registered ports and check if they're still active
    while IFS= read -r port; do
        if is_port_available "$port"; then
            log_info "Removing stale registration for port: $port"
            jq --arg port "$port" --arg ts "$timestamp" \
               'del(.ports[$port]) | .last_updated = $ts' \
               "$PORT_REGISTRY" > "${PORT_REGISTRY}.tmp" && mv "${PORT_REGISTRY}.tmp" "$PORT_REGISTRY"
            ((cleaned_count++))
        fi
    done < <(jq -r '.ports | keys[]' "$PORT_REGISTRY" 2>/dev/null || true)
    
    log_success "Cleaned up $cleaned_count stale registrations"
}

# Manage firewall rules
manage_firewall() {
    local port=$1
    local action=${2:-"allow"}
    
    log_info "Managing firewall rule for port $port: $action"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "[DRY RUN] Would $action port $port in firewall"
        return 0
    fi
    
    # Check if ufw is available
    if command -v ufw >/dev/null 2>&1; then
        case "$action" in
            "allow")
                if sudo ufw allow "$port" 2>/dev/null; then
                    log_success "Firewall rule added: allow port $port"
                else
                    log_warning "Failed to add firewall rule (may require manual intervention)"
                fi
                ;;
            "deny"|"delete")
                if sudo ufw delete allow "$port" 2>/dev/null; then
                    log_success "Firewall rule removed: port $port"
                else
                    log_warning "Failed to remove firewall rule"
                fi
                ;;
        esac
    else
        log_warning "ufw not available - firewall management skipped"
    fi
}

# Execute action
execute_action() {
    case "$ACTION" in
        "status")
            show_port_status
            ;;
        "check")
            if [[ -z "$TARGET_PORT" ]]; then
                log_error "Port required for check action (--port PORT)"
                exit 1
            fi
            check_port "$TARGET_PORT"
            ;;
        "find")
            local available_port
            if available_port=$(find_available_port "$PORT_RANGE_START" "$PORT_RANGE_END"); then
                log_success "Next available port: $available_port"
                echo "$available_port"
            else
                log_error "No available ports in range $PORT_RANGE_START-$PORT_RANGE_END"
                exit 1
            fi
            ;;
        "register")
            if [[ -z "$TARGET_PORT" ]] || [[ -z "$SERVICE_NAME" ]]; then
                log_error "Port and service name required (--port PORT --service SERVICE)"
                exit 1
            fi
            register_port "$TARGET_PORT" "$SERVICE_NAME"
            ;;
        "unregister")
            if [[ -z "$TARGET_PORT" ]]; then
                log_error "Port required for unregister action (--port PORT)"
                exit 1
            fi
            unregister_port "$TARGET_PORT"
            ;;
        "kill")
            if [[ -z "$TARGET_PORT" ]]; then
                log_error "Port required for kill action (--port PORT)"
                exit 1
            fi
            kill_port_process "$TARGET_PORT"
            ;;
        "scan")
            scan_port_range "$PORT_RANGE_START" "$PORT_RANGE_END"
            ;;
        "cleanup")
            cleanup_registry
            ;;
        "firewall")
            if [[ -z "$TARGET_PORT" ]]; then
                log_error "Port required for firewall action (--port PORT)"
                exit 1
            fi
            manage_firewall "$TARGET_PORT" "allow"
            ;;
        *)
            log_error "Unknown action: $ACTION"
            log_error "Valid actions: status, check, find, register, unregister, kill, scan, cleanup, firewall"
            exit 1
            ;;
    esac
}

# Display summary
display_summary() {
    log_info "=== Port Manager Summary ==="
    log_info "Action: $ACTION"
    log_info "Target Port: ${TARGET_PORT:-"N/A"}"
    log_info "Service Name: ${SERVICE_NAME:-"N/A"}"
    log_info "Port Range: $PORT_RANGE_START-$PORT_RANGE_END"
    log_info "Registry: $PORT_REGISTRY"
    log_info ""
    
    log_info "=== Common Commands ==="
    log_info "Check port: $0 --action check --port 3000"
    log_info "Find available: $0 --action find"
    log_info "Register service: $0 --action register --port 3000 --service my-app"
    log_info "Kill process: $0 --action kill --port 3000"
    log_info "Show status: $0 --action status"
    
    log_info ""
    log_info "Log file: $LOG_FILE"
}

# Main execution function
main() {
    log_info "Starting port management..."
    log_info "Script: $SCRIPT_NAME"
    log_info "Dry run mode: $DRY_RUN"
    log_info "Action: $ACTION"
    
    check_prerequisites
    execute_action
    
    log_success "Port management completed successfully!"
    display_summary
}

# Execute main function
main "$@"